# Retend Clone —— Retend 的 clean-room 复刻

> **CLEAN-ROOM 声明**：本项目为依据功能需求描述（`intel/paid-list.md` 第 21 条
> "Retend"）从零独立编写的复刻实现。编写过程中未反编译原插件，未阅读、复制或
> 改写原插件的任何源代码、字节码或资源文件；仅依赖 Adobe After Effects 公开
> 脚本 API 与需求文档。与原产品的相似性仅来自功能需求本身。公开检索未获得
> 超出情报单一句核心描述的原品行为细节（aescripts 页有 Cloudflare 防护，
> 通用检索未收录有效细节），故行为模型按需求文档 + AE 公开机制自行设计，
> 差异见「三、已知限制」。

- 原品：Retend（Oleksandr Yukhno，aescripts，$29，jsx）
- 复刻：`main.jsx`（ExtendScript / ES3，单文件，UTF-8 带 BOM，约 890 行）
- 定位：一键重定时/延长整棵嵌套 precomp 树——改根 comp 时长时，同步处理
  整棵嵌套预合成树的 comp 时长、图层与关键帧。

---

## 一、功能对照表

### 已复刻

| 功能 | 说明 |
|------|------|
| 递归遍历 comp 依赖树 | 多选根 comp，DFS 收集全部嵌套子 comp（含根），`String(item.id)` 全局去重防环；列表按层级缩进预览整树 |
| 延长模式（Extend） | 树内每个 comp 的 `duration` 统一改为目标时长（帧对齐；只延长不截断：已 ≥ 目标的 comp 不动）；原贴合旧 comp 结尾的图层出点延长到目标时长；关键帧不动，动画结束后由 AE 原生 hold 语义冻结 |
| 重定时模式（Retime） | 每棵树按 f = 目标时长/根时长 等比缩放：comp `duration`、图层入出点、全部关键帧时间、已有时间重映射的键时间与键值、comp/图层标记时间、工作区全部乘 f；时间值对齐到帧 |
| 关键帧等比缩放 | 逐键删除重建：值/时间/插值类型/时间缓动/空间切线/roving/时间-空间自动贝塞尔/连续性逐键保留；同帧合并（保留前者）；MarkerValue/Shape/数组值按对象原样写回 |
| 时间重映射已存在的情况 | `timeRemapEnabled`（官方收录）探测 + `ADBE Time Remapping` matchName 定位；键时间与键值同乘 f（remap 值为源时间，子 comp 源时间轴已随树拉长）；属性树遍历以对象同一性跳过 remap，避免二次缩放 |
| 必要时写入时间重映射 | 可选"素材层同步变速"：对引用 footage 的层启用 timeRemap，清除自动键后写两个线性键（键时间×f、键值×f），画面随树同步变速；含音频层给警告（remap 不作用于音频） |
| comp/图层标记 | Retime 下标记时间等比缩放（层标记直接改 startTime 不删建；comp 标记按键缩放） |
| 工作区 | Retime 下 `workAreaStart`/`workAreaDuration` 等比缩放 |
| 帧对齐 | 所有新时间值 snap 到 `comp.frameDuration`，避免浮点漂移 |
| 入出点安全写入 | 中间态不允许入>出：放大先改出点、缩小先改入点 |
| 多选根 | 每棵树按各自根时长独立计算比例；跨树共享子 comp 先到先得（只处理一次） |
| 操作前确认对话框 | 执行前弹确认：模式/目标时长/影响 comp 清单（10 个截断）/已启用选项 |
| 撤销组 | `app.beginUndoGroup`/`endUndoGroup` try/finally，一次 Ctrl+Z 整体回滚 |
| 错误处理 | 逐 comp/逐层 try/catch；锁定层跳过并警告；结束弹窗汇总（comp 数/关键帧数/重映射数/警告前 8 条） |
| 设置记忆 | 模式/目标时长/选项经 `app.settings` 持久化（`getHavingSaved`+`getSetting` 两段式，失败静默降级） |
| ES3 兼容 | 无 let/const/箭头/模板串/JSON/ES5 数组方法；集合遍历用文档保证的 `numLayers`/`layer(i)` 1-based |

### 未复刻（与原品的差距）

| 功能 | 状态 | 说明 |
|------|------|------|
| 原品的精确内部策略 | 未核实 | 原品无公开技术细节可查（见 CLEAN-ROOM 声明），Extend/Retime 的边界语义（哪些图层延长、比例如何取整、remap 如何处理）为按需求文档自行设计，与原品的取舍可能不同 |
| 素材层 startTime/stretch 缩放 | 未做 | 保守不动：Retime 下素材层默认保持 1:1 推进（不随树变慢/变快）；需要同步变速请勾选"素材层同步变速"（写入时间重映射） |
| 表达式内时间值缩放 | 未做 | 表达式原样保留；表达式内写死的时间/帧号不随比例缩放 |
| 音频变速 | 未做 | 时间重映射不作用于音频；含音频层在"素材同步变速"时给出警告 |
| 原品 UI 布局/附加功能 | 未复刻 | 原品 UI 无公开细节，按需求文档自行设计 ScriptUI 面板 |

---

## 二、安装与使用

### 安装

两种方式任选：

1. **直接运行**：AE 菜单 `文件 > 脚本 > 运行脚本文件...`，选择 `main.jsx`。
2. **面板常驻**：把 `main.jsx` 复制到 AE 脚本目录
   - Windows: `C:\Program Files\Adobe\Adobe After Effects <版本>\Support Files\Scripts\ScriptUI Panels\`
   - macOS: `/Applications/Adobe After Effects <版本>/Scripts/ScriptUI Panels/`
   重启 AE 后在 `窗口` 菜单底部出现。

> 无需勾选"允许脚本写入文件与访问网络"也能运行（仅用 app.settings 记忆偏好；
> 未授权则偏好记忆静默失效，功能不受影响）。

### 使用步骤

1. 在**项目面板**选中 1 个或多个根 comp（要重定时/延长的合成）。
2. 运行脚本；顶部显示"已选 N 个根 comp，整树共 M 个 comp 将被修改"，
   列表按层级缩进预览整树。
3. 选模式（延长/重定时），输入目标时长（秒）。
4. 按需勾选："延长原贴合 comp 结尾的图层出点"（仅延长模式）；
   "素材层同步变速"（仅重定时模式）。
5. 点 **执行** → 确认对话框（模式/目标时长/影响 comp 清单）→ 执行。
6. 完成后弹窗汇总（comp 数/关键帧数/重映射数/警告）；一次 Ctrl+Z 可整体撤销。

### 两种模式的行为细节

**延长模式（Extend）**：

- 每个 comp 的 `duration` → 目标时长（帧对齐；只延长不截断：树内已 ≥ 目标的 comp 不动）
- 图层出点：出点 ≈ 旧 comp 时长（容差半帧）或更靠后的层 → 出点延长到目标时长；
  中途结束的层不动
- 关键帧/重映射/标记：不动。动画结束后 AE 原生 hold 冻结
- 校验：目标时长 < 根 comp 当前时长时拒绝执行（延长模式只能放大）

**重定时模式（Retime）**：

- 比例 f = 目标时长 / 根 comp 当前时长（每棵树独立计算）
- 全树等比：comp duration、图层入出点、全部关键帧时间、已有时间重映射键时间
  与键值、comp/图层标记、工作区
- 素材层默认画面照常 1:1 推进（不随树变速）；勾选"素材同步变速"后写入时间
  重映射同步变速
- 时间值全部对齐到帧

---

## 三、已知限制

1. **行为模型自行设计**：原品无公开技术细节（见 CLEAN-ROOM 声明），Extend/Retime
   的边界语义与原品可能不同。
2. **Extend 图层延长为启发式**：只延长"出点 ≈ 旧 comp 时长（容差半帧）或更靠后"
   的层；中途结束的层不动。
3. **Extend 不截断**：树内已 ≥ 目标时长的 comp 不动（不截短）。
4. **Retime 不缩放**：图层 `startTime`、`stretch`（播放速度百分比）；素材层默认
   保持 1:1 推进（可用"素材同步变速"选项写入重映射）。
5. **关键帧缩放 = 删除重建**：缩放后落在同一帧的键合并（保留前者，f 很小时同帧
   合并可能丢键）；极端情况下（删除或重建中途异常）属性可能处于半删状态——
   整个操作包在一次撤销组内，Ctrl+Z 可整体回滚。
6. **速查表未单列成员**：`ADBE Time Remapping` matchName 与 `CompItem.markerProperty`
   属官方指南收录但速查表未单列的成员，均按白名单规则包 try/catch；remap 定位
   失败时降级为普通属性处理（只缩放键时间不缩放键值）并警告。
7. **音频不变速**：时间重映射不作用于音频轨；含音频层在"素材同步变速"时给警告。
8. **表达式原样保留**：表达式内写死的时间/帧号不随比例缩放。
9. **跨树共享子 comp 先到先得**：多选根时，共享子 comp 按先遇到的树的参数处理一次。
10. **Extend 延长 footage 层出点后**：超出素材末尾的部分由 AE hold 最后一帧
    （视频）/保持静帧（图片）。
11. **层标记时间缩放**：直接改 startTime（不删建）；失败保留原时间并警告。
12. **静态自查完成，未做 AE 实机冒烟**（本机无 AE）。

---

## 四、自查结果（编写期已完成）

| 检查项 | 结果 |
|--------|------|
| `node --check`（剥离 `#target` 行后） | 通过 |
| ES3 特征扫描（let/const/箭头/模板串/JSON/ES5 数组方法/for-of/空值合并/可选链/class） | 干净（仅文档注释提及"无 let/const"字样） |
| `.indexOf(` / 尾逗号扫描 | 0 处 |
| 括号配平 | `{}` 307/307；`[]` 48/48；ASCII 圆括号差 8 来自注释序号"1)"等非语法内容，语法已由 node --check 验证 |
| 编码 | UTF-8 带 BOM（中文 Windows 下 ExtendScript 无 BOM 会按系统码页误读中文字符串） |
| API 名核对 | 全部 API 对照 `docs/api-cheatsheet.md` 白名单：PropertyValueType 枚举未用到；关键帧双接口 `keyInTemporalEase`/`keyOutTemporalEase`/`setTemporalEaseAtKey`、`removeKey`（勿用 deleteKey）、`setInterpolationTypeAtKey`、`setTemporalAutoBezierAtKey`、`setSpatialTangentsAtKey`、`setRovingAtKey`、`setSpatialAutoBezierAtKey`、`setTemporalContinuousAtKey` 均为官方收录或已登记的社区通行名（包 try/catch）；集合遍历 1-based `numLayers`/`layer(i)`；`app.settings` 两段式 |

> 说明：本机无 After Effects，以上为静态自查；建议按"使用步骤"在 AE 中做一次
> 冒烟测试（嵌套两层 comp + 带关键帧图层 + 已开时间重映射的层 + footage 层 +
> 层标记），对照修改前后各属性。

---

## 五、冒烟测试建议（AE 中）

1. 建 `Inner`（内含带关键帧的纯色层 0-3s）、`Mid`（引用 Inner + 文本层带关键帧）、
   `Main`（引用 Mid + 一层引用 footage 且带层标记 + 一层手动开时间重映射打两个键）。
2. 选中 `Main` → 运行脚本 → 预览应显示"整树共 3 个 comp"。
3. 延长模式 15 秒：三个 comp duration → 15s；贴边层出点 → 15s；动画 3s 后冻结；
   带 remap 层键不动、末尾冻结。
4. 重定时 6 秒（f=0.5）：三个 comp duration → 6s；全部关键帧时间×0.5；
   带 remap 层键时间×0.5 且键值×0.5；层标记×0.5。
5. 勾选"素材同步变速"重跑：footage 层出现 Time Remap 两键，画面随树变速。
6. 延长模式输入小于根时长的目标 → 应拒绝并提示改用重定时。
7. 一次 Ctrl+Z 整体回滚。

---

## 文件清单

```
clones/retend-clone/
├── main.jsx    # 复刻主体（单文件，UTF-8 带 BOM，ES3）
└── README.md   # 本文件
```

> 交付路径：`C:\Users\19894\ae-mission\clones\retend-clone\`
> （本 README 与 `main.jsx` 为任务沙箱内产出，由指挥会话搬运落位后即为最终交付。）
