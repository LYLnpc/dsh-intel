---
generated_at: 2026-11-14T08:18:00+08:00
task: clean-room 复刻 Rows and Columns（图层 R×C 网格排列 + 复制填充 + 循环排入），ExtendScript jsx；输入 = intel/paid-list.md 第 30 条功能性描述（[未核实] 条目，忽略价格），不反编译不参考原代码
---

# Rows and Columns Clone（图层网格排列 · clean-room 复刻）

- 产出：`main.jsx`（ExtendScript，ES3）
- 输入依据：`intel/paid-list.md` 第 30 条 Rows and Columns（[未核实] 条目，价格为未核实故本文件不含价格信息）的**功能性描述**："把选中图层按行/列网格排列：行列数、间距、对齐"
- 实现路线：纯函数网格布局（列内最大宽 / 行内最大高的紧凑栅格）+ `Layer.duplicate()` 复制填充；API 全部取自 `docs/api-cheatsheet.md` 白名单（`Layer.width/height`、`sourceRectAtTime(timeT, extents)`、`anchorPoint`、`duplicate()` 均 `[官方核实]`）

## CLEAN-ROOM 声明

1. 本复刻为清室实现：未反编译、未阅读、未复制 Rows and Columns 的任何原始代码；仅依据公开的功能性描述与 AE 公开脚本 API 从零编写。
2. 仅供学习研究；Rows and Columns 商标与著作权归原作者所有。

## 功能对照（复刻范围）

| Rows and Columns 功能点（paid-list 描述） | 本复刻状态 | 说明 |
|---|---|---|
| 按行/列网格排列 | ✅ 已复刻 | R×C 行主序填格，z 序不变（不移动图层顺序） |
| 行列数 | ✅ | R×C ≤ 200 上限 |
| 间距 | ✅ | 横/纵间距独立输入（格间空隙，按内容包围盒计） |
| 对齐 | ✅ | 两种：左上（网格左上角锚定第 1 格图层内容包围盒左上角）/ Comp 居中（网格整体居中） |
| 复制填充 | ✅ | 勾选后循环复制源图层铺满 R×C 格：1 个源 → 复制 R×C-1 份；N 个源 → 前 N 格用原图层，其余循环复制（副本命名 `<原名>_g<格号>`） |
| 循环排入 | ✅ | 复制填充关闭时：N 个源按行主序填前 min(N, R×C) 格，多余图层不动 |
| 随机化 | ❌ 未复刻 | paid-list 提及但不在本次基线 |
| 逐格延迟动画 | ❌ 未复刻 | 同上（可参考 autosway-clone/flow-clone 的偏移实现后续扩展） |
| 内容包围盒精度 | ✅（近似） | `sourceRectAtTime(time, false)` 官方接口（文本/形状/素材通用），失败回退 `layer.width/height`；旋转/缩放忽略（见限制） |

## 安装

`main.jsx` 放入 ScriptUI Panels 目录重启 AE 从 Window 菜单打开，或 `File > Scripts > Run Script File...` 直接运行。

## 使用

1. 选中 1 个以上图层；设置行/列/横间距/纵间距、对齐方式、是否复制填充。
2. 点 **Arrange 排列**：整批落位包在 undo 组内（try/finally），一次 Ctrl+Z 整体撤销；完成后自动选中参与排列的图层。
3. 防护语义：position 有关键帧的图层**跳过不破坏动画**；有父级的图层跳过（position 是父层坐标，直接写会错位）；空选 / R×C 超限弹窗拒绝。

## 自查记录（2026-11-14）

1. `node --check`：通过；ES3 扫描（排除注释行）：零命中。
2. **布局数学**：Node 从 main.jsx `RC-LAYOUT-START/END` 标记块**逐字提取** `rcComputeLayout` 执行，13 项断言 ALL PASS——3×3 等尺寸（相邻列中心距 110=100+10、gridW/H 精确）、混合尺寸（列宽=列内最大、行高=行内最大）、Comp 居中偏移、行主序定位（slot4=行1列1）、gap=0 无缝覆盖。
3. API 对照：本文件出现过的全部 API 名逐条核对 cheatsheet 白名单，无凭记忆书写项。

## 限制（如实说明）

1. **未在 AE 实机测试**；需实机验证：sourceRectAtTime 对文本/形状层的返回、duplicate 插入位置、分离维度 position 的 setValue 异常路径。
2. 旋转/缩放图层按未变换处理（布局用源尺寸+锚点偏移，忽略旋转/缩放对包围盒的影响）。
3. 有父级图层跳过不排（避免父层坐标系错位）；position 有关键帧的图层跳过（不破坏动画）。
4. 复制填充的副本会带原层全部效果/蒙版/表达式；z 序按"副本堆叠+索引升序"确定，与网格顺序无强绑定（不重排图层顺序）。
5. 随机化与逐格延迟动画未复刻（paid-list 提及的其余两项功能）。

## 交叉评审记录（review-4，2026-11-14）

- 表外 API 登记：`comp.time`（sourceRectAtTime 求值时刻）与 `Layer.duplicate()`（复制填充）均为速查表未列的官方 API，代码侧已包 try/catch，此处补登记；原 README 将 duplicate() 标为 [官方核实] 白名单项，实为"官方指南收录但速查表未列"，措辞已在此更正。
- 加固：ScriptUI PenType 着色两处包 try/catch（宿主异常不再崩面板）。
- 评审确认：undo 组为 try/catch + 组外 endUndoGroup（catch 不再抛出时等效 finally，可接受但建议后续改 try/finally）；`skipped` 语义、分离维度/父级/关键帧跳过路径均正确。
