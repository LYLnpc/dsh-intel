/*******************************************************************************
 * TwoBone IK Clone (RubberHose-style two-bone IK rig + hose bezier) - main.jsx
 * generated_at: 2026-11-14T07:28:00+08:00
 * task: clean-room 复刻 RubberHose/Limber 类两骨 IK 绑定核心功能
 *       （输入 = intel/paid-list.md #8 RubberHose 3 / #9 Limber 2 的功能性描述）
 *
 * CLEAN-ROOM 声明：
 * 1. 本脚本为清室（clean-room）独立实现。实现者未反编译、未阅读、未复制
 *    RubberHose（Battle Axe, $65）或 Limber（Mike Overbeck, $65）的任何原始
 *    代码；仅依据公开的功能性描述（"已知根/梢位置与肢体总长求膝点"、"两骨
 *    IK 软肢体 + 端点控制器"）与初中几何（余弦定理/law of cosines）从零编写。
 * 2. 数学核心（IK-CORE 块）：给定根关节 R、末端 E、两骨长 L1/L2，由余弦定理
 *    解出根关节处内角 A1 = acos((L1^2 + d^2 - L2^2) / (2*L1*d))，
 *    肘/膝位置 M = R + L1*[cos(θ + s*A1), sin(θ + s*A1)]，θ = atan2(dy, dx)。
 *    该公式块以字符串形式注入 AE 表达式，并由 Node 自查脚本逐字提取验证。
 * 3. 本脚本按 ES3 (ExtendScript) 编写：无 let/const/箭头函数/JSON.stringify。
 *
 * 装配约定（README 有完整说明）：
 *   - 选中 2 层：第 1 层 = 根关节层（髋/肩），第 2 层 = 末端控制层（脚/手）；
 *     图层锚点(Anchor Point)即关节位置（表达式用 toComp 换算，兼容父化）。
 *   - 生成 2 个 null 控制器："IKC: Upper"（上层旋转 = atan2+acos）与
 *     "IKC: Elbow"（肘/膝位置 = 余弦定理 + 下层旋转 = atan2），
 *     骨骼参数 L1/L2/弯向 Checkbox 挂在 IKC: Elbow 上。
 *   - 大腿/上肢 artwork 父化到 IKC: Upper，小腿/下肢 artwork 父化到 IKC: Elbow
 *     （artwork 旋转 0 时沿 +X 方向、锚点在关节）。
 *   - "IKC: Hose" 形状层：三点贝塞尔（根关节、肘、末端）近似软管弯曲，
 *     描边宽度由 "IKC: Thickness" Slider 驱动。
 ******************************************************************************/

(function (thisObj) {

    var SCRIPT_NAME = "TwoBone IK Clone";
    var SCRIPT_VER = "1.0.0";
    var P = "IKC:"; // 效果/图层命名前缀

    // >>> IK-CORE-START（两骨 IK 核心公式：Node 数学自查从本块逐字提取验证）
    var IK_CORE_LINES = [
        "var dx = E[0] - R[0];",
        "var dy = E[1] - R[1];",
        "var d = Math.sqrt(dx * dx + dy * dy);",
        "var dMax = L1 + L2;",
        "var dMin = Math.max(Math.abs(L1 - L2), 0.0001);",
        "var dc = Math.min(Math.max(d, dMin), dMax);",
        "var cosA = (L1 * L1 + dc * dc - L2 * L2) / (2 * L1 * dc);",
        "cosA = Math.min(1, Math.max(-1, cosA));",
        "var A1 = Math.acos(cosA);",
        "var th = Math.atan2(dy, dx);",
        "var ang = th + s * A1;"
    ];
    // <<< IK-CORE-END

    // ------------------------------------------------------------------
    // 小工具
    // ------------------------------------------------------------------
    function toNum(v, fallback) {
        var x = parseFloat(v);
        if (isNaN(x)) { return fallback; }
        return x;
    }

    function escName(n) {
        return ("" + n).replace(/"/g, "\\\"");
    }

    function ensureFx(layer, matchName, fxName, valuePropName, defaultValue) {
        var effects = layer.property("ADBE Effect Parade");
        var fx = null;
        var i;
        for (i = 1; i <= effects.numProperties; i++) {
            var p = effects.property(i);
            if (p.name === fxName) { fx = p; break; }
        }
        if (fx === null) {
            fx = effects.addProperty(matchName);
            fx.name = fxName;
            if (defaultValue !== null && defaultValue !== undefined) {
                fx.property(valuePropName).setValue(defaultValue);
            }
        }
        return fx;
    }

    function anchorOf(layer) { // 图层锚点的合成坐标（表达式用）；脚本端仅取 position 作近似
        return layer.property("ADBE Transform Group").property("ADBE Position").value;
    }

    // 把根/末层名写进肘关节 null 的 comment，供后续 Create Hose 读取
    function writeRigComment(elbowLayer, rootName, endName) {
        elbowLayer.comment = P + " root=" + rootName + ";end=" + endName;
    }

    function readRigComment(elbowLayer) {
        var c = "" + elbowLayer.comment;
        var rootName = "", endName = "";
        var parts = c.split(";");
        var i, kv;
        for (i = 0; i < parts.length; i++) {
            if (parts[i].indexOf("root=") === 0) { rootName = parts[i].substring(5); }
            if (parts[i].indexOf("end=") === 0) { endName = parts[i].substring(4); }
        }
        return { root: rootName, end: endName };
    }

    // ------------------------------------------------------------------
    // 表达式生成（全部 ES3 字符串拼接）
    // ------------------------------------------------------------------
    function coreCode() {
        return IK_CORE_LINES.join("\n");
    }

    // IKC: Upper 的旋转表达式：atan2 方向角 + acos 内角（含弯向符号）
    function buildUpperRotExpr(rootName, endName) {
        var L = [];
        L.push("// === TwoBone IK Clone (clean-room) v" + SCRIPT_VER + " : upper rotation ===");
        L.push("var elb = thisComp.layer(\"" + P + " Elbow\");");
        L.push("var L1 = elb.effect(\"" + P + " L1\")(\"Slider\");");
        L.push("var L2 = elb.effect(\"" + P + " L2\")(\"Slider\");");
        L.push("var s = (elb.effect(\"" + P + " Bend Flip\")(\"Checkbox\") == 1) ? -1 : 1;");
        L.push("var rl = thisComp.layer(\"" + escName(rootName) + "\");");
        L.push("var R = rl.toComp(rl.anchorPoint);");
        L.push("var el = thisComp.layer(\"" + escName(endName) + "\");");
        L.push("var E = el.toComp(el.anchorPoint);");
        L.push("if (L1 <= 0 || L2 <= 0) {");
        L.push("  Math.atan2(E[1] - R[1], E[0] - R[0]) * 180 / Math.PI;");
        L.push("} else {");
        L.push(coreCode());
        L.push("  ang * 180 / Math.PI;");
        L.push("}");
        return L.join("\n");
    }

    // IKC: Elbow 的位置表达式：余弦定理解肘/膝点（零除与可达域保护）
    function buildElbowPosExpr(rootName, endName) {
        var L = [];
        L.push("// === TwoBone IK Clone (clean-room) v" + SCRIPT_VER + " : elbow position ===");
        L.push("var L1 = Math.max(0.0001, effect(\"" + P + " L1\")(\"Slider\"));");
        L.push("var L2 = Math.max(0.0001, effect(\"" + P + " L2\")(\"Slider\"));");
        L.push("var s = (effect(\"" + P + " Bend Flip\")(\"Checkbox\") == 1) ? -1 : 1;");
        L.push("var rl = thisComp.layer(\"" + escName(rootName) + "\");");
        L.push("var R = rl.toComp(rl.anchorPoint);");
        L.push("var el = thisComp.layer(\"" + escName(endName) + "\");");
        L.push("var E = el.toComp(el.anchorPoint);");
        L.push(coreCode());
        L.push("[R[0] + L1 * Math.cos(ang), R[1] + L1 * Math.sin(ang)];");
        return L.join("\n");
    }

    // IKC: Elbow 的旋转表达式：下层骨骼指向末端（零向量保护）
    function buildLowerRotExpr(endName) {
        var L = [];
        L.push("// === TwoBone IK Clone (clean-room) v" + SCRIPT_VER + " : lower rotation ===");
        L.push("var el = thisComp.layer(\"" + escName(endName) + "\");");
        L.push("var E = el.toComp(el.anchorPoint);");
        L.push("var M = transform.position;");
        L.push("var dxE = E[0] - M[0];");
        L.push("var dyE = E[1] - M[1];");
        L.push("if (Math.abs(dxE) < 1e-9 && Math.abs(dyE) < 1e-9) {");
        L.push("  0;");
        L.push("} else {");
        L.push("  Math.atan2(dyE, dxE) * 180 / Math.PI;");
        L.push("}");
        return L.join("\n");
    }

    // Hose 形状层 Path 表达式：三点贝塞尔（根关节、肘、末端）
    function buildHosePathExpr(rootName, endName) {
        var L = [];
        L.push("// === TwoBone IK Clone (clean-room) v" + SCRIPT_VER + " : hose path ===");
        L.push("var rl = thisComp.layer(\"" + escName(rootName) + "\");");
        L.push("var el = thisComp.layer(\"" + escName(endName) + "\");");
        L.push("var elb = thisComp.layer(\"" + P + " Elbow\");");
        L.push("var R = rl.toComp(rl.anchorPoint);");
        L.push("var E = el.toComp(el.anchorPoint);");
        L.push("var M = elb.toComp(elb.anchorPoint);");
        L.push("var v1 = [M[0] - R[0], M[1] - R[1]];");
        L.push("var v2 = [E[0] - M[0], E[1] - M[1]];");
        L.push("var kEnd = 0.35;");   // 根/末段切线系数
        L.push("var kElb = 0.5;");    // 弯部切线系数（软管圆润度）
        L.push("var pts = [R, M, E];");
        L.push("var inT = [[0, 0], [-v1[0] * kElb, -v1[1] * kElb], [-v2[0] * kEnd, -v2[1] * kEnd]];");
        L.push("var outT = [[v1[0] * kEnd, v1[1] * kEnd], [v2[0] * kElb, v2[1] * kElb], [0, 0]];");
        L.push("createPath(points = pts, inTangents = inT, outTangents = outT, is_closed = false);");
        return L.join("\n");
    }

    // ------------------------------------------------------------------
    // 创建 IK / 创建 Hose / 移除
    // ------------------------------------------------------------------
    function findLayerByName(comp, name) {
        var i;
        for (i = 1; i <= comp.numLayers; i++) {
            if (comp.layer(i).name === name) { return comp.layer(i); }
        }
        return null;
    }

    function createIK(cfg) {
        if (app.project === null) { alert("没有打开的项目。"); return; }
        var comp = app.project.activeItem;
        if (comp === null || !(comp instanceof CompItem)) {
            alert("请先激活一个合成。"); return;
        }
        var sel = comp.selectedLayers;
        if (sel.length < 2) {
            alert("请先选中 2 个图层：第 1 个 = 根关节层（髋/肩），第 2 个 = 末端控制层（脚/手）。"); return;
        }
        var rootL = cfg.swap ? sel[1] : sel[0];
        var endL = cfg.swap ? sel[0] : sel[1];

        // 骨长：自动 = 0.6 × 当前根末距离（总长 1.2d，留弯曲余量）；手动用 UI 值
        var R0 = anchorOf(rootL);
        var E0 = anchorOf(endL);
        var d0 = Math.sqrt((E0[0] - R0[0]) * (E0[0] - R0[0]) + (E0[1] - R0[1]) * (E0[1] - R0[1]));
        var L1 = cfg.manual ? cfg.l1 : d0 * 0.6;
        var L2 = cfg.manual ? cfg.l2 : d0 * 0.6;

        app.beginUndoGroup("TwoBone IK Clone: Create IK");
        var upper = null, elbow = null;
        try {
            // 上层控制器 null：位置跟随根关节层锚点，旋转 = atan2 + acos
            upper = comp.layers.addNull();
            upper.name = P + " Upper";
            upper.property("ADBE Transform Group").property("ADBE Position").setValue(R0);
            upper.property("ADBE Transform Group").property("ADBE Rotation").expression =
                buildUpperRotExpr(rootL.name, endL.name);
            upper.property("ADBE Transform Group").property("ADBE Position").expression =
                "var rl = thisComp.layer(\"" + escName(rootL.name) + "\");\nrl.toComp(rl.anchorPoint);";

            // 肘/膝控制器 null：位置 = 余弦定理解点，旋转 = 下层角；骨骼参数挂这里
            elbow = comp.layers.addNull();
            elbow.name = P + " Elbow";
            elbow.property("ADBE Transform Group").property("ADBE Position").setValue([(R0[0] + E0[0]) / 2, (R0[1] + E0[1]) / 2]);
            ensureFx(elbow, "ADBE Slider Control", P + " L1", "Slider", L1);
            ensureFx(elbow, "ADBE Slider Control", P + " L2", "Slider", L2);
            ensureFx(elbow, "ADBE Checkbox Control", P + " Bend Flip", "Checkbox", cfg.bendFlip ? 1 : 0);
            elbow.property("ADBE Transform Group").property("ADBE Position").expression =
                buildElbowPosExpr(rootL.name, endL.name);
            elbow.property("ADBE Transform Group").property("ADBE Rotation").expression =
                buildLowerRotExpr(endL.name);

            writeRigComment(elbow, rootL.name, endL.name);
        } catch (e) {
            app.endUndoGroup();
            alert("创建 IK 失败: " + e.toString()); return;
        }
        app.endUndoGroup();

        alert("IK 已创建：\n  [" + P + " Upper] 位置跟随根关节层，旋转=上层骨角（atan2+acos）\n" +
            "  [" + P + " Elbow] 位置=肘/膝点（law of cosines），旋转=下层骨角；L1=" +
            Math.round(L1 * 100) / 100 + "  L2=" + Math.round(L2 * 100) / 100 + "\n" +
            "装配：大腿 artwork 父化到 " + P + " Upper，小腿 artwork 父化到 " + P + " Elbow" +
            "（artwork 旋转 0 时沿 +X、锚点在关节）。弯向用 Elbow 层的 [" + P + " Bend Flip] 切换。");
    }

    function createHose(cfg) {
        if (app.project === null) { alert("没有打开的项目。"); return; }
        var comp = app.project.activeItem;
        if (comp === null || !(comp instanceof CompItem)) {
            alert("请先激活一个合成。"); return;
        }
        var elbow = findLayerByName(comp, P + " Elbow");
        if (elbow === null) {
            alert("未找到 [" + P + " Elbow]。请先用 Create IK 生成绑定。"); return;
        }
        var rig = readRigComment(elbow);
        if (rig.root === "" || rig.end === "") {
            alert("[" + P + " Elbow] 的 comment 缺少根/末层名，请重新 Create IK。"); return;
        }

        app.beginUndoGroup("TwoBone IK Clone: Create Hose");
        try {
            var hose = comp.layers.addShape();
            hose.name = P + " Hose";
            ensureFx(hose, "ADBE Slider Control", P + " Thickness", "Slider", cfg.thickness);

            var contents = hose.property("ADBE Root Vectors Group");
            var group = contents.addProperty("ADBE Vector Shape - Group");
            group.name = "Hose Path";

            // 兼容不同 AE 版本的 Path matchName，逐个尝试
            var pathProp = null;
            var tries = ["ADBE Vector Shape - Path", "ADBE Vector Shape - Group"];
            var ti;
            for (ti = 0; ti < tries.length; ti++) {
                try {
                    var cand = group.property(tries[ti]);
                    if (cand !== null) { pathProp = cand; break; }
                } catch (e1) { /* 尝试下一个 */ }
            }
            if (pathProp === null) {
                pathProp = group.addProperty("ADBE Vector Shape - Path");
            }

            // 软管粗细
            var stroke = group.addProperty("ADBE Vector Graphic - Stroke");
            stroke.property("ADBE Vector Stroke Color").setValue([0.15, 0.15, 0.15]);
            stroke.property("ADBE Vector Stroke Line Cap").setValue(2);   // 圆头
            stroke.property("ADBE Vector Stroke Line Join").setValue(2);  // 圆角
            stroke.property("ADBE Vector Stroke Width").expression =
                "effect(\"" + P + " Thickness\")(\"Slider\");";

            pathProp.expression = buildHosePathExpr(rig.root, rig.end);
        } catch (e2) {
            app.endUndoGroup();
            alert("创建 Hose 失败: " + e2.toString() + "\n（IK 绑定不受影响；此功能需要 AE 15.0+ 的 createPath 表达式支持）"); return;
        }
        app.endUndoGroup();
        alert("Hose 已创建：三点贝塞尔（根关节→肘→末端），描边宽度用 [" + P + " Thickness] 调节。");
    }

    function removeRig() {
        if (app.project === null) { return; }
        var comp = app.project.activeItem;
        if (comp === null || !(comp instanceof CompItem)) {
            alert("请先激活一个合成。"); return;
        }
        app.beginUndoGroup("TwoBone IK Clone: Remove");
        var names = [P + " Upper", P + " Elbow", P + " Hose"];
        var removed = 0;
        var n, i, j;
        for (n = 0; n < names.length; n++) {
            for (i = comp.numLayers; i >= 1; i--) {
                if (comp.layer(i).name === names[n]) {
                    comp.layer(i).remove();
                    removed++;
                }
            }
        }
        app.endUndoGroup();
        alert("已移除 " + removed + " 个 [" + P + "] 图层（用户 artwork 不受影响，父化关系随 null 删除自动解除）。");
    }

    // ------------------------------------------------------------------
    // UI
    // ------------------------------------------------------------------
    function buildUI(thisObj) {
        var win = (thisObj instanceof Panel) ? thisObj : new Window("palette", SCRIPT_NAME, undefined, { resizeable: true });
        win.orientation = "column";
        win.alignChildren = ["fill", "top"];
        win.spacing = 6;
        win.margins = 12;

        win.add("statictext", undefined, SCRIPT_NAME + " v" + SCRIPT_VER + "（clean-room）");
        var tip = win.add("statictext", undefined, "先选根关节层，再加选末端控制层。");
        tip.graphics.foregroundColor = tip.graphics.newPen(win.graphics.PenType.SOLID_COLOR, [0.5, 0.5, 0.5], 1);

        var rowSel = win.add("group");
        rowSel.orientation = "row";
        var cbSwap = rowSel.add("checkbox", undefined, "交换根/末");
        cbSwap.value = false;

        var rowLen = win.add("group");
        rowLen.orientation = "row";
        rowLen.add("statictext", undefined, "骨长:");
        var ddLen = rowLen.add("dropdownlist", undefined, ["Auto 自动测量", "Manual 手动输入"]);
        ddLen.selection = 0;
        rowLen.add("statictext", undefined, " L1:");
        var etL1 = rowLen.add("edittext", undefined, "100");
        etL1.characters = 6;
        rowLen.add("statictext", undefined, " L2:");
        var etL2 = rowLen.add("edittext", undefined, "100");
        etL2.characters = 6;

        var rowDir = win.add("group");
        rowDir.orientation = "row";
        rowDir.alignChildren = ["left", "center"];
        var cbBend = rowDir.add("checkbox", undefined, "弯向翻转（肘/膝朝另一侧）");
        cbBend.value = false;
        rowDir.add("statictext", undefined, " 粗细:");
        var etTh = rowDir.add("edittext", undefined, "30");
        etTh.characters = 5;

        var gBtn = win.add("group");
        gBtn.orientation = "row";
        var btnIK = gBtn.add("button", undefined, "Create IK", { name: "ok" });
        var btnHose = gBtn.add("button", undefined, "Create Hose");
        var btnRm = gBtn.add("button", undefined, "Remove");

        var note = win.add("statictext", undefined, "ES3/ExtendScript；公式=law of cosines，Node 自查逐字一致。");
        note.graphics.foregroundColor = note.graphics.newPen(win.graphics.PenType.SOLID_COLOR, [0.5, 0.5, 0.5], 1);

        function collectCfg() {
            var manual = (ddLen.selection !== null && ddLen.selection.index === 1);
            return {
                swap: cbSwap.value,
                manual: manual,
                l1: Math.max(0.0001, toNum(etL1.text, 100)),
                l2: Math.max(0.0001, toNum(etL2.text, 100)),
                bendFlip: cbBend.value,
                thickness: Math.max(0.1, toNum(etTh.text, 30))
            };
        }

        btnIK.onClick = function () {
            try { createIK(collectCfg()); } catch (e) { alert("Create IK 失败: " + e.toString()); }
        };
        btnHose.onClick = function () {
            try { createHose(collectCfg()); } catch (e) { alert("Create Hose 失败: " + e.toString()); }
        };
        btnRm.onClick = function () {
            try { removeRig(); } catch (e) { alert("Remove 失败: " + e.toString()); }
        };

        win.layout.layout(true);
        if (win instanceof Window) {
            win.center();
            win.show();
        }
        return win;
    }

    buildUI(thisObj);

})(this);
