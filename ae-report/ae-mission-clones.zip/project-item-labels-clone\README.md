# Project Item Labels Clone

按项目项类型批量给 AE 项目面板的条目重设标签颜色（label index 1–16）。

- 版本：1.0.0｜文件：`main.jsx`｜类型：ScriptUI 面板

> **Clean-room 声明**：只依据公开的一句话功能描述「按项目项类型批量设置标签颜色（整理导入项目用）」和通用 AE Scripting API 知识独立实现。未获取或参考原商业化脚本的任何源码/安装包/资源。

---

## 一、对应原插件的功能

原商品（aescripts，$5.99 / NYOP，作者 Zack Lovatt）的用途：导入素材/工程后一键把「合成」「文件夹」「图片」「视频」「音频」「丢失素材」等分门别类上色，方便项目管理。

本复刻支持 9 类规则、16 种标签索引、可整项目递归或只处理选中项。

## 二、使用方式

1. `File > Scripts > Run Script File...` 选 `main.jsx`（或丢进 `Scripts/ScriptUI Panels/` 常驻）；
2. 左侧勾选框启用某类规则，右侧下拉选标签；
3. 选作用范围（整项目递归 / 仅选中项）；
4. `Apply Labels` → 顶部状态栏显示 `Scanned N, relabelled M, skipped K.`；
5. 一步 `Ctrl+Z` 可整体撤销。

## 三、类型判定规则（按优先级）

| 优先级 | 类别 | 判定条件 |
|---|---|---|
| 1 | Missing footage | `FootageItem.footageMissing === true` |
| 2 | Placeholders | `mainSource instanceof PlaceholderSource` |
| 3 | Solids | `mainSource instanceof SolidSource` |
| 4 | Compositions | `item instanceof CompItem` |
| 5 | Folders | `item instanceof FolderItem` |
| 6 | Still images | 文件扩展名 ∈ png/jpg/jpeg/gif/psd/psb/tif/tiff/bmp/tga/ai/pdf/exr/hdr/dpx |
| 7 | Video / sequences | 扩展名 ∈ mov/mp4/m4v/avi/mxf/wmv/webm/mkv/r3d/braw/flv/mpg/mpeg，**或**素材没有可用扩展名（按图像序列/视频处理） |
| 8 | Audio | 扩展名 ∈ wav/mp3/aif/aiff/m4a/aac/ogg/flac |
| 9 | Everything else | 以上都不匹配（默认不启用） |

先判「丢失」再判类型，是因为丢失素材的 `file` 路径可能还有扩展名，若不优先处理会被错标成图片/视频——这往往是用户最想一眼看到的一类。

## 四、能力限制（诚实说明）

1. **脚本只能写标签索引 1–16，读不到实际颜色值**。索引对应什么颜色完全取决于用户的 `AE 首选项 > 标签` 设置。面板下拉里的颜色名（Grey/Red/Yellow…）是按 AE 出厂预设写的参考名，用户改过首选项后名称会不准——遇到这种情况按索引理解即可。
2. **不做「自动猜分类」以外的智能**：不识别文件名关键字（如「_final」「_v2」），也不按文件夹名推断用途。
3. **不改图层标签**，只改项目面板条目。图层标签（`layer.label`）是另一套界面，本脚本未覆盖。
4. **递归只走 `app.project.rootFolder`**；不会处理「回收站」以外的特殊容器。若只用选中项模式，选中文件夹**不会**展开它内部的条目，只处理选中的那一个。
5. **没有预设保存/导出**：规则配置关闭面板即丢失，不写入磁盘。原商业版是否记忆偏好未公开，本复刻选择不落盘（避免污染用户配置）。
6. **无预览**：Apply 前看不到「哪些条目会变成什么色」。想预览就先用「仅选中项」小范围试。
7. 标签索引设 0 在部分 AE 版本上会报错/恢复默认，本脚本下拉不提供 0，避免误设。

## 五、API 使用核对（全部在白名单内）

- `app.project`、`app.project.rootFolder`、`app.project.selection`
- `FolderItem`：`numItems`、`item(i)`（1-based）
- `Item.label`（可读写，1–16）、`Item.name`
- `FootageItem`：`footageMissing`、`mainSource`、`file`
- `SolidSource` / `PlaceholderSource` 的 `instanceof` 判定
- `app.beginUndoGroup` / `app.endUndoGroup`
- ScriptUI：`Window`/`Panel`、`checkbox`、`dropdownlist`（`selection.index` 0-based、`onChange`）、`radiobutton`、`edittext` 未用、`statictext`、`button.onClick`

未调用白名单外 API。`item.file.name` 包在 try/catch 里（部分素材的 `file` 可能为 null 或抛异常）。

## 六、验收清单

1. 一个含 合成/文件夹/PNG/MOV/WAV/丢失素材 的项目 → 各类按规则上色，状态栏计数正确。
2. 只选中某个文件夹 + 「仅选中项」→ 只有该文件夹变色，内部条目不变。
3. 关闭某条规则 → 该类条目计数进 skipped，颜色不变。
4. 勾「Skip items already using that label」→ 第二次执行时 relabelled 应为 0。
5. `Reset Rules` → 恢复默认（Missing=红 2、Placeholder=12、Solid=13、Comp=9、Folder=1、Image=10、Video=11、Audio=8、Other=1 关闭）。
6. 撤销一次应全部回退。
7. 项目无素材时点 Apply → 不报错。

## 七、文件

```
clones/project-item-labels-clone/
├─ main.jsx
└─ README.md
```

静态检查：`node --check` 通过、ES3 扫描无命中、源码纯 ASCII、无 BOM。
