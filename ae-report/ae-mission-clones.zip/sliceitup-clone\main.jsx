/*******************************************************************************
 * Slice it Up Clone (grid slicing tool) - main.jsx
 * generated_at: 2026-11-14T08:30:00+08:00
 * task: clean-room 复刻 Slice it Up 2（aescripts, $29.99, renderTom）核心功能：
 *       图层按 R×C 网格无损切分为独立图层，支持 gap 与随机错位起步偏移
 *       （输入 = intel/paid-list.md 第 22 条的功能性描述，不反编译不抄原代码）
 *
 * CLEAN-ROOM 声明：
 * 1. 本脚本为清室（clean-room）独立实现。实现者未反编译、未阅读、未复制
 *    Slice it Up 2 的任何原始代码；仅依据公开的功能性描述（"程序化无损切分
 *    图层为 N×M 切片，支持 gap 与切片延迟动画参数"）与 AE 公开脚本 API
 *    （对照 docs/api-cheatsheet.md 白名单）从零编写。
 * 2. 实现路线（与原品实现方式无关）：对原图层逐格 Layer.duplicate()（官方
 *    文档化的同 comp 复制方法，anchor/position/效果/全部属性随副本保留），
 *    每个副本加一个矩形蒙版裁出对应格子。蒙版顶点在**源像素空间**（原点 =
 *    素材左上角），因此切片几何与图层自身的 anchor/position/旋转/缩放无关，
 *    副本与原图层天然原位重合。
 * 3. ES3 (ExtendScript) 编写：无 let/const/箭头函数/JSON.stringify。
 *    API 全部取自 docs/api-cheatsheet.md 白名单（[官方核实] 级）。
 *
 * 用法：File > Scripts > Run Script File... 或放入 ScriptUI Panels 目录。
 * 选中 1 个以上可视图层（图片/实拍/预合成/形状均可），设置行列/gap/随机偏移，
 * 点 Slice。
 ******************************************************************************/

(function (thisObj) {

    var SCRIPT_NAME = "Slice it Up Clone";
    var SCRIPT_VER = "1.0.0";
    var MAX_CELLS = 400; // R×C 上限，防失控

    // ------------------------------------------------------------------
    // 小工具（ES3）
    // ------------------------------------------------------------------
    function toInt(v, fallback, min) {
        var x = parseInt(v, 10);
        if (isNaN(x)) { x = fallback; }
        if (x < min) { x = min; }
        return x;
    }

    function toNum2(v, fallback, min) {
        var x = parseFloat(v);
        if (isNaN(x)) { x = fallback; }
        if (x < min) { x = min; }
        return x;
    }

    // 在图层上查找具名蒙版（防重复生成用）
    function findMaskByPrefix(layer, prefix) {
        var parade = null;
        try { parade = layer.property("ADBE Mask Parade"); } catch (e0) { parade = null; }
        if (parade === null) { return true; } // 无蒙版组（如摄像机层）视作已有
        var n = parade.numProperties;
        var i;
        for (i = 1; i <= n; i++) {
            var m = parade.property(i);
            if (m.name.indexOf(prefix) === 0) { return true; }
        }
        return false;
    }

    // 给图层加一个矩形蒙版（顶点在源像素空间：原点=素材左上角）
    function addRectMask(layer, name, l, t, r, b) {
        var parade = layer.property("ADBE Mask Parade");
        var mask = parade.addProperty("ADBE Mask Atom");
        try { mask.name = name; } catch (eN) { /* 命名失败不阻断 */ }
        var shapeProp = mask.property("ADBE Mask Shape");
        var sh = new Shape();
        sh.vertices = [[l, t], [r, t], [r, b], [l, b]];
        sh.inTangents = [[0, 0], [0, 0], [0, 0], [0, 0]];
        sh.outTangents = [[0, 0], [0, 0], [0, 0], [0, 0]];
        sh.closed = true;
        shapeProp.setValue(sh);
        try { mask.maskMode = MaskMode.ADD; } catch (eM) { /* 默认即为 Add */ }
        return mask;
    }

    // 可视图层判定：跳过摄像机/灯光（文本/形状层无 source 但可视，必须放行）
    function isVisualLayer(layer) {
        try {
            if (layer instanceof CameraLayer || layer instanceof LightLayer) { return false; }
        } catch (e1) { /* 类不可用则视为可视 */ }
        return true;
    }

    // ------------------------------------------------------------------
    // 核心：单层切片
    // ------------------------------------------------------------------
    function sliceOneLayer(comp, src, cfg, report) {
        var W = 0, H = 0;
        try { W = src.width; H = src.height; } catch (e0) { W = 0; H = 0; }
        if (!(W > 0) || !(H > 0)) {
            report.warnings.push("图层 [" + src.name + "] 无有效尺寸，跳过。");
            return;
        }
        if (findMaskByPrefix(src, "slice_")) {
            // 原层已有本工具生成的切片蒙版时不重复切（避免误切"切片成品"）
            report.warnings.push("图层 [" + src.name + "] 已含 slice_ 前缀蒙版，跳过（避免重复切片）。");
            return;
        }

        var R = cfg.rows, C = cfg.cols;
        var cellW = W / C;
        var cellH = H / R;
        var inset = cfg.gap / 2;
        var fd = 1 / 25;
        try { fd = 1 / comp.frameRate; } catch (eF) { fd = 1 / 25; }
        var tStart = comp.time;

        var r, c;
        for (r = 1; r <= R; r++) {
            for (c = 1; c <= C; c++) {
                // 源像素空间格子矩形。gap 只收缩"内侧边"（左右/上下相邻边各退
                // inset=gap/2，相邻块间隙=gap）；最外圈边贴齐原图层边界，保证
                // 全部切片的并集仍完整覆盖原画面。
                var l = (c - 1) * cellW + ((c > 1) ? inset : 0);
                var t = (r - 1) * cellH + ((r > 1) ? inset : 0);
                var rr = c * cellW - ((c < C) ? inset : 0);
                var bb = r * cellH - ((r < R) ? inset : 0);
                if (rr - l <= 1 || bb - t <= 1) {
                    report.warnings.push("格子 r" + r + "c" + c + " 因 gap 过大退化为空，跳过。");
                    continue;
                }

                // 复制图层（anchor/position/效果/属性全部随副本保留，原位重合）
                var dup = src.duplicate();
                var pieceName = src.name + "_r" + r + "c" + c;
                try { dup.name = pieceName; } catch (eN) { pieceName = dup.name; }

                // 矩形蒙版裁出该格
                try {
                    addRectMask(dup, "slice_r" + r + "c" + c, l, t, rr, bb);
                } catch (eMask) {
                    report.warnings.push("[" + pieceName + "] 蒙版创建失败：" + eMask.toString());
                    try { dup.remove(); } catch (eRm) { /* 移除失败保留现场 */ }
                    continue;
                }

                // 随机错位起步偏移：起步保持原位（Hold），到延迟点跳到随机偏移位
                if (cfg.doOffset) {
                    try {
                        var pos = dup.property("ADBE Transform Group").property("ADBE Position");
                        var basePos = pos.value;
                        var delay = ((r - 1) * C + (c - 1)) * cfg.staggerFrames * fd +
                                    Math.random() * cfg.staggerFrames * fd * 0.5;
                        var dx = (Math.random() * 2 - 1) * cfg.maxOffset;
                        var dy = (Math.random() * 2 - 1) * cfg.maxOffset;
                        // 逐维偏移：2D 位置 [x,y]，3D 位置 [x,y,z]（z 不动）
                        var newPos = [];
                        var di;
                        for (di = 0; di < basePos.length; di++) {
                            var add = 0;
                            if (di === 0) { add = dx; }
                            if (di === 1) { add = dy; }
                            newPos.push(basePos[di] + add);
                        }
                        var t1 = tStart;
                        var t2 = tStart + delay;
                        pos.setValueAtTime(t1, basePos);
                        pos.setValueAtTime(t2, (basePos.length > 1) ? newPos : (basePos[0] + dx));
                        var k1 = pos.nearestKeyIndex(t1);
                        var k2 = pos.nearestKeyIndex(t2);
                        try {
                            pos.setInterpolationTypeAtKey(k1, KeyframeInterpolationType.BEZIER, KeyframeInterpolationType.HOLD);
                        } catch (eI1) { /* 退化保留平滑 */ }
                    } catch (eOff) {
                        report.warnings.push("[" + pieceName + "] 偏移动画失败：" + eOff.toString());
                    }
                }

                report.pieces++;
                try { dup.selected = true; } catch (eSel) { /* 选中失败不阻断 */ }
            }
        }

        // 隐藏原层（副本已完整覆盖原画面）
        if (cfg.hideOriginal) {
            try { src.enabled = false; } catch (eH) { /* 保留原层可见 */ }
        }
    }

    // ------------------------------------------------------------------
    // 主流程
    // ------------------------------------------------------------------
    function doSlice(cfg) {
        if (app.project === null) { alert("没有打开的项目。"); return; }
        var comp = app.project.activeItem;
        if (comp === null || !(comp instanceof CompItem)) {
            alert("请先激活一个合成。"); return;
        }
        var sel = comp.selectedLayers;
        if (sel.length === 0) {
            alert("请先在时间线中选中至少 1 个可视图层（图片/实拍/预合成/形状/文本）。");
            return;
        }
        if (cfg.rows * cfg.cols > MAX_CELLS) {
            alert("行列乘积超过上限 " + MAX_CELLS + "（当前 " + cfg.rows + "×" + cfg.cols + "）。请减小行列数。");
            return;
        }

        app.beginUndoGroup("Slice it Up Clone: Slice");
        var report = { pieces: 0, warnings: [] };
        var i;
        try {
            for (i = 0; i < sel.length; i++) {
                var layer = sel[i];
                if (!isVisualLayer(layer)) {
                    report.warnings.push("图层 [" + layer.name + "] 是摄像机/灯光/音频层，跳过。");
                    continue;
                }
                sliceOneLayer(comp, layer, cfg, report);
            }
        } catch (e) {
            report.warnings.push("执行异常：" + e.toString());
        }
        app.endUndoGroup();

        var msg = "完成：生成 " + report.pieces + " 个切片图层。";
        if (report.warnings.length > 0) {
            var max = Math.min(report.warnings.length, 6);
            msg += "\n---- 警告 " + report.warnings.length + " 条 ----";
            for (var w = 0; w < max; w++) { msg += "\n" + report.warnings[w]; }
            if (report.warnings.length > max) { msg += "\n…… 其余从略"; }
        }
        alert(msg, SCRIPT_NAME);
    }

    // ------------------------------------------------------------------
    // UI（ScriptUI，可停靠）
    // ------------------------------------------------------------------
    function buildUI(thisObj) {
        var win = (thisObj instanceof Panel) ? thisObj : new Window("palette", SCRIPT_NAME, undefined, { resizeable: true });
        win.orientation = "column";
        win.alignChildren = ["fill", "top"];
        win.spacing = 6;
        win.margins = 12;

        win.add("statictext", undefined, SCRIPT_NAME + " v" + SCRIPT_VER + "（clean-room）");
        var tip = win.add("statictext", undefined, "选中可视图层，按 R×C 蒙版切片（原位保留）。");
        tip.graphics.foregroundColor = tip.graphics.newPen(win.graphics.PenType.SOLID_COLOR, [0.5, 0.5, 0.5], 1);

        var rowGrid = win.add("group");
        rowGrid.orientation = "row";
        rowGrid.add("statictext", undefined, "行数:");
        var etRows = rowGrid.add("edittext", undefined, "3");
        etRows.characters = 4;
        rowGrid.add("statictext", undefined, " 列数:");
        var etCols = rowGrid.add("edittext", undefined, "3");
        etCols.characters = 4;
        rowGrid.add("statictext", undefined, " gap(px):");
        var etGap = rowGrid.add("edittext", undefined, "0");
        etGap.characters = 5;

        var countText = win.add("statictext", undefined, "将生成 9 块");
        function updateCount() {
            var r = toInt(etRows.text, 3, 1);
            var c = toInt(etCols.text, 3, 1);
            countText.text = "将生成 " + (r * c) + " 块 × 选中图层数";
        }
        etRows.onChange = updateCount;
        etCols.onChange = updateCount;

        var cbOffset = win.add("checkbox", undefined, "随机错位起步偏移（Hold 跳变）");
        cbOffset.value = false;

        var rowOff = win.add("group");
        rowOff.orientation = "row";
        rowOff.add("statictext", undefined, "最大偏移(px):");
        var etMaxOff = rowOff.add("edittext", undefined, "40");
        etMaxOff.characters = 5;
        rowOff.add("statictext", undefined, " 间隔(帧/格):");
        var etStagger = rowOff.add("edittext", undefined, "2");
        etStagger.characters = 4;

        var cbHide = win.add("checkbox", undefined, "完成后隐藏原层");
        cbHide.value = true;

        var gBtn = win.add("group");
        gBtn.orientation = "row";
        var btnGo = gBtn.add("button", undefined, "Slice 切片", { name: "ok" });

        var note = win.add("statictext", undefined, "ES3；副本+矩形蒙版路线；蒙版顶点=源像素空间。");
        note.graphics.foregroundColor = note.graphics.newPen(win.graphics.PenType.SOLID_COLOR, [0.5, 0.5, 0.5], 1);

        btnGo.onClick = function () {
            try {
                doSlice({
                    rows: toInt(etRows.text, 3, 1),
                    cols: toInt(etCols.text, 3, 1),
                    gap: toNum2(etGap.text, 0, 0),
                    doOffset: cbOffset.value,
                    maxOffset: toNum2(etMaxOff.text, 40, 0),
                    staggerFrames: Math.max(0, toNum2(etStagger.text, 2, 0)),
                    hideOriginal: cbHide.value
                });
            } catch (e) {
                alert("Slice 失败: " + e.toString());
            }
        };

        win.layout.layout(true);
        if (win instanceof Window) {
            win.center();
            win.show();
        }
        return win;
    }

    buildUI(thisObj);

})(this);
