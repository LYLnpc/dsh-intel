#target aftereffects

/**************************************************************************
 * Easify 4 Clone (AE side)  v1.0.0  (ExtendScript .jsx for After Effects)
 * ------------------------------------------------------------------------
 * CLEAN-ROOM REIMPLEMENTATION NOTICE:
 * Written from scratch from the public feature table of the commercial
 * extension (easing presets, multi-property batch, cross-property
 * normalised easing, loops / offsets) plus general AE Scripting API
 * knowledge. No original source, installer, binary or resource of the
 * product was obtained, inspected or referenced.
 *
 * SCOPE (deliberate, see README):
 *   - After Effects only. The Premiere Pro side has no public keyframe
 *     API and is out of scope.
 *   - No interactive Speed Graph canvas (preset + numeric influence
 *     instead of a draggable curve editor).
 *   - No path easing, no composite curve stacking.
 * ------------------------------------------------------------------------
 * ES3 / ExtendScript only. ASCII-only source on purpose.
 *
 * NON-WHITELISTED APIs: none beyond the cheatsheet list, except
 * Prop.selectedKeys (0-based array of 1-based key indexes), which is in
 * the cheatsheet section 3.
 **************************************************************************/

(function easifyClone(thisObj) {

    var SCRIPT_NAME = "Easify Clone";
    var VERSION = "1.0.0";

    var KIT_LINEAR = KeyframeInterpolationType.LINEAR;
    var KIT_BEZIER = KeyframeInterpolationType.BEZIER;
    var KIT_HOLD = KeyframeInterpolationType.HOLD;

    /* ==================================================================
     *  Property discovery
     * ================================================================== */

    function getActiveComp() {
        if (!app.project) { return null; }
        var it = app.project.activeItem;
        if (!it || !(it instanceof CompItem)) { return null; }
        return it;
    }

    function isKeyedProp(p) {
        if (!p) { return false; }
        if (p.numKeys === undefined) { return false; }
        return p.numKeys > 0;
    }

    function asVals(v) {
        if (v instanceof Array) { return v; }
        return [v];
    }

    function dimOf(prop) {
        var vt = prop.propertyValueType;
        if (vt === PropertyValueType.TwoD) { return 2; }
        if (vt === PropertyValueType.TwoD_SPATIAL) { return 2; }
        if (vt === PropertyValueType.ThreeD) { return 3; }
        if (vt === PropertyValueType.ThreeD_SPATIAL) { return 3; }
        return 1;
    }

    function targetProps(comp) {
        var out = [];
        if (!comp) { return out; }
        var list = comp.selectedProperties;
        var i;
        for (i = 0; i < list.length; i++) {
            if (isKeyedProp(list[i])) { out.push(list[i]); }
        }
        return out;
    }

    // Selected key indexes of one property, sorted ascending; falls back to
    // every key when nothing is selected inside it.
    function targetKeys(prop, onlySelected) {
        var keys = [];
        var i;
        var sel = prop.selectedKeys;
        if (onlySelected && sel && sel.length > 0) {
            for (i = 0; i < sel.length; i++) { keys.push(sel[i]); }
        } else {
            for (i = 1; i <= prop.numKeys; i++) { keys.push(i); }
        }
        keys.sort(function (a, b) { return a - b; });
        return keys;
    }

    /* ==================================================================
     *  Ease writing
     * ================================================================== */

    // Average slope of the segment [a..b] per dimension. Keeps the motion
    // amplitude unchanged when only the influence is adjusted.
    function segSlope(prop, a, b, dim) {
        var dt = prop.keyTime(b) - prop.keyTime(a);
        var out = [];
        var d;
        if (dt <= 0) { dt = 0.0001; }
        var va = asVals(prop.keyValue(a));
        var vb = asVals(prop.keyValue(b));
        for (d = 0; d < dim; d++) {
            var x1 = (va[d] === undefined) ? 0 : va[d];
            var x2 = (vb[d] === undefined) ? 0 : vb[d];
            out.push((x2 - x1) / dt);
        }
        return out;
    }

    function makeEaseArray(dim, speeds, influence) {
        var arr = [];
        var d;
        for (d = 0; d < dim; d++) {
            arr.push(new KeyframeEase(speeds[d], influence));
        }
        return arr;
    }

    // Applies a two-sided influence pair to the segment between keys a and b.
    function easeSegment(prop, a, b, infStart, infEnd, flat) {
        var dim = dimOf(prop);
        var speeds = segSlope(prop, a, b, dim);
        if (flat) {
            var z = [];
            var d;
            for (d = 0; d < dim; d++) { z.push(0); }
            speeds = z;
        }

        // left key: only its OUT ease changes
        var inA = null;
        try { inA = prop.keyInTemporalEase(a); } catch (eA) { inA = null; }
        if (!inA) { inA = makeEaseArray(dim, speeds, 33.33); }
        prop.setTemporalEaseAtKey(a, inA, makeEaseArray(dim, speeds, infStart));
        prop.setInterpolationTypeAtKey(a, KIT_BEZIER, KIT_BEZIER);

        // right key: only its IN ease changes
        var outB = null;
        try { outB = prop.keyOutTemporalEase(b); } catch (eB) { outB = null; }
        if (!outB) { outB = makeEaseArray(dim, speeds, 33.33); }
        prop.setTemporalEaseAtKey(b, makeEaseArray(dim, speeds, infEnd), outB);
        prop.setInterpolationTypeAtKey(b, KIT_BEZIER, KIT_BEZIER);
    }

    /* ==================================================================
     *  Easing curve families (for bake-to-keys)
     * ================================================================== */

    function curveValue(fn, u) {
        var t = u;
        if (fn === "back") {
            var c1 = 1.70158;
            var c3 = c1 + 1;
            var p = t - 1;
            return 1 + c3 * p * p * p + c1 * p * p;
        }
        if (fn === "bounce") {
            if (t < 1 / 2.75) { return 7.5625 * t * t; }
            if (t < 2 / 2.75) {
                t -= 1.5 / 2.75;
                return 7.5625 * t * t + 0.75;
            }
            if (t < 2.5 / 2.75) {
                t -= 2.25 / 2.75;
                return 7.5625 * t * t + 0.9375;
            }
            t -= 2.625 / 2.75;
            return 7.5625 * t * t + 0.984375;
        }
        if (fn === "elastic") {
            if (t === 0) { return 0; }
            if (t === 1) { return 1; }
            var c4 = (2 * Math.PI) / 3;
            return Math.pow(2, -10 * t) * Math.sin((t * 10 - 0.75) * c4) + 1;
        }
        return t;
    }

    // Bakes a curve family into real keyframes across [a..b]; the segment
    // endpoints keep their exact values.
    function bakeSegment(prop, a, b, fnName, comp) {
        var tA = prop.keyTime(a);
        var tB = prop.keyTime(b);
        if (tB <= tA) { return 0; }

        // Refuse to bake over keys that already live inside the segment.
        if (b - a > 1) { return -1; }

        var vA = asVals(prop.keyValue(a));
        var vB = asVals(prop.keyValue(b));
        var fd = comp.frameDuration;
        var span = tB - tA;
        var steps = Math.max(2, Math.round(span / fd));
        var i;
        var d;
        var dim = vA.length;

        // Insert sampled keys (skip the first, it already exists).
        for (i = 1; i < steps; i++) {
            var u = i / steps;
            var f = curveValue(fnName, u);
            var vals = [];
            for (d = 0; d < dim; d++) {
                vals.push(vA[d] + (vB[d] - vA[d]) * f);
            }
            var t = tA + span * u;
            var v = (vals.length === 1) ? vals[0] : vals;
            prop.setValueAtTime(t, v);
        }

        // Every key in the baked range becomes linear.
        var lo = a;
        var hi = prop.numKeys;
        var k;
        for (k = lo; k <= hi; k++) {
            try {
                var kt = prop.keyTime(k);
                if (kt > tB + 0.0000005) { break; }
                if (kt >= tA - 0.0000005) {
                    prop.setInterpolationTypeAtKey(k, KIT_LINEAR, KIT_LINEAR);
                }
            } catch (eK) { /* skip unreadable key */ }
        }
        return steps - 1;
    }

    /* ==================================================================
     *  Key list helpers
     * ================================================================== */

    function snapshotKeys(prop) {
        var list = [];
        var k;
        for (k = 1; k <= prop.numKeys; k++) {
            list.push({ t: prop.keyTime(k), v: prop.keyValue(k) });
        }
        return list;
    }

    function clearKeys(prop) {
        var k;
        for (k = prop.numKeys; k >= 1; k--) {
            prop.removeKey(k);
        }
    }

    function writeBack(prop, list) {
        var i;
        for (i = 0; i < list.length; i++) {
            prop.setValueAtTime(list[i].t, list[i].v);
        }
    }

    /* ==================================================================
     *  Cross-property transfer (normalised time mapping)
     * ================================================================== */

    var syncSource = null;   // {prop, keys:[{u, inInf, outInf, v}]}

    function captureSource(comp) {
        var props = targetProps(comp);
        if (props.length === 0) {
            return { ok: false, message: "Select at least one animated property first." };
        }
        var src = props[0];
        var n = src.numKeys;
        if (n < 2) {
            return { ok: false, message: "The first selected property needs at least two keys." };
        }
        var t0 = src.keyTime(1);
        var t1 = src.keyTime(n);
        var span = t1 - t0;
        if (span <= 0) {
            return { ok: false, message: "Source keys all sit on the same time." };
        }
        var list = [];
        var k;
        var dim = dimOf(src);
        for (k = 1; k <= n; k++) {
            var inf = 33.33;
            var ouf = 33.33;
            try {
                var a = src.keyOutTemporalEase(k);
                if (a && a.length > 0) { ouf = a[0].influence; }
                var b = src.keyInTemporalEase(k);
                if (b && b.length > 0 && k > 1) { inf = b[0].influence; }
            } catch (eCapture) { /* keep defaults */ }
            list.push({ u: (src.keyTime(k) - t0) / span, inInf: inf, outInf: ouf });
        }
        syncSource = { prop: src, keys: list, dim: dim };
        return { ok: true, message: "Captured " + n + " keys from \"" + src.name + "\"." , count: n };
    }

    // Maps the captured curve onto every other selected property, stretched
    // to that property's own key span.
    function applySync(comp) {
        if (!syncSource) {
            return { ok: false, message: "No source captured yet - press \"Set source\" first." };
        }
        var props = targetProps(comp);
        var applied = 0;
        var skipped = 0;
        var i;

        var failMsgS = null;
        app.beginUndoGroup(SCRIPT_NAME + " - cross-property ease");
        try {
            for (i = 0; i < props.length; i++) {
                var p = props[i];
                if (p === syncSource.prop) { continue; }
                var n = p.numKeys;
                if (n < 2) { skipped++; continue; }

                var t0 = p.keyTime(1);
                var t1 = p.keyTime(n);
                var span = t1 - t0;
                if (span <= 0) { skipped++; continue; }

                // Stretch the source's u values onto this property's span.
                var m;
                var dim = dimOf(p);
                for (m = 0; m < syncSource.keys.length; m++) {
                    var s = syncSource.keys[m];
                    var t = t0 + s.u * span;

                    // Keep the target's own value at that time, just insert a
                    // key there so the ease has somewhere to live.
                    var v = null;
                    try { v = p.valueAtTime(t, false); } catch (eV) { v = null; }
                    if (v === null) { continue; }
                    p.setValueAtTime(t, v);
                }

                // Apply influences key by key on the freshly built keys.
                var kCount = p.numKeys;
                for (m = 1; m <= kCount; m++) {
                    var u = (p.keyTime(m) - t0) / span;
                    var src = nearestByU(syncSource.keys, u);
                    if (!src) { continue; }
                    var speeds = [];
                    var d;
                    for (d = 0; d < dim; d++) { speeds.push(0); }
                    var inArr = makeEaseArray(dim, speeds, clampInf(src.inInf));
                    var outArr = makeEaseArray(dim, speeds, clampInf(src.outInf));
                    try {
                        p.setTemporalEaseAtKey(m, inArr, outArr);
                        p.setInterpolationTypeAtKey(m, KIT_BEZIER, KIT_BEZIER);
                    } catch (eSet) { /* key type refuses ease */ }
                }
                applied++;
            }
        } catch (err) {
            failMsgS = err.toString();
        } finally {
            app.endUndoGroup();
        }
        if (failMsgS) {
            return { ok: false, message: "Sync failed: " + failMsgS };
        }

        var msg = "Synced " + applied + " propert" + (applied === 1 ? "y" : "ies") + ".";
        if (skipped > 0) { msg += " Skipped " + skipped + " (fewer than two keys)."; }
        return { ok: true, message: msg };
    }

    function clampInf(v) {
        if (v < 0.1) { return 0.1; }
        if (v > 100) { return 100; }
        return v;
    }

    function nearestByU(list, u) {
        var best = null;
        var bestD = 1e9;
        var i;
        for (i = 0; i < list.length; i++) {
            var d = list[i].u - u;
            if (d < 0) { d = -d; }
            if (d < bestD) { bestD = d; best = list[i]; }
        }
        return best;
    }

    /* ==================================================================
     *  Loops, offsets, align
     * ================================================================== */

    function loopProp(prop, mode, count) {
        var n = prop.numKeys;
        if (n < 2) { return false; }
        var tFirst = prop.keyTime(1);
        var tLast = prop.keyTime(n);
        var span = tLast - tFirst;
        if (span <= 0) { return false; }

        var base = snapshotKeys(prop);
        var c;
        var i;

        if (mode === "pingpong") {
            // Each pass mirrors the previous one, so the motion runs back
            // and forth with no jump at the turning points.
            for (c = 1; c <= count; c++) {
                var anchor = tLast + (c - 1) * span;
                for (i = 0; i < base.length; i++) {
                    var t = 2 * anchor - base[i].t;
                    if (t > tLast + c * span + 0.0000005) { continue; }
                    prop.setValueAtTime(t, base[i].v);
                }
            }
        } else {
            for (c = 1; c <= count; c++) {
                for (i = 0; i < base.length; i++) {
                    prop.setValueAtTime(base[i].t + c * span, base[i].v);
                }
            }
        }
        return true;
    }

    function offsetProp(prop, dt) {
        var list = snapshotKeys(prop);
        var i;
        for (i = 0; i < list.length; i++) { list[i].t += dt; }
        clearKeys(prop);
        writeBack(prop, list);
        return list.length;
    }

    function alignProp(prop) {
        var n = prop.numKeys;
        if (n < 3) { return 0; }
        var t0 = prop.keyTime(1);
        var t1 = prop.keyTime(n);
        var list = snapshotKeys(prop);
        var step = (t1 - t0) / (n - 1);
        var i;
        for (i = 0; i < list.length; i++) { list[i].t = t0 + step * i; }
        list[list.length - 1].t = t1;
        clearKeys(prop);
        writeBack(prop, list);
        return n;
    }

    /* ==================================================================
     *  Preset application
     * ================================================================== */

    var PRESETS = [
        { name: "AE default (33 / 33)", kind: "ease", a: 33.33, b: 33.33 },
        { name: "Ease In Out (67 / 67)", kind: "ease", a: 66.67, b: 66.67 },
        { name: "Ease Out - slow finish (0 / 67)", kind: "ease", a: 0.1, b: 66.67 },
        { name: "Ease In - slow start (67 / 0)", kind: "ease", a: 66.67, b: 0.1 },
        { name: "Maximum ease (100 / 100)", kind: "ease", a: 100, b: 100 },
        { name: "Linear", kind: "linear" },
        { name: "Back (overshoot, baked)", kind: "bake", fn: "back" },
        { name: "Bounce (baked)", kind: "bake", fn: "bounce" },
        { name: "Elastic (baked)", kind: "bake", fn: "elastic" }
    ];

    function applyPreset(comp, preset, onlySelected, flat) {
        var props = targetProps(comp);
        var totalProps = 0;
        var totalSegs = 0;
        var totalBaked = 0;
        var failed = 0;
        var i;

        if (props.length === 0) {
            return { ok: false, message: "Select keyframes in the timeline first." };
        }

        var failMsgP = null;
        app.beginUndoGroup(SCRIPT_NAME + " - " + preset.name);

        try {
            for (i = 0; i < props.length; i++) {
                var p = props[i];
                var keys = targetKeys(p, onlySelected);
                if (keys.length === 0) { continue; }
                totalProps++;

                var j;
                for (j = 0; j < keys.length; j++) {
                    var k = keys[j];
                    try {
                        if (preset.kind === "linear") {
                            p.setInterpolationTypeAtKey(k, KIT_LINEAR, KIT_LINEAR);
                            continue;
                        }
                        if (preset.kind === "bake") {
                            if (j + 1 < keys.length) {
                                var used = bakeSegment(p, k, keys[j + 1], preset.fn, comp);
                                if (used > 0) { totalBaked += used; totalSegs++; }
                            }
                            continue;
                        }
                        // ease: needs a following key to form a segment
                        if (j + 1 < keys.length) {
                            easeSegment(p, k, keys[j + 1], preset.a, preset.b, flat);
                            totalSegs++;
                        } else {
                            // lone key: make it bezier with symmetric handles
                            var dim = dimOf(p);
                            var z = [];
                            var d;
                            for (d = 0; d < dim; d++) { z.push(0); }
                            p.setInterpolationTypeAtKey(k, KIT_BEZIER, KIT_BEZIER);
                            p.setTemporalEaseAtKey(k,
                                makeEaseArray(dim, z, preset.a),
                                makeEaseArray(dim, z, preset.b));
                        }
                    } catch (errKey) {
                        failed++;
                    }
                }
            }
        } catch (err) {
            failMsgP = err.toString();
        } finally {
            app.endUndoGroup();
        }
        if (failMsgP) {
            return { ok: false, message: "Failed: " + failMsgP };
        }

        var msg = preset.name + ": " + totalProps + " propert" + (totalProps === 1 ? "y" : "ies") +
            ", " + totalSegs + " segment(s)";
        if (totalBaked > 0) { msg += ", " + totalBaked + " baked key(s)"; }
        if (failed > 0) { msg += ", " + failed + " skipped"; }
        return { ok: true, message: msg + "." };
    }

    /* ==================================================================
     *  UI
     * ================================================================== */

    function buildUI(thisObj) {
        var pal = (thisObj instanceof Panel) ? thisObj :
            new Window("palette", SCRIPT_NAME + " " + VERSION, undefined, { resizeable: true });
        pal.orientation = "column";
        pal.alignChildren = ["fill", "top"];
        pal.spacing = 8;
        pal.margins = 12;

        var head = pal.add("statictext", undefined,
            "Easing for keyframes: presets, cross-property sync, loops." +
            "\nAfter Effects only (no Premiere Pro panel).", { multiline: true });
        head.preferredSize.width = 340;

        var probe = pal.add("statictext", undefined, "Selection: -");
        probe.preferredSize.width = 340;

        var presetBox = pal.add("panel", undefined, "Preset");
        presetBox.orientation = "column";
        presetBox.alignChildren = ["left", "top"];
        presetBox.margins = 8;
        presetBox.spacing = 4;

        var ddPreset = presetBox.add("dropdownlist", undefined, []);
        var i;
        for (i = 0; i < PRESETS.length; i++) { ddPreset.add("item", PRESETS[i].name); }
        ddPreset.selection = 1;
        ddPreset.preferredSize.width = 300;

        var cbSelected = presetBox.add("checkbox", undefined, "Only selected keys (else every key)");
        cbSelected.value = true;
        var cbFlat = presetBox.add("checkbox", undefined, "Flat handles (speed = 0, classic AE)");
        cbFlat.value = false;

        var btnApply = presetBox.add("button", undefined, "Apply preset");
        btnApply.preferredSize.width = 140;

        var syncBox = pal.add("panel", undefined, "Cross-property sync");
        syncBox.orientation = "column";
        syncBox.alignChildren = ["left", "top"];
        syncBox.margins = 8;
        syncBox.spacing = 4;
        syncBox.add("statictext", undefined, "First selected property = source.");
        var syncRow = syncBox.add("group");
        var btnSetSrc = syncRow.add("button", undefined, "Set source");
        btnSetSrc.preferredSize.width = 100;
        var btnSync = syncRow.add("button", undefined, "Apply to others");
        btnSync.preferredSize.width = 120;

        var loopBox = pal.add("panel", undefined, "Loop / offset / align");
        loopBox.orientation = "column";
        loopBox.alignChildren = ["left", "top"];
        loopBox.margins = 8;
        loopBox.spacing = 4;

        var lr1 = loopBox.add("group");
        var ddLoop = lr1.add("dropdownlist", undefined, ["Ping-pong", "Repeat (offset)"]);
        ddLoop.selection = 0;
        ddLoop.preferredSize.width = 130;
        lr1.add("statictext", undefined, "times:");
        var edCount = lr1.add("edittext", undefined, "1");
        edCount.characters = 4;
        var btnLoop = lr1.add("button", undefined, "Loop");

        var lr2 = loopBox.add("group");
        lr2.add("statictext", undefined, "Shift by frames:");
        var edShift = lr2.add("edittext", undefined, "0");
        edShift.characters = 5;
        var btnShift = lr2.add("button", undefined, "Shift");

        var lr3 = loopBox.add("group");
        var btnAlign = lr3.add("button", undefined, "Distribute keys evenly");
        btnAlign.preferredSize.width = 180;

        var status = pal.add("statictext", undefined, "Ready.", { multiline: true });
        status.preferredSize.width = 340;

        function refresh() {
            var comp = getActiveComp();
            if (!comp) {
                probe.text = "Selection: (open a comp)";
                return;
            }
            var props = targetProps(comp);
            var keys = 0;
            var i2;
            for (i2 = 0; i2 < props.length; i2++) {
                keys += props[i2].selectedKeys ? props[i2].selectedKeys.length : 0;
            }
            probe.text = "Selection: " + props.length + " animated propert" +
                (props.length === 1 ? "y" : "ies") + ", " + keys + " selected key(s).";
        }

        btnApply.onClick = function () {
            var comp = getActiveComp();
            if (!comp) { status.text = "Open a composition first."; return; }
            var preset = PRESETS[ddPreset.selection.index];
            var res = applyPreset(comp, preset, cbSelected.value, cbFlat.value);
            status.text = res.message;
            refresh();
        };

        btnSetSrc.onClick = function () {
            var comp = getActiveComp();
            if (!comp) { status.text = "Open a composition first."; return; }
            var res = captureSource(comp);
            status.text = res.message;
        };

        btnSync.onClick = function () {
            var comp = getActiveComp();
            if (!comp) { status.text = "Open a composition first."; return; }
            var res = applySync(comp);
            status.text = res.message;
            refresh();
        };

        btnLoop.onClick = function () {
            var comp = getActiveComp();
            if (!comp) { status.text = "Open a composition first."; return; }
            var props = targetProps(comp);
            if (props.length === 0) { status.text = "Select keyed properties first."; return; }
            var count = parseInt(edCount.text, 10);
            if (isNaN(count) || count < 1 || count > 50) {
                status.text = "Times must be 1..50.";
                return;
            }
            var mode = (ddLoop.selection.index === 0) ? "pingpong" : "repeat";
            var done = 0;
            var i3;
            app.beginUndoGroup(SCRIPT_NAME + " - loop");
            try {
                for (i3 = 0; i3 < props.length; i3++) {
                    try {
                        if (loopProp(props[i3], mode, count)) { done++; }
                    } catch (eLoop) { /* skip this property */ }
                }
            } finally {
                app.endUndoGroup();
            }
            status.text = "Looped " + done + " propert" + (done === 1 ? "y" : "ies") +
                " (" + mode + " x" + count + ").";
            refresh();
        };

        btnShift.onClick = function () {
            var comp = getActiveComp();
            if (!comp) { status.text = "Open a composition first."; return; }
            var frames = parseFloat(edShift.text);
            if (isNaN(frames) || frames === 0) { status.text = "Enter a non-zero frame offset."; return; }
            var props = targetProps(comp);
            if (props.length === 0) { status.text = "Select keyed properties first."; return; }
            var dt = frames * comp.frameDuration;
            var moved = 0;
            var i4;
            app.beginUndoGroup(SCRIPT_NAME + " - shift keys");
            try {
                for (i4 = 0; i4 < props.length; i4++) {
                    try {
                        offsetProp(props[i4], dt);
                        moved++;
                    } catch (eShift) { /* skip */ }
                }
            } finally {
                app.endUndoGroup();
            }
            status.text = "Shifted keys on " + moved + " propert" + (moved === 1 ? "y" : "ies") + ".";
            refresh();
        };

        btnAlign.onClick = function () {
            var comp = getActiveComp();
            if (!comp) { status.text = "Open a composition first."; return; }
            var props = targetProps(comp);
            if (props.length === 0) { status.text = "Select keyed properties first."; return; }
            var aligned = 0;
            var i5;
            app.beginUndoGroup(SCRIPT_NAME + " - align keys");
            try {
                for (i5 = 0; i5 < props.length; i5++) {
                    if (alignProp(props[i5]) > 0) { aligned++; }
                }
            } finally {
                app.endUndoGroup();
            }
            status.text = "Distributed keys on " + aligned + " propert" + (aligned === 1 ? "y" : "ies") + ".";
            refresh();
        };

        pal.onResizing = pal.onResize = function () { this.layout.resize(); };

        refresh();
        return pal;
    }

    var ui = buildUI(thisObj);
    if (ui instanceof Window) {
        ui.center();
        ui.show();
    } else {
        ui.layout.layout(true);
    }

})(this);
