---
generated_at: 2026-11-14T08:42:00+08:00
task: clean-room 复刻 Slice it Up 2（图层 R×C 网格切片 + gap + 随机错位偏移），ExtendScript jsx；输入 = intel/paid-list.md 第 22 条功能性描述，不反编译不参考原代码
---

# Slice it Up Clone（图层网格切片 · clean-room 复刻）

- 产出：`main.jsx`（ExtendScript，ES3）
- 输入依据：`intel/paid-list.md` 第 22 条 Slice it Up 2（aescripts，$29.99，renderTom）的**功能性描述**："程序化无损切分图层为 N×M 切片，支持 gap 与切片延迟动画参数"
- 实现路线：**副本 + 矩形蒙版**（`Layer.duplicate()` + 每副本一个矩形蒙版裁格），与原品实现方式无关；API 全部取自 `docs/api-cheatsheet.md` 白名单（`[官方核实]` 级）

## CLEAN-ROOM 声明

1. 本复刻为清室实现：未反编译、未阅读、未复制 Slice it Up 2 的任何原始代码；仅依据公开的功能性描述与 AE 公开脚本 API 从零编写。
2. 仅供学习研究；Slice it Up 2 商标与著作权归原作者所有，需要完整功能（圆角、蒙版切片模式等）请购买正版。

## 功能对照（复刻范围）

| Slice it Up 2 功能点（paid-list 描述） | 本复刻状态 | 说明 |
|---|---|---|
| 图层程序化无损切分为 N×M 切片 | ✅ 已复刻 | R×C 网格；每格生成一个**完整副本图层** + 一个矩形蒙版裁格，原图层保留（可一键隐藏） |
| gap（块间间隙） | ✅ 已复刻 | 蒙版内侧边各内缩 gap/2，相邻块间隙 = gap；**最外圈边贴齐原图层边界**，全部切片并集仍完整覆盖原画面（Node 数学自查验证） |
| 切片延迟动画参数 | ✅ 变体复刻 | "随机错位起步偏移"：每块 position 打 2 键（起步=原位 Hold，延迟点跳到随机偏移位），延迟按格序递增（行主序）+ 随机抖动，形成错位起步 |
| 圆角切片 | ❌ 未复刻 | 矩形蒙版路线暂无圆角（Shape 顶点加圆弧切线可后续扩展） |
| 切分"蒙版"（对已有蒙版切分） | ❌ 未复刻 | 本路线切整层；源层已有蒙版时切片=蒙版并集∩格子（多蒙版合并语义），效果可能偏离预期 |
| 按行列命名 | ✅ | `<原层名>_r行c列`（如 `bg_r1c2`）；若原层名为 `piece` 则与示例 `piece_r1c2` 一致 |
| 原位保留 | ✅ | 副本由 `duplicate()` 生成，anchor/position/旋转/缩放/效果/全部属性随副本，蒙版在源像素空间裁切，与图层变换无关，切片与原图层天然重合 |

## 安装

1. `main.jsx` 放入 `C:\Program Files\Adobe\Adobe After Effects <版本>\Support Files\Scripts\ScriptUI Panels\`（重启 AE，Window 菜单打开，可停靠）；
2. 或 `File > Scripts > Run Script File...` 直接运行（浮动面板）。

## 使用

1. 时间线选中 1 个以上可视图层（图片/实拍/预合成/形状/文本均可；摄像机/灯光自动跳过）。
2. 面板设置：行数、列数、gap(px)、随机偏移（可选：最大偏移 px、每格间隔帧数）、是否隐藏原层。
3. 点 **Slice 切片**：整批生成包在 undo 组内，一次 Ctrl+Z 可整体撤销；切片完成后自动选中全部切片层。
4. 命名规则：`<原层名>_r行c列`，行主序（r 外层、c 内层）。
5. 已含 `slice_` 前缀蒙版的图层会被跳过（防止把切片成品再切一遍）；要重新切请先删除切片层。

### 随机偏移动画说明

勾选后每块生成两个 position 关键帧：`t1=当前时间`（原位置，出方向 **HOLD**）→ `t2=当前时间+延迟`（原位置±随机偏移）。延迟 = `(r-1)×列数 + (c-1) 每格间隔帧数` + 半格随机抖动，播放时呈逐格跳出的错位感。偏移向量逐维随机（3D 层 z 不偏移）。随机数每次执行不同，想要固定布局请用 gap=0 + 不勾偏移。

## 自查记录（2026-11-14）

1. `node --check`：通过（复制为 .js 检查）。
2. ES3 扫描（排除注释行）：`let/const/箭头函数/JSON.stringify/模板串/forEach/map/filter/includes/trim/for-of` 零命中。
3. 网格几何 Node 验证：gap=0 时 3×3 格无缝精确覆盖；gap=10 时相邻块水平/垂直间隙精确 =10、最外圈贴齐原图层边界（并集完整覆盖）；所有格子非退化。
4. API 白名单对照：`Layer.duplicate()`、`ADBE Mask Parade` / `ADBE Mask Atom` / `ADBE Mask Shape`、`new Shape()` + `vertices/inTangents/outTangents/closed`、`maskMode`/`MaskMode.ADD`、`setValueAtTime`/`nearestKeyIndex`/`setInterpolationTypeAtKey`/`KeyframeInterpolationType.HOLD`、`layer.remove()`、`comp.time`、`frameRate` 均为 `[官方核实]` 条目（docs/api-cheatsheet.md）。
5. 逻辑自查修复 2 处：文本/形状层被误判非可视（改为仅排除摄像机/灯光）；随机偏移对 3D 位置逐维处理（z 不动）。

## 限制（如实说明）

1. **未在 AE 实机测试**：本环境无 After Effects。语法/ES3/几何数学已验证；需实机验证的点：`ADBE Mask Atom` 加蒙版与 Shape 赋值行为、duplicate 后蒙版命名、HOLD 插值视觉效果、`ADBE Mask Parade` 在形状/文本层上的表现。
2. **源层已有蒙版**：切片=原蒙版并集∩格子（AE 多蒙版默认相加语义），与原品"切分蒙版"模式不等价；README 不建议对带蒙版层使用。
3. **分离维度位置**：若原层 position 已用 Separate Dimensions，偏移写入会失败并计入警告（可先合并维度再切片）。
4. **原层有 position 动画时**：偏移键会插入到既有动画曲线中间（HOLD 只作用于本工具新键），建议对静态层使用偏移动画。
5. **上限**：单次行列乘积 ≤400（20×20），防误操作生成失控图层量；大网格下逐层 duplicate+蒙版较慢属预期。
6. **圆角未实现**；切片层均为"完整副本+蒙版"，工程体积随块数线性增长（无损路线的代价，换自由度）。
7. 本工具生成的蒙版名以 `slice_` 前缀标识，再次对该源层运行会被跳过（防连锁误切）。
