﻿#target aftereffects
/**
 * ============================================================================
 *  Retend Clone —— Retend 的 clean-room 复刻实现
 * ============================================================================
 *
 *  [交付落位] 本文件的目标绝对路径为：
 *    C:\Users\19894\ae-mission\clones\retend-clone\main.jsx
 *  因任务会话沙箱越界写受限，暂存于任务工作区 out\retend-clone\main.jsx，
 *  由指挥会话搬运落位（内容即最终版）。
 *
 *  [CLEAN-ROOM 声明]
 *  本脚本依据功能需求描述（intel/paid-list.md 第 21 条 "Retend"：一键重定时/
 *  延长整棵嵌套 precomp 树）从零独立编写。编写过程中未反编译原插件，未阅读、
 *  复制或改写原插件的任何源代码、字节码或资源文件；仅依赖 Adobe After Effects
 *  公开脚本 API（After Effects Scripting Guide，API 名以 docs/api-cheatsheet.md
 *  白名单为准）与需求文档。与原产品的相似性仅来自功能需求本身。
 *
 *  功能概述：
 *    - 递归遍历选中 comp 的整棵嵌套 precomp 依赖树（含根；支持多选；去重防环）；
 *    - 延长模式（Extend）：树内每个 comp 时长统一改为目标时长（只延长不截断）；
 *      原贴合旧 comp 结尾的图层出点随之延长；关键帧不动——动画结束后由 AE 原生
 *      hold 语义停在最后一帧；
 *    - 重定时模式（Retime）：整棵树按同一比例缩放到目标时长——comp 时长、图层
 *      入出点、全部关键帧时间、已有时间重映射的键时间与键值、comp/图层标记时间、
 *      工作区均按比例缩放；可选给素材层写入时间重映射实现同步变速；
 *    - 所有新时间值对齐到帧；执行前有确认对话框；整个操作包在一次撤销组内；
 *      逐 comp/逐层/逐键 try/catch，单点失败不中断整树，结束弹出警告汇总。
 *
 *  实现要点：
 *    - 关键帧缩放 = 收集（时间/值/插值/时间缓动/空间切线/roving/各开关）→
 *      倒序 removeKey → 按缩放后时间逐键重建。官方指南唯一收录的删除方法为
 *      Property.removeKey（勿用 deleteKey）；缩放后落在同一帧的键合并（保留前者）。
 *    - 已有时间重映射的图层：layer.timeRemapEnabled 探测 + matchName
 *      "ADBE Time Remapping"（指南未收录，已按白名单规则包 try/catch）定位
 *      remap 属性，缩放其键时间与键值（remap 值 = 源时间，须随树同步缩放）；
 *      属性树遍历中以对象同一性（===）跳过该属性，避免二次缩放。
 *    - ExtendScript / ES3 兼容：无 let/const/箭头函数/JSON/ES5 数组方法。
 *
 *  兼容环境：After Effects（脚本引擎 ExtendScript），
 *  File > Scripts > Run Script File 或放入 ScriptUI Panels 目录。
 * ============================================================================
 */

(function () {

    var SCRIPT_NAME = "Retend Clone";
    var SCRIPT_VERSION = "1.0.0";
    var SETTINGS_SECTION = "retendClone";
    var KEY_MODE = "mode";              // "extend" | "retime"
    var KEY_TARGET = "targetDur";       // 目标时长（秒，字符串存储）
    var KEY_EDGE = "extendEdgeLayers";  // "1"/"0"
    var KEY_SYNC = "syncFootageSpeed";  // "1"/"0"

    var MODE_EXTEND = "extend";
    var MODE_RETIME = "retime";

    /* ======================================================================
     *  基础工具（ES3）
     * ==================================================================== */

    function errText(e) {
        var s = "未知错误";
        try {
            if (e != null && e.message != null && e.message !== "") {
                s = e.message;
            } else if (e != null) {
                s = e.toString();
            }
        } catch (e2) {
            s = "未知错误";
        }
        return s;
    }

    function nameSafe(obj) {
        var s = "?";
        try {
            if (obj != null && obj.name != null) s = obj.name;
        } catch (e0) {
            s = "?";
        }
        return s;
    }

    function approxEq(a, b) {
        return Math.abs(a - b) < 0.000001;
    }

    // 时间对齐到帧（fd = comp.frameDuration；fd 无效时原样返回）
    function snapTime(t, fd) {
        if (!(fd > 0)) return t;
        return Math.round(t / fd) * fd;
    }

    /* ======================================================================
     *  设置持久化（app.settings 两段式读取，失败静默降级）
     * ==================================================================== */

    function loadSetting(key, fallback) {
        // 官方指南：getHavingSaved 返回布尔（是否已保存），getSetting 读值
        // （缺失时抛异常）。两段式读取，失败静默降级为 fallback。
        try {
            if (app.settings.getHavingSaved(SETTINGS_SECTION, key)) {
                return app.settings.getSetting(SETTINGS_SECTION, key);
            }
        } catch (e1) {
            // 未保存或读取失败 → fallback
        }
        return fallback;
    }

    function saveSetting(key, value) {
        try {
            app.settings.saveSetting(SETTINGS_SECTION, key, value);
        } catch (e1) {}
        try {
            app.settings.saveToDisk();
        } catch (e2) {}
    }

    /* ======================================================================
     *  项目扫描与依赖树收集
     * ==================================================================== */

    function getSelectedComps() {
        var out = [];
        try {
            var sel = app.project.selection;
            if (sel != null) {
                for (var i = 0; i < sel.length; i++) {
                    if (sel[i] instanceof CompItem) out.push(sel[i]);
                }
            }
        } catch (e0) {}
        return out;
    }

    // 单个 comp 的直接子 comp：AVLayer 且 source 为 CompItem
    // （文本/形状/空对象/摄像机/灯光无 source，camera/light 的 source 为 null）
    function compDirectChildComps(comp) {
        var comps = [];
        var n = 0;
        try { n = comp.numLayers; } catch (e0) { n = 0; }
        for (var i = 1; i <= n; i++) {
            var lay = null;
            try { lay = comp.layer(i); } catch (e1) { lay = null; }
            if (lay == null) continue;
            var src = null;
            try { src = lay.source; } catch (e2) { src = null; }
            if (src != null && src instanceof CompItem) comps.push(src);
        }
        return comps;
    }

    // 多根 DFS 收树：返回 { trees: [{root, entries: [{comp, depth}]}], warnings: [] }
    // 以 String(item.id) 全局去重防环；跨树共享的子 comp 先到先得（按根的
    // 选择顺序），后遇到的树不再重复处理（与第一棵树共用同一次修改）。
    function collectTrees(rootComps) {
        var seen = {};
        var trees = [];
        var warnings = [];

        function visit(comp, depth, list) {
            var cid = String(comp.id);
            if (seen[cid]) return;
            seen[cid] = true;
            list.push({ comp: comp, depth: depth });
            var kids = compDirectChildComps(comp);
            for (var i = 0; i < kids.length; i++) {
                visit(kids[i], depth + 1, list);
            }
        }

        for (var r = 0; r < rootComps.length; r++) {
            var root = rootComps[r];
            var rid = String(root.id);
            if (seen[rid]) {
                warnings.push("根 comp「" + root.name + "」已包含在先前的树中，该树不再重复处理。");
                continue;
            }
            var list = [];
            visit(root, 0, list);
            trees.push({ root: root, entries: list });
        }
        return { trees: trees, warnings: warnings };
    }

    /* ======================================================================
     *  关键帧收集与缩放（重定时模式核心）
     * ==================================================================== */

    // 读取单个键的全部可保留数据；时间或值读不到时返回 null（整属性放弃）
    function readKeyData(prop, i) {
        var k = {};
        try { k.t = prop.keyTime(i); } catch (e0) { return null; }
        try { k.v = prop.keyValue(i); } catch (e1) { return null; }
        try { k.inI = prop.keyInInterpolationType(i); } catch (e2) { k.inI = null; }
        try { k.outI = prop.keyOutInterpolationType(i); } catch (e3) { k.outI = null; }
        try { k.inE = prop.keyInTemporalEase(i); } catch (e4) { k.inE = null; }
        try { k.outE = prop.keyOutTemporalEase(i); } catch (e5) { k.outE = null; }
        try { k.tAB = prop.keyTemporalAutoBezier(i); } catch (e6) { k.tAB = false; }
        try { k.tC = prop.keyTemporalContinuous(i); } catch (e7) { k.tC = false; }
        try { k.sAB = prop.keySpatialAutoBezier(i); } catch (e8) { k.sAB = false; }
        try { k.sC = prop.keySpatialContinuous(i); } catch (e9) { k.sC = false; }
        try { k.rov = prop.keyRoving(i); } catch (e10) { k.rov = false; }
        try { k.inT = prop.keyInSpatialTangent(i); } catch (e11) { k.inT = null; }
        try { k.outT = prop.keyOutSpatialTangent(i); } catch (e12) { k.outT = null; }
        return k;
    }

    // 缩放一个带键属性的全部关键帧。
    // scaleValues = true 时键值同乘 f（仅时间重映射属性：remap 值为源时间）；
    // 其余属性只缩放键时间，值不动（MarkerValue/Shape/数组值按对象引用原样写回）。
    // 返回 { keys: 成功重建键数（-1 = 属性不可读，未做任何改动）, merged: 帧对齐合并键数 }
    function scalePropertyKeys(prop, f, fd, scaleValues) {
        var n = 0;
        try { n = prop.numKeys; } catch (eN) { n = 0; }
        if (n == null || n <= 0) return { keys: 0, merged: 0 };

        // 1) 收集全部键数据（此阶段不改动任何东西，失败则整属性放弃）
        var data = [];
        var i;
        for (i = 1; i <= n; i++) {
            var k = readKeyData(prop, i);
            if (k == null) return { keys: -1, merged: 0 };
            data.push(k);
        }

        // 2) 倒序删除全部键（官方指南唯一收录的删除方法 removeKey）
        for (i = n; i >= 1; i--) {
            try { prop.removeKey(i); } catch (eR) {}
        }

        // 3) 按缩放后时间逐键重建（时间对齐到帧；同帧合并保留前者）。
        //    缩放保序（乘正数 + 取整不减序），故新键按时间升序依次落位，
        //    索引 = 已重建键数。
        var built = 0;
        var merged = 0;
        var prevT = null;
        for (i = 0; i < n; i++) {
            var kd = data[i];
            var nt = snapTime(kd.t * f, fd);
            var nv = kd.v;
            if (scaleValues && typeof nv === "number") nv = nv * f;
            if (prevT != null && approxEq(nt, prevT)) {
                merged++;
                continue;
            }
            try {
                prop.setValueAtTime(nt, nv);
            } catch (eS) {
                continue; // 个别键写不进（属性此刻不可写等），跳过
            }
            built++;
            prevT = nt;
            var idx = built;
            try {
                if (kd.inI != null && kd.outI != null) {
                    prop.setInterpolationTypeAtKey(idx, kd.inI, kd.outI);
                }
            } catch (eI1) {}
            try {
                if (kd.inE != null) {
                    // 速查表：只写一侧时另一侧会被设为同值，故先补读出的另一侧
                    prop.setTemporalEaseAtKey(idx, kd.inE, (kd.outE != null ? kd.outE : kd.inE));
                }
            } catch (eI2) {}
            try { if (kd.tAB) prop.setTemporalAutoBezierAtKey(idx, true); } catch (eI3) {}
            try { if (kd.tC) prop.setTemporalContinuousAtKey(idx, true); } catch (eI4) {}
            try { if (kd.sAB) prop.setSpatialAutoBezierAtKey(idx, true); } catch (eI5) {}
            try { if (kd.sC) prop.setSpatialContinuousAtKey(idx, true); } catch (eI6) {}
            try { if (kd.rov) prop.setRovingAtKey(idx, true); } catch (eI7) {}
            try {
                if (kd.inT != null && kd.outT != null) {
                    prop.setSpatialTangentsAtKey(idx, kd.inT, kd.outT);
                }
            } catch (eI8) {}
        }
        return { keys: built, merged: merged };
    }

    /* ======================================================================
     *  属性树遍历（重定时）：缩放图层属性树内所有带键属性
     * ==================================================================== */

    function walkPropertyGroup(group, isLayerRoot, skipProp, f, fd, stats) {
        var n = 0;
        try { n = group.numProperties; } catch (e0) { n = 0; }
        for (var i = 1; i <= n; i++) {
            var child = null;
            try { child = group.property(i); } catch (e1) { child = null; }
            if (child == null) continue;
            if (isLayerRoot) {
                var mn = null;
                try { mn = child.matchName; } catch (eM) { mn = null; }
                if (mn === "ADBE Marker Parade") continue; // 图层标记单独处理
            }
            if (skipProp != null) {
                var same = false;
                try { same = (child === skipProp); } catch (eC) { same = false; }
                if (same) continue; // 时间重映射已单独缩放（键值也要乘 f）
            }
            var isGroup = false;
            try { isGroup = (child.numProperties !== undefined); } catch (e2) { isGroup = false; }
            if (isGroup) {
                walkPropertyGroup(child, false, skipProp, f, fd, stats);
            } else {
                var r = null;
                try {
                    r = scalePropertyKeys(child, f, fd, false);
                } catch (e3) {
                    stats.warnings.push("属性「" + nameSafe(child) + "」关键帧缩放异常：" + errText(e3));
                    r = null;
                }
                if (r != null) {
                    if (r.keys > 0) {
                        stats.keys += r.keys;
                        stats.merged += r.merged;
                        stats.props++;
                    } else if (r.keys < 0) {
                        stats.warnings.push("属性「" + nameSafe(child) + "」关键帧不可读，未缩放。");
                    }
                }
            }
        }
    }

    /* ======================================================================
     *  时间重映射定位
     *  matchName "ADBE Time Remapping" 为指南未收录的社区通行 matchName，
     *  按白名单规则包 try/catch，并以 timeRemapEnabled（官方收录）为前提；
     *  取不到时返回 null，由调用方降级处理。
     * ==================================================================== */

    function findTimeRemapProp(layer) {
        var enabled = false;
        try { enabled = layer.timeRemapEnabled; } catch (e0) { enabled = false; }
        if (!enabled) return null;
        try {
            return layer.property("ADBE Time Remapping");
        } catch (e1) {
            return null;
        }
    }

    /* ======================================================================
     *  素材层同步变速（重定时可选项）：写入时间重映射，
     *  把原可见区间的源内容铺到 f 倍长的新时间轴上。
     * ==================================================================== */

    function writeFootageRemap(layer, oldIn, oldOut, oldStart, f, fd, stats) {
        var ok = false;
        try {
            layer.timeRemapEnabled = true;
            ok = layer.timeRemapEnabled;
        } catch (e0) {
            ok = false;
        }
        if (!ok) {
            stats.warnings.push("图层「" + nameSafe(layer) + "」无法启用时间重映射（音频层或类型不支持），未同步变速。");
            return;
        }
        var rp = findTimeRemapProp(layer);
        if (rp == null) {
            stats.warnings.push("图层「" + nameSafe(layer) + "」已启用时间重映射但无法定位该属性，未同步变速。");
            return;
        }
        var audioOn = false;
        try { audioOn = layer.audioEnabled; } catch (eA) { audioOn = false; }
        if (audioOn) {
            stats.warnings.push("图层「" + nameSafe(layer) + "」含音频：时间重映射只作用于视频，音频不会变速。");
        }
        // 清除启用重映射时自动生成的键，再写两个线性键
        var nk = 0;
        try { nk = rp.numKeys; } catch (eK) { nk = 0; }
        for (var i = nk; i >= 1; i--) {
            try { rp.removeKey(i); } catch (eR) {}
        }
        var t1 = snapTime(oldIn * f, fd);
        var t2 = snapTime(oldOut * f, fd);
        var v1 = oldStart;
        var v2 = oldStart + (oldOut - oldIn); // 源区间长度不变，铺在 f 倍长的新时间轴上
        try { rp.setValueAtTime(t1, v1); } catch (eS1) {}
        try { rp.setValueAtTime(t2, v2); } catch (eS2) {}
        try {
            rp.setInterpolationTypeAtKey(1, KeyframeInterpolationType.LINEAR, KeyframeInterpolationType.LINEAR);
        } catch (eI1) {}
        try {
            rp.setInterpolationTypeAtKey(2, KeyframeInterpolationType.LINEAR, KeyframeInterpolationType.LINEAR);
        } catch (eI2) {}
        stats.remaps++;
    }

    /* ======================================================================
     *  图层标记（重定时）：直接改标记 property 的 startTime（不删建）
     * ==================================================================== */

    function scaleLayerMarkers(layer, f, fd, stats) {
        var mp = null;
        try { mp = layer.property("ADBE Marker Parade"); } catch (e0) { mp = null; }
        if (mp == null) return;
        var n = 0;
        try { n = mp.numProperties; } catch (e1) { n = 0; }
        for (var i = 1; i <= n; i++) {
            var mk = null;
            try { mk = mp.property(i); } catch (e2) { mk = null; }
            if (mk == null) continue;
            try {
                var st = mk.startTime;
                mk.startTime = snapTime(st * f, fd);
                stats.markers++;
            } catch (e3) {
                stats.warnings.push("图层「" + nameSafe(layer) + "」的标记时间缩放失败（保留原时间）。");
            }
        }
    }

    // comp 标记：CompItem.markerProperty 为官方指南收录成员（速查表未单列，
    // 按白名单规则整段 try/catch，失败静默跳过）
    function scaleCompMarkers(comp, f, fd, stats) {
        try {
            var r = scalePropertyKeys(comp.markerProperty, f, fd, false);
            if (r.keys > 0) {
                stats.keys += r.keys;
                stats.merged += r.merged;
                stats.markers += r.keys;
            }
        } catch (e0) {}
    }

    /* ======================================================================
     *  图层重定时
     * ==================================================================== */

    function retimeLayer(layer, f, fd, syncFootage, stats) {
        var locked = false;
        try { locked = layer.locked; } catch (eL) { locked = false; }
        if (locked) {
            stats.warnings.push("图层「" + nameSafe(layer) + "」已锁定，跳过（请先解锁后重跑）。");
            return;
        }

        var oldIn = 0;
        var oldOut = 0;
        var oldStart = 0;
        var src = null;
        try { oldIn = layer.inPoint; } catch (e1) { oldIn = 0; }
        try { oldOut = layer.outPoint; } catch (e2) { oldOut = 0; }
        try { oldStart = layer.startTime; } catch (e3) { oldStart = 0; }
        try { src = layer.source; } catch (e4) { src = null; }

        // 1) 已有时间重映射：键时间与键值同步缩放（remap 值 = 源时间，
        //    子 comp 的源时间轴已随树拉长，值必须同乘 f 才能对上）
        var rp = findTimeRemapProp(layer);
        if (rp != null) {
            var rr = null;
            try { rr = scalePropertyKeys(rp, f, fd, true); } catch (eR0) { rr = null; }
            if (rr != null) {
                if (rr.keys > 0) {
                    stats.remaps++;
                    stats.keys += rr.keys;
                    stats.merged += rr.merged;
                } else if (rr.keys < 0) {
                    stats.warnings.push("图层「" + nameSafe(layer) + "」的时间重映射键不可读，未缩放。");
                }
            }
        } else if (syncFootage && src != null && (src instanceof FootageItem)) {
            // 2) 素材层同步变速（可选，默认关）：写入时间重映射
            if (oldOut - oldIn > fd * 0.5) {
                try {
                    writeFootageRemap(layer, oldIn, oldOut, oldStart, f, fd, stats);
                } catch (eW) {
                    stats.warnings.push("图层「" + nameSafe(layer) + "」写入时间重映射失败：" + errText(eW));
                }
            }
        }

        // 3) 入出点缩放。中间态不允许入点大于出点：
        //    放大先改出点（新出点必大于旧入点），缩小先改入点。
        var newIn = snapTime(oldIn * f, fd);
        var newOut = snapTime(oldOut * f, fd);
        if (newOut >= newIn) {
            if (f >= 1) {
                try { layer.outPoint = newOut; } catch (e5) {}
                try { layer.inPoint = newIn; } catch (e6) {}
            } else {
                try { layer.inPoint = newIn; } catch (e7) {}
                try { layer.outPoint = newOut; } catch (e8) {}
            }
        }

        // 4) 属性树内全部关键帧时间缩放（跳过 remap 属性——已单独处理）
        walkPropertyGroup(layer, true, rp, f, fd, stats);

        // 5) 图层标记时间缩放
        scaleLayerMarkers(layer, f, fd, stats);
    }

    /* ======================================================================
     *  comp 重定时
     * ==================================================================== */

    function retimeComp(comp, f, syncFootage, stats) {
        var fd = 1 / 30;
        try { fd = comp.frameDuration; } catch (e0) { fd = 1 / 30; }
        var oldDur = 0;
        try { oldDur = comp.duration; } catch (e1) { oldDur = 0; }

        var newDur = snapTime(oldDur * f, fd);
        if (!(newDur > 0)) newDur = fd;

        try {
            comp.duration = newDur;
        } catch (e2) {
            stats.warnings.push("comp「" + comp.name + "」时长修改失败：" + errText(e2));
            return;
        }
        stats.comps++;

        // 工作区缩放
        try {
            var waS = comp.workAreaStart;
            var waD = comp.workAreaDuration;
            if (waD > 0) {
                comp.workAreaStart = snapTime(waS * f, fd);
                comp.workAreaDuration = snapTime(waD * f, fd);
            }
        } catch (e3) {}

        scaleCompMarkers(comp, f, fd, stats);

        var n = 0;
        try { n = comp.numLayers; } catch (e4) { n = 0; }
        for (var i = 1; i <= n; i++) {
            var lay = null;
            try { lay = comp.layer(i); } catch (e5) { lay = null; }
            if (lay == null) continue;
            try {
                retimeLayer(lay, f, fd, syncFootage, stats);
            } catch (e6) {
                stats.warnings.push("图层「" + nameSafe(lay) + "」重定时异常：" + errText(e6));
            }
        }
    }

    /* ======================================================================
     *  comp 延长（Extend 模式）
     * ==================================================================== */

    function extendComp(comp, target, extendEdge, stats) {
        var fd = 1 / 30;
        try { fd = comp.frameDuration; } catch (e0) { fd = 1 / 30; }
        var oldDur = 0;
        try { oldDur = comp.duration; } catch (e1) { oldDur = 0; }
        var T = snapTime(target, fd);

        if (T > oldDur + fd * 0.5) {
            try {
                comp.duration = T;
                stats.comps++;
            } catch (e2) {
                stats.warnings.push("comp「" + comp.name + "」时长修改失败：" + errText(e2));
                return;
            }
        } else {
            stats.skipped++; // 已 ≥ 目标时长：只延长不截断
        }

        if (!extendEdge) return;

        // 只延长"原贴合旧 comp 结尾（或更靠后）"的图层出点：这些层显然是被
        // 旧时长截断的；中途结束的层保持设计者原意，不动。
        var n = 0;
        try { n = comp.numLayers; } catch (e3) { n = 0; }
        for (var i = 1; i <= n; i++) {
            var lay = null;
            try { lay = comp.layer(i); } catch (e4) { lay = null; }
            if (lay == null) continue;
            var locked = false;
            try { locked = lay.locked; } catch (eL) { locked = false; }
            if (locked) {
                stats.warnings.push("图层「" + nameSafe(lay) + "」已锁定，未延长出点。");
                continue;
            }
            var op = 0;
            try { op = lay.outPoint; } catch (e5) { continue; }
            if (op >= oldDur - fd * 0.5 && op < T) {
                try {
                    lay.outPoint = T;
                    stats.layers++;
                } catch (e6) {
                    stats.warnings.push("图层「" + nameSafe(lay) + "」出点延长失败：" + errText(e6));
                }
            }
        }
    }

    /* ======================================================================
     *  主流程
     * ==================================================================== */

    function newStats() {
        return {
            comps: 0,
            layers: 0,
            keys: 0,
            merged: 0,
            props: 0,
            remaps: 0,
            markers: 0,
            skipped: 0,
            warnings: []
        };
    }

    function runMode(mode, target, extendEdge, syncFootage, trees, stats) {
        for (var t = 0; t < trees.length; t++) {
            var tree = trees[t];
            var rootDur = 0;
            try { rootDur = tree.root.duration; } catch (eR) { rootDur = 0; }

            if (mode === MODE_RETIME) {
                if (!(rootDur > 0)) {
                    stats.warnings.push("根 comp「" + tree.root.name + "」时长为 0，该树跳过。");
                    continue;
                }
                var f = target / rootDur;
                for (var c = 0; c < tree.entries.length; c++) {
                    var comp = tree.entries[c].comp;
                    try {
                        retimeComp(comp, f, syncFootage, stats);
                    } catch (eC) {
                        stats.warnings.push("comp「" + comp.name + "」重定时异常：" + errText(eC));
                    }
                }
            } else {
                for (var c2 = 0; c2 < tree.entries.length; c2++) {
                    var comp2 = tree.entries[c2].comp;
                    try {
                        extendComp(comp2, target, extendEdge, stats);
                    } catch (eC2) {
                        stats.warnings.push("comp「" + comp2.name + "」延长异常：" + errText(eC2));
                    }
                }
            }
        }
    }

    function doRun(mode, target, extendEdge, syncFootage, trees) {
        app.beginUndoGroup(SCRIPT_NAME);
        var stats = newStats();
        try {
            runMode(mode, target, extendEdge, syncFootage, trees, stats);
            var lines = [];
            if (mode === MODE_RETIME) {
                lines.push("重定时完成：修改 " + stats.comps + " 个 comp（比例缩放到 " + target + " 秒）");
                lines.push("缩放关键帧 " + stats.keys + " 个（属性 " + stats.props + " 个；同帧合并 " + stats.merged + " 个）");
                lines.push("时间重映射 " + stats.remaps + " 个；标记 " + stats.markers + " 个");
            } else {
                lines.push("延长完成：修改 " + stats.comps + " 个 comp（目标时长 " + target + " 秒）");
                lines.push("延长图层出点 " + stats.layers + " 个");
            }
            if (stats.skipped > 0) {
                lines.push("另有 " + stats.skipped + " 个 comp 时长已 ≥ 目标，未改动（只延长不截断）");
            }
            if (stats.warnings.length > 0) {
                lines.push("---- 警告 " + stats.warnings.length + " 条 ----");
                var max = Math.min(stats.warnings.length, 8);
                for (var i = 0; i < max; i++) {
                    lines.push(stats.warnings[i]);
                }
                if (stats.warnings.length > max) {
                    lines.push("…… 其余 " + (stats.warnings.length - max) + " 条从略");
                }
            }
            alert(lines.join("\n"), SCRIPT_NAME);
        } catch (e) {
            var msg = "执行失败：" + errText(e);
            try {
                if (e.line != null) msg += "（行 " + e.line + "）";
            } catch (e2) {}
            alert(msg, SCRIPT_NAME);
        } finally {
            try { app.endUndoGroup(); } catch (e3) {}
        }
    }

    /* ======================================================================
     *  UI（ScriptUI，ES3）
     * ==================================================================== */

    function buildUI() {
        var roots = getSelectedComps();
        var treeInfo = collectTrees(roots);
        var trees = treeInfo.trees;

        var w = new Window("dialog", SCRIPT_NAME + " v" + SCRIPT_VERSION);
        w.orientation = "column";
        w.alignChildren = ["fill", "top"];
        w.spacing = 8;
        w.margins = 16;

        var infoText = w.add("statictext", undefined, "");
        infoText.preferredSize = [430, 34];

        var refreshBtn = w.add("button", undefined, "刷新选中");
        refreshBtn.alignment = ["left", "center"];
        refreshBtn.onClick = function () {
            roots = getSelectedComps();
            treeInfo = collectTrees(roots);
            trees = treeInfo.trees;
            updatePreview();
        };

        w.add("statictext", undefined, "模式：");
        var radioExtend = w.add("radiobutton", undefined, "延长（Extend）：树内 comp 时长统一改为目标时长，动画节奏不变");
        var radioRetime = w.add("radiobutton", undefined, "重定时（Retime）：整棵树按同一比例缩放到目标时长，关键帧同步缩放");
        var hintExtend = w.add("statictext", undefined, "    关键帧不动，动画结束后由 AE 原生 hold 语义停在最后一帧；原贴合旧 comp 结尾的图层出点随之延长。");
        var hintRetime = w.add("statictext", undefined, "    comp 时长、图层入出点、关键帧时间、已有时间重映射（键时间与键值）、标记、工作区同步缩放。");
        hintExtend.preferredSize = [430, 30];
        hintRetime.preferredSize = [430, 30];

        var targetGrp = w.add("group");
        targetGrp.orientation = "row";
        targetGrp.alignChildren = ["left", "center"];
        targetGrp.add("statictext", undefined, "目标时长（秒）：");
        var targetEdit = targetGrp.add("edittext");
        targetEdit.characters = 8;
        targetEdit.text = loadSetting(KEY_TARGET, "10");
        var rootInfoText = targetGrp.add("statictext", undefined, "");

        var chkEdge = w.add("checkbox", undefined, "延长原贴合 comp 结尾的图层出点（仅延长模式生效）");
        chkEdge.value = (loadSetting(KEY_EDGE, "1") === "1");
        var chkSync = w.add("checkbox", undefined, "素材层同步变速——给素材层写入时间重映射（仅重定时模式生效）");
        chkSync.value = (loadSetting(KEY_SYNC, "0") === "1");

        w.add("statictext", undefined, "影响范围（整棵嵌套 precomp 树，含根）：");
        var lb = w.add("listbox", undefined, []);
        lb.preferredSize = [430, 160];

        function updatePreview() {
            if (roots.length === 0) {
                infoText.text = "未选中 comp：请在项目面板选中要处理的合成（可多选），然后点「刷新选中」。";
            } else {
                var total = 0;
                for (var i = 0; i < trees.length; i++) total += trees[i].entries.length;
                infoText.text = "已选 " + roots.length + " 个根 comp，整树共 " + total + " 个 comp 将被修改。";
            }
            var rootDurText = "";
            if (roots.length > 0) {
                var rd = 0;
                try { rd = roots[0].duration; } catch (eR) { rd = 0; }
                rootDurText = "（根 comp 当前时长：" + (Math.round(rd * 100) / 100) + " 秒" + (roots.length > 1 ? " 等 " + roots.length + " 个根" : "") + "）";
            }
            rootInfoText.text = rootDurText;
            try { lb.removeAll(); } catch (eL) {}
            for (var t = 0; t < trees.length; t++) {
                var entries = trees[t].entries;
                for (var c = 0; c < entries.length; c++) {
                    var indent = "";
                    for (var d = 0; d < entries[c].depth; d++) indent += "    ";
                    var label = indent + entries[c].comp.name;
                    if (entries[c].depth === 0) label += "（根）";
                    try { lb.add("item", label); } catch (eAdd) {}
                }
            }
            for (var wI = 0; wI < treeInfo.warnings.length; wI++) {
                try { lb.add("item", "! " + treeInfo.warnings[wI]); } catch (eW2) {}
            }
        }

        function currentMode() {
            return radioRetime.value ? MODE_RETIME : MODE_EXTEND;
        }

        function updateHints() {
            var m = currentMode();
            hintExtend.visible = (m === MODE_EXTEND);
            hintRetime.visible = (m === MODE_RETIME);
        }
        radioExtend.onClick = updateHints;
        radioRetime.onClick = updateHints;

        var btnGrp = w.add("group");
        btnGrp.orientation = "row";
        btnGrp.alignment = ["right", "bottom"];
        var runBtn = btnGrp.add("button", undefined, "执行");
        var cancelBtn = btnGrp.add("button", undefined, "取消");

        runBtn.onClick = function () {
            if (roots.length === 0 || trees.length === 0) {
                alert("请先在项目面板选中要处理的 comp（可多选）。", SCRIPT_NAME);
                return;
            }
            var target = parseFloat(targetEdit.text);
            if (!(target > 0)) {
                alert("请输入有效的目标时长（大于 0 的秒数）。", SCRIPT_NAME);
                return;
            }
            var mode = currentMode();

            // 延长模式只延长不截断：目标时长必须 ≥ 每棵根 comp 的当前时长
            if (mode === MODE_EXTEND) {
                for (var t = 0; t < trees.length; t++) {
                    var rd = 0;
                    try { rd = trees[t].root.duration; } catch (eR) { rd = 0; }
                    if (target < rd - 0.000001) {
                        alert("延长模式只能放大时长：目标时长 " + target + " 秒小于根 comp「" + trees[t].root.name + "」的当前时长 " + rd + " 秒。\n如需整树加速/减速，请改用「重定时」模式。", SCRIPT_NAME);
                        return;
                    }
                }
            }

            // 操作前确认对话框
            var total = 0;
            for (var c = 0; c < trees.length; c++) total += trees[c].entries.length;
            var lines = [];
            lines.push("即将修改 " + total + " 个 comp（整棵嵌套 precomp 树）：");
            lines.push("模式：" + (mode === MODE_RETIME ? "重定时（按比例缩放）" : "延长（节奏不变，结尾保持）"));
            lines.push("目标时长：" + target + " 秒");
            var showMax = 10;
            var shown = 0;
            for (var t2 = 0; t2 < trees.length && shown < showMax; t2++) {
                for (var c2 = 0; c2 < trees[t2].entries.length && shown < showMax; c2++) {
                    lines.push(" - " + trees[t2].entries[c2].comp.name);
                    shown++;
                }
            }
            if (total > showMax) lines.push(" …… 共 " + total + " 个");
            if (mode === MODE_RETIME && chkSync.value) lines.push("已启用：素材层同步变速（写入时间重映射）");
            if (mode === MODE_EXTEND && chkEdge.value) lines.push("已启用：延长原贴合 comp 结尾的图层出点");
            lines.push("确定执行？（整个操作可通过 Ctrl+Z 一次撤销）");
            if (!confirm(lines.join("\n"), SCRIPT_NAME)) return;

            saveSetting(KEY_MODE, mode);
            saveSetting(KEY_TARGET, String(target));
            saveSetting(KEY_EDGE, chkEdge.value ? "1" : "0");
            saveSetting(KEY_SYNC, chkSync.value ? "1" : "0");
            w.close(1);
            doRun(mode, target, chkEdge.value, chkSync.value, trees);
        };

        cancelBtn.onClick = function () {
            w.close(0);
        };

        // 恢复上次的模式选择（ScriptUI 不会因设置一个 radio 而自动取消另一个）
        var savedMode = loadSetting(KEY_MODE, MODE_EXTEND);
        if (savedMode === MODE_RETIME) {
            radioExtend.value = false;
            radioRetime.value = true;
        } else {
            radioExtend.value = true;
            radioRetime.value = false;
        }
        updateHints();
        updatePreview();
        w.center();
        w.show();
    }

    /* ======================================================================
     *  入口
     * ==================================================================== */

    function main() {
        if (app.project == null) {
            alert("请先打开一个 After Effects 工程。", SCRIPT_NAME);
            return;
        }
        buildUI();
    }

    try {
        main();
    } catch (eFatal) {
        var fatalMsg = "脚本初始化失败：" + errText(eFatal);
        try {
            if (eFatal.line != null) fatalMsg += "（行 " + eFatal.line + "）";
        } catch (eL) {}
        alert(fatalMsg, SCRIPT_NAME);
    }
})();
