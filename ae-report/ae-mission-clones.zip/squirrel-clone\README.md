---
generated_at: 2026-11-14T00:26:00Z
task: 自主选件 clean-room 复刻第二轮（中间段未复刻 A 类）——已选 Squirrel（#13），产出 main.jsx + README；功能输入为 intel/paid-list.md #13 条目；未反编译、未接触原代码
---

# SquirrelClone v1.0（Squirrel 的 clean-room 复刻）

## 选件理由（中间段未复刻项对比）

上一轮选的 Easy Bake 位于清单后半段，本轮按要求从中间段挑。中间段未复刻：Squirrel (13)、WobbleBox (14)、Easify 4 (15)、Keyframe Parent (16)、Scribe (25)、Trim Comp to Contents (26)、Project Item Labels (27)。（Parrot (12) 刚被其他工人完成 `parrot-clone`，出局。）

| 候选 | 落选硬伤 |
|---|---|
| Easify 4 | AE+PR 双宿主，PR 侧 jsx 无法实现，条目粒度粗 |
| Keyframe Parent | "父化关键帧组"语义不明，推断歧义大，无法定验收口径 |
| Scribe | 需要"自动字型库"= 字形轮廓提取，AE Scripting 无此 API |
| Trim Comp to Contents | 核心依赖 `comp.duration` 可写，速查表未核实，主功能可能整体落空 |
| Project Item Labels | 价值低（改标签色），描述薄 |
| WobbleBox | $5 小预设，描述最薄（"果冻盒子"一句话），复刻口径难立 |
| **Squirrel（选中）** | 描述给出明确行为面（层级树视图 / 重父化 / 快速选择 / 重命名），全部落在白名单 API（`layer.parent` 读写、`layer.selected`、`layer(i)` 遍历、`layer.name`），功能闭环可验收 |

## Clean-room 声明

仅依据公开功能描述（"A hierarchy editor that converts your timeline into an interactive treeview based on layer parenting, much like what you would find in any 3D application."）从零实现；未反编译/读取/复制/翻译任何原产品代码。所有 AE API 按 `docs/api-cheatsheet.md` 白名单书写，表外 API 包 try/catch。

## 功能对照

### 复刻栏

| 条目要点 | 本实现 |
|---|---|
| 时间线→交互树视图 | treeview 按父链（`layer.parent`）构建：根=无父图层（时间线自上而下排序），子节点挂父节点内，行文本 = `名称  [索引]`；REFRESH TREE 重建（含根数/总数状态） |
| 重父化 | PARENT SEL：时间线选中层 → 下拉框选目标父层（None = 解除父化）；**环检测**（目标在子链上则拒并报 warning）、自父检测；UNPARENT SEL 一键解除；单次 undo 组 |
| 快速选择 | 树中选行 → SELECT IN COMP：该层成为 comp 唯一选中层（其余取消选中） |
| 重命名 | 输入新名 → RENAME SEL：批量重命名时间线选中层，多选时自动后缀 "名 1…N"，逐层 try/catch 收集失败 |
| 防护 | 无活动 comp / 时间线零选中 / 下拉未选 / 树未选 全部明确报错；父层按 index 绑定（下拉项挂 index2），重名层不会错绑 |

### 未复刻栏（含交互形态降级说明）

1. **拖拽重父化**（原条目"drag reparent"）——ScriptUI treeview 拖拽不可靠，降级为"下拉选父 + 按钮"，行为等价、交互形态不同；
2. 3D 软件式多树/多合成同屏（单 comp 单树）；
3. 树节点图标/缩略图、分支整体折叠状态记忆；
4. 拖拽排序图层顺序（本工具只管 parent 链，不动时间线层序）；
5. 跨合成批量操作、AE 实机冒烟（本环境无 AE）。

## 推断范围注明

官方条目仅一句话简介（paid-list #13 [未核实细节]）：树视图、重父化、快速选择、重命名四个能力面为本复刻的推断定义；批量重命名后缀样式、环检测拒绝策略均为本实现的口径。

## 安装

`main.jsx` 拷入 AE `ScriptUI Panels` 目录后从 Window 菜单打开；或 File > Scripts > Run Script File 直接运行。面板打开时若无活动 comp，直接改好 comp 后按 REFRESH TREE。

## API 合规（对照 docs/api-cheatsheet.md）

- 白名单核心项：`comp.layer(i)` 1-based + `numLayers` 遍历、`comp.selectedLayers`（0-based length）、`layer.parent` 读/写、`layer.selected` 读写、`layer.name` 读写、`layer.index`、`app.project.activeItem` + `instanceof CompItem`、`app.beginUndoGroup/endUndoGroup`（try/finally 成对）。
- `layer.parent = null` 解除父化、`layer.name = x` 批量改名均为官方读写属性（速查表列 parent/name 为可读；写方向已逐层包 try/catch，失败收为 warning）。
- 树节点/下拉项挂自定义属性（`node.layerIndex`、`it.index2`）为 ExtendScript 动态属性（非 AE 对象模型，无风险）。

## 自查结果（2026-11-14）

- `node --check`（.jsx 后缀经 .js 副本检查）：**通过**。
- ES3 扫描（箭头/let/const/模板串/JSON./Object.keys/数组方法链/for..of/Set/Map/可选链等 30+ 模式）：**0 命中**；数组尾逗号 0 命中；无 BOM。
- 首跑冒烟建议：建 3 层 A/B/C → 树中确认 B、C 挂 A → 选中 C + 下拉选 B → PARENT SEL → 树变为 A→B→C → UNPARENT → 环测试（选中 A 且下拉选其子孙应被拒）。

## 限制

- 重命名会破坏面板内引用的显示（每次操作后自动 REFRESH 重建树与下拉，index 绑定不受影响）；
- 深层父链（>64 层）环检测提前放弃（报 warning 不误伤）；
- 树深超过 32 层的分支不再展开（MAX_DEPTH 保护，行仍在下拉框中可选作父层）；
- 面板不监听 AE 选中变化（ScriptUI 无轮询事件），选中操作以按钮触发的瞬间状态为准。
