﻿/***************************************************************************
 * JNS Clone —— Joysticks 'n Sliders 核心功能 clean-room 复刻
 * ============================================================================
 * CLEAN-ROOM 声明：
 *   本脚本仅依据公开渠道的功能性描述（ae-mission/intel/paid-list.md 第 7 条，
 *   来源为 aescripts.com 官方商品页全文）独立实现，未反编译、未获取、未参考
 *   Joysticks 'n Sliders 原脚本的任何源代码、字节码、资源或安装包内容。
 *   实现中的所有公式、命名、UI 与工作流均为本项目的原创设计。
 *
 * 功能基线（本克隆范围）：
 *   一个控制图层（Joy）的 X/Y 位置，驱动目标图层若干「姿势属性」，
 *   按 Joy 在边界矩形内的相对位置做双线性插值：
 *     u = clamp((joyX - L) / (R - L), 0, 1)
 *     v = clamp((joyY - T) / (B - T), 0, 1)
 *     wTL = (1-u)(1-v)   wTR = u(1-v)   wBL = (1-u)v   wBR = uv   （权重和恒为 1）
 *   每个被绑定的目标属性在 Joy 层上生成 4 个角点姿势容器
 *   （1D -> Slider Control，2D -> Point Control，3D/4D -> 分量滑杆），
 *   并对目标属性写入引用 Joy 位置做加权求和的表达式。
 *   可选 EaseBias：0-100 平滑 S 曲线混合（对 u、v 做 smoothstep 混合）。
 *
 * 兼容目标：AE CC 及以上（表达式同时兼容 Legacy ExtendScript 引擎与
 *   JavaScript 引擎）。脚本本体为 ES3 ExtendScript。
 *
 * 自查记录（见 README.md）：node --check 语法通过；ES3 禁用特性扫描通过。
 * 本环境无 AE 实机，尚未在 AE 中运行验证，首次使用请先在测试工程试跑。
 *
 * 用法入口：ScriptUI Panels 方式停靠，或 File > Scripts > Run Script File。
 * ============================================================================
 */

var JNSC = (function () {

    var VERSION = "1.0.0";
    var PREFIX = "JNS|";            // 本克隆生成的效果统一前缀（命名即登记表）
    var BIAS_NAME = "JNS|EaseBias"; // 可选偏置滑杆（简化版 EaseBias）
    var CORNERS = ["TL", "TR", "BL", "BR"];
    var COMP_LABELS = ["X", "Y", "Z", "W"];   // 3D/4D 分量后缀
    var COLOR_LABELS = ["R", "G", "B", "A"];  // 颜色分量后缀

    var ui = null;        // UI 控件引用集合
    var joyItems = [];    // Joy 下拉数据 [{idx, name}]
    var tgtItems = [];    // 目标层下拉数据
    var pickedProps = []; // 属性浏览器选中的待绑定项 [{prop, label, dim}]

    // ---------------------------------------------------------------- 小工具

    function r3(n) { return Math.round(n * 1000) / 1000; }

    // 效果名里不允许出现会破坏表达式字符串字面量的字符
    function sanitizeName(s) {
        var out = "";
        for (var i = 0; i < s.length; i++) {
            var ch = s.charAt(i);
            if (ch === "|" || ch === '"' || ch === "'") { out += "-"; } else { out += ch; }
        }
        if (out === "") { out = "prop"; }
        return out;
    }

    function isComp(x) {
        return (x !== null && x !== undefined && x instanceof CompItem);
    }

    function getComp() {
        if (app.project === null || app.project === undefined) { return null; }
        if (app.project.numItems === 0) { return null; }
        var a = app.project.activeItem;
        return isComp(a) ? a : null;
    }

    function setInfo(msg) {
        if (ui !== null && ui.info !== null) { ui.info.text = msg; }
    }

    function selData(drop, items) {
        if (drop.selection === null || drop.selection === undefined) { return null; }
        return items[drop.selection.index];
    }

    // ------------------------------------------------------- 属性类型判断

    // 返回值维度：1/2/3/4，不可绑定返回 0
    function dimOf(p) {
        var t = p.propertyValueType;
        if (t === PropertyValueType.OneD) { return 1; }
        if (t === PropertyValueType.TwoD || t === PropertyValueType.TwoD_SPATIAL) { return 2; }
        if (t === PropertyValueType.ThreeD || t === PropertyValueType.ThreeD_SPATIAL) { return 3; }
        if (t === PropertyValueType.COLOR) { return 4; }
        return 0;
    }

    function isBindable(p) {
        if (p.propertyType !== PropertyType.PROPERTY) { return false; }
        var t = p.propertyValueType;
        if (t === PropertyValueType.NoValue || t === PropertyValueType.TEXT ||
            t === PropertyValueType.LAYER_INDEX || t === PropertyValueType.MARKER ||
            t === PropertyValueType.SHAPE || t === PropertyValueType.CUSTOM) { return false; }
        if (dimOf(p) === 0) { return false; }
        try {
            if (!p.canSetExpression || !p.expressionEditable) { return false; }
        } catch (e) { return false; }
        return true;
    }

    // 递归收集图层上的可绑定数值属性（叶子）
    function collectProps(group, depth, prefix, out) {
        if (depth > 6 || out.length > 400) { return; }
        for (var i = 1; i <= group.numProperties; i++) {
            var p = null;
            try { p = group.property(i); } catch (eGet) { continue; }
            if (p === null || p === undefined) { continue; }
            if (p.propertyType === PropertyType.PROPERTY) {
                // 分离维度的位置：拆成 X/Y 等 1D 子属性逐个绑定
                if (p.dimensionsSeparated === true && p.numProperties > 0) {
                    collectProps(p, depth + 1, prefix + p.name + " > ", out);
                } else if (isBindable(p)) {
                    out.push({ prop: p, label: prefix + p.name, dim: dimOf(p) });
                }
            } else {
                if (p.matchName === "ADBE Effect Parade") { continue; } // 不列效果控件本身
                collectProps(p, depth + 1, prefix + p.name + " > ", out);
            }
        }
    }

    // 属性所属图层（沿 propertyGroup 向上走到 Layer）
    function ownerLayerOf(p) {
        var g = null;
        try { g = p.propertyGroup(1); } catch (e) { return null; }
        var guard = 0;
        while (g !== null && g !== undefined && guard < 40) {
            if (g instanceof Layer) { return g; }
            var nxt = null;
            try { nxt = g.propertyGroup(1); } catch (e2) { return null; }
            if (nxt === null || nxt === g) { return null; }
            g = nxt;
            guard++;
        }
        return null;
    }

    // 是否位于本克隆生成的 JNS| 效果内部（避免把姿势滑杆自己再绑出去）
    function insideJnsEffect(p) {
        var g = null;
        try { g = p.propertyGroup(1); } catch (e) { return false; }
        var guard = 0;
        while (g !== null && g !== undefined && guard < 32) {
            try {
                if (g.name !== null && g.name !== undefined && g.name.indexOf(PREFIX) === 0) { return true; }
            } catch (e2) { /* 无 name 属性的组，忽略 */ }
            var nxt = null;
            try { nxt = g.propertyGroup(1); } catch (e3) { nxt = null; }
            if (nxt === g) { break; }
            g = nxt;
            guard++;
        }
        return false;
    }

    // ------------------------------------------------------- Joy 层效果管理

    function findEffect(layer, name) {
        var fxGroup = layer.property("ADBE Effect Parade");
        for (var i = 1; i <= fxGroup.numProperties; i++) {
            var e = fxGroup.property(i);
            if (e.name === name) { return e; }
        }
        return null;
    }

    // 该属性前缀的效果组是否已存在（避免把 "Scale_2" 误判为 "Scale"）
    function baseExists(joy, base) {
        var fxGroup = joy.property("ADBE Effect Parade");
        var p1 = PREFIX + base + "|";
        var p2 = PREFIX + base + "~";
        for (var i = 1; i <= fxGroup.numProperties; i++) {
            var nm = fxGroup.property(i).name;
            if (nm.indexOf(p1) === 0 || nm.indexOf(p2) === 0) { return true; }
        }
        return false;
    }

    function uniqueBase(joy, base) {
        var b = base;
        var n = 2;
        while (baseExists(joy, b)) {
            b = base + "_" + n;
            n++;
        }
        return b;
    }

    // 角点效果命名：dim<=2 -> "JNS|base|TL"；dim>=3 -> "JNS|base~X|TL"
    function effName(base, dim, k, corner) {
        if (dim <= 2) { return PREFIX + base + "|" + corner; }
        var lab = (dim === 4) ? COLOR_LABELS[k] : COMP_LABELS[k];
        return PREFIX + base + "~" + lab + "|" + corner;
    }

    function ensureBias(joy) {
        if (findEffect(joy, BIAS_NAME) !== null) { return; }
        var fx = joy.addProperty("ADBE Slider Control");
        fx.name = BIAS_NAME;
        fx.property(1).setValue(0);
    }

    // 读取属性当前值分量（作为初始姿势）
    function currentComponents(p, dim) {
        var v = null;
        try { v = p.value; } catch (e) { return null; }
        if (v === null || v === undefined) { return null; }
        var out = [];
        for (var k = 0; k < dim; k++) {
            var num = (dim === 1) ? Number(v) : Number(v[k]);
            if (isNaN(num)) { num = 0; }
            out.push(num);
        }
        return out;
    }

    // 在 Joy 层上创建（或复用）某属性的 4 个角点姿势容器
    function createCornerEffects(joy, base, dim, initVals, capture) {
        for (var c = 0; c < 4; c++) {
            var corner = CORNERS[c];
            if (dim === 2) {
                var nm2 = effName(base, 2, 0, corner);
                var fx2 = findEffect(joy, nm2);
                if (fx2 === null) {
                    fx2 = joy.addProperty("ADBE Point Control");
                    fx2.name = nm2;
                }
                if (capture && initVals !== null) {
                    fx2.property(1).setValue([initVals[0], initVals[1]]);
                }
            } else {
                for (var k = 0; k < dim; k++) {
                    var nm = effName(base, dim, k, corner);
                    var fx = findEffect(joy, nm);
                    if (fx === null) {
                        fx = joy.addProperty("ADBE Slider Control");
                        fx.name = nm;
                    }
                    if (capture && initVals !== null) {
                        fx.property(1).setValue(initVals[k]);
                    }
                }
            }
        }
    }

    // ------------------------------------------------------- 表达式生成

    function cornerSumExpr(base, dim, k) {
        var parts = [];
        // 读取效果属性的第 (k+1) 个分量：Point Control (1)=X, (2)=Y；
        // dim<=2 时四个角点共用同一个 Point/Slider 效果名，靠 k 选分量
        var compIdx = k + 1;
        for (var c = 0; c < 4; c++) {
            parts.push('w' + CORNERS[c] + '*joy.effect("' +
                effName(base, dim, k, CORNERS[c]) + '")(' + compIdx + ')');
        }
        return parts.join(" + ");
    }

    function buildExpression(joyIdx, bnds, dim, base, withBias) {
        var L = [];
        L.push("// JNS-clone v" + VERSION + " : bilinear pose blend (clean-room)");
        L.push("var joy = thisComp.layer(" + joyIdx + ");");
        L.push("var p = joy.toComp(joy.anchorPoint);");
        L.push("var u = (p[0] - (" + bnds[0] + ")) / (" + r3(bnds[2] - bnds[0]) + ");");
        L.push("var v = (p[1] - (" + bnds[1] + ")) / (" + r3(bnds[3] - bnds[1]) + ");");
        L.push("u = Math.max(0, Math.min(1, u));");
        L.push("v = Math.max(0, Math.min(1, v));");
        if (withBias) {
            L.push('var eb = joy.effect("' + BIAS_NAME + '")(1) / 100;');
            L.push('if (eb > 0) { var us = u * u * (3 - 2 * u); u = u + (us - u) * eb; ' +
                'var vs = v * v * (3 - 2 * v); v = v + (vs - v) * eb; }');
        }
        L.push("var wTL = (1 - u) * (1 - v);");
        L.push("var wTR = u * (1 - v);");
        L.push("var wBL = (1 - u) * v;");
        L.push("var wBR = u * v;");
        if (dim === 1) {
            L.push("value = " + cornerSumExpr(base, dim, 0) + ";");
        } else if (dim === 2) {
            // 2D：Point Control 的 X/Y 分量分别加权和，输出二维数组
            L.push("value = [" + cornerSumExpr(base, dim, 0) + ", " +
                cornerSumExpr(base, dim, 1) + "];");
        } else {
            var comps = [];
            for (var k = 0; k < dim; k++) {
                comps.push(cornerSumExpr(base, dim, k));
            }
            L.push("value = [" + comps.join(", ") + "];");
        }
        return L.join("\n");
    }

    // ------------------------------------------------------- 属性浏览器

    function pickProps() {
        var comp = getComp();
        if (!comp) { alert("请先在项目面板激活一个合成。"); return; }
        var tgt = selData(ui.tgtDrop, tgtItems);
        if (!tgt) { alert("请先选择目标图层。"); return; }
        var layer = comp.layer(tgt.idx);
        var out = [];
        collectProps(layer, 0, "", out);
        if (out.length === 0) { alert("该图层没有可绑定的数值属性。"); return; }

        var d = new Window("dialog", "选择目标属性（Ctrl / Shift 多选）");
        d.orientation = "column";
        d.alignChildren = ["fill", "top"];
        d.spacing = 8;
        d.margins = 12;
        d.add("statictext", undefined,
            "图层: " + layer.name + "    可绑定数值属性共 " + out.length + " 个");
        var lb = d.add("listbox", undefined, [], { multiselect: true });
        lb.preferredSize = [500, 340];
        for (var i = 0; i < out.length; i++) {
            lb.add("item", out[i].label + "    [维度 " + out[i].dim + "]");
        }
        var row = d.add("group");
        row.alignment = "right";
        row.add("button", undefined, "确定", { name: "ok" });
        row.add("button", undefined, "取消", { name: "cancel" });
        if (d.show() === 1) {
            pickedProps = [];
            if (lb.selection !== null) {
                for (var j = 0; j < lb.selection.length; j++) {
                    pickedProps.push(out[lb.selection[j].index]);
                }
            }
            updatePickedList();
        }
    }

    function updatePickedList() {
        ui.pickedList.removeAll();
        for (var i = 0; i < pickedProps.length; i++) {
            ui.pickedList.add("item", pickedProps[i].label + "  [维度 " + pickedProps[i].dim + "]");
        }
    }

    function gatherProps(comp) {
        var res = [];
        if (pickedProps.length > 0) {
            for (var i = 0; i < pickedProps.length; i++) {
                var it = pickedProps[i];
                try { it.prop.value; res.push(it); } catch (eStale) { /* 引用已失效，跳过 */ }
            }
            return res;
        }
        var sel = comp.selectedProperties;
        if (sel === null || sel === undefined) { return res; }
        for (var j = 0; j < sel.length; j++) {
            var p = sel[j];
            if (!isBindable(p)) { continue; }
            if (insideJnsEffect(p)) { continue; }
            res.push({ prop: p, label: p.name, dim: dimOf(p) });
        }
        return res;
    }

    // ------------------------------------------------------- 主流程

    function readBounds(comp) {
        var b = null;
        if (ui.rbComp.value) {
            b = [0, 0, comp.width, comp.height];
        } else {
            var L = parseFloat(ui.etL.text);
            var T = parseFloat(ui.etT.text);
            var R = parseFloat(ui.etR.text);
            var B = parseFloat(ui.etB.text);
            if (isNaN(L) || isNaN(T) || isNaN(R) || isNaN(B)) {
                alert("自定义边界需要 4 个数字（左/上/右/下）。");
                return null;
            }
            if (R <= L || B <= T) {
                alert("右必须大于左，下必须大于上。");
                return null;
            }
            b = [L, T, R, B];
        }
        if ((b[2] - b[0]) < 1 || (b[3] - b[1]) < 1) {
            alert("边界宽高过小，无法插值。");
            return null;
        }
        return [r3(b[0]), r3(b[1]), r3(b[2]), r3(b[3])];
    }

    function createJoyLayer(comp, bnds) {
        var cx = (bnds[0] + bnds[2]) / 2;
        var cy = (bnds[1] + bnds[3]) / 2;
        var lay = comp.layers.addShape();
        lay.name = "Joy_Controller";
        lay.property("ADBE Transform Group").property("ADBE Position").setValue([cx, cy]);
        var contents = lay.property("ADBE Root Vectors Group");
        // 边界矩形（可视化插值范围）
        var g1 = contents.addProperty("ADBE Vector Group");
        g1.name = "JNS_Bounds";
        var vg1 = g1.property("ADBE Vectors Group");
        var rect = vg1.addProperty("ADBE Vector Shape - Rect");
        rect.property("ADBE Rect Size").setValue([bnds[2] - bnds[0], bnds[3] - bnds[1]]);
        var st1 = vg1.addProperty("ADBE Vector Graphic - Stroke");
        st1.property("ADBE Stroke Color").setValue([1, 0.8, 0, 1]);
        st1.property("ADBE Stroke Width").setValue(2);
        // 中心手柄圆
        var g2 = contents.addProperty("ADBE Vector Group");
        g2.name = "JNS_Knob";
        var vg2 = g2.property("ADBE Vectors Group");
        var el = vg2.addProperty("ADBE Vector Shape - Ellipse");
        el.property("ADBE Ellipse Size").setValue([36, 36]);
        var st2 = vg2.addProperty("ADBE Vector Graphic - Stroke");
        st2.property("ADBE Stroke Color").setValue([1, 1, 1, 1]);
        st2.property("ADBE Stroke Width").setValue(3);
        lay.moveToBeginning();
        return 1; // 移到顶层后索引为 1
    }

    function doCreateJoy() {
        var comp = getComp();
        if (!comp) { alert("请先在项目面板激活一个合成。"); return; }
        var bnds = readBounds(comp);
        if (!bnds) { return; }
        app.beginUndoGroup("JNS Clone: 创建 Joy 控制层");
        try {
            var idx = createJoyLayer(comp, bnds);
            refreshLists();
            // 把新建的 Joy 层设为下拉选中项（索引 1）
            for (var i = 0; i < joyItems.length; i++) {
                if (joyItems[i].idx === idx) { ui.joyDrop.selection = i; break; }
            }
            setInfo("已创建 Joy_Controller（层索引 " + idx + "），边界矩形已可视化。");
        } catch (e) {
            alert("创建失败: " + e.toString());
        }
        app.endUndoGroup();
    }

    function doBind() {
        var comp = getComp();
        if (!comp) { alert("请先在项目面板激活一个合成。"); return; }
        var joySel = selData(ui.joyDrop, joyItems);
        if (!joySel) { alert("请先选择 Joy 控制层（没有就点「创建 Joy 控制层」）。"); return; }
        var joyIdx = joySel.idx;
        var joy = null;
        try { joy = comp.layer(joyIdx); } catch (eJoy) { joy = null; }
        if (joy === null) {
            alert("Joy 层引用失败（图层列表可能已变化），请点「刷新」后重试。");
            return;
        }
        var bnds = readBounds(comp);
        if (!bnds) { return; }

        var props = gatherProps(comp);
        if (props.length === 0) {
            alert("未找到可绑定的属性。\n请用「选属性…」从目标层挑选，或先在时间线中选中目标属性再点绑定。");
            return;
        }

        var withBias = ui.biasChk.value;
        var capture = ui.capChk.value;

        var okCount = 0;
        var errs = [];
        app.beginUndoGroup("JNS Clone: 绑定姿势插值");
        if (withBias) { ensureBias(joy); }
        for (var i = 0; i < props.length; i++) {
            var pr = props[i].prop;
            var label = props[i].label;
            try {
                var dim = props[i].dim;
                if (!dim || dim < 1) { dim = dimOf(pr); }
                if (dim < 1) { errs.push(label + " : 不可绑定的值类型"); continue; }
                // 防自环：不允许把 Joy 层自己的位置绑到 Joy 位置上
                var ol = ownerLayerOf(pr);
                var olIdx = -1;
                if (ol !== null) {
                    for (var li = 1; li <= comp.numLayers; li++) {
                        if (comp.layer(li) === ol) { olIdx = li; break; }
                    }
                }
                if (olIdx === joyIdx &&
                    (pr.matchName === "ADBE Position" || pr.matchName === "ADBE Position_0" ||
                     pr.name === "Position" || pr.name === "位置")) {
                    errs.push(label + " : Joy 层自身位置不能绑到 Joy 位置（自环）");
                    continue;
                }
                var base = uniqueBase(joy, sanitizeName(pr.name));
                var initVals = capture ? currentComponents(pr, dim) : null;
                createCornerEffects(joy, base, dim, initVals, capture);
                var expr = buildExpression(joyIdx, bnds, dim, base, withBias);
                pr.expression = expr;
                okCount++;
            } catch (eBind) {
                errs.push(label + " : " + eBind.toString());
            }
        }
        app.endUndoGroup();

        var msg = "绑定完成: " + okCount + " 个属性。";
        if (errs.length > 0) {
            msg += "\n失败 " + errs.length + " 个:\n  " + errs.join("\n  ");
        }
        msg += "\n摆姿势: 打开 Joy 层效果控件，调 JNS|<属性>|TL/TR/BL/BR 四个角点值。";
        setInfo(msg);
    }

    function doClearExpressions() {
        var comp = getComp();
        if (!comp) { alert("请先在项目面板激活一个合成。"); return; }
        var sel = comp.selectedProperties;
        if (!sel || sel.length === 0) {
            alert("请先在时间线中选中要解除绑定的属性。");
            return;
        }
        var n = 0;
        app.beginUndoGroup("JNS Clone: 移除表达式");
        for (var i = 0; i < sel.length; i++) {
            try {
                sel[i].expression = "";
                n++;
            } catch (e) { /* 不可移除表达式的属性，忽略 */ }
        }
        app.endUndoGroup();
        setInfo("已移除 " + n + " 个属性的表达式（JNS| 滑杆效果保留，可手动删除）。");
    }

    // ------------------------------------------------------- 列表与边界 UI

    function refreshLists() {
        ui.joyDrop.removeAll();
        ui.tgtDrop.removeAll();
        joyItems = [];
        tgtItems = [];
        var comp = getComp();
        if (!comp) {
            setInfo("未检测到激活的合成。请先在项目面板双击某个合成。");
            prefillBounds(null);
            return;
        }
        for (var i = 1; i <= comp.numLayers; i++) {
            var ly = comp.layer(i);
            joyItems.push({ idx: i, name: ly.name });
            tgtItems.push({ idx: i, name: ly.name });
            ui.joyDrop.add("item", i + ": " + ly.name);
            ui.tgtDrop.add("item", i + ": " + ly.name);
        }
        // 默认 Joy 层：名字含 joy（不区分大小写）者优先，否则第 1 层
        var joyDefault = 0;
        for (var j = 0; j < joyItems.length; j++) {
            if (joyItems[j].name.toLowerCase().indexOf("joy") >= 0) { joyDefault = j; break; }
        }
        if (joyItems.length > 0 && ui.joyDrop.items.length > joyDefault) {
            ui.joyDrop.selection = joyDefault;
        }
        // 默认目标层：当前合成里选中的第一个图层（且不是 Joy 层）
        var tgtDefault = (joyDefault === 0 && joyItems.length > 1) ? 1 : 0;
        if (comp.selection && comp.selection.length > 0) {
            var sl = comp.selection[0];
            if (sl instanceof TextLayer || sl instanceof ShapeLayer ||
                sl instanceof AVLayer || sl instanceof CameraLayer || sl instanceof LightLayer) {
                for (var k = 0; k < tgtItems.length; k++) {
                    if (tgtItems[k].idx === sl.index) { tgtDefault = k; break; }
                }
            }
        }
        if (tgtItems.length > 0 && ui.tgtDrop.items.length > tgtDefault) {
            ui.tgtDrop.selection = tgtDefault;
        }
        prefillBounds(comp);
        setInfo("就绪。合成: " + comp.name + "（" + comp.numLayers + " 层）");
    }

    function prefillBounds(comp) {
        if (comp === null || comp === undefined) {
            ui.etL.text = "0"; ui.etT.text = "0";
            ui.etR.text = "1920"; ui.etB.text = "1080";
            return;
        }
        ui.etL.text = "0";
        ui.etT.text = "0";
        ui.etR.text = String(comp.width);
        ui.etB.text = String(comp.height);
    }

    function onBoundsModeChange() {
        var custom = ui.rbCustom.value;
        ui.etL.enabled = custom;
        ui.etT.enabled = custom;
        ui.etR.enabled = custom;
        ui.etB.enabled = custom;
        if (!custom) {
            var comp = getComp();
            prefillBounds(comp);
        }
    }

    // ------------------------------------------------------- UI 组装

    function buildUI(thisObj) {
        var w = (thisObj instanceof Panel)
            ? thisObj
            : new Window("palette", "JNS Clone · Joystick 姿势插值", undefined, { resizeable: true });
        w.orientation = "column";
        w.alignChildren = ["fill", "top"];
        w.spacing = 6;
        w.margins = 10;

        // Joy 控制层
        var g1 = w.add("group");
        g1.orientation = "row";
        g1.alignChildren = ["left", "center"];
        g1.add("statictext", undefined, "Joy 控制层");
        var joyDrop = g1.add("dropdownlist");
        joyDrop.preferredSize.width = 210;
        var joyRefresh = g1.add("button", undefined, "刷新");
        joyRefresh.preferredSize.width = 48;
        joyRefresh.helpTip = "重新读取当前合成的图层列表";

        // 目标图层
        var g2 = w.add("group");
        g2.orientation = "row";
        g2.alignChildren = ["left", "center"];
        g2.add("statictext", undefined, "目标图层");
        var tgtDrop = g2.add("dropdownlist");
        tgtDrop.preferredSize.width = 210;
        var pickBtn = g2.add("button", undefined, "选属性…");
        pickBtn.helpTip = "从目标图层挑选要绑定的数值属性（可多选）";

        // 待绑定列表
        var g3 = w.add("group");
        g3.orientation = "column";
        g3.alignChildren = ["fill", "top"];
        g3.add("statictext", undefined, "待绑定属性（留空则使用时间线中选中的属性）：");
        var pickedList = g3.add("listbox");
        pickedList.preferredSize = [300, 60];
        var clrBtn = g3.add("button", undefined, "清空列表");
        clrBtn.preferredSize.width = 90;

        // 边界
        var gb = w.add("panel", undefined, "插值边界（Joy 位置在此矩形内归一化）");
        gb.orientation = "column";
        gb.alignChildren = ["left", "top"];
        gb.margins = [10, 8, 10, 8];
        gb.spacing = 4;
        var gr1 = gb.add("group");
        gr1.orientation = "row";
        var rbComp = gr1.add("radiobutton", undefined, "合成边界");
        rbComp.value = true;
        var rbCustom = gr1.add("radiobutton", undefined, "自定义");
        var gr2 = gb.add("group");
        gr2.orientation = "row";
        gr2.add("statictext", undefined, "左");
        var etL = gr2.add("edittext"); etL.characters = 7;
        gr2.add("statictext", undefined, "上");
        var etT = gr2.add("edittext"); etT.characters = 7;
        gr2.add("statictext", undefined, "右");
        var etR = gr2.add("edittext"); etR.characters = 7;
        gr2.add("statictext", undefined, "下");
        var etB = gr2.add("edittext"); etB.characters = 7;

        // 选项
        var go = w.add("group");
        go.orientation = "row";
        var capChk = go.add("checkbox", undefined, "初始姿势=当前值");
        capChk.value = true;
        capChk.helpTip = "绑定时把目标属性当前值写入 4 个角点（中性起步）";
        var biasChk = go.add("checkbox", undefined, "添加 EaseBias");
        biasChk.helpTip = "在 Joy 层加 0-100 偏置滑杆：值越大，中性区越平滑（S 曲线）";

        // 按钮
        var gc1 = w.add("group");
        gc1.orientation = "row";
        var mkJoyBtn = gc1.add("button", undefined, "创建 Joy 控制层");
        mkJoyBtn.helpTip = "创建带边界矩形可视化的 Joy 控制层（位置在边界中心）";
        var bindBtn = gc1.add("button", undefined, "绑定 → 生成表达式");
        var gc2 = w.add("group");
        gc2.orientation = "row";
        var clrExprBtn = gc2.add("button", undefined, "移除选中属性表达式");
        var helpBtn = gc2.add("button", undefined, "帮助");

        // 信息区
        var info = w.add("statictext", undefined, "就绪。", { multiline: true });
        info.preferredSize = [320, 52];
        var foot = w.add("statictext", undefined,
            "clean-room 复刻 v" + VERSION + " · 原版: Joysticks 'n Sliders ($39.95, aescripts.com)");

        ui = {
            win: w,
            joyDrop: joyDrop, tgtDrop: tgtDrop,
            pickedList: pickedList,
            rbComp: rbComp, rbCustom: rbCustom,
            etL: etL, etT: etT, etR: etR, etB: etB,
            capChk: capChk, biasChk: biasChk,
            info: info
        };

        joyRefresh.onClick = refreshLists;
        pickBtn.onClick = pickProps;
        clrBtn.onClick = function () {
            pickedProps = [];
            updatePickedList();
        };
        rbComp.onClick = onBoundsModeChange;
        rbCustom.onClick = onBoundsModeChange;
        mkJoyBtn.onClick = doCreateJoy;
        bindBtn.onClick = doBind;
        clrExprBtn.onClick = doClearExpressions;
        helpBtn.onClick = function () {
            alert(
                "快速上手:\n" +
                "1. 激活合成 -> 点「创建 Joy 控制层」（黄色矩形=插值边界）。\n" +
                "2. 选目标图层 -> 「选属性…」勾选要绑定的属性\n   （或直接在时间线选中属性）。\n" +
                "3. 设定边界（合成边界或自定义数值）。\n" +
                "4. 点「绑定 -> 生成表达式」。\n" +
                "5. 摆姿势: 选中 Joy 层，在效果控件里调\n   JNS|<属性>|TL/TR/BL/BR 四个角点值。\n" +
                "6. 拖动 Joy 层位置: 四角姿势按双线性权重混合。\n\n" +
                "注意: Joy 层用索引引用，删除/重排图层会使表达式错位。\n" +
                "详情见同目录 README.md。"
            );
        };
        w.onResizing = w.onResize = function () { this.layout.resize(); };

        refreshLists();
        if (w instanceof Window) { w.show(); }
        return w;
    }

    function main(thisObj) {
        buildUI(thisObj);
    }

    // 对外暴露（便于其他脚本/调试调用核心逻辑）
    return {
        main: main,
        version: VERSION,
        buildExpression: buildExpression
    };
})();

// 入口：作为 ScriptUI Panel 停靠时 this 为 Panel；脚本方式运行时 this 为全局对象
JNSC.main(this);
