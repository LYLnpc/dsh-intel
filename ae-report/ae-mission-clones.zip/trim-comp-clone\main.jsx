#target aftereffects

/**************************************************************************
 * Trim Comp to Contents Clone  v1.0.0  (ExtendScript .jsx for AE)
 * ------------------------------------------------------------------------
 * CLEAN-ROOM REIMPLEMENTATION NOTICE:
 * Written from scratch from the public one-line product description
 * ("Trim or extend comp duration to fit layer contents") plus general
 * After Effects Scripting API knowledge. No original source, installer,
 * binary or resource of the commercial script was obtained, inspected,
 * decompiled or referenced.
 * ------------------------------------------------------------------------
 * ES3 / ExtendScript only: no let/const, no arrow functions, no JSON,
 * no ES5+ array extras. ASCII-only source on purpose.
 **************************************************************************/

(function trimCompClone(thisObj) {

    var SCRIPT_NAME = "Trim Comp to Contents Clone";
    var VERSION = "1.0.0";

    /* ==================================================================
     *  Small helpers
     * ================================================================== */

    function getActiveComp() {
        if (!app.project) { return null; }
        var it = app.project.activeItem;
        if (!it || !(it instanceof CompItem)) { return null; }
        return it;
    }

    function num(v, fallback) {
        var n = parseFloat(v);
        if (isNaN(n)) { return fallback; }
        return n;
    }

    // Round a time to the nearest whole frame of the given comp.
    function snapToFrame(t, comp) {
        var fd = comp.frameDuration;
        if (!fd || fd <= 0) { return t; }
        return Math.round(t / fd) * fd;
    }

    /* ==================================================================
     *  Content range detection
     * ================================================================== */

    // Walks every layer of comp and returns {start, end} in comp seconds.
    // start/end are the earliest content time and latest content time.
    //
    // Rules:
    //  - guide layers and (optionally) disabled layers are ignored.
    //  - A precomp layer whose outPoint was clipped by a too-short comp is
    //    re-extended from its source comp duration * stretch, because its
    //    own outPoint no longer reflects the real content length.
    //  - A precomp layer starting before 0 (clipped head) is re-extended
    //    back to its negative startTime.
    //  - time-remapped layers are taken at face value (outPoint).
    function contentRange(comp, opt) {
        var start = null;
        var end = null;
        var i;
        var L;
        var s;
        var e;

        for (i = 1; i <= comp.numLayers; i++) {
            L = comp.layer(i);
            if (opt.skipGuides && L.guideLayer) { continue; }
            if (opt.skipDisabled && !L.enabled) { continue; }
            if (opt.onlySelection && comp.selectedLayers.length > 0) {
                var hit = false;
                var k;
                for (k = 0; k < comp.selectedLayers.length; k++) {
                    if (comp.selectedLayers[k] === L) { hit = true; break; }
                }
                if (!hit) { continue; }
            }

            s = L.inPoint;
            e = L.outPoint;

            if (opt.followPrecomps && L.source && (L.source instanceof CompItem) && !L.timeRemapEnabled) {
                var stretch = L.stretch;
                if (!stretch || stretch <= 0) { stretch = 1; }
                var trueEnd = L.startTime + L.source.duration * stretch;
                if (trueEnd > e) { e = trueEnd; }
                if (L.startTime < s) { s = L.startTime; }
            }

            if (start === null || s < start) { start = s; }
            if (end === null || e > end) { end = e; }
        }

        return { start: start, end: end };
    }

    /* ==================================================================
     *  Actions
     * ================================================================== */

    function applyTrim(comp, opt) {
        var range = contentRange(comp, opt);
        var info = {
            ok: false,
            message: "",
            before: comp.duration,
            after: comp.duration,
            start: range.start,
            end: range.end,
            shifted: 0
        };

        if (range.start === null || range.end === null) {
            info.message = "No usable layer found in this comp.";
            return info;
        }

        var start = range.start;
        var end = range.end;

        // Optional head normalisation: slide every layer so contents begin at 0.
        var shouldShift = opt.snapToZero && start > 0;
        var offset = shouldShift ? start : 0;

        var newStart = start - offset;
        var newEnd = end - offset;

        // Optional tail padding in frames.
        var padFrames = num(opt.padFrames, 0);
        if (padFrames !== 0) {
            newEnd = newEnd + padFrames * comp.frameDuration;
            if (padFrames > 0) { newEnd = Math.ceil(newEnd / comp.frameDuration) * comp.frameDuration; }
        }

        newEnd = snapToFrame(newEnd, comp);
        newStart = snapToFrame(newStart, comp);

        var newDuration = newEnd - newStart;

        if (newDuration <= 0) {
            info.message = "Computed duration is zero or negative; nothing to do.";
            return info;
        }

        app.beginUndoGroup(SCRIPT_NAME + " - trim to contents");

        try {
            // 1. Shift first, while the comp still has its old length, so no
            //    layer gets clipped by the move.
            if (offset !== 0) {
                var i;
                for (i = 1; i <= comp.numLayers; i++) {
                    var L = comp.layer(i);
                    try {
                        L.startTime = L.startTime - offset;
                    } catch (eShift) { /* locked layer: leave it */ }
                }
                info.shifted = offset;
            }

            // 2. Grow before shrinking: growing never destroys keyframe data.
            if (newDuration > comp.duration) {
                comp.duration = newDuration;
            }

            // 3. Work area follows the new contents.
            comp.workAreaStart = 0;
            comp.workAreaDuration = comp.duration;

            // 4. Shrink last (this clips layers that extend past the end,
            //    which is exactly the requested trim).
            if (newDuration < comp.duration) {
                comp.duration = newDuration;
            }

            info.ok = true;
            info.after = comp.duration;
            info.message = "Trimmed: " + comp.duration.toFixed(3) + "s (" +
                Math.round(comp.duration * comp.frameRate) + " frames).";
        } catch (err) {
            info.message = "Failed: " + err.toString();
        } finally {
            app.endUndoGroup();
        }

        return info;
    }

    /* ==================================================================
     *  UI
     * ================================================================== */

    function buildUI(thisObj) {
        var pal = (thisObj instanceof Panel) ? thisObj : new Window("palette", SCRIPT_NAME + " " + VERSION, undefined, { resizeable: true });
        pal.orientation = "column";
        pal.alignChildren = ["fill", "top"];
        pal.spacing = 8;
        pal.margins = 12;

        var head = pal.add("group");
        head.orientation = "column";
        head.alignChildren = ["left", "top"];
        head.spacing = 2;
        var compText = head.add("statictext", undefined, "Comp: -");
        var rangeText = head.add("statictext", undefined, "Contents: -");
        var durText = head.add("statictext", undefined, "Duration: -");
        var targetText = head.add("statictext", undefined, "Target: -");

        var optBox = pal.add("panel", undefined, "Options");
        optBox.orientation = "column";
        optBox.alignChildren = ["left", "top"];
        optBox.margins = 10;
        optBox.spacing = 4;

        var cbGuides = optBox.add("checkbox", undefined, "Ignore guide layers");
        cbGuides.value = true;
        var cbDisabled = optBox.add("checkbox", undefined, "Ignore disabled layers");
        cbDisabled.value = false;
        var cbPrecomp = optBox.add("checkbox", undefined, "Follow nested precomp length");
        cbPrecomp.value = true;
        var cbZero = optBox.add("checkbox", undefined, "Slide contents to start at 0");
        cbZero.value = false;
        var cbSel = optBox.add("checkbox", undefined, "Only selected layers (if any selected)");
        cbSel.value = false;

        var padRow = pal.add("group");
        padRow.alignment = ["fill", "top"];
        padRow.add("statictext", undefined, "Tail padding (frames):").preferredSize.width = 150;
        var padEdit = padRow.add("edittext", undefined, "0");
        padEdit.characters = 6;

        var btnRow = pal.add("group");
        btnRow.alignment = ["fill", "top"];
        var btnRefresh = btnRow.add("button", undefined, "Refresh");
        var btnTrim = btnRow.add("button", undefined, "Trim to Contents");
        btnTrim.preferredSize.width = 150;

        var status = pal.add("statictext", undefined, " ", { multiline: true });
        status.preferredSize.width = 330;

        function readOptions() {
            return {
                skipGuides: cbGuides.value,
                skipDisabled: cbDisabled.value,
                followPrecomps: cbPrecomp.value,
                snapToZero: cbZero.value,
                onlySelection: cbSel.value,
                padFrames: num(padEdit.text, 0)
            };
        }

        function refresh() {
            var comp = getActiveComp();
            if (!comp) {
                compText.text = "Comp: (open a comp)";
                rangeText.text = "Contents: -";
                durText.text = "Duration: -";
                targetText.text = "Target: -";
                return;
            }
            var opt = readOptions();
            var r = contentRange(comp, opt);
            compText.text = "Comp: " + comp.name;
            durText.text = "Duration: " + comp.duration.toFixed(3) + "s (" +
                Math.round(comp.duration * comp.frameRate) + " frames)";
            if (r.start === null) {
                rangeText.text = "Contents: (no layers)";
                targetText.text = "Target: -";
                return;
            }
            rangeText.text = "Contents: " + r.start.toFixed(3) + "s -> " + r.end.toFixed(3) + "s";
            var offset = (opt.snapToZero && r.start > 0) ? r.start : 0;
            var tEnd = r.end - offset + num(opt.padFrames, 0) * comp.frameDuration;
            var tDur = snapToFrame(tEnd, comp);
            targetText.text = "Target: " + tDur.toFixed(3) + "s (" + Math.round(tDur * comp.frameRate) + " frames)";
        }

        btnRefresh.onClick = function () {
            refresh();
            status.text = "";
        };

        btnTrim.onClick = function () {
            var comp = getActiveComp();
            if (!comp) {
                status.text = "Open a composition first.";
                return;
            }
            var opt = readOptions();
            var info = applyTrim(comp, opt);
            status.text = info.message;
            refresh();
        };

        padEdit.onChanging = function () { refresh(); };
        cbGuides.onClick = refresh;
        cbDisabled.onClick = refresh;
        cbPrecomp.onClick = refresh;
        cbZero.onClick = refresh;
        cbSel.onClick = refresh;

        pal.onResizing = pal.onResize = function () { this.layout.resize(); };

        refresh();
        return pal;
    }

    var ui = buildUI(thisObj);
    if (ui instanceof Window) {
        ui.center();
        ui.show();
    } else {
        ui.layout.layout(true);
    }

})(this);
