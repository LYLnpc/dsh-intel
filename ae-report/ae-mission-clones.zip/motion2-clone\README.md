# M2 Clone (clean-room)

- generated_at: 2026-11-14T07:55:00+08:00
- task: ae-mission / clean-room 复刻 Motion 2 核心功能集（ExtendScript jsx）

## Clean-room 声明

本项目为 **clean-room 复刻**：仅依据 `intel/paid-list.md` 中 Motion 2 条目的**文字功能描述**（Ease / Burst / Anchor Point / Direction 等功能清单）独立实现。未反编译、未下载、未参考任何 Motion 2 原始代码或资源；全部数学推导、代码结构、命名与表达式均为原创。Motion 2 是 Mt. Mograph 的商业产品（$65），本项目不包含也不替代其授权代码，仅复刻其公开宣传的核心**功能思路**。

## 产出

- `main.jsx` —— ExtendScript 面板（ScriptUI），ES3 语法，顶部含 clean-room 声明。

## 安装与运行

1. 复制 `main.jsx` 到 AE 脚本目录（可停驻面板）：
   - Windows: `C:\Program Files\Adobe\Adobe After Effects <版本>\Support Files\Scripts\ScriptUI Panels\`
2. 重启 AE，菜单 Window 底部出现 `main.jsx`；或直接 `File > Scripts > Run Script File...` 运行为浮动面板。
3. 若提示允许脚本读写，勾选 `Edit > Preferences > Scripting & Expressions > Allow Scripts to Write Files and Access Network`（本工具本身不写文件，仅为常规建议）。

## 功能对照（原版 Motion 2 paid-list 功能点 vs 本克隆）

| Motion 2 功能点（paid-list 描述） | 本克隆状态 | 说明 |
|---|---|---|
| Anchor Point 工具（锚点移到几何中心/指定点，画面不动） | ✅ 已复刻 | 3×3 网格目标（角/边/中心），toComp/fromComp 逐关键帧精确补偿，支持父级/旋转/缩放 |
| Direction（动画方向相关工具） | 🔁 变体实现 | 原版为交换首尾关键帧值翻转方向；本克隆改为 velocityAtTime 驱动的 rotation 朝向 + scale 挤压拉伸（motion direction 联动） |
| Ease 滑块（一键写入 keyframeEase） | ❌ 未复刻 | 属 Flow 类缓动编辑，见 flow-clone |
| Burst（放射状爆发图形） | ❌ 未复刻 | — |
| Clone/复制关键帧 | ❌ 未复刻 | — |
| Rig（父子绑定辅助） | ❌ 未复刻 | — |
| （自扩展）弹性后处理预设 | ➕ 新增 | elastic/bounce/pendulum 衰减正弦表达式，amp/freq/decay 可调；原版没有的免费增值项 |

## 功能区说明

### 1. Smart Anchor Move（锚点智能移动）

- 3×3 网格按钮：把选中图层的锚点移到图层内容包围盒（`sourceRectAtTime`，退化用图层宽高）的左上/中上/右上/左中/中心/右中/左下/中下/右下。
- **位置补偿数学**：移动前按每个 position 关键帧时间 `t` 采集锚点的合成空间点 `P = toComp(oldAnchor, t)`；改锚点后令 `position(t) = fromComp(P, t)`。由于 `toComp/fromComp` 内部包含父级链、旋转、缩放变换，该补偿在 2D 图层、任意父级/旋转/缩放组合下是**精确**的（Δposition = R·S·Δanchor 的推广形式，由引擎代算）。
- 关键帧：position 有动画时逐关键帧分别补偿；anchorPoint 有动画的图层跳过（避免歧义）；3D 图层、摄像机/灯光跳过并在状态栏提示。

### 2. Keyframe Direction Tools（关键帧方向联动）

- **Dir > Rotation**：给选中图层 rotation 写入表达式。取 position 最近关键帧区间中点的速度向量 `velocityAtTime(midT)`，`radiansToDegrees(atan2(v[1], v[0]))` 让图层朝运动方向旋转（y 向下坐标系，0° 朝右、90° 朝下）。速度近零时保持原值。
- **Speed > Squash**：给 scale 写入速度驱动的挤压拉伸表达式：`k = min(|v|*0.06, 60)/100`，`scale.x*(1+k)`、`scale.y/(1+k)`（近似体积守恒）。增益/上限是文件顶部常量 `SQUASH_GAIN` / `SQUASH_MAX`。
- 前提：position 至少 2 个关键帧；表达式实时响应关键帧移动，不需要重新生成。

### 3. Spring Presets（弹性/缓动一键预设）

- 对**选中的关键帧所在属性**（未选关键帧则回退到选中图层的 position）挂后处理表达式，三种模式：
  - `elastic`：过冲弹簧 `value + V·A·sin(2πFt)/e^(Dt)`，V 为进入该关键帧的速度（在关键帧前半帧采样 `velocityAtTime(key(n).time - frameDuration/10)`）；
  - `bounce`：单边反弹 `value + V·A·|sin(πFt)|/e^(Dt)`（触地不穿透的视觉近似）；
  - `pendulum`：固定幅值摆动 `value + A·sin(2πFt)/e^(Dt)`（不依赖速度；amp 字段 1 单位 = 1000 度，0.02 = 20°）。
- 参数：amp（弹性系数）、freq（频率 Hz）、decay（衰减指数），均可 UI 调节并注入表达式。
- 与缓动的关系：本区做的是关键帧**后处理**（速度驱动的物理扰动），与「写入 keyframeEase」的缓动编辑互补。

## 已知边界（诚实声明）

- 仅支持 2D 图层（3D 层的锚点补偿与投影数学未做）。
- Smart Anchor Move 依赖 `sourceRectAtTime`，空图层/极小内容回退到图层宽高。
- Squash 沿 x 轴固定拉伸，不做沿运动方向的旋转拉伸合成。
- 表达式为英文注释（避免 ExtendScript 无 BOM 时的编码问题）；面板标签为英文同理。
- 未实现 Motion 2 的 Ease 滑块（keyframeEase 批量写入）、Burst、Clone、Rig（见 paid-list.md 功能清单，属后续迭代）。

## 自查记录

- `node --check main.jsx` 通过（语法有效；无 `#target` 指令以保证 node 可解析）。
- ES3 扫描：无 let/const/箭头函数/Array.prototype 高阶方法/Object.keys/JSON/String.trim/Date.now/for-of 等 ES5+ 特性。
- AE 实测项（待人工）：面板停靠、中文 AE 版本 UI 显示、undo 组还原完整性。
