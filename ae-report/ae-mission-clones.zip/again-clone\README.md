---
generated_at: 2026-11-14T08:05:00+08:00
task: ae-mission / clean-room 复刻 Again!（关键帧循环/以新起点重复动画），ExtendScript jsx；输入 = intel/paid-list.md #19 Again! 条目（功能性描述，[未核实细节]），不反编译不参考原代码
---

# AG Clone（Again! 风格关键帧循环工具 · clean-room 复刻）

- 产出：`main.jsx`（ExtendScript，ES3，ScriptUI 面板）
- 输入依据：`intel/paid-list.md` #19 "Again!"（Adam Sacks，$5 NYOP）的核心功能一句话——**"以新起点值重复动画：把既有动画的运动模式套到新的起始值上（换起点重复同一段运动）"**，源条目标注 [未核实细节]；本克隆按任务下发的功能基线实现，不猜测原版内部细节
- 实现方式：AE 原生 `loopIn/loopOut` 表达式 + 自定义区间重放表达式（`valueAtTime` 段内采样，递归深度 ≤ 2）+ 时间重映射循环

## CLEAN-ROOM 声明

1. 本复刻为清室实现：未反编译、未阅读、未复制 Again! 原始代码，仅依据公开商品页的功能性描述与任务功能基线从零编写。
2. 表达式核心为 AE 官方表达式语言（`loopIn/loopOut` 为 AE 内置函数）与公开数学（模运算区间映射、smoothstep），不构成对原作品表达性内容的复制。
3. 仅供学习研究；Again! 商标与著作权归 Adam Sacks 所有。需要完整功能请购买正版（aescripts.com，$5 NYOP）。

## 功能对照（任务基线 vs 本克隆）

| 功能点（任务功能基线） | 本克隆状态 | 说明 |
|---|---|---|
| 标准循环：loopIn/loopOut × cycle/pingpong/offset/continue | ✅ 一键应用 | 生成 AE 原生 `loopOut("mode")` / `loopIn("mode")` 表达式，作用对象 = 选中关键帧所在属性 |
| 自定义循环区间与次数 | ✅ | 选中关键帧首尾键自动推断区间 [K1..K2]（未选键则整条属性首尾键），REPS=0 无限；cycle 重放段、offset 每轮累加段内值差（Again! 式"以新起点重复运动"） |
| pingpong 带插值回摆 | ✅ | 自定义回摆表达式：去程 t0→t1、回摆 t1→t0，可选 smoothstep（x²(3−2x)）缓动回摆，REPS 可限次 |
| 时间重映射循环 | ✅ | 对选中图层 `timeRemapEnabled = true`（可关）后写入 `loopOut("mode")`；失败时逐层报错并提示手动 Layer > Time > Enable Time Remapping |
| UI 预设一键应用 | ✅ | 四区面板：标准循环 / 自定义区间（cycle、offset）/ pingpong 回摆 / 时间重映射，各一个 Apply |
| 选中关键帧自动推断循环段 | ✅ | `prop.selectedKeys`（1-based，手工数值 min/max）优先；无选中键用 1..numKeys；"Show detected segment" 按钮显示推断区间与时间 |

## 安装

- 方式 A（可停靠面板）：`main.jsx` 放入 `Support Files\Scripts\ScriptUI Panels\`，重启 AE，Window 菜单打开。
- 方式 B：`File > Scripts > Run Script File...` 直接运行。
- 需在 `Edit > Preferences > Scripting & Expressions` 允许脚本运行（新版 AE 默认允许）。

## 使用（上手第一个动作）

1. 在时间线选中一个带 ≥2 个关键帧的属性（或选中其部分关键帧 = 循环段）。
2. **标准循环**：点 Zone 1 Apply → 段后立刻循环。适合首尾同值的弹跳/摆动（cycle）。
3. **Again! 式重复**：Zone 2 选 `offset (Again! style)` → Apply → 每一轮重复都以前一轮终点为新起点再走一遍同样的相对运动（值持续前进，不回头）。
4. **回摆循环**：Zone 3 Apply → 段尾平滑摆回段首（勾选 smoothstep 时回摆带缓动）。
5. **素材循环**：选中视频层 → Zone 4 Apply → 时间重映射循环播放素材（先勾 enable time remap 自动启用）。

## 数学说明（自行推导）

- 区间重放：`raw = time − t1`，第 n 轮 = `floor(raw/seg)+1`，段内映射 `tt = t0 + (raw % seg) ∈ [t0, t1)`。
- offset（Again! 式）：第 n 轮值 = `valueAtTime(tt) + (v(t1) − v(t0)) × n`——段首尾值差 delta 每轮累加，保证 `time→t1+` 时与上一轮终点值连续（`v(t0)+delta = v(t1)`）；若首尾同值则退化为 cycle。
- pingpong：周期 = 2·seg；`rem < seg` 走去程映射，否则回摆 `tt = t1 − ease(x)·seg`，ease 可选 smoothstep。
- **递归安全性**：`valueAtTime` 对带表达式的属性会先求值表达式；本表达式只在 `time > t1` 分支采样，且采样点 `tt ≤ t1` 恒成立（回摆端点 x=0 时 `tt=t1` 也不满足 `time > t1`），故嵌套一层即落入纯 `value` 分支，**递归深度 ≤ 2**，无栈风险。

## 限制（如实说明）

1. **未在 AE 实机验证**（本环境无 After Effects）；API 名对照 docs/api-cheatsheet.md 核实（`timeRemapEnabled` 可写性官方指南未明确标注，已包 try/catch，失败会提示手动启用）。
2. 自定义区间表达式会**覆盖段后原有关键帧动画**（t1 之后的既有关键帧不再生效）——这是"选中段循环"的语义，README 明示。
3. `valueAtTime` 采样保留原关键帧 easing（好于手工线性插值），但属性上若已有其他表达式会被本表达式覆盖。
4. cycle 模式在段首尾值不同时会有跳变（AE 原生 cycle 同行为）；需要平滑衔接用 offset 或 pingpong。
5. offset 的 delta 取自段首尾**值差**（不含速度方向语义）；段尾恰为 HOLD 插值时回放形状与原段逐帧一致。
6. `loopIn` 与 `loopOut` 不能同时一键生成（AE 中两者叠加的求值顺序易出错），面板刻意只做单侧，需要双侧时手动组合。
7. 时间重映射循环以"合成秒"为单位（AE timeRemap 语义），反转/变速素材请先确认段边界。

## 自查记录（2026-11-14）

1. `node --check`：通过（剥离 BOM 后复制为 .js 检查）。
2. ES3 扫描（let/const/箭头/JSON.stringify/模板串/forEach/map/filter/for-of/Object.keys/trim）：代码零命中。
3. API 对照 api-cheatsheet.md：`selectedKeys`（1-based，手工 min/max）、`numKeys`、`expression`、`canSetExpression`、`propertyType` 字符串嗅探 `'PROPERTY'`、`timeRemapEnabled`（try/catch）、undo 组 try/finally 成对——全部按白名单写法。
