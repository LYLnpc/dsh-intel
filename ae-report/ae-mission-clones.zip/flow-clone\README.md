# Flow Clone（clean-room 复刻）

一个 ExtendScript (jsx) 编写的 After Effects 缓动曲线工具，clean-room 方式复刻收费脚本
**Flow**（aescripts + aeplugins 出品）的核心功能：**预设缓动曲线库 + 选中关键帧一键应用 + 强度/速度参数调节**。

## Clean-room 重实现声明

本脚本**仅依据公开的功能描述**与标准公开数学资料（cubic-bezier 缓动定义、Penner 风格缓动方程、
CSS cubic-bezier 预设值）以及 Adobe 官方 After Effects 脚本 API 文档独立重写。
**未使用、未查看、未复制原作 Flow 的任何源代码、反编译产物或内部数据文件。**
行为上的相似仅限于公开功能描述本身与标准数学所决定的部分。

## 功能对照表（原版 Flow vs 本克隆）

| 原版 Flow 功能 | 本克隆状态 | 说明 |
|---|---|---|
| 预设缓动曲线库（按强度分级） | ✅ 已复刻 | 内置 16 条预设（12 条贝塞尔 + 4 条曲线函数），见下表 |
| 选中关键帧 → 一键应用缓动 | ✅ 已复刻 | 支持单关键帧（半曲线成形）与相邻关键帧对（整段曲线） |
| 强度（Intensity）/ 速度（Speed）参数调节 | ✅ 已复刻 | 全局滑杆/输入框，0.2–3.0 倍 |
| spring / bounce 类预设 | ✅ 已复刻（实现方式不同） | 原版用贝塞尔近似；本克隆用**逐帧采样插入中间关键帧**实现（AE 两个关键帧间的 temporal ease 无法表达数值过冲） |
| snappy（快速起停）预设 | ✅ 已复刻 | 以强 ease-out 型贝塞尔实现 |
| 曲线可视化编辑器（拖拽手柄） | ❌ 未复刻 | 仅有面板内曲线形状预览小图（只读） |
| 保存 / 加载 / 导入自定义预设 | ❌ 未复刻 | |
| 拖拽曲线到时间轴、曲线分享等交互 | ❌ 未复刻 | |
| 面板可停靠（Dockable Panel） | ✅ 已复刻 | ScriptUI Panel 版，放入 ScriptUI Panels 文件夹即可 |
| 浮动窗口运行 | ✅ 已复刻 | File > Scripts > Run Script File 以 palette 窗口运行 |
| 命令行 / 脚本调用 | ✅ 额外提供 | 原版没有的加分项：`--flc-*` 启动参数 + `$.global` API |

## 安装方法

1. 将 `main.jsx` 拷贝到 AE 的 **ScriptUI Panels** 文件夹：
   - Windows：`C:\Program Files\Adobe\Adobe After Effects <版本>\Support Files\Scripts\ScriptUI Panels\`
   - macOS：`/Applications/Adobe After Effects <版本>/Scripts/ScriptUI Panels/`
   - 建议重命名为 `Flow-Clone.jsx`（面板菜单显示文件名，更好认）。
2. **重启 After Effects**。
3. 菜单 **Window（窗口）** 底部会出现该脚本名，点击打开可停靠面板。

备用运行方式（不进面板）：`File > Scripts > Run Script File...` 直接运行，以浮动 palette 窗口出现。

## 使用方法

1. 在时间轴上**选中关键帧**（选中一段的两端关键帧效果最完整）；
2. 在面板选择预设曲线，调节 Intensity / Speed（0.2–3.0）；
3. 点击 **Apply to selected keyframes**。

应用规则：

- **相邻选中的关键帧对**：整条预设曲线作用于该段（起始关键帧写 out-ease，结束关键帧写 in-ease）。
- **单个选中的关键帧**（贝塞尔类预设）：入方向用曲线终点半段、出方向用曲线起点半段成形。
- **Overshoot / Spring / Bounce**：必须**同时选中一段的两端关键帧**；脚本会逐帧采样曲线函数并
  插入中间关键帧（先清除该段旧的中间关键帧，可安全重复应用）。单选关键帧时这类预设会被跳过并提示。
- 勾选 "No keys selected: use all keys..." 时，若属性上没有选中任何关键帧，则对该属性的全部关键帧
  生效（同时兼容不支持 `Property.selectedKeys` 的旧版 AE）。

## 预设曲线参数说明（16 条）

### 贝塞尔类（cubic-bezier 控制点 [x1,y1,x2,y2]，归一化 0–1 空间）

| # | 预设名 | 控制点 | 参考标准曲线 |
|---|---|---|---|
| 1 | Linear (reference) | (0, 0, 1, 1) | 线性参照 |
| 2 | Smooth - Light | (0.37, 0, 0.63, 1) | easeInOutSine |
| 3 | Smooth - Medium | (0.645, 0.045, 0.355, 1) | easeInOutCubic |
| 4 | Smooth - Strong | (1, 0, 0, 1) | easeInOutExpo（受 AE 手柄 ≤100% 约束自动收窄为陡 S 曲线） |
| 5 | Ease In - Light | (0.55, 0.085, 0.68, 0.53) | easeInQuad |
| 6 | Ease In - Medium | (0.55, 0.055, 0.675, 0.19) | easeInCubic |
| 7 | Ease In - Strong | (0.95, 0.05, 0.795, 0.035) | easeInExpo |
| 8 | Ease Out - Light | (0.25, 0.46, 0.45, 0.94) | easeOutQuad |
| 9 | Ease Out - Medium | (0.215, 0.61, 0.355, 1) | easeOutCubic |
| 10 | Ease Out - Strong | (0.19, 1, 0.22, 1) | easeOutExpo |
| 11 | Snappy - Light | (0.3, 0.75, 0.25, 1) | 快出缓停 |
| 12 | Snappy - Strong | (0.05, 0.9, 0.1, 1) | 极快出、立即停 |

**Intensity（强度）k**：将控制柄相对段角点的偏移量按 k 缩放（k>1 更激进、k<1 趋向线性）；
**Speed（速度）s**：将控制柄的时间跨度除以 s（s>1 响应更快、s<1 过渡铺得更开）。
换算后自动做 AE 约束钳制：手柄 y ∈ [0,1]，出/入影响度之和 ≤ ~100%。
AE 侧换算（官方 temporal ease 模型）：`outSpeed = y1·Δ / (x1·D)`、`inSpeed = (1−y2)·Δ / ((1−x2)·D)`、
`influence = x1·100 / (1−x2)·100`，其中 Δ 为该维度数值差、D 为段时长（秒）。
**多维度属性每维度各一组 KeyframeEase，速度按该维度数值差等比缩放**，保证各维度缓动手感一致。

### 曲线函数类（采样 f(t)，强度/速度作用于函数参数）

| # | 预设名 | 函数 | 默认参数 | 强度 k / 速度 s 的作用 |
|---|---|---|---|---|
| 13 | Overshoot (back out) | easeOutBack：`1 + (c1+1)(t−1)³ + c1(t−1)²` | c1 = 1.70158（约 10% 过冲） | k 缩放过冲幅度；s 无效 |
| 14 | Overshoot In-Out (back inOut) | easeInOutBack（标准公式，c2 = c1·1.525） | c1 = 1.70158 | k 缩放过冲/回拉幅度；s 无效 |
| 15 | Spring (damped oscillation) | 归一化衰减余弦：`(1 − e^(−λt)·cos(ωt)) / (1 − e^(−λ)·cos(ω))` | λ = 6/k，ω = 12s（默认约 21% 首峰过冲、约 2 个周期） | k 控制阻尼（k 大 = 弹得多）；s 控制振荡频率（k、s 均保持 f(0)=0、f(1)=1） |
| 16 | Bounce (settle) | 标准 easeOutBounce（n1=7.5625, d1=2.75），与线性按 k 混合 | k=1 为标准弹跳 | k<1 减弱弹跳（k=0 退化为线性）；s 无效 |

> 速度 s 对 13/14/16 无效是刻意设计（曲线形状由强度控制，避免端点失配），面板 Help 里有提示。

## 命令行 / 脚本调用

**启动参数（实验性，需 AE 16.0+，支持 `app.getCommandLineArguments` 的版本）：**

```
AfterFX.exe -r "C:\...\main.jsx" --flc-preset="Ease Out - Strong" --flc-intensity=1.5 --flc-speed=1
```

无 UI 直接作用于当前合成/选中项，结果写入脚本目录 `flc-cli-log.txt`。

**ExtendScript API（供其他脚本调用）：**

```javascript
$.global.flcApplyPreset("Ease Out - Strong", 1.5, 1.0, true);  // 返回报告对象
$.global.flcListPresets();                                     // 预设名数组
$.global.flcPresets;                                           // 完整预设表
```

## 已知限制

1. **关键帧选中检测**依赖 `Property.selectedKeys`；个别环境下该接口不可用时回退为"该属性全部关键帧"
   （面板勾选项控制），与"仅选中关键帧"的语义有差别。
2. Spring / Bounce / Overshoot 通过**插入中间关键帧**实现，会改变关键帧结构（每帧一个键）；
   应用前请考虑是否需要保留原始关键帧布局（有 Undo 组保护，Ctrl+Z 可整体撤销）。
   该类预设作用于**整段**，不支持单关键帧半段成形。
3. 两个关键帧间的 temporal ease 无法表达数值过冲，贝塞尔类预设的手柄 y 值被钳制在 [0,1]，
   影响度总和钳制 ≤ ~100%：Smooth - Strong（expo in-out）实际表现为陡 S 曲线而非真正的双指数。
4. 不支持 Color / Source Text / Shape path / Marker / Gradient 等非 1D/2D/3D 数值关键帧（自动跳过并计数）。
5. 命令行模式依赖 `app.getCommandLineArguments`（AE 16+）；旧版直接显示面板。
6. 曲线预览依赖 ScriptUI 绘图 API，个别 AE 版本可能不渲染（静默降级为文字，不影响功能）。
7. 纯逻辑已用 Node 数值自查（括号配平、ES3 扫描、曲线端点/越界/过冲验证、AE 手柄换算往返一致性），
   但本开发环境无 After Effects，**未在真实 AE 内做端到端运行验证**——首次使用建议先在测试工程上
   配合 Undo 验证。

## 文件清单

- `main.jsx` — 脚本本体（ES3 兼容 ExtendScript，含 clean-room 声明注释）
- `README.md` — 本文件
