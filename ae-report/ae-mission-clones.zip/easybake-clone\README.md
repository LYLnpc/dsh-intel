---
generated_at: 2026-11-14T00:22:00Z
task: 自主选件 clean-room 复刻（清单后半部分未复刻 A 类）——已选 Easy Bake（#25），产出 main.jsx + README；功能输入为 intel/paid-list.md #25 条目；未反编译、未接触原代码
---

# EasyBake Clone v1.0（Easy Bake 的 clean-room 复刻）

## 选件理由（清单后半部分未复刻项对比）

后半部分尚未复刻的 A 类 jsx 项：Easy Bake (#25)、Scribe (#26)、Trim Comp to Contents (#27)、Project Item Labels (#28)、Overlord (#29)、Move Anchor Point 4 (#30)、Keyframe Parent (#16)。

| 候选 | 为什么没选 |
|---|---|
| Scribe | 需要"自动字型库"= 字形轮廓提取，AE Scripting 无此 API，jsx 不可达 |
| Trim Comp to Contents | 核心功能依赖 `comp.duration` 可写，速查表未核实其可写性，主功能可能整体落空 |
| Overlord | 双宿主（Ai 扩展 + AE），超出单 jsx 范围 |
| Move Anchor Point 4 | 现售已是 aex 原生形态，v4 含 comp 裁剪等附加功能；逻辑虽 A 类但条目描述薄 |
| Keyframe Parent | "Parent keyframes" 语义不明，推断歧义大 |
| Project Item Labels | 可做但价值低（改标签色），且描述同样薄 |
| **Easy Bake（选中）** | 一句话描述定义了完整核心循环（表达式→关键帧烘焙），全流程仅用白名单 API（`valueAtTime(t,true)` 采样、`setValueAtTime`/`removeKey`），日常高频实用，与现有 17 个 clone 零重叠 |

## Clean-room 声明

仅依据公开的一句话功能描述（"Convert expressions to keyframes faster, simpler and with more control than ever before."）从零实现；未反编译/读取/复制/翻译任何原产品代码。烘焙循环 = 每帧采样 `valueAtTime(t, preExpression=true)` 的表达式前原始值并写回关键帧，是标准脚本手法。所有 AE API 按 `docs/api-cheatsheet.md` 白名单书写。

## 推断范围注明（重要）

官方条目仅一句话简介，原版的具体控制项不可知。**本工具的全部功能面（范围三选、步长、静态优化、表达式移除、范围内清键）均为本复刻对 "more control" 的推断定义**，非原版对照；复刻组/验收时按此口径核对。

## 功能对照

### 复刻栏（对应条目核心功能）

| 条目要点 | 本实现 |
|---|---|
| Convert expressions to keyframes | 逐帧采样 `valueAtTime(t, true)`（表达式前原始值）→ `setValueAtTime` 写线性关键帧；随后可选 `expression = ""` 交给关键帧接管 |
| faster, simpler | 选中属性/整层一键批量；单次 undo 组（try/finally 成对）；统计反馈（烘焙数/键数/清键数/跳过数） |
| more control | ①范围三选：工作区 / 图层 in-out（`parentProperty` 回溯属主层）/ 全合成；②采样步长 1–100 帧可调；③**静态优化**：值不变的采样段不写键（Hold 段收口时自动补前一键，容差 1e-7）；④**范围内清旧键**（烘焙前删除 [t1,t2] 内已有键，removeKey 降序删除）；⑤烘焙后是否移除表达式可选 |
| 批量与健壮 | 效果参数组递归收集表达式属性（层作用域，深度上限 12）；采样失败/写键失败/表达式移除失败逐条收集为 warning（上限 10 条展示），不中断整批；每属性采样上限 5000 帧 |

### 未复刻栏

1. 原版的交互细节/预设/进度条/热键（无从得知，未定义）；
2. SHAPE（蒙版/路径）、TEXT_DOCUMENT（源文本）、MARKER、CUSTOM_VALUE 类型属性不烘焙（表达式虽可能存在，但值对象回写易碎，刻意排除）；
3. 关键帧缓动保留/贝塞尔拟合（本实现统一线性插值；原版若有"保缓动"能力未复刻）；
4. 采样步长自动适配（如按曲线曲率加密采样）；
5. 跨合成/多 comp 批处理；
6. AE 实机冒烟（本环境无 AE）。

## 安装

`main.jsx` 拷入 AE 的 `ScriptUI Panels` 目录后从 Window 菜单打开；或 File > Scripts > Run Script File 直接运行。

## 使用

1. 时间线选中**带表达式的属性**（Scope=Selected properties），或选中图层（Scope=Selected layers）；
2. 设定范围（默认工作区——先在时间线拉好工作区）与步长；
3. BAKE。默认：清范围内旧键 + 静态优化开启、移除表达式关闭（烘焙后表达式仍在，可对比后手动删，或勾选自动删）。

## API 合规（对照 docs/api-cheatsheet.md）

- 白名单核心项：`valueAtTime(t, preExpression=true)`、`setValueAtTime`、`keyTime(i)`、`removeKey`（未用指南 0 命中的 `deleteKey`）、`setInterpolationTypeAtKey + KeyframeInterpolationType.LINEAR`、`setRovingAtKey`、`numKeys`、`expression`、`selectedProperties/selectedLayers`、`workAreaStart/workAreaDuration/duration/frameDuration`、`inPoint/outPoint`、`PropertyValueType.TwoD_SPATIAL`（混合大小写）。
- 白名单未收录、已按政策整体包 try/catch 的 API：`Property.parentProperty`（属主层回溯，失败回退全合成范围）、`instanceof Property/Layer` 类型嗅探（cheatsheet 认可的 numKeys 嗅探思路的同族用法）。
- 集合遍历遵守两套索引约定（1-based numXxx / 0-based selected 数组）。

## 自查结果（2026-11-14）

- `node --check`（.jsx 后缀经 .js 副本检查）：**通过**。
- ES3 扫描（箭头/let/const/模板串/JSON./Object.keys/数组方法链/for..of/Set/Map/可选链等 30+ 模式）：**0 命中**；数组尾逗号 0 命中；无 BOM。
- 首跑冒烟建议：给 Position 写 `wiggle()` → 工作区烘焙（步长 1）→ 核对曲线吻合 → 勾选移除表达式再烘一次确认键值接管。

## 限制

- 线性关键帧逐帧采样是折线近似：步长>1 时曲线细节有损（静态优化会进一步抽稀）；
- 表达式采样依赖渲染上下文，个别属性（如引用不存在的图层）会逐样本抛错——已被逐条捕获为 warning，产出为部分键；
- `parentProperty` 回溯失败时"图层 in/out"范围自动退化为全合成（有 warning 提示）；
- 烘焙大量属性 × 全合成时长可能较慢（每属性每帧一次 DOM 调用），有 5000 帧/属性上限保护。
