﻿/*******************************************************************************
 * Limber Clone（Limber 2 风格 · 双骨 IK 肢体生成器 + 肢体样式预设库）main.jsx
 * generated_at: 2026-11-14T12:40:00+08:00
 *
 * 目标落位路径（指挥搬运）：C:\Users\19894\ae-mission\clones\limber-clone\main.jsx
 * 说明：本任务会话的沙箱只能写自身工作区，故成品暂存于
 *       C:\Users\19894\.dsh\bot\workspace\out\limber-clone\ —— 需搬运落位。
 *
 * task: clean-room 复刻 aescripts「Limber 2」(Mike Overbeck, $65, jsx) 的功能骨架
 *       输入 = intel/paid-list.md「## 9. Limber 2」的功能性描述（唯一功能依据）
 *
 * CLEAN-ROOM 声明：
 * 1. 本脚本为清室（clean-room）独立实现。实现者未反编译、未阅读、未复制 Limber /
 *    Limber 2 的任何原始代码，也未接触本机已装的同名插件；仅依据公开商品页的
 *    功能性描述（"一键生成带双骨 IK 的肢体形状层"／"肢体分段、长度、弯折曲线风格
 *    （squash & stretch、弹性弯）、内层/高光分层配色自动生成"／"手脚形状可替换并
 *    随肢体自动跟随、自动打关键帧"／"样式库"）与公开几何知识从零编写。
 * 2. IK 数学 = 余弦定理（law of cosines），属公开知识；肢体轮廓 = 中心线采样 +
 *    法向偏移闭合环 + Catmull-Rom 切线，均为自行推导。
 * 3. ES3 / ExtendScript 编写：无 let/const/箭头函数/模板串/JSON/Array.prototype.map
 *    等 ES5+ 语法（含注入 AE 的表达式字符串，同样只用 ES3 语法）。
 *
 * 装配约定（README 有完整说明）：
 *   - 每个肢体 = 1 个形状层 + 6 个 null 控制器，命名前缀 "LC<编号> "：
 *       LC1 Root    根关节（髋/肩），用户拖动 = 移动整条肢体
 *       LC1 Tip     末端 IK 目标（手/脚位置），用户拖动 = 摆姿势
 *       LC1 Joint   解算出的关节（肘/膝）；**所有参数效果都挂在这一层**
 *       LC1 Upper   位于根关节、旋转 = 上段骨角（父化自绘的上肢/大腿 artwork）
 *       LC1 Lower   位于关节、旋转 = 下段骨角（父化自绘的下肢/小腿 artwork）
 *       LC1 TipBone 位于末端、旋转 = 下段骨角（手/脚形状自动跟随用）
 *       LC1 Limb    形状层（Body + Highlight 两组），路径由表达式逐帧重算
 *   - 形状层的变换恒为 position[0,0] / anchor[0,0] / rotation 0 / scale 100%，
 *     因此"图层坐标 == 合成坐标"，路径表达式可直接吃 toComp 的结果（省掉 fromComp）。
 *   - 所有路径/位置表达式都用 toComp(anchorPoint) 取世界坐标，所以控制器被父化、
 *     缩放、旋转后仍正确。
 ******************************************************************************/

(function (thisObj) {

    var SCRIPT_NAME = "Limber Clone";
    var SCRIPT_VER = "1.0.0";
    var P = "LC";                 // 肢体图层名前缀（LC1 Root / LC1 Limb ...）
    var PREFS_SEC = "LimberClone"; // app.settings 分区名（自定义预设持久化）

    // ------------------------------------------------------------------
    // IK 核心（两骨余弦定理解算）——Node 自查脚本逐字提取执行验证
    // 约定：R=根点、E=末点、L1=上段长、L2=下段长、s=弯向符号(±1)
    // 输出：d/dc/A1/th/ang（ang = 上段骨绝对角，弧度，AE 坐标 Y 向下）
    // >>> IK-CORE-START
    var IK_CORE_LINES = [
        "var dx = E[0] - R[0];",
        "var dy = E[1] - R[1];",
        "var d = Math.sqrt(dx * dx + dy * dy);",
        "var dMax = L1 + L2;",
        "var dMin = Math.max(Math.abs(L1 - L2), 0.0001);",
        "var dc = Math.min(Math.max(d, dMin), dMax);",
        "var cosA = (L1 * L1 + dc * dc - L2 * L2) / (2 * L1 * dc);",
        "cosA = Math.min(1, Math.max(-1, cosA));",
        "var A1 = Math.acos(cosA);",
        "var th = Math.atan2(dy, dx);",
        "var ang = th + s * A1;"
    ];
    // <<< IK-CORE-END

    // ------------------------------------------------------------------
    // 内置肢体样式预设（参数包：三段宽度 / 弯折风格 / 平滑 / 挤压 / 弹性 /
    // 高光比例与偏移 / 描边宽 / 基色）
    // style: 1=圆润 2=尖锐 3=弹性 4=直管
    // ------------------------------------------------------------------
    var PRESETS = [
        { name: "基础胶囊 Capsule",   w: [44, 44, 40], style: 1, smooth: 55, squash: 100, elastic: 20, hi: 42, hiOff: 30, out: 0, rgb: [0.87, 0.63, 0.45] },
        { name: "粗细渐变 Taper",     w: [58, 42, 24], style: 1, smooth: 65, squash: 100, elastic: 15, hi: 45, hiOff: 28, out: 0, rgb: [0.93, 0.55, 0.32] },
        { name: "圆胖软肢 Squishy",   w: [62, 66, 54], style: 3, smooth: 80, squash: 165, elastic: 70, hi: 50, hiOff: 34, out: 0, rgb: [0.96, 0.76, 0.55] },
        { name: "弹性面条 Noodle",    w: [30, 26, 22], style: 3, smooth: 90, squash: 60,  elastic: 90, hi: 40, hiOff: 30, out: 0, rgb: [0.55, 0.78, 0.95] },
        { name: "机械分段 Mech",      w: [38, 32, 26], style: 2, smooth: 8,  squash: 0,   elastic: 0,  hi: 30, hiOff: 24, out: 4, rgb: [0.62, 0.66, 0.72] },
        { name: "线稿描边 Outline",   w: [34, 30, 24], style: 4, smooth: 85, squash: 80,  elastic: 25, hi: 0,  hiOff: 0,  out: 3, rgb: [0.98, 0.97, 0.94] },
        { name: "深色高光 DarkGloss", w: [46, 50, 42], style: 1, smooth: 70, squash: 120, elastic: 35, hi: 55, hiOff: 36, out: 0, rgb: [0.24, 0.27, 0.35] }
    ];

    // ==================================================================
    // 一、小工具
    // ==================================================================
    function toNum(v, fallback) {
        var x = parseFloat(v);
        if (isNaN(x)) { return fallback; }
        return x;
    }

    function clampNum(v, lo, hi) {
        if (v < lo) { return lo; }
        if (v > hi) { return hi; }
        return v;
    }

    function escName(n) {                        // 注入表达式字符串里的双引号转义
        return ("" + n).replace(/\\/g, "\\\\").replace(/"/g, "\\\"");
    }

    function isAllDigits(s) {
        var i, c;
        if (s === null || s.length === 0) { return false; }
        for (i = 0; i < s.length; i++) {
            c = s.charCodeAt(i);
            if (c < 48 || c > 57) { return false; }
        }
        return true;
    }

    function two(n) {
        return (n < 10 ? "0" : "") + n;
    }

    function mixColor(c1, c2, t) {               // 线性混色，AE 颜色为 [0..1]
        return [
            clampNum(c1[0] + (c2[0] - c1[0]) * t, 0, 1),
            clampNum(c1[1] + (c2[1] - c1[1]) * t, 0, 1),
            clampNum(c1[2] + (c2[2] - c1[2]) * t, 0, 1)
        ];
    }

    function round2(v) {
        return Math.round(v * 100) / 100;
    }

    // ==================================================================
    // 二、AE 版本 / 应用级设施
    // ==================================================================
    function aeVerNum() {
        var v = 0;
        try { v = parseFloat(app.version); } catch (e) { v = 0; }
        if (isNaN(v)) { v = 0; }
        return v;
    }

    // 形状层外形依赖 createPath() 表达式（AE 15.0 / CC2018 起）。
    function checkVersion() {
        var v = aeVerNum();
        if (v > 0 && v < 15) {
            return confirm("检测到 After Effects " + v + "。\n\n" +
                "本脚本的肢体外形用 createPath() 表达式逐帧重算轮廓，需要 AE 15.0（CC2018）以上。\n" +
                "更低版本里骨架（IK 控制器）可用，但形状层会报表达式错误。\n\n仍然继续吗？");
        }
        return true;
    }

    function settingGet(key, dflt) {
        try {
            if (app.settings.haveSetting(PREFS_SEC, key)) {
                return app.settings.getSetting(PREFS_SEC, key);
            }
        } catch (e1) { /* 缺失或异常都回落到默认值 */ }
        return dflt;
    }

    function settingSet(key, val) {
        try {
            app.settings.saveSetting(PREFS_SEC, key, val);
            app.settings.saveToDisk();
        } catch (e) { /* 首选项写失败不影响主流程 */ }
    }

    // ==================================================================
    // 三、图层 / 效果 辅助
    // ==================================================================
    function activeComp() {
        if (app.project === null) { alert("没有打开的项目。"); return null; }
        var cmp = app.project.activeItem;
        if (cmp === null || !(cmp instanceof CompItem)) {
            alert("请先激活一个合成（Comp）。");
            return null;
        }
        return cmp;
    }

    function findLayer(cmp, name) {
        var i;
        for (i = 1; i <= cmp.numLayers; i++) {
            if (cmp.layer(i).name === name) { return cmp.layer(i); }
        }
        return null;
    }

    function rigName(id, suffix) {
        return P + id + " " + suffix;
    }

    function maxRigId(cmp) {
        var i, nm, sp, head, v, mx = 0;
        for (i = 1; i <= cmp.numLayers; i++) {
            nm = "" + cmp.layer(i).name;
            if (nm.substring(0, P.length) === P) {
                sp = nm.indexOf(" ");
                if (sp > P.length) {
                    head = nm.substring(P.length, sp);
                    if (isAllDigits(head)) {
                        v = parseInt(head, 10);
                        if (v > mx) { mx = v; }
                    }
                }
            }
        }
        return mx;
    }

    // 目标肢体：优先用 UI 里填的编号；否则从选中图层名推断；再否则取最大编号。
    function resolveRigId(cmp, wanted) {
        var w = Math.round(toNum(wanted, 0));
        if (w > 0 && findLayer(cmp, rigName(w, "Limb")) !== null) { return w; }
        var sel = null, i, nm, sp, head;
        try { sel = cmp.selectedLayers; } catch (e) { sel = null; }
        if (sel !== null && sel !== undefined) {
            for (i = 0; i < sel.length; i++) {
                nm = "" + sel[i].name;
                if (nm.substring(0, P.length) === P) {
                    sp = nm.indexOf(" ");
                    if (sp > P.length) {
                        head = nm.substring(P.length, sp);
                        if (isAllDigits(head)) { return parseInt(head, 10); }
                    }
                }
            }
        }
        return maxRigId(cmp);
    }

    function xf(layer) { return layer.property("ADBE Transform Group"); }

    function posOf(layer) { return xf(layer).property("ADBE Position"); }

    function ensureEffect(layer, matchName, fxName, valueProp, defVal) {
        var fx = null, i;
        try {
            var fxGroup = layer.property("ADBE Effect Parade");
            for (i = 1; i <= fxGroup.numProperties; i++) {
                if (fxGroup.property(i).name === fxName) { fx = fxGroup.property(i); break; }
            }
            if (fx === null) {
                fx = fxGroup.addProperty(matchName);
                fx.name = fxName;
            }
            if (defVal !== null && defVal !== undefined) {
                fx.property(valueProp).setValue(defVal);
            }
        } catch (e) { /* 单个效果失败不影响整体，由调用方兜底 */ }
        return fx;
    }

    function setFx(layer, fxName, val, propName) {
        var pn = propName || "Slider";
        if (layer === null) { return; }
        try {
            var fx = layer.effect(fxName);
            if (fx !== null) { fx.property(pn).setValue(val); }
        } catch (e) { }
    }

    function getFx(layer, fxName, dflt, propName) {
        var pn = propName || "Slider";
        if (layer === null) { return dflt; }
        try {
            var fx = layer.effect(fxName);
            if (fx !== null) {
                var v = fx.property(pn).value;
                if (typeof v === "number" && !isNaN(v)) { return v; }
            }
        } catch (e) { }
        return dflt;
    }

    function layerCompPoint(layer) {           // 图层锚点的合成坐标
        try { return layer.toComp(layer.anchorPoint); } catch (e) { return [0, 0]; }
    }

    // ==================================================================
    // 四、形状层内容构造（matchName 逐候选尝试 + try/catch，兼顾各版本）
    // ==================================================================
    function addShapeGroup(parentGroup, name) {
        var g = null;
        try { g = parentGroup.addProperty("ADBE Vector Group"); } catch (e) { g = null; }
        if (g === null) { throw new Error("无法创建形状组（ADBE Vector Group）。"); }
        g.name = name;
        return g;
    }

    function vectorsOf(group) {
        try { return group.property("ADBE Vectors Group"); } catch (e) { return null; }
    }

    // 在组内建一个路径项，返回可写 expression 的路径属性
    // 只用核实过的 matchName：路径项 = "ADBE Vector Shape - Group"，其中的路径属性 = "ADBE Vector Shape"
    function addShapePath(group) {
        var v = vectorsOf(group);
        if (v === null) { throw new Error("无法访问形状组内容（ADBE Vectors Group）。"); }
        var item = null, pathProp = null;
        try { item = v.addProperty("ADBE Vector Shape - Group"); } catch (e1) { item = null; }
        if (item === null) { throw new Error("无法创建路径项（ADBE Vector Shape - Group）。"); }
        try { pathProp = item.property("ADBE Vector Shape"); } catch (e2) { pathProp = null; }
        if (pathProp === null) { throw new Error("无法取得路径属性（ADBE Vector Shape）。"); }
        return pathProp;
    }

    function addFill(group, rgb) {
        var v = vectorsOf(group);
        if (v === null) { throw new Error("无法访问形状组内容（Fill）。"); }
        var f = v.addProperty("ADBE Vector Graphic - Fill");
        try { f.property("ADBE Vector Fill Color").setValue(rgb); } catch (e) { }
        return f;
    }

    function addStroke(group, rgb, width) {
        var v = vectorsOf(group);
        if (v === null) { throw new Error("无法访问形状组内容（Stroke）。"); }
        var s = v.addProperty("ADBE Vector Graphic - Stroke");
        try { s.property("ADBE Vector Stroke Color").setValue(rgb); } catch (e1) { }
        try { s.property("ADBE Vector Stroke Width").setValue(width); } catch (e2) { }
        try { s.property("ADBE Vector Stroke Line Cap").setValue(2); } catch (e3) { }   // 圆头
        try { s.property("ADBE Vector Stroke Line Join").setValue(2); } catch (e4) { }  // 圆角
        return s;
    }

    // 组内所有填充/描边的颜色设置（不新增对象，找不到就静默跳过）
    function setGroupColors(limb, groupName, rgb) {
        try {
            var g = limb.property("ADBE Root Vectors Group").property(groupName);
            var v = g.property("ADBE Vectors Group");
            var i, pr;
            for (i = 1; i <= v.numProperties; i++) {
                pr = v.property(i);
                if (pr.matchName === "ADBE Vector Graphic - Fill") {
                    pr.property("ADBE Vector Fill Color").setValue(rgb);
                } else if (pr.matchName === "ADBE Vector Graphic - Stroke") {
                    pr.property("ADBE Vector Stroke Color").setValue(rgb);
                }
            }
        } catch (e) { }
    }

    function setGroupFillOpacity(limb, groupName, op) {
        try {
            var g = limb.property("ADBE Root Vectors Group").property(groupName);
            var v = g.property("ADBE Vectors Group");
            var i, pr;
            for (i = 1; i <= v.numProperties; i++) {
                pr = v.property(i);
                if (pr.matchName === "ADBE Vector Graphic - Fill") {
                    pr.property("ADBE Vector Fill Opacity").setValue(op);
                }
            }
        } catch (e) { /* 部分版本无该属性，忽略 */ }
    }

    function readGroupFill(limb, groupName, dflt) {
        try {
            var g = limb.property("ADBE Root Vectors Group").property(groupName);
            var v = g.property("ADBE Vectors Group");
            var i, pr, c;
            for (i = 1; i <= v.numProperties; i++) {
                pr = v.property(i);
                if (pr.matchName === "ADBE Vector Graphic - Fill") {
                    c = pr.property("ADBE Vector Fill Color").value;
                    if (c !== null && c.length >= 3) { return [c[0], c[1], c[2]]; }
                }
            }
        } catch (e) { }
        return dflt;
    }

    // ==================================================================
    // 五、表达式生成器
    // ==================================================================
    function coreCode() {
        return IK_CORE_LINES.join("\n");
    }

    // 关节位置：余弦定理直接解肘/膝点（不可达时钳制伸直，过近时折叠，无 NaN）
    function buildJointPosExpr(n) {
        var L = [];
        L.push("// === Limber Clone v" + SCRIPT_VER + " : IK joint position (law of cosines) ===");
        L.push("var RL = thisComp.layer(\"" + escName(rigName(n, "Root")) + "\");");
        L.push("var TL = thisComp.layer(\"" + escName(rigName(n, "Tip")) + "\");");
        L.push("var R = RL.toComp(RL.anchorPoint);");
        L.push("var E = TL.toComp(TL.anchorPoint);");
        L.push("var L1 = Math.max(0.01, effect(\"" + P + n + " L1\")(\"Slider\"));");
        L.push("var L2 = Math.max(0.01, effect(\"" + P + n + " L2\")(\"Slider\"));");
        L.push("var s = (effect(\"" + P + n + " BendFlip\")(\"Checkbox\") == 1) ? -1 : 1;");
        L.push(coreCode());
        L.push("[R[0] + L1 * Math.cos(ang), R[1] + L1 * Math.sin(ang)];");
        return L.join("\n");
    }

    // 上段骨绝对角 = 余弦定理内角 + 弦方向角
    function buildUpperRotExpr(n) {
        var L = [];
        L.push("// === Limber Clone v" + SCRIPT_VER + " : upper bone angle ===");
        L.push("var RL = thisComp.layer(\"" + escName(rigName(n, "Root")) + "\");");
        L.push("var TL = thisComp.layer(\"" + escName(rigName(n, "Tip")) + "\");");
        L.push("var R = RL.toComp(RL.anchorPoint);");
        L.push("var E = TL.toComp(TL.anchorPoint);");
        L.push("var L1 = Math.max(0.01, effect(\"" + P + n + " L1\")(\"Slider\"));");
        L.push("var L2 = Math.max(0.01, effect(\"" + P + n + " L2\")(\"Slider\"));");
        L.push("var s = (effect(\"" + P + n + " BendFlip\")(\"Checkbox\") == 1) ? -1 : 1;");
        L.push(coreCode());
        L.push("ang * 180 / Math.PI;");
        return L.join("\n");
    }

    // 下段骨绝对角 = 关节 → 末端的方位角（零向量保护）
    function buildLowerRotExpr(n) {
        var L = [];
        L.push("// === Limber Clone v" + SCRIPT_VER + " : lower bone angle ===");
        L.push("var JL = thisComp.layer(\"" + escName(rigName(n, "Joint")) + "\");");
        L.push("var TL = thisComp.layer(\"" + escName(rigName(n, "Tip")) + "\");");
        L.push("var M = JL.toComp(JL.anchorPoint);");
        L.push("var E = TL.toComp(TL.anchorPoint);");
        L.push("var qx = E[0] - M[0];");
        L.push("var qy = E[1] - M[1];");
        L.push("var rot = 0;");
        L.push("if (Math.abs(qx) > 0.000001 || Math.abs(qy) > 0.000001) {");
        L.push("  rot = Math.atan2(qy, qx) * 180 / Math.PI;");
        L.push("}");
        L.push("rot;");
        return L.join("\n");
    }

    // 跟随点：位置 = 某图层的锚点位置（Upper = Root，Lower = Joint，TipBone = Tip）
    function buildFollowPosExpr(n, srcSuffix) {
        return "// === Limber Clone v" + SCRIPT_VER + " : follow " + srcSuffix + " ===\n" +
            "var SL = thisComp.layer(\"" + escName(rigName(n, srcSuffix)) + "\");\n" +
            "SL.toComp(SL.anchorPoint);";
    }

    // 肢体轮廓路径表达式。kind = "body" | "hi"
    // 计算链：R/E/M → 折线采样 → 平滑曲线混合 → 宽度剖面（含挤压/弹性）
    //        → 法向偏移构建闭合环（含两端圆帽）→ Catmull-Rom 切线 → createPath
    function buildPathExpr(n, kind) {
        var L = [];
        var isHi = (kind === "hi");
        L.push("// === Limber Clone v" + SCRIPT_VER + " : limb " + (isHi ? "highlight" : "body") + " path ===");
        L.push("var RL = thisComp.layer(\"" + escName(rigName(n, "Root")) + "\");");
        L.push("var TL = thisComp.layer(\"" + escName(rigName(n, "Tip")) + "\");");
        L.push("var JL = thisComp.layer(\"" + escName(rigName(n, "Joint")) + "\");");
        L.push("var R = RL.toComp(RL.anchorPoint);");
        L.push("var E = TL.toComp(TL.anchorPoint);");
        L.push("var M = JL.toComp(JL.anchorPoint);");
        L.push("var L1 = Math.max(0.01, JL.effect(\"" + P + n + " L1\")(\"Slider\"));");
        L.push("var L2 = Math.max(0.01, JL.effect(\"" + P + n + " L2\")(\"Slider\"));");
        L.push("var st = Math.round(JL.effect(\"" + P + n + " Style\")(\"Slider\"));");
        L.push("var sm = Math.min(1, Math.max(0, JL.effect(\"" + P + n + " Smooth\")(\"Slider\") / 100));");
        L.push("var sqA = Math.max(0, JL.effect(\"" + P + n + " Squash\")(\"Slider\") / 100);");
        L.push("var elA = Math.min(1, Math.max(0, JL.effect(\"" + P + n + " Elastic\")(\"Slider\") / 100));");
        L.push("var restD = Math.max(1, JL.effect(\"" + P + n + " Rest\")(\"Slider\"));");
        L.push("var nS = Math.round(Math.min(24, Math.max(4, JL.effect(\"" + P + n + " Samples\")(\"Slider\"))));");
        L.push("var wR = Math.max(0.5, effect(\"W Root\")(\"Slider\"));");
        L.push("var wM = Math.max(0.5, effect(\"W Mid\")(\"Slider\"));");
        L.push("var wT = Math.max(0.5, effect(\"W Tip\")(\"Slider\"));");
        if (isHi) {
            L.push("var wMul = Math.min(1.5, Math.max(0, effect(\"Hi %\")(\"Slider\") / 100));");
            L.push("var nOffR = effect(\"Hi Off\")(\"Slider\") / 100;");
        } else {
            L.push("var wMul = 1;");
            L.push("var nOffR = 0;");
        }
        // --- 可达比 / squash & stretch / 弹性弯
        L.push("var r = L1 / (L1 + L2);");
        L.push("var len = L1 + L2;");
        L.push("var qx = E[0] - R[0];");
        L.push("var qy = E[1] - R[1];");
        L.push("var qd = Math.sqrt(qx * qx + qy * qy);");
        L.push("var ratio = Math.min(1, Math.max(0.001, qd / len));");
        L.push("var restRatio = Math.min(1, Math.max(0.001, restD / len));");
        L.push("var ws = 1;");
        L.push("if (sqA > 0.001) { ws = Math.pow(restRatio / ratio, sqA * 0.5); }");
        L.push("ws = Math.min(2.5, Math.max(0.35, ws));");
        L.push("var cmpK = Math.min(1, Math.max(0, (restRatio - ratio) / restRatio));");
        // --- 平滑曲线控制点（过 M 的二次贝塞尔：C = 2M - (R+E)/2）
        L.push("var cx = 2 * M[0] - 0.5 * (R[0] + E[0]);");
        L.push("var cy = 2 * M[1] - 0.5 * (R[1] + E[1]);");
        L.push("var bx2 = cx - (R[0] + E[0]) * 0.5;");
        L.push("var by2 = cy - (R[1] + E[1]) * 0.5;");
        L.push("var bl = Math.sqrt(bx2 * bx2 + by2 * by2);");
        L.push("if (bl > 0.0001 && cmpK > 0.0001) {");
        L.push("  cx += bx2 / bl * cmpK * elA * len * 0.18;");
        L.push("  cy += by2 / bl * cmpK * elA * len * 0.18;");
        L.push("}");
        // --- 风格 → 平滑权重（折线 ↔ 贝塞尔 混合）
        L.push("var sw;");
        L.push("if (st == 2) { sw = 0.10 + 0.30 * sm; }");
        L.push("else if (st == 3) { sw = 0.65 + 0.35 * sm; }");
        L.push("else if (st == 4) { sw = 0.90 + 0.10 * sm; }");
        L.push("else { sw = 0.55 + 0.45 * sm; }");
        // --- 中心线采样 + 宽度剖面
        L.push("var pts = []; var wid = []; var nrm = [];");
        L.push("var i, t, u, plx, ply, bx, by, w0, w1, wv;");
        L.push("for (i = 0; i < nS; i++) {");
        L.push("  t = (nS <= 1) ? 0 : i / (nS - 1);");
        L.push("  if (t <= r) {");
        L.push("    u = (r > 0.0001) ? t / r : 0;");
        L.push("    plx = R[0] + (M[0] - R[0]) * u; ply = R[1] + (M[1] - R[1]) * u;");
        L.push("    w0 = wR; w1 = wM;");
        L.push("  } else {");
        L.push("    u = ((1 - r) > 0.0001) ? (t - r) / (1 - r) : 1;");
        L.push("    plx = M[0] + (E[0] - M[0]) * u; ply = M[1] + (E[1] - M[1]) * u;");
        L.push("    w0 = wM; w1 = wT;");
        L.push("  }");
        L.push("  bx = (1 - t) * (1 - t) * R[0] + 2 * t * (1 - t) * cx + t * t * E[0];");
        L.push("  by = (1 - t) * (1 - t) * R[1] + 2 * t * (1 - t) * cy + t * t * E[1];");
        L.push("  pts.push([plx * (1 - sw) + bx * sw, ply * (1 - sw) + by * sw]);");
        L.push("  u = u * u * (3 - 2 * u);");
        L.push("  wv = (w0 + (w1 - w0) * u) * ws;");
        L.push("  if (cmpK > 0.0001) { wv = wv * (1 + cmpK * elA * 0.55 * Math.sin(Math.PI * t)); }");
        L.push("  wid.push(Math.max(0.5, wv));");
        L.push("}");
        // --- 法向
        L.push("var i0, i1, tx, ty, tl;");
        L.push("for (i = 0; i < nS; i++) {");
        L.push("  i0 = (i > 0) ? i - 1 : 0;");
        L.push("  i1 = (i < nS - 1) ? i + 1 : nS - 1;");
        L.push("  tx = pts[i1][0] - pts[i0][0]; ty = pts[i1][1] - pts[i0][1];");
        L.push("  tl = Math.sqrt(tx * tx + ty * ty);");
        L.push("  if (tl < 0.00001) { tx = 1; ty = 0; tl = 1; }");
        L.push("  nrm.push([-ty / tl, tx / tl]);");
        L.push("}");
        // --- 闭合环：左缘 → 末端圆帽 → 右缘 → 根端圆帽
        L.push("var lp = []; var hw, of;");
        L.push("for (i = 0; i < nS; i++) {");
        L.push("  hw = wid[i] * 0.5 * wMul;");
        L.push("  of = wid[i] * nOffR;");
        L.push("  lp.push([pts[i][0] + nrm[i][0] * (hw + of), pts[i][1] + nrm[i][1] * (hw + of)]);");
        L.push("}");
        L.push("var e0 = pts[nS - 1];");
        L.push("var tx0 = e0[0] - pts[nS - 2][0]; var ty0 = e0[1] - pts[nS - 2][1];");
        L.push("var tl0 = Math.sqrt(tx0 * tx0 + ty0 * ty0);");
        L.push("if (tl0 < 0.00001) { tx0 = 1; ty0 = 0; tl0 = 1; }");
        L.push("tx0 = tx0 / tl0; ty0 = ty0 / tl0;");
        L.push("var nx0 = nrm[nS - 1][0]; var ny0 = nrm[nS - 1][1];");
        L.push("var rr0 = Math.max(0.5, wid[nS - 1] * 0.5 * wMul);");
        L.push("var of0 = wid[nS - 1] * nOffR;");
        L.push("var ccx = e0[0] + nx0 * of0; var ccy = e0[1] + ny0 * of0;");
        L.push("var k, ag;");
        L.push("for (k = 1; k <= 3; k++) {");
        L.push("  ag = Math.PI / 2 - k * (Math.PI / 4);");
        L.push("  lp.push([ccx + tx0 * Math.cos(ag) * rr0 + nx0 * Math.sin(ag) * rr0,");
        L.push("           ccy + ty0 * Math.cos(ag) * rr0 + ny0 * Math.sin(ag) * rr0]);");
        L.push("}");
        L.push("for (i = nS - 1; i >= 0; i--) {");
        L.push("  hw = wid[i] * 0.5 * wMul;");
        L.push("  of = wid[i] * nOffR;");
        L.push("  lp.push([pts[i][0] + nrm[i][0] * (of - hw), pts[i][1] + nrm[i][1] * (of - hw)]);");
        L.push("}");
        L.push("var s0 = pts[0];");
        L.push("var tx1 = s0[0] - pts[1][0]; var ty1 = s0[1] - pts[1][1];");
        L.push("var tl1 = Math.sqrt(tx1 * tx1 + ty1 * ty1);");
        L.push("if (tl1 < 0.00001) { tx1 = -1; ty1 = 0; tl1 = 1; }");
        L.push("tx1 = tx1 / tl1; ty1 = ty1 / tl1;");
        L.push("var nx1 = nrm[0][0]; var ny1 = nrm[0][1];");
        L.push("var rr1 = Math.max(0.5, wid[0] * 0.5 * wMul);");
        L.push("var of1 = wid[0] * nOffR;");
        L.push("var csx = s0[0] + nx1 * of1; var csy = s0[1] + ny1 * of1;");
        L.push("for (k = 1; k <= 3; k++) {");
        L.push("  ag = -Math.PI / 2 + k * (Math.PI / 4);");
        L.push("  lp.push([csx + tx1 * Math.cos(ag) * rr1 + nx1 * Math.sin(ag) * rr1,");
        L.push("           csy + ty1 * Math.cos(ag) * rr1 + ny1 * Math.sin(ag) * rr1]);");
        L.push("}");
        // --- Catmull-Rom 切线（闭合环，首尾自动衔接）
        L.push("var cnt = lp.length; var inT = []; var outT = [];");
        L.push("var pv, nx2, ddx, ddy;");
        L.push("for (i = 0; i < cnt; i++) {");
        L.push("  pv = (i - 1 + cnt) % cnt;");
        L.push("  nx2 = (i + 1) % cnt;");
        L.push("  ddx = lp[nx2][0] - lp[pv][0]; ddy = lp[nx2][1] - lp[pv][1];");
        L.push("  outT.push([ddx / 6, ddy / 6]);");
        L.push("  inT.push([-ddx / 6, -ddy / 6]);");
        L.push("}");
        L.push("createPath(points = lp, inTangents = inT, outTangents = outT, is_closed = true);");
        return L.join("\n");
    }

    // ==================================================================
    // 六、预设库（内置 + app.settings 里持久化的自定义）
    // ==================================================================
    function presetToStr(p) {
        return p.name + "~" + p.w[0] + "," + p.w[1] + "," + p.w[2] + "~" + p.style + "~" +
            p.smooth + "~" + p.squash + "~" + p.elastic + "~" + p.hi + "~" + p.hiOff + "~" +
            p.out + "~" + p.rgb[0] + "," + p.rgb[1] + "," + p.rgb[2];
    }

    // 序列化格式（~ 分隔，10 段）：name~w0,w1,w2~style~smooth~squash~elastic~hi~hiOff~out~r,g,b
    function strToPreset(s) {
        var f = ("" + s).split("~");
        if (f.length < 10) { return null; }
        var w = f[1].split(","), c = f[9].split(",");
        if (w.length < 3 || c.length < 3) { return null; }
        var p = {
            name: f[0],
            w: [toNum(w[0], 40), toNum(w[1], 40), toNum(w[2], 36)],
            style: Math.round(toNum(f[2], 1)),
            smooth: toNum(f[3], 55),
            squash: toNum(f[4], 100),
            elastic: toNum(f[5], 20),
            hi: toNum(f[6], 42),
            hiOff: toNum(f[7], 30),
            out: toNum(f[8], 0),
            rgb: [clampNum(toNum(c[0], 0.8), 0, 1), clampNum(toNum(c[1], 0.6), 0, 1), clampNum(toNum(c[2], 0.4), 0, 1)],
            custom: true
        };
        return p;
    }

    function allPresets() {
        var list = [], i, cnt, s, p;
        for (i = 0; i < PRESETS.length; i++) { list.push(PRESETS[i]); }
        cnt = Math.round(toNum(settingGet("cpCount", "0"), 0));
        for (i = 1; i <= cnt && i <= 20; i++) {
            s = settingGet("cp." + i, "");
            if (s !== "" && s !== null) {
                p = strToPreset(s);
                if (p !== null) { list.push(p); }
            }
        }
        return list;
    }

    function presetNames() {
        var list = allPresets(), out = [], i;
        for (i = 0; i < list.length; i++) { out.push(list[i].name); }
        return out;
    }

    // ==================================================================
    // 七、创建肢体
    // ==================================================================
    function createLimb(cfg) {
        var cmp = activeComp();
        if (cmp === null) { return; }
        if (!checkVersion()) { return; }

        // 端点初值：选中 2 层则取其锚点位置（顺序无文档保证，可在 UI 里交换）
        var vw = 1920, vh = 1080, rootP, tipP, sel = null;
        try { vw = cmp.width; vh = cmp.height; } catch (e0) { }
        rootP = [vw * 0.40, vh * 0.55];
        tipP = [vw * 0.60, vh * 0.55];
        try { sel = cmp.selectedLayers; } catch (e1) { sel = null; }
        if (sel !== null && sel !== undefined && sel.length >= 2) {
            try {
                rootP = layerCompPoint(cfg.swap ? sel[1] : sel[0]);
                tipP = layerCompPoint(cfg.swap ? sel[0] : sel[1]);
            } catch (e2) { }
        }

        var d0 = Math.sqrt((tipP[0] - rootP[0]) * (tipP[0] - rootP[0]) + (tipP[1] - rootP[1]) * (tipP[1] - rootP[1]));
        if (!(d0 > 1)) { d0 = Math.min(vw, vh) * 0.25; }
        var L1 = cfg.manual ? Math.max(1, cfg.l1) : d0 * 0.58;
        var L2 = cfg.manual ? Math.max(1, cfg.l2) : d0 * 0.58;

        var made = [];
        var id = 0;
        app.beginUndoGroup("Limber Clone: Create Limb");
        try {
            id = maxRigId(cmp) + 1;

            // --- 1) 根控制器（用户拖动 = 移动整条肢体）
            var rootL = cmp.layers.addNull();
            made.push(rootL);
            rootL.name = rigName(id, "Root");
            posOf(rootL).setValue(rootP);
            try { rootL.label = 9; } catch (eL1) { }

            // --- 2) 末端 IK 目标（用户拖动 = 摆姿势）
            var tipL = cmp.layers.addNull();
            made.push(tipL);
            tipL.name = rigName(id, "Tip");
            posOf(tipL).setValue(tipP);
            try { tipL.label = 11; } catch (eL2) { }

            // --- 3) 关节层：先写参数效果，再挂表达式（表达式读自己的效果）
            var jointL = cmp.layers.addNull();
            made.push(jointL);
            jointL.name = rigName(id, "Joint");
            posOf(jointL).setValue([(rootP[0] + tipP[0]) / 2, (rootP[1] + tipP[1]) / 2]);
            try { jointL.label = 3; } catch (eL3) { }

            ensureEffect(jointL, "ADBE Slider Control", P + id + " L1", "Slider", L1);
            ensureEffect(jointL, "ADBE Slider Control", P + id + " L2", "Slider", L2);
            ensureEffect(jointL, "ADBE Slider Control", P + id + " Rest", "Slider", d0);
            ensureEffect(jointL, "ADBE Slider Control", P + id + " Style", "Slider", cfg.style);
            ensureEffect(jointL, "ADBE Slider Control", P + id + " Smooth", "Slider", cfg.smooth);
            ensureEffect(jointL, "ADBE Slider Control", P + id + " Squash", "Slider", cfg.squash);
            ensureEffect(jointL, "ADBE Slider Control", P + id + " Elastic", "Slider", cfg.elastic);
            ensureEffect(jointL, "ADBE Slider Control", P + id + " Samples", "Slider", cfg.samples);
            ensureEffect(jointL, "ADBE Checkbox Control", P + id + " BendFlip", "Checkbox", cfg.bendFlip ? 1 : 0);

            posOf(jointL).expression = buildJointPosExpr(id);

            // --- 4) 上段骨 null（父化自绘 artwork 用）
            var upperL = cmp.layers.addNull();
            made.push(upperL);
            upperL.name = rigName(id, "Upper");
            posOf(upperL).expression = buildFollowPosExpr(id, "Root");
            xf(upperL).property("ADBE Rotation").expression = buildUpperRotExpr(id);

            // --- 5) 下段骨 null（父化自绘 artwork / 手脚用）
            var lowerL = cmp.layers.addNull();
            made.push(lowerL);
            lowerL.name = rigName(id, "Lower");
            posOf(lowerL).expression = buildFollowPosExpr(id, "Joint");
            xf(lowerL).property("ADBE Rotation").expression = buildLowerRotExpr(id);

            // --- 6) 末端跟随 null（手/脚形状挂这里）
            var tipBoneL = cmp.layers.addNull();
            made.push(tipBoneL);
            tipBoneL.name = rigName(id, "TipBone");
            posOf(tipBoneL).expression = buildFollowPosExpr(id, "Tip");
            xf(tipBoneL).property("ADBE Rotation").expression = buildLowerRotExpr(id);

            // --- 7) 形状层（变换恒等 → 图层坐标 == 合成坐标）
            var limb = cmp.layers.addShape();
            made.push(limb);
            limb.name = rigName(id, "Limb");
            xf(limb).property("ADBE Position").setValue([0, 0]);
            xf(limb).property("ADBE Anchor Point").setValue([0, 0]);
            xf(limb).property("ADBE Rotation").setValue(0);
            xf(limb).property("ADBE Scale").setValue([100, 100]);

            var all = allPresets();
            var preset = all[clampNum(Math.round(cfg.presetIndex), 0, all.length - 1)];
            if (!preset) { preset = PRESETS[0]; }

            ensureEffect(limb, "ADBE Slider Control", "W Root", "Slider", preset.w[0]);
            ensureEffect(limb, "ADBE Slider Control", "W Mid", "Slider", preset.w[1]);
            ensureEffect(limb, "ADBE Slider Control", "W Tip", "Slider", preset.w[2]);
            ensureEffect(limb, "ADBE Slider Control", "Hi %", "Slider", preset.hi);
            ensureEffect(limb, "ADBE Slider Control", "Hi Off", "Slider", preset.hiOff);
            ensureEffect(limb, "ADBE Slider Control", "Out W", "Slider", preset.out);

            var rootVec = limb.property("ADBE Root Vectors Group");

            var gBody = addShapeGroup(rootVec, "Body");
            var pBody = addShapePath(gBody);
            addFill(gBody, preset.rgb);
            var strokeGrp = addStroke(gBody, mixColor(preset.rgb, [0, 0, 0], 0.55), 1);
            try {
                strokeGrp.property("ADBE Vector Stroke Width").expression = "effect(\"Out W\")(\"Slider\");";
            } catch (eSW) { }
            pBody.expression = buildPathExpr(id, "body");

            var gHi = addShapeGroup(rootVec, "Highlight");
            var pHi = addShapePath(gHi);
            addFill(gHi, mixColor(preset.rgb, [1, 1, 1], 0.45));
            pHi.expression = buildPathExpr(id, "hi");
            if (preset.hi <= 0) { setGroupFillOpacity(limb, "Highlight", 0); }

            // --- 8) 可选：创建时给两个控制器各打一帧
            if (cfg.autoKey) {
                var t0 = 0;
                try { t0 = cmp.time; } catch (eT) { t0 = 0; }
                try {
                    var rpa = posOf(rootL), tpa = posOf(tipL);
                    rpa.setValueAtTime(t0, rpa.value);
                    tpa.setValueAtTime(t0, tpa.value);
                } catch (eK) { }
            }

            // --- 9) 绑定信息写进 Joint 的 comment，便于后续找回
            try {
                jointL.comment = P + " id=" + id + ";root=" + rigName(id, "Root") + ";tip=" + rigName(id, "Tip");
            } catch (eC) { }

        } catch (err) {
            // 回滚：删掉半成品，避免留下一地碎层
            var i;
            for (i = made.length - 1; i >= 0; i--) {
                try { made[i].remove(); } catch (eR) { }
            }
            alert("创建肢体失败，已回滚：\n" + err.toString());
            return;
        } finally {
            app.endUndoGroup();
        }

        alert("肢体 LC" + id + " 已创建：\n" +
            "  LC" + id + " Root      根关节（拖动整条肢体）\n" +
            "  LC" + id + " Tip       末端 IK 目标（拖它摆姿势）\n" +
            "  LC" + id + " Joint     关节解算点；参数都在这里（L1/L2/Style/Smooth/Squash/Elastic）\n" +
            "  LC" + id + " Upper / Lower / TipBone   骨轴 null，可父化自绘 artwork 或手/脚\n" +
            "  LC" + id + " Limb      形状层（Body + Highlight）\n\n" +
            "骨长 L1=" + round2(L1) + "  L2=" + round2(L2) + "  初始间距 " + round2(d0) + "\n" +
            "细节可调：LC" + id + " Limb 上的 W Root / W Mid / W Tip（粗细）、Hi %、Hi Off、Out W。");
    }

    // ==================================================================
    // 八、应用样式 / 捕获预设
    // ==================================================================
    function applyStyleToLimb(cfg) {
        var cmp = activeComp();
        if (cmp === null) { return; }
        var id = resolveRigId(cmp, cfg.id);
        var limb = findLayer(cmp, rigName(id, "Limb"));
        var joint = findLayer(cmp, rigName(id, "Joint"));
        if (limb === null || joint === null) {
            alert("没找到 LC" + id + " 的 Limb/Joint 图层。\n请先在「编号」里填对，或选中该肢体的任一图层。");
            return;
        }
        var list = allPresets();
        var idx = clampNum(Math.round(cfg.presetIndex), 0, list.length - 1);
        var p = list[idx];
        if (!p) { alert("预设索引无效。"); return; }

        app.beginUndoGroup("Limber Clone: Apply Style");
        try {
            setFx(limb, "W Root", p.w[0]);
            setFx(limb, "W Mid", p.w[1]);
            setFx(limb, "W Tip", p.w[2]);
            setFx(limb, "Hi %", p.hi);
            setFx(limb, "Hi Off", p.hiOff);
            setFx(limb, "Out W", p.out);
            setFx(joint, P + id + " Style", p.style);
            setFx(joint, P + id + " Smooth", p.smooth);
            setFx(joint, P + id + " Squash", p.squash);
            setFx(joint, P + id + " Elastic", p.elastic);
            setGroupColors(limb, "Body", p.rgb);
            setGroupColors(limb, "Highlight", mixColor(p.rgb, [1, 1, 1], 0.45));
            setGroupFillOpacity(limb, "Highlight", p.hi <= 0 ? 0 : 100);
        } catch (err) {
            alert("应用样式失败：" + err.toString());
            return;
        } finally {
            app.endUndoGroup();
        }
        alert("已把预设「" + p.name + "」应用到 LC" + id + "。");
    }

    function captureCurrentAsPreset(cfg) {
        var cmp = activeComp();
        if (cmp === null) { return; }
        var id = resolveRigId(cmp, cfg.id);
        var limb = findLayer(cmp, rigName(id, "Limb"));
        var joint = findLayer(cmp, rigName(id, "Joint"));
        if (limb === null || joint === null) {
            alert("没找到 LC" + id + " 的 Limb/Joint 图层。");
            return;
        }
        var name = "自定义" + two(id) + "-LC" + id;
        var p = {
            name: name,
            w: [getFx(limb, "W Root", 44), getFx(limb, "W Mid", 44), getFx(limb, "W Tip", 40)],
            style: Math.round(getFx(joint, P + id + " Style", 1)),
            smooth: getFx(joint, P + id + " Smooth", 55),
            squash: getFx(joint, P + id + " Squash", 100),
            elastic: getFx(joint, P + id + " Elastic", 20),
            hi: getFx(limb, "Hi %", 42),
            hiOff: getFx(limb, "Hi Off", 30),
            out: getFx(limb, "Out W", 0),
            rgb: readGroupFill(limb, "Body", [0.8, 0.6, 0.4])
        };
        var cnt = Math.round(toNum(settingGet("cpCount", "0"), 0)) + 1;
        if (cnt > 20) { cnt = 20; }
        settingSet("cpCount", "" + cnt);
        settingSet("cp." + cnt, presetToStr(p));
        alert("已把 LC" + id + " 的当前参数存为预设「" + p.name + "」。\n" +
            "关掉面板再打开即可在样式列表里看到它（存在 AE 首选项里，跨工程有效）。");
    }

    // ==================================================================
    // 九、手/脚：生成、绑定、替换
    // ==================================================================
    function bindArtToTip(cfg) {
        var cmp = activeComp();
        if (cmp === null) { return; }
        var sel = null;
        try { sel = cmp.selectedLayers; } catch (e0) { sel = null; }
        if (sel === null || sel === undefined || sel.length < 1) {
            alert("请先选中要当作手/脚的那个图层（可选多个）。");
            return;
        }
        var id = resolveRigId(cfg.id);
        var tipBone = findLayer(cmp, rigName(id, "TipBone"));
        if (tipBone === null) {
            alert("没找到 LC" + id + " TipBone。请先用「创建肢体」。");
            return;
        }
        app.beginUndoGroup("Limber Clone: Bind Hand/Foot");
        var ok = 0, i;
        try {
            for (i = 0; i < sel.length; i++) {
                var art = sel[i];
                if (art === tipBone) { continue; }
                // 记录原世界锚点位置，父化后补偿回去（AE 不会自动保持位置）
                var p0 = null;
                try { p0 = art.toComp(art.anchorPoint); } catch (e1) { p0 = null; }
                var rot0 = 0;
                try { rot0 = xf(art).property("ADBE Rotation").value; } catch (e2) { rot0 = 0; }
                art.parent = tipBone;
                if (p0 !== null) {
                    var pLocal = p0;
                    try { pLocal = tipBone.fromComp(p0); } catch (e3) { pLocal = p0; }
                    try { posOf(art).setValue(pLocal); } catch (e4) { }
                }
                if (cfg.followRot) {
                    try { xf(art).property("ADBE Rotation").setValue(0); } catch (e5) { }
                } else {
                    // 不跟随：用表达式抵消末端骨的旋转，保持原来的绝对朝向
                    try {
                        xf(art).property("ADBE Rotation").expression =
                            "-thisComp.layer(\"" + escName(rigName(id, "TipBone")) + "\").transform.rotation + " + rot0;
                    } catch (e6) { }
                }
                ok++;
            }
        } catch (err) {
            alert("绑定失败：" + err.toString());
            return;
        } finally {
            app.endUndoGroup();
        }
        alert("已把 " + ok + " 个图层绑定到 LC" + id + " TipBone（随肢体末端自动跟随）。");
    }

    function createDefaultHand(cfg) {
        var cmp = activeComp();
        if (cmp === null) { return; }
        var id = resolveRigId(cmp, cfg.id);
        var tipBone = findLayer(cmp, rigName(id, "TipBone"));
        if (tipBone === null) {
            alert("没找到 LC" + id + " TipBone。请先用「创建肢体」。");
            return;
        }
        var limb = findLayer(cmp, rigName(id, "Limb"));
        var base = limb !== null ? readGroupFill(limb, "Body", [0.87, 0.63, 0.45]) : [0.87, 0.63, 0.45];
        var wTip = limb !== null ? getFx(limb, "W Tip", 40) : 40;
        var r = Math.max(6, wTip * 0.5);

        app.beginUndoGroup("Limber Clone: Create Hand/Foot");
        var made = [];
        try {
            var hand = cmp.layers.addShape();
            made.push(hand);
            hand.name = rigName(id, cfg.foot ? "Foot" : "Hand");
            xf(hand).property("ADBE Anchor Point").setValue([0, 0]);
            xf(hand).property("ADBE Position").setValue([0, 0]);
            xf(hand).property("ADBE Rotation").setValue(0);
            xf(hand).property("ADBE Scale").setValue([100, 100]);

            var rootVec = hand.property("ADBE Root Vectors Group");
            var g = addShapeGroup(rootVec, "Shape");
            var v = vectorsOf(g);
            if (v === null) { throw new Error("无法访问形状组内容。"); }
            var el = v.addProperty("ADBE Vector Shape - Ellipse");
            try { el.property("ADBE Vector Ellipse Size").setValue([r * 2, r * 2]); } catch (eS) { }
            try { el.property("ADBE Vector Ellipse Position").setValue([0, 0]); } catch (eP) { }
            addFill(g, base);
            addStroke(g, mixColor(base, [0, 0, 0], 0.55), Math.max(1, r * 0.12));

            hand.parent = tipBone;
            xf(hand).property("ADBE Position").setValue([0, 0]);
        } catch (err) {
            var i;
            for (i = 0; i < made.length; i++) { try { made[i].remove(); } catch (eR) { } }
            alert("生成手/脚失败：" + err.toString());
            return;
        } finally {
            app.endUndoGroup();
        }
        alert("已生成 " + rigName(id, cfg.foot ? "Foot" : "Hand") + "（半径 " + round2(r) +
            "px，父化到 TipBone）。\n想换成自己的形状：选中它 → 「绑定到末端」即可。");
    }

    // ==================================================================
    // 十、自动打关键帧
    // ==================================================================
    function poseKey(cfg) {
        var cmp = activeComp();
        if (cmp === null) { return; }
        var id = resolveRigId(cmp, cfg.id);
        var tip = findLayer(cmp, rigName(id, "Tip"));
        var root = findLayer(cmp, rigName(id, "Root"));
        if (tip === null) { alert("没找到 LC" + id + " Tip。"); return; }
        var t = 0;
        try { t = cmp.time; } catch (e0) { t = 0; }
        app.beginUndoGroup("Limber Clone: Pose Key");
        try {
            var tp = posOf(tip);
            tp.setValueAtTime(t, tp.value);
            if (cfg.keyRoot && root !== null) {
                var rp = posOf(root);
                rp.setValueAtTime(t, rp.value);
            }
        } catch (err) {
            alert("打关键帧失败：" + err.toString());
            return;
        } finally {
            app.endUndoGroup();
        }
        alert("已在 " + round2(t) + "s 给 LC" + id + " 的控制器打了关键帧。");
    }

    function genCycle(cfg) {
        var cmp = activeComp();
        if (cmp === null) { return; }
        var id = resolveRigId(cmp, cfg.id);
        var tip = findLayer(cmp, rigName(id, "Tip"));
        var root = findLayer(cmp, rigName(id, "Root"));
        var joint = findLayer(cmp, rigName(id, "Joint"));
        if (tip === null || root === null || joint === null) {
            alert("没找到 LC" + id + " 的控制器。请先用「创建肢体」。");
            return;
        }
        var L1 = getFx(joint, P + id + " L1", 120);
        var L2 = getFx(joint, P + id + " L2", 120);
        var reach = Math.max(10, L1 + L2);

        var base = null;
        try { base = posOf(tip).value; } catch (e0) { base = [0, 0]; }
        var t0 = 0, dur = 1;
        try { dur = cmp.duration; } catch (e1) { dur = 1; }
        try {
            if (cmp.workAreaDuration > 0) {
                t0 = cmp.workAreaStart;
                dur = cmp.workAreaDuration;
            }
        } catch (e2) { t0 = 0; }
        if (!(dur > 0)) { dur = 1; }

        var reps = clampNum(Math.round(cfg.cycles), 1, 12);
        var poses = 4;
        var total = reps * poses;
        var ax = reach * 0.42;
        var ay = reach * 0.26;
        var keys = [], i, frac, phi;
        for (i = 0; i <= total; i++) {
            frac = i / total;
            phi = (i % poses) * (Math.PI / 2);
            keys.push([t0 + dur * frac, [base[0] + ax * Math.cos(phi), base[1] + ay * Math.sin(phi)]]);
        }

        app.beginUndoGroup("Limber Clone: Auto Key Cycle");
        try {
            var tp = posOf(tip);
            for (i = 0; i < keys.length; i++) {
                tp.setValueAtTime(keys[i][0], keys[i][1]);
            }
            var infl = clampNum(cfg.ease, 0.1, 100);
            var k;
            for (k = 1; k <= tp.numKeys; k++) {
                try {
                    var eIn = new KeyframeEase(0, infl);
                    var eOut = new KeyframeEase(0, infl);
                    tp.setTemporalEaseAtKey(k, [eIn, eIn], [eOut, eOut]);
                } catch (eE) { }
                try {
                    tp.setInterpolationTypeAtKey(k, KeyframeInterpolationType.BEZIER, KeyframeInterpolationType.BEZIER);
                } catch (eI) { }
            }
        } catch (err) {
            alert("生成循环失败：" + err.toString());
            return;
        } finally {
            app.endUndoGroup();
        }
        alert("已给 LC" + id + " Tip 生成 " + reps + " 圈 × " + poses + " 姿势 = " +
            keys.length + " 个关键帧（" + round2(t0) + "s → " + round2(t0 + dur) + "s，" +
            "贝塞尔缓动 influence=" + round2(cfg.ease) + "）。\n幅度按骨长 L1+L2 自动取 0.42/0.26。");
    }

    // ==================================================================
    // 十一、移除
    // ==================================================================
    function removeRig(cfg, all) {
        var cmp = activeComp();
        if (cmp === null) { return; }
        var suffixes = ["Root", "Tip", "Joint", "Upper", "Lower", "TipBone", "Limb", "Hand", "Foot"];
        var id = resolveRigId(cmp, cfg.id);
        if (all) {
            if (!confirm("要删除本合成里所有 LC 层的肢体吗？（用户自绘 artwork 不受影响）")) { return; }
        }
        app.beginUndoGroup("Limber Clone: Remove");
        var removed = 0, i, j, nm, target, hit, sfx;
        try {
            for (i = cmp.numLayers; i >= 1; i--) {
                nm = "" + cmp.layer(i).name;
                if (nm.substring(0, P.length) !== P) { continue; }
                hit = false;
                for (j = 0; j < suffixes.length; j++) {
                    sfx = suffixes[j];
                    if (all) {
                        // 任意编号 + 已知后缀
                        if (nm.length > sfx.length && nm.substring(nm.length - sfx.length) === sfx &&
                            nm.charAt(nm.length - sfx.length - 1) === " ") {
                            hit = true; break;
                        }
                    } else if (nm === rigName(id, sfx)) {
                        hit = true; break;
                    }
                }
                if (hit) {
                    target = cmp.layer(i);
                    target.remove();
                    removed++;
                }
            }
        } catch (err) {
            alert("移除失败：" + err.toString());
            return;
        } finally {
            app.endUndoGroup();
        }
        alert("已移除 " + removed + " 个 LC 图层（父化在其上的 artwork 会随父层删除而解除父子关系，不会被删）。");
    }

    // ==================================================================
    // 十二、UI
    // ==================================================================
    function numField(parent, label, defVal, chars) {
        parent.add("statictext", undefined, label);
        var et = parent.add("edittext", undefined, defVal);
        et.characters = chars || 5;
        return et;
    }

    function buildUI(thisObj) {
        var win = (thisObj instanceof Panel)
            ? thisObj
            : new Window("palette", SCRIPT_NAME + " v" + SCRIPT_VER, undefined, { resizeable: true });
        win.orientation = "column";
        win.alignChildren = ["fill", "top"];
        win.spacing = 6;
        win.margins = 12;

        var ttl = win.add("statictext", undefined, SCRIPT_NAME + " v" + SCRIPT_VER + "  ·  双骨 IK 肢体");
        try { ttl.graphics.font = ScriptUI.newFont("dialog", ScriptUI.FontStyle.BOLD, 12); } catch (eF) { }

        var tipTx = win.add("statictext", undefined, "先激活合成；可选：选中 2 层（根、末端）用其位置当起手。", { multiline: true });
        try {
            tipTx.graphics.foregroundColor = tipTx.graphics.newPen(win.graphics.PenType.SOLID_COLOR, [0.5, 0.5, 0.5], 1);
        } catch (eC) { }

        var gSel = win.add("group");
        gSel.orientation = "row";
        var cbSwap = gSel.add("checkbox", undefined, "交换根/末");
        cbSwap.value = false;
        var cbKey = gSel.add("checkbox", undefined, "创建时打首帧");
        cbKey.value = false;
        var cbFlip = gSel.add("checkbox", undefined, "反向弯");
        cbFlip.value = false;

        var gLen = win.add("panel", undefined, "骨长（肢体分段）");
        gLen.orientation = "row";
        gLen.alignChildren = ["left", "center"];
        gLen.margins = [10, 14, 10, 8];
        var ddLen = gLen.add("dropdownlist", undefined, ["自动（0.58×当前间距）", "手动"]);
        ddLen.selection = 0;
        var etL1 = numField(gLen, " L1", "120", 5);
        var etL2 = numField(gLen, " L2", "120", 5);
        var etSmp = numField(gLen, " 采样", "12", 4);

        var gSty = win.add("panel", undefined, "肢体样式预设库");
        gSty.orientation = "column";
        gSty.alignChildren = ["fill", "top"];
        gSty.margins = [10, 14, 10, 8];
        var gSty1 = gSty.add("group");
        gSty1.orientation = "row";
        var ddPreset = gSty1.add("dropdownlist", undefined, presetNames());
        ddPreset.selection = 0;
        var btnApply = gSty1.add("button", undefined, "应用样式");
        var gSty2 = gSty.add("group");
        gSty2.orientation = "row";
        var ddStyle = gSty2.add("dropdownlist", undefined,
            ["1 圆润 Round", "2 尖锐 Sharp", "3 弹性 Elastic", "4 直管 Hose"]);
        ddStyle.selection = 0;
        var etSquash = numField(gSty2, " 挤压%", "100", 4);
        var etElastic = numField(gSty2, " 弹性%", "20", 4);
        var gSty3 = gSty.add("group");
        gSty3.orientation = "row";
        var etHi = numField(gSty3, "高光%", "42", 4);
        var etOut = numField(gSty3, " 描边", "0", 4);
        var btnCap = gSty3.add("button", undefined, "存为预设");

        var gHand = win.add("panel", undefined, "手脚形状（随肢体自动跟随）");
        gHand.orientation = "column";
        gHand.alignChildren = ["fill", "top"];
        gHand.margins = [10, 14, 10, 8];
        var gH1 = gHand.add("group");
        gH1.orientation = "row";
        var btnHand = gH1.add("button", undefined, "生成手");
        var btnFoot = gH1.add("button", undefined, "生成脚");
        var btnBind = gH1.add("button", undefined, "绑定到末端");
        var gH2 = gHand.add("group");
        gH2.orientation = "row";
        var cbFollow = gH2.add("checkbox", undefined, "手/脚跟随肢体旋转");
        cbFollow.value = true;

        var gKey = win.add("panel", undefined, "自动打关键帧");
        gKey.orientation = "column";
        gKey.alignChildren = ["fill", "top"];
        gKey.margins = [10, 14, 10, 8];
        var gK1 = gKey.add("group");
        gK1.orientation = "row";
        var btnPose = gK1.add("button", undefined, "当前姿势打帧");
        var cbKeyRoot = gK1.add("checkbox", undefined, "连根一起");
        cbKeyRoot.value = false;
        var gK2 = gKey.add("group");
        gK2.orientation = "row";
        var etCyc = numField(gK2, "圈数", "2", 4);
        var etEase = numField(gK2, " 缓动", "66", 4);
        var btnCycle = gK2.add("button", undefined, "生成 4 姿势循环");

        var gMain = win.add("group");
        gMain.orientation = "row";
        var btnCreate = gMain.add("button", undefined, "创建肢体");
        try { btnCreate.name = "ok"; } catch (eN) { }
        var btnRemove = gMain.add("button", undefined, "移除");
        var btnRemoveAll = gMain.add("button", undefined, "移除全部");
        var etId = numField(gMain, " 编号", "0", 4);

        var foot = win.add("statictext", undefined,
            "操作目标编号 0 = 自动（按选中层/最大编号）。ES3 脚本，公式=余弦定理。", { multiline: true });
        try {
            foot.graphics.foregroundColor = foot.graphics.newPen(win.graphics.PenType.SOLID_COLOR, [0.5, 0.5, 0.5], 1);
        } catch (eC2) { }

        function collect() {
            return {
                swap: cbSwap.value,
                autoKey: cbKey.value,
                bendFlip: cbFlip.value,
                manual: (ddLen.selection !== null && ddLen.selection.index === 1),
                l1: Math.max(1, toNum(etL1.text, 120)),
                l2: Math.max(1, toNum(etL2.text, 120)),
                samples: clampNum(toNum(etSmp.text, 12), 4, 24),
                presetIndex: (ddPreset.selection !== null ? ddPreset.selection.index : 0),
                style: (ddStyle.selection !== null ? ddStyle.selection.index + 1 : 1),
                smooth: 55,
                squash: Math.max(0, toNum(etSquash.text, 100)),
                elastic: Math.max(0, toNum(etElastic.text, 20)),
                hi: Math.max(0, toNum(etHi.text, 42)),
                out: Math.max(0, toNum(etOut.text, 0)),
                id: toNum(etId.text, 0),
                cycles: Math.max(1, toNum(etCyc.text, 2)),
                ease: clampNum(toNum(etEase.text, 66), 0.1, 100),
                keyRoot: cbKeyRoot.value,
                followRot: cbFollow.value,
                foot: false
            };
        }

        // 预设列表可能因"存为预设"而变长：重建下拉
        function refreshPresetList() {
            var names = presetNames();
            var prev = (ddPreset.selection !== null) ? ddPreset.selection.index : 0;
            while (ddPreset.items.length > 0) { ddPreset.remove(ddPreset.items[0]); }
            var i;
            for (i = 0; i < names.length; i++) {
                ddPreset.add("item", names[i]);
            }
            ddPreset.selection = clampNum(prev, 0, names.length - 1);
        }

        btnCreate.onClick = function () {
            try { createLimb(collect()); } catch (e) { alert("创建肢体异常：" + e.toString()); }
        };
        btnApply.onClick = function () {
            try { applyStyleToLimb(collect()); } catch (e) { alert("应用样式异常：" + e.toString()); }
        };
        btnCap.onClick = function () {
            try { captureCurrentAsPreset(collect()); refreshPresetList(); } catch (e) { alert("存预设异常：" + e.toString()); }
        };
        btnHand.onClick = function () {
            var c = collect(); c.foot = false;
            try { createDefaultHand(c); } catch (e) { alert("生成手异常：" + e.toString()); }
        };
        btnFoot.onClick = function () {
            var c = collect(); c.foot = true;
            try { createDefaultHand(c); } catch (e) { alert("生成脚异常：" + e.toString()); }
        };
        btnBind.onClick = function () {
            try { bindArtToTip(collect()); } catch (e) { alert("绑定异常：" + e.toString()); }
        };
        btnPose.onClick = function () {
            try { poseKey(collect()); } catch (e) { alert("打帧异常：" + e.toString()); }
        };
        btnCycle.onClick = function () {
            try { genCycle(collect()); } catch (e) { alert("生成循环异常：" + e.toString()); }
        };
        btnRemove.onClick = function () {
            try { removeRig(collect(), false); } catch (e) { alert("移除异常：" + e.toString()); }
        };
        btnRemoveAll.onClick = function () {
            try { removeRig(collect(), true); } catch (e) { alert("移除异常：" + e.toString()); }
        };

        win.onResizing = win.onResize = function () { this.layout.resize(); };

        win.layout.layout(true);
        if (win instanceof Window) {
            win.center();
            win.show();
        }
        return win;
    }

    // ==================================================================
    // 十三、入口
    // ==================================================================
    // Node 自查钩子：在 AE 里 module 未定义，此块被跳过（不影响面板启动）
    if (typeof module !== "undefined" && module && module.exports) {
        module.exports = {
            buildPathExpr: buildPathExpr,
            buildJointPosExpr: buildJointPosExpr,
            buildUpperRotExpr: buildUpperRotExpr,
            buildLowerRotExpr: buildLowerRotExpr,
            IK_CORE_LINES: IK_CORE_LINES,
            PRESETS: PRESETS,
            presetToStr: presetToStr,
            strToPreset: strToPreset,
            version: SCRIPT_VER
        };
        return;
    }

    buildUI(thisObj);

})(this);
