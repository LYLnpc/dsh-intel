#target aftereffects

/**************************************************************************
 * Scribe Clone  v1.0.0  (ExtendScript .jsx for After Effects)
 * ------------------------------------------------------------------------
 * CLEAN-ROOM REIMPLEMENTATION NOTICE:
 * Mechanism written from scratch from the public product description
 * ("automated typeface library for quick write-on / write-off effect",
 * Lesterbanks review) and the spec in intel/specs/scribe.md.
 * No original source, installer, binary, font asset or resource of the
 * commercial script was obtained, inspected or referenced.
 *
 * FONT ASSETS: the original 6 typefaces are copyrighted artwork and are
 * NOT reproduced here. Glyph outlines come from the PUBLIC DOMAIN Hershey
 * single-stroke fonts (see README section 2). Behaviour is equivalent,
 * the letterforms are deliberately different.
 * ------------------------------------------------------------------------
 * ES3 / ExtendScript only. ASCII-only source on purpose.
 *
 * NON-WHITELISTED APIs USED (declared in README section 6):
 *   new Shape(), Layer.property(matchName), PropertyBase.matchName,
 *   group.addProperty() for vector groups / trim / stroke,
 *   Property.setValueAtTime / setInterpolationTypeAtKey /
 *   setTemporalEaseAtKey for the trim keyframes.
 **************************************************************************/

(function scribeClone(thisObj) {

    var SCRIPT_NAME = "Scribe Clone";
    var VERSION = "1.0.0";
    var SET_SECTION = "ScribeClone";

    /* ------------------------------------------------------------------
     * Public-domain Hershey single-stroke glyph table (compressed).
     *   chars separated by '#', strokes by '|', each point = 2 chars
     *   (x then y), value = charCode - 57.  chars[0] is ASCII 33 '!'.
     * Source: techninja/hersheytextjs hersheytext.min.json (Hershey fonts,
     * public domain, original vector data by Dr. A. V. Hershey / US NBS).
     * ------------------------------------------------------------------ */
    var GLYPH_DATA = {"futural":">:>H|>M=N>O?N>M#=:=A|E:EA#D6=V|J6CV|=CKC|<IJI#A6AS|E6ES|J=H;E:A:>;<=<?=A>B@CFEHFIGJIJLHNEOAO>N<L#N:<O|A:C<C>B@@A>A<?<==;?:A:C;F<I<L;N:|JHHIGKGMIOKOMNNLNJLHJH#PCPBOANAMBLDJIHLFNDO@O>N=M<K<I=G>FEBFAG?G=F;D:B;A=A?BBDEILKNMOOOPNPM#><=;>:?;?=>?=@#D6B8@;>?=D=H>M@QBTDV#<6>8@;B?CDCHBM@Q>T<V#A@AL|<CFI|FC<I#F=FO|=FOF#>K=L<K=J>K>M<O#=FOF#=J<K=L>K=J#M6;V#B:?;=><C<F=K?NBODOGNIKJFJCI>G;D:B:#?>A=D:DO#=?=>><?;A:E:G;H<I>I@HBFE<OJO#>:I:CBFBHCIDJGJIILGNDOAO>N=M<K#F:<HKH|F:FO#H:>:=C>BAADAGBIDJGJIILGNDOAO>N=M<K#I=H;E:C:@;>>=C=H>L@NCODOGNILJIJHIEGCDBCB@C>E=H#J:@O|<:J:#A:>;===?>A@BDCGDIFJHJKIMHNEOAO>N=M<K<H=F?DBCFBHAI?I=H;E:A:#IAHDFFCGBG?F=D<A<@==?;B:C:F;H=IAIFHKFNCOAO>N=L#=C<D=E>D=C|=J<K=L>K=J#=C<D=E>D=C|>K=L<K=J>K>M<O#M==FMO#=COC|=IOI#==MF=O#<?<>=<>;@:D:F;G<H>H@GBFCBEBH|BMANBOCNBM#KBJ@H?E?C@BAADAGBIDJGJIIJG|E?CABDBGCIDJ|K?JGJILJNJPHQEQCP@O>M<K;H:E:B;@<>>=@<C<F=I>K@MBNEOHOKNMMNL|L?KGKILJ#B::O|B:JO|=HGH#=:=O|=:F:I;J<K>K@JBICFD|=DFDIEJFKHKKJMINFO=O#K?J=H;F:B:@;>==?<B<G=J>L@NBOFOHNJLKJ#=:=O|=:D:G;I=J?KBKGJJILGNDO=O#=:=O|=:J:|=DED|=OJO#=:=O|=:J:|=DED#K?J=H;F:B:@;>==?<B<G=J>L@NBOFOHNJLKJKG|FGKG#=:=O|K:KO|=DKD#=:=O#E:EJDMCNAO?O=N<M;J;H#=:=O|K:=H|BCKO#=:=O|=OIO#=:=O|=:EO|M:EO|M:MO#=:=O|=:KO|K:KO#B:@;>==?<B<G=J>L@NBOFOHNJLKJLGLBK?J=H;F:B:#=:=O|=:F:I;J<K>KAJCIDFE=E#B:@;>==?<B<G=J>L@NBOFOHNJLKJLGLBK?J=H;F:B:|EKKQ#=:=O|=:F:I;J<K>K@JBICFD=D|DDKO#J=H;E:A:>;<=<?=A>B@CFEHFIGJIJLHNEOAO>N<L#A:AO|::H:#=:=I>L@NCOEOHNJLKIK:#::BO|J:BO#;:@O|E:@O|E:JO|O:JO#<:JO|J:<O#::BDBO|J:BD#J:<O|<:J:|<OJO#=6=V|>6>V|=6D6|=VDV#9:GR#B6BV|C6CV|<6C6|<VCV#A89F|A8IF#9VKV#>?<A<C=D>C=B<C#HAHO|HDFBDAAA?B=D<G<I=L?NAODOFNHL#=:=O|=D?BAADAFBHDIGIIHLFNDOAO?N=L#HDFBDAAA?B=D<G<I=L?NAODOFNHL#H:HO|HDFBDAAA?B=D<G<I=L?NAODOFNHL#<GHGHEGCFBDAAA?B=D<G<I=L?NAODOFNHL#C:A:?;>>>O|;ABA#HAHQGTFUDVAV?U|HDFBDAAA?B=D<G<I=L?NAODOFNHL#=:=O|=E@BBAEAGBHEHO#<:=;>:=9<:|=A=O#>:?;@:?9>:|?A?R>U<V:V#=:=O|GA=K|AGHO#=:=O#=A=O|=E@BBAEAGBHEHO|HEKBMAPARBSESO#=A=O|=E@BBAEAGBHEHO#AA?B=D<G<I=L?NAODOFNHLIIIGHDFBDAAA#=A=V|=D?BAADAFBHDIGIIHLFNDOAO?N=L#HAHV|HDFBDAAA?B=D<G<I=L?NAODOFNHL#=A=O|=G>D@BBAEA#GDFBCA@A=B<D=F?GDHFIGKGLFNCO@O=N<L#>:>K?NAOCO|;ABA#=A=K>N@OCOENHK|HAHO#;AAO|GAAO#<A@O|DA@O|DAHO|LAHO#<AGO|GA<O#;AAO|GAAO?S=U;V:V#GA<O|<AGA|<OGO#B6@7?8>:><?>@?AAAC?E|@7?9?;@=A>B@BBAD=FAHBJBLAN@O?Q?S@U|?GAIAK@M?N>P>R?T@UBV#=6=V#>6@7A8B:B<A>@??A?CAE|@7A9A;@=?>>@>B?DCF?H>J>L?N@OAQAS@U|AG?I?K@MANBPBRAT@U>V#<I<G=D?CACCDGGIHKHMGNE|<G=E?DADCEGHIIKIMHNENC#9:9O:O::;:;O<O<:=:=O>O>:?:?O@O@:A:AOBOB:C:CODOD:E:EOFOF:G:GOHOH:I:IO","futuram":">:>H?H|>:?:?H|>L=M=N>O?O@N@M?L>L|>M>N?N?M>M#>:=;=A|>;=A|>:?;=A|G:F;FA|G;FA|G:H;FA#D6=V|J6CV|=CKC|<IJI#B6BSCS|B6C6CS|G=I=G;D:A:>;<=<?=A>BFFGGHIHKGMDNAN?M>L|G=F<D;A;><===?>AFEHGIIIKHMGNDOAO>N<L>L|HLEN#N:<O|A:C<C>B@@A>A<?<==;?:A:C;F<I<L;N:|JHHIGKGMIOKOMNNLNJLHJH#NBMCNDOCOBNAMALBKDIIGLENCO@O=N<L<I=GCCEAF?F=E;C:A;@=@?ABCEHLJNMONOONOM|@O>N=L=I>G@E|@?AAILKNMO#>:=;=A|>;=A|>:?;=A#D6B8@;>?=D=H>M@QBTDV|B8@<??>D>H?M@PBT#<6>8@;B?CDCHBM@Q>T<V|>8@<A?BDBHAM@P>T#A:@;BEAF|A:AF|A:B;@EAF|<===ECFC|<=FC|<=<>FBFC|F=E==C<C|F=<C|F=F><B<C#E=ENFN|E=F=FN|=ENENF|=E=FNF#@N?O>O=N=M>L?L@M@P?R=S|>M>N?N?M>M|?O@P|@N?R#=FOF#>L=M=N>O?O@N@M?L>L|>M>N?N?M>M#M6;V<V|M6N6<V#B:?;=><C<F=K?NBODOGNIKJFJCI>G;D:B:|@;>>=C=F>K@N|?MBNDNGM|FNHKIFICH>F;|G<D;B;?<#?>A=D:DO|?>??A>C<CODO#=?=>><?;A:E:G;H<I>I@HBFE=O|=?>?>>?<A;E;G<H>H@GBEE<O|=NJNJO|<OJO#>:I:BC|>:>;H;|H:AC|BBDBGCIEJHJIILGNDOAO>N=M<K=K|ACDCGDIG|ECHEIHIIHLEN|IJGMDNAN>M=K|@N=L#F=FOGO|G:GO|G:<JKJ|F==J|=IKIKJ#>:=C|?;>B|>:H:H;|?;H;|>BAADAGBIDJGJIILGNDOAO>N=M<K=K|=C>C@BDBGCIF|EBHDIGIIHLEN|IJGMDNAN>M=K|@N=L#G;H=I=H;E:C:@;>>=C=H>L@NCODOGNILJIJHIEGCDBCB@C>E|H<E;C;@<|A;?>>C>H?LBN|>J@MCNDNGMIJ|ENHLIIIHHEEC|IGGDDCCC@D>G|BC?E>H#<:J:@O|<:<;I;|I:?O@O#A:>;===?>A?BACEDGEHFIHIKHMENAN>M=K=H>F?EADECGBHAI?I=H;E:A:|?;>=>??AABECGDIFJHJKIMHNEOAO>N=M<K<H=F?DACEBGAH?H=G;|H<E;A;><|=L@N|FNIL#HDFFCGBG?F=D<A<@==?;B:C:F;H=IAIFHKFNCOAO>N=L>L?N|HAGDDF|HBFECFBF?E=B|AF>D=A=@>=A;|=??<B;C;F<H?|D;G=HAHFGKEN|FMCNAN>M#>A=B=C>D?D@C@B?A>A|>B>C?C?B>B|>L=M=N>O?O@N@M?L>L|>M>N?N?M>M#>A=B=C>D?D@C@B?A>A|>B>C?C?B>B|@N?O>O=N=M>L?L@M@P?R=S|>M>N?N?M>M|?O@P|@N?R#M==FMO#=ANANB|=A=BNB|=ININJ|=I=JNJ#==MF=O#<?<>=<>;A:D:G;H<I>I@HBGCEDBE|<?=?=>><A;D;G<H>H@GBECBD|==@;|E;H=|HADD|BDBHCHCD|BLAMANBOCODNDMCLBL|BMBNCNCMBM#KBJ@H?E?C@BAADAGBIDJGJIIJG|E?CABDBGCIDJ|K?JGJILJNJPHQEQCP@O>M<K;H:E:B;@<>>=@<C<F=I>K@MBNEOHOKNMMNL|L?KGKILJ#C:;O|C=<O;O|C=JOKO|C:KO|>IHI|=JIJ#=:=O|>;>N|=:E:H;I<J>JAICHDEE|>;E;H<I>IAHCED|>DEDHEIFJHJKIMHNEO=O|>EEEHFIHIKHMEN>N#K?J=H;F:B:@;>==?<B<G=J>L@NBOFOHNJLKJ|K?J?I=H<F;B;@<>?=B=G>J@MBNFNHMILJJKJ#=:=O|>;>N|=:D:G;I=J?KBKGJJILGNDO=O|>;D;G<H=I?JBJGIJHLGMDN>N#=:=O|>;>N|=:I:|>;I;I:|>DDDDE|>EDE|>NINIO|=OIO#=:=O|>;>O=O|=:I:|>;I;I:|>DDDDE|>EDE#K?J=H;F:B:@;>==?<B<G=J>L@NBOFOHNJLKJKFFF|K?J?I=H<F;B;@<?=>?=B=G>J?L@MBNFNHMILJJJGFGFF#=:=O|=:>:>O=O|K:J:JOKO|K:KO|>DJD|>EJE#=:=O>O|=:>:>O#E:EJDMBN@N>M=J<J|E:F:FJEMDNBO@O>N=M<J#=:=O>O|=:>:>O|K:J:>F|K:>G|ACJOKO|BCKO#=:=O|=:>:>N|>NINIO|=OIO#=:=O|>?>O=O|>?EO|=:EL|M:EL|L?EO|L?LOMO|M:MO#=:=O|>=>O=O|>=KO|=:JL|J:JL|J:K:KO#B:@;>==?<B<G=J>L@NBOFOHNJLKJLGLBK?J=H;F:B:|C;@<>?=B=G>J@MCNENHMJJKGKBJ?H<E;C;#=:=O|>;>O=O|=:F:H;I<J>JAICHDFE>E|>;F;H<I>IAHCFD>D#B:@;>==?<B<G=J>L@NBOFOHNJLKJLGLBK?J=H;F:B:|C;@<>?=B=G>J@MCNENHMJJKGKBJ?H<E;C;|ELJQKQ|ELFLKQ#=:=O|>;>O=O|=:E:H;I<J>JAICHDEE>E|>;E;H<I>IAHCED>D|CEIOJO|DEJO#J=H;E:A:>;<=<?=A>B@CEEGFHGIIILHMENAN?M>L<L|J=H=G<E;A;><===?>A@BEDGEIGJIJLHNEOAO>N<L#A;AO|B;BOAO|;:H:H;|;:;;H;#=:=I>L@NCOEOHNJLKIK:|=:>:>I?L@MCNENHMILJIJ:K:#;:CO|;:<:CL|K:J:CL|K:CO#;:AO|;:<:AL|F:AL|F=AO|F=KO|F:KL|Q:P:KL|Q:KO#<:IOJO|<:=:JO|J:I:<O|J:=O<O#;:BDBOCO|;:<:CD|J:I:BD|J:CDCO#I:<O|J:=O|<:J:|<:<;I;|=NJNJO|<OJO#=6=V|>6>V|=6D6|=VDV#9:GR#B6BV|C6CV|<6C6|<VCV#<HDCLH|<HDDLH#9VMV#=:B@|=:<;B@#HAHOIO|HAIAIO|HDFBDAAA?B=D<G<I=L?NAODOFNHL|HDDBAB?C>D=G=I>L?MANDNHL#=:=O>O|=:>:>O|>D@BBAEAGBIDJGJIILGNEOBO@N>L|>DBBEBGCHDIGIIHLGMENBN>L#HDFBDAAA?B=D<G<I=L?NAODOFNHL|HDGEFCDBAB?C>D=G=I>L?MANDNFMGKHL#H:HOIO|H:I:IO|HDFBDAAA?B=D<G<I=L?NAODOFNHL|HDDBAB?C>D=G=I>L?MANDNHL#=HHHHEGCFBDAAA?B=D<G<I=L?NAODOFNHL|=GGGGEFCDBAB?C>D=G=I>L?MANDNFMGKHL#D:B:@;?>?O@O|D:D;B;@<|A;@>@O|<ACACB|<A<BCB#IAHAHPGSFTDUBU@T?S=S|IAIPHSFUDVAV?U=S|HDFBDAAA?B=D<G<I=L?NAODOFNHL|HDDBAB?C>D=G=I>L?MANDNHL#=:=O>O|=:>:>O|>EABCAFAHBIEIO|>EACCBEBGCHEHOIO#=:<;<<==>=?<?;>:=:|=;=<><>;=;|=A=O>O|=A>A>O#=:<;<<==>=?<?;>:=:|=;=<><>;=;|=A=V>V|=A>A>V#=:=O>O|=:>:>O|IAHA>K|IA>L|AHGOIO|BGIO#=:=O>O|=:>:>O#=A=O>O|=A>A>O|>EABCAFAHBIEIO|>EACCBEBGCHEHOIO|IELBNAQASBTETO|IELCNBPBRCSESOTO#=A=O>O|=A>A>O|>EABCAFAHBIEIO|>EACCBEBGCHEHOIO#AA?B=D<G<I=L?NAODOFNHLIIIGHDFBDAAA|AB?C>D=G=I>L?MANDNFMGLHIHGGDFCDBAB#=A=V>V|=A>A>V|>D@BBAEAGBIDJGJIILGNEOBO@N>L|>DBBEBGCHDIGIIHLGMENBN>L#HAHVIV|HAIAIV|HDFBDAAA?B=D<G<I=L?NAODOFNHL|HDDBAB?C>D=G=I>L?MANDNHL#=A=O>O|=A>A>O|>G?DABCAFA|>G?EACCBFBFA#GDFBCA@A=B<D=F?GDIFJ|EIFKFLEN|FMCN@N=M|>N=L<L|GDFDEB|FCCB@B=C|>B=D>F|=E?FDHFIGKGLFNCO@O=N<L#>:>O?O|>:?:?O|;ABABB|;A;BBB#=A=K>N@OCOENHK|=A>A>K?MANCNEMHK|HAHOIO|HAIAIO#;AAO|;A<AAM|GAFAAM|GAAO#<AAO|<A=AAL|EAAL|EDAO|EDIO|EAIL|NAMAIL|NAIO#<AGOHO|<A=AHO|HAGA<O|HA=O<O#;AAO|;A<AAM|GAFAAM=V|GAAO>V=V#FB<O|HA>N|<AHA|<A<BFB|>NHNHO|<OHO#C6<FCV#=6=V#=6DF=V#<I<G=D?CACCDGGIHKHMGNE|<G=E?DADCEGHIIKIMHNENC#9:9O:O::;:;O<O<:=:=O>O>:?:?O@O@:A:AOBOB:C:CODOD:E:EOFOF:G:GOHOH:I:IO","scripts":"A:@;>G|A;>G|A:B;>G|<M;N<O=N<M#@:>A|A:>A|I:GA|J:GA#D6=V|J6CV|=CKC|<IJI#E6=S|J6BS|K>J?K@L?L>K<J;G:C:@;>=>??A@BGFIH|>?@AGEHFIHIKHMGNDO@O=N<M;K;J<I=J<K#N:<O|A:C<C>B@@A>A<?<==;?:A:C;F<I<L;N:|JHHIGKGMIOKOMNNLNJLHJH#PBOCPDQCQBPAOAMBKDFLDNBO?O<N;L;J<H=G?FDDFCHAI?I=H;F:D;C=C@DFEIGLINKOMONMNL|?O=N<L<J=H>GDD|C@DEEHGKIMKNMNNM#A<@;A:B;B<A>?@#H6D9A<??=C<H<L=Q>T?V|D9A=?A>D=I=N>S?V#B6C8D;E@EDDIBM@P=S9V|B6C9D>DCCHBK@O=S#C:CF|>=HC|H=>C#F=FO|=FOF#<O;N<M=N=O<Q:S#=FOF#>M=N>O?N>M#Q67V#E:B;@=>@=C<G<J=M>N@OBOENGLIIJFKBK?J<I;G:E:|E:C;A=?@>C=G=J>M@O|BODNFLHIIFJBJ?I<G:#E>@O|G:AO|G:D=A??@|F=B??@#@>A?@@???>@<A;D:G:J;K=K?JAHCEEAG>I<K:O|G:I;J=J?IAGCAG|;M<L>LCNFNHMIK|>LCOFOHNIK#@>A?@@???>@<A;D:G:J;K=K?JAGCDD|G:I;J=J?IAGC|BDDDGEHFIHIKHMGNDO@O=N<M;K;J<I=J<K|DDFEGFHHHKGMFNDO#I;CO|J:DO|J:;IKI#B:=D|B:L:|B;G;L:|=D>CABDBGCHDIFIIHLFNCO@O=N<M;K;J<I=J<K|DBFCGDHFHIGLENCO#J=I>J?K>K=J;H:E:B;@=>@=C<G<K=M>N@OCOFNHLIJIGHEGDECBC@D>F=H|E:C;A=?@>C=G=L>N|COENGLHJHFGD#?:=@|L:K=I@DFBIAK@O|I@CFAI@K?O|>=A:C:H=|?<A;C;H=J=K<L:#D:A;@<?>?A@CBDEDICJBK@K=J;G:D:|D:B;A<@>@AACBD|EDHCIBJ@J=I;G:|BD>E<G;I;L<N?OCOGNHMIKIHHFGEED|BD?E=G<I<L=N?O|COFNGMHKHGGE#JAICGEEFBF@E?D>B>??=A;D:G:I;J<K>KBJFIIGLENBO?O=N<L<K=J>K=L|@E?C??@=B;D:|I;J=JBIFHIFLDNBO#?A>B?C@B?A|<M;N<O=N#?A>B?C@B?A|<O;N<M=N=O<Q:S#M==FMO#=COC|=IOI#==MF=O#@>A?@@???>@<A;D:H:K;L=L?KAJBDDBEBGCHEH|H:J;K=K?JAIBGC|AM@NAOBNAM#KBJ@H?E?C@BAADAGBIDJGJIIJG|E?CABDBGCIDJ|K?JGJILJNJPHQEQCP@O>M<K;H:E:B;@<>>=@<C<F=I>K@MBNEOHOKNMMNL|L?KGKILJ#9O;N>KAGE@H:HOGLEICG@E>E=F=H>J@LCNFOKO#F<G=G@FDEGDIBL@N>O=O<N<K=F>C?AA>C<E;H:K:M;N=N?MALBJCGD|FDGDJEKFLHLKKMJNHOEOCNBL#E@EAFBHBJAK?K=J;H:E:B;@=>@=B<F<J=M>N@OBOENGLHJ#F:D;C=BAAG@J?L=N;O9O8N8L9K;K=L?NBOEOHNJLLHMCM?L<K;I:F:D<D>EAGDIFLHNI#G>G?H@J@K?K=J;G:C:@;?=?@@BACDDAD>E=F<H<K=M>NAODOGNILJJ#C@A@??>=?;B:E:I;L;N:|I;GBEHCLAN?O=O;N:L:J;I=I?J|BDKD#9O;N?JBECBD>D;C:B:A;@=@@ABCCGCJBKAL?LEKJJLHNEOAO>N<L;J;H#@A>@=>==>;@:A:C;D=D?CCAI?M=O;O:N:L|@FICKBN@P>Q<Q;P:O:M<K@IFHKHNIOJOLNMMOJ#GJEHCEBCA@A=B;C:E:F;G=G@FEDJCLAN?O=O;N:L:J;I=I?J#CRAO?J>D>>?;A:C:D;E>EADFAO?U>X=Z;[:Z:X;U=R?PBNFL#@A>@=>==>;@:A:C;D=D?CCAI?M=O;O:N:L|Q=Q;P:O:M;K=I@GBECCC|ECFEFLGNHOIOKNLMNJ#=F?FCEFCHAI?I<H:F:E;D=CBBGAJ@L>N<O:O9N9L:K<K>LANDOFOINKL#>A<@;>;=<;>:?:A;B=B?AD@H>O|@HC@E<F;H:I:K;L=L?KDJHHO|JHM@O<P;R:S:U;V=V?UDSKSNTOUOWNXMZJ#>A<@;>;=<;>:?:A;B=B?AD@H>O|@HC@E<F;H:J:L;M=M?LDJKJNKOLONNOMQJ#E:B;@=>@=B<F<J=M>N@OBOENGLIIJGKCK?J<I;G:E:C<C?DBFEHGKIMJ#F<G=G@FDEGDIBL@N>O=O<N<K=F>C?AA>C<E;H:M:O;P<Q>QAPCODMEJEHDGC#F@EBDCBD@D?B?@@=B;E:H:J;K=KAJDHGDKAM?N<O:O9N9L:K<K>LANDOGOJNLL#F<G=G@FDEGDIBL@N>O=O<N<K=F>C?AA>C<E;H:L:N;O<P>PAOCNDLEIEFDGEHGHLINKOMNNMPJ#9O;N=L@HBEDAE>E;D:C:B;A=A?BADCGEIGJIJKIMHNEOAO>N<L;J;H#C@A@??>=?;B:E:I;L;N:|I;GBEHCLAN?O=O;N:L:J;I=I?J#>A<@;>;=<;>:?:A;B=B?AC@F?J?L@NBODOFNGMIILAN:|LAKEJKJNKOLONNOMQJ#>A<@;>;=<;>:?:A;B=B?AC@F?J?M@OBODNGKIHKDLAM=M;L:K:J;I=I?JBLDNE#>A<@;>;=<;>:?:A;B=B@AO|K:AO|K:IO|W:U;R>OBLHIO#A@?@>?>=?;A:C:E;F=F@DIDLENGOIOKNLLLJKIII|P=P;O:M:K;I=G@CIAL?N=O;O:N:L#>A<@;>;=<;>:?:A;B=B?AC@F?J?L@NAOCOENGLIIJGLA|N:LAIKGQEVCZA[@Z@XAUCRFOIMNJ#F@EBDCBD@D?B?@@=B;E:H:J;K=KAJDHHEKAN?O<O;N;L<K?KALBMCOCRBUAW?Z=[<Z<X=U?RBOEMKJ#=6=V|>6>V|=6D6|=VDV#9:GR#B6BV|C6CV|<6C6|<VCV#?@A=C@|<CA>FC|A>AO#9QIQ#B:@<?>??@@A?@>#BIAG?F=F;G:H9J9L:N<O>O@NALCFBKBNCODOFNGMIJ#9J;G>B?@@=@;?:=;<=;A:H:N;O<O>N@LAIAFBJCKEKGJ#@H@G?F=F;G:H9J9L:N<O?OBMDJ#BIAG?F=F;G:H9J9L:N<O>O@NALG:|CFBKBNCODOFNGMIJ#:M<L=K>I>G=F<F:G9I9L:N<O>O@NAMCJ#9J=E?B@@A=A;@:>;==;E8N5U4X4Z5[7Z8W9N:O<O>N?MAJ#BIAG?F=F;G:H9J9L:N<O>O@NAM|CFAM=X<Z:[9Z9X:U=R@PBOEMHJ#9J;G>B?@@=@;?:=;<=;A:G9O|9O:L;J=G?FAFBGBIALANBOCOENFMHJ#<A<B=B=A<A|9J;F9L9N:O;O=N>M@J#<A<B=B=A<A|9J;F5X4Z2[1Z1X2U5R8P:O=M@J#9J;G>B?@@=@;?:=;<=;A:G9O|9O:L;J=G?FAFBGBI@J=J|=J?K@NAOBODNEMGJ#9J;G>B?@@=@;?:=;<=;A:H:N;O<O>N?MAJ#9J;G=F>G>H=L<O|=L>J@GBFDFEGEHDLCO|DLEJGGIFKFLGLIKLKNLOMOONPMRJ#9J;G=F>G>H=L<O|=L>J@GBFDFEGEIDLDNEOFOHNIMKJ#?F=F;G:H9J9L:N<O>O@NAMBKBIAG?F>G>I?KALDLFKGJ#9J;G<E;I5[|;I<G>F@FBGCICKBMAN?O|;N=O@OCNEMHJ#BIAG?F=F;G:H9J9L:N<O>O@N|CFBI@N=U<X<Z=[?Z@W@PBOEMHJ#9J;G<E<G?G@H@J?M?N@OAOCNDMFJ#9J;G<E<G>J?L?N=O|9N;O?OANBMDJ#9J;G=C|@::L:N;O=O?N@MBJ|:BAB#9J;F9L9N:O<O>N@LBI|CFALANBOCOENFMHJ#9J;F:K:N;O<O?NALBIBF|BFCJDKFKHJ#<F:H9K9M:O<O>N@L|BF@L@NAOCOENGLHIHF|HFIJJKLKNJ#9J;G=F?F@G@NAODOGMIJ|FGEFCFBG>N=O;O:N#9J;F9L9N:O<O>N@LBI|CF=X<Z:[9Z9X:U=R@PBOEMHJ#9J;G=F?FAHAJ@L>N;O=P>R>U=X<Z:[9Z9X:U=R@PDMGJ#B6@7?8>:><?>@?AAAC?E|@7?9?;@=A>B@BBAD=FAHBJBLAN@O?Q?S@U|?GAIAK@M?N>P>R?T@UBV#=6=V#>6@7A8B:B<A>@??A?CAE|@7A9A;@=?>>@>B?DCF?H>J>L?N@OAQAS@U|AG?I?K@MANBPBRAT@U>V#<I<G=D?CACCDGGIHKHMGNE|<G=E?DADCEGHIIKIMHNENC#?:=;<=<?=A?BABCAD?D=C;A:?:","scriptc":"A:@;>G|A;>G|A:B;>G|<M;N<O=N<M#@:>A|A:>A|I:GA|J:GA#D:=V|J:CV|=EKE|<KJK#E6=S|J6BS|K>J?K@L?L>K<J;G:C:@;>=>??A@BGFIH|>?@AGEHFIHIKHMGNDO@O=N<M;K;J<I=J<K#N:<O|A:C<C>B@@A>A<?<==;?:A:C;F<I<L;N:|JHHIGKGMIOKOMNNLNJLHJH#PBOCPDQCQBPAOAMBKDFLDNBO?O<N;L;J<H=G?FDDFCHAI?I=H;F:D;C=C@DFEIGLINKOMONMNL|?O=N<L<J=H>GDD|C@DEEHGKIMKNMNNM#A<@;A:B;B<A>?@#H6D9A<??=C<H<L=Q>T?V|D9A=?A>D=I=N>S?V#B6C8D;E@EDDIBM@P=S9V|B6C9D>DCCHBK@O=S#C:CF|>=HC|H=>C#F=FO|=FOF#<O;N<M=N=O<Q:S#=FOF#<M;N<O=N<M#Q67V#E:B;@=>@=C<G<J=M>N@OBOENGLIIJFKBK?J<I;G:E:|E:C;A=?@>C=G=J>M@O|BODNFLHIIFJBJ?I<G:#E>@O|G:AO|G:D=A??@|F=B??@#@>A?@@???>@<A;D:G:J;K=K?JAHCEEAG>I<K:O|G:I;J=J?IAGCAG|;M<L>LCNFNHMIK|>LCOFOHNIK#@>A?@@???>@<A;D:G:J;K=K?JAGCDD|G:I;J=J?IAGC|BDDDGEHFIHIKHMGNDO@O=N<M;K;J<I=J<K|DDFEGFHHHKGMFNDO#I;CO|J:DO|J:;IKI#B:=D|B:L:|B;G;L:|=D>CABDBGCHDIFIIHLFNCO@O=N<M;K;J<I=J<K|DBFCGDHFHIGLENCO#J=I>J?K>K=J;H:E:B;@=>@=C<G<K=M>N@OCOFNHLIJIGHEGDECBC@D>F=H|E:C;A=?@>C=G=L>N|COENGLHJHFGD#?:=@|L:K=I@DFBIAK@O|I@CFAI@K?O|>=A:C:H=|?<A;C;H=J=K<L:#D:A;@<?>?A@CBDEDICJBK@K=J;G:D:|D:B;A<@>@AACBD|EDHCIBJ@J=I;G:|BD>E<G;I;L<N?OCOGNHMIKIHHFGEED|BD?E=G<I<L=N?O|COFNGMHKHGGE#JAICGEEFBF@E?D>B>??=A;D:G:I;J<K>KBJFIIGLENBO?O=N<L<K=J>K=L|@E?C??@=B;D:|I;J=JBIFHIFLDNBO#?A>B?C@B?A|<M;N<O=N#?A>B?C@B?A|<O;N<M=N=O<Q:S#M==FMO#=COC|=IOI#==MF=O#@>A?@@???>@<A;D:H:K;L=L?KAJBDDBEBGCHEH|H:J;K=K?JAIBGC|AM@NAOBNAM#KBJ@H?E?C@BAADAGBIDJGJIIJG|E?CABDBGCIDJ|K?JGJILJNJPHQEQCP@O>M<K;H:E:B;@<>>=@<C<F=I>K@MBNEOHOKNMMNL|L?KGKILJ#L:J<H?EDCG@K=N;O9O8N8L9K:L9M|L:K>IHHO|L:IO|HOHMGJFHDFBE@E?F?H@KCNFOJOLN#H;G<F>DCBIAK?N=O|G<F?DGCJBL@N=O;O:N:L;K<L;M|B@AB@C>C=B=@>>@<B;E:K:M;N=N?MAKBGCEC|K:L;M=M?LAKB|GCJDKELGLJKMJNHOFOENELFI|GCIDJEKGKJJMHO#<<;>;@<B?CBCFBHAJ?K=K;J:H:E;B>@A>E=I=L>NAOCOFNHLIJIHHFFFDGCI|H:F;C>AA?E>I>L?NAO#H;G<F>DCBIAK?N=O|G<F?DGCJBL@N=O;O:N:L;K=K?LANCOFOHNJLLHMCM@L=J;H:C:@;>==?=A>B@BAAB?#G=F>F@GAIAJ?J=I;G:D:B;A<@>@@ABCC|D:B<A>AACC|CCAC>D<F;H;K<M=N?OBOENGLHJHHGFEFCGBI|AC?D=F<H<L=N#I<H>FCDICKAN?O|C@BB@C>C=A=?>=@;C:M:J;I<H?FGEJDLBN?O=O;N:M:L;K<L;M|E:I;J;|AGBFDEHEJDLAJH#<=;?;A<C>DADDCFBI?J<J;I:H:F;D=C?BBBECGEHGHIGKELC|I:G;E=D?CBCFEH|LCKGIKGMENAO>O<N;L;K<J=K<L|KGIJGLDNAO#?@>?>=?;B:E:BE@K?M>N<O:O9N9L:K;L:M|E:BCAF?K>M<O|=H>G@FICKBN@P>Q<Q;P:O:M;K>J@HFGJGMIOJOLNNL|O:M<K@IFHJHMIO#G<E?CDAI@K>N<O|I@GBDCAC?B>@>>?<A;E:I:G<F>DDBJAL?N<O:O9N9L:K;L:M#I:G<E?CD@M>Q|IAGCDDAD?C>A>??=A;E:I:G=F?CHAL@N>Q=R;S:R:P;N=L?KBJFI#?@>?>=@;C:E:BE@K?M>N<O:O9N9L:K;L:M|E:BCAF?K>M<O|M;J?HAFBCC|P;O<P=Q<Q;P:O:M;J@IAGBCC|CCFDGFHMIO|CCEDFFGMIOJOLNNL#==<?<A=C?DBDECGBJ?K<K;J:I:G;F<D?@I?K=N;O|F<D@BGAJ@L>N;O9O8N8L9K;K=L@NBOEOGNIL#G:CC@I>L<N:O8O7N7L8K9L8M|G:EADECJCNEO|G:F>ECDJDNEO|P:LCGLEO|P:NAMELJLNNOOOQNSL|P:O>NCMJMNNO#D:C>AD?I>K<N:O8O7N7L8K9L8M|D:D?EJFO|D:E?FJFO|R;Q<R=S<S;R:P:N;L>K@IEGKFO#D:B;@=>@=B<F<J=M>N@OBOENGLIIJGKCK?J<I;H;F<D>BBAGAJ|B;@>>B=F=J>M@O#H;G<F>DCBIAK?N=O|G<F?DGCJBL@N=O;O:N:L;K<L;M|B@AB@C>C=B=@>>@<B;E:I:L;M<N>NAMCLDIEGEED|I:K;L<M>MALCKDIE#F>F@EBDCBD@D?B?@@=B;E:H:J;K=KAJDHGDKAM?N<O:O9N9L:K<K>LANDOGOINKL|H:I;J=JAIDGGDJ@M<O#H;G<F>DCBIAK?N=O|G<F?DGCJBL@N=O;O:N:L;K<L;M|B@AB@C>C=B=@>>@<B;E:J:M;N=N?MALBICEC|J:L;M=M?LAKBIC|ECHDIFJMKO|ECGDHFIMKOLONNPL#?=>?>A?CADDDGCIBL?M<M;L:K:I;H<G>FADHCKAN?O|G>FBEIDLBN?O<O:N9L9K:J;K:L#I<H>FCDICKAN?O|C@BB@C>C=A=?>=@;C:L:J;I<H?FGEJDLBN?O=O;N:M:L;K<L;M|E:I;J;#:><;>:?:A<A?@B=J=M>O|?:@<@?=G<J<M>O@OBNEKGHHF|L:HFGJGMIOJOLNNL|M:IFHJHMIO#:><;>:?:A<A?@C>J>M?O|?:@<@?>F=J=M?O@OCNFKHHJDKAL=L;K:J:I;H=H@IBKDMEOE#<@;@:?:=;;=:A:@<?@>I=O|?@?I>O|I:G<E@BI@M>O|I:H<G@FIEO|G@GIFO|S:Q;O=M@JIHMFO#A?@@>@=?==>;@:B:D;E=E@DDBI@L>N;O9O8N8L9K:L9M|B:C;D=D@CDAI?L=N;O|N;M<N=O<O;N:L:J;H=F@DDCICLDNEOFOHNJL#<>>;@:A:C;C=ACAFBH|A:B;B=@C@FBHDHGGIEKBL@|N:L@IHGL|O:M@KEIIGLENBO>O<N;L;K<J=K<L#L<K>ICHFGHEKCMAN>O|E@DBBC@C?A??@=B;E:O:M;L<K?JCHIFLCN>O:O9N9L:K<K>LANCOFOINKL|H:L;M;#=6=V|>6>V|=6D6|=VDV#9:GR#B6BV|C6CV|<6C6|<VCV#?@A=C@|<CA>FC|A>AO#9QIQ#B:@<?>??@@A?@>#CIBG@F>F<G;H:J:L;N=O?OANBL|>F<H;J;M=O|DFBLBNDOFNGMIJ|EFCLCNDO#9J;G=C|@::L:N<O=O?NALBIBFCJDKEKGJ|A:;L;N<O#AG@HAHAG@F>F<G;H:J:L;N=O@OCMEJ|>F<H;J;M=O#CIBG@F>F<G;H:J:L;N=O?OANBL|>F<H;J;M=O|H:BLBNDOFNGMIJ|I:CLCNDO#<M>L?K@I@G?F>F<G;H:J:L;N=O@OCMEJ|>F<H;J;M=O#<F?CA@B=B;A:?;>=5X5Z6[8Z9W:N;O=O?N@MBJ|>==B<F9O7T5X#CIBG@F>F<G;H:J:L;N=O?OANBL|>F<H;J;M=O|DF>X|EFBO@T>X=Z;[:Z:X;U=S@QDOGMIJ#9J;G=C|@:9O|A::O|<I>G@FAFCGCIBLBNCO|AFBGBIALANCOENFMHJ#>@=A>B?A>@|<F:L:N<O>N?MAJ|=F;L;N<O#>@=A>B?A>@|<F6X|=F:O8T6X5Z3[2Z2X3U5S8Q<O?MAJ#9J;G=C|@:9O|A::O|BFBGCGBFAF?H<I|<I?J@NAO|<I>J?NAOBOEMGJ#9J;G=C|@::L:N<O>N?MAJ|A:;L;N<O#9J;G=F?G?I=O|=F>G>I<O|?IAGCFDFFGFIDO|DFEGEICO|FIHGJFKFMGMILLLNMO|KFLGLIKLKNMOONPMRJ#9J;G=F?G?I=O|=F>G>I<O|?IAGCFDFFGFIELENFO|DFEGEIDLDNFOHNIMKJ#@F>F<G;H:J:L;N=O?OANBMCKCIBG@F?G?I@KBLDLFKGJ|>F<H;J;M=O#9J;G=C|>@5[|?@6[|<I>G@FAFCGCIBLBNCO|AFBGBIALANCOENFMHJ#CIBG@F>F<G;H:J:L;N=O?OAN|>F<H;J;M=O|DF>X>Z?[AZBWBODOGMIJ|EFBO@T>X#9J;G=F?G?I=O|=F>G>I<O|?IAGCFDFCI|CFCIDKEKGJ#9J;G<E<G?I@K@M?N=O|<G>I?K?M=O|9N;O@OCMEJ#9J;G=C|@::L:N<O>N?MAJ|A:;L;N<O|;BAB#<F:L:N<O=O?NALCI|=F;L;N<O|DFBLBNDOFNGMIJ|EFCLCNDO#<F;H:K:N<O=O@NBLCICF|=F<H;K;N<O|CFDJEKFKHJ#=F;H:K:N<O=O?NAL|>F<H;K;N<O|CFALANCODOFNHLIIIF|DFBLBNCO|IFJJKKLKNJ#9J;G=F?F@G@I?L>N<O;O:N:M;M:N|FGEHFHFGEFDFBGAI@L@NAODOGMIJ|@GAI|BG@I|?L@N|@L>N#<F:L:N<O=O?NALCI|=F;L;N<O|DF>X|EFBO@T>X=Z;[:Z:X;U=S@QDOGMIJ#9J;G=F?FAGAJ@L=N;O|?F@G@J?L=N|;O=P>R>U=X;Z9[8Z8X9U<R?PCMFJ|;O<P=R=U<X;Z#B6@7?8>:><?>@?AAAC?E|@7?9?;@=A>B@BBAD=FAHBJBLAN@O?Q?S@U|?GAIAK@M?N>P>R?T@UBV#=6=V#>6@7A8B:B<A>@??A?CAE|@7A9A;@=?>>@>B?DCF?H>J>L?N@OAQAS@U|AG?I?K@MANBPBRAT@U>V#<I<G=D?CACCDGGIHKHMGNE|<G=E?DADCEGHIIKIMHNENC#A:?;>=>??AABCBEAF?F=E;C:A:","timesr":">:=<>H?<>:|><>B|>M=N>O?N>M#>:=;=A|>;=A|>:?;=A|G:F;FA|G;FA|G:H;FA#D6=V|J6CV|=CKC|<IJI#A6AS|E6ES|I=H>I?J>J=H;E:A:>;<=<?=A>B@CFEHFJH|<?>A@BFDHEIFJHJLHNEOAO>N<L<K=J>K=L#N:<O|A:C<C>B@@A>A<?<==;?:A:C;F<I<L;N:|JHHIGKGMIOKOMNNLNJLHJH#NBMCNDOCOBNAMALBKDIIGLENCO@O=N<L<I=GCCEAF?F=E;C:A;@=@?ABCEHLJNMONOONOM|@O>N=L=I>G@E|@?AAILKNMO#=:<A|>:<A#D6B8@;>?=D=H>M@QBTDV|B8@<??>D>H?M@PBT#<6>8@;B?CDCHBM@Q>T<V|>8@<A?BDBHAM@P>T#A@AL|<CFI|FC<I#F=FO|=FOF#>K=L<K=J>K>M<O#=FOF#=J<K=L>K=J#M6;V#B:?;=><C<F=K?NBODOGNIKJFJCI>G;D:B:|B:@;?<>>=C=F>K?M@NBO|DOFNGMHKIFICH>G<F;D:#?>A=D:DO|C;CO|?OHO#=>>?=@<?<>=<>;A:E:H;I<J>J@IBFDAF?G=I<L<O|E:G;H<I>I@HBEDAF|<M=L?LDNGNIMJL|?LDOHOINJLJJ#=>>?=@<?<>=<>;A:E:H;I=I@HBECBC|E:G;H=H@GBEC|ECGDIFJHJKIMHNEOAO>N=M<K<J=I>J=K|HEIHIKHMGNEO#E<EO|F:FO|F:;IKI|BOIO#>:<D|<D>BAADAGBIDJGJIILGNDOAO>N=M<K<J=I>J=K|DAFBHDIGIIHLFNDO|>:H:|>;C;H:#H=G>H?I>I=H;F:C:@;>==?<C<I=L?NBODOGNILJIJHIEGCDBCB@C>E=H|C:A;?=>?=C=I>L@NBO|DOFNHLIIIHHEFCDB#<:<@|<>=<?:A:F=H=I<J:|=<?;A;F=|J:J=I@EEDGCJCO|I@DECGBJBO#A:>;===@>BACECHBI@I=H;E:A:|A:?;>=>@?BAC|ECGBH@H=G;E:|AC>D=E<G<K=M>NAOEOHNIMJKJGIEHDEC|AC?D>E=G=K>M?NAO|EOGNHMIKIGHEGDEC#IAHDFFCGBG?F=D<A<@==?;B:D:G;I=J@JFIJHLFNCO@O>N=L=K>J?K>L|BG@F>D=A=@>=@;B:|D:F;H=I@IFHJGLENCO#=C<D=E>D=C|=J<K=L>K=J#=C<D=E>D=C|>K=L<K=J>K>M<O#M==FMO#=COC|=IOI#==MF=O#=>>?=@<?<>=<>;@:C:F;G<H>H@GBFCBEBH|C:E;F<G>G@FBDD|BMANBOCNBM#KBJ@H?E?C@BAADAGBIDJGJIIJG|E?CABDBGCIDJ|K?JGJILJNJPHQEQCP@O>M<K;H:E:B;@<>>=@<C<F=I>K@MBNEOHOKNMMNL|L?KGKILJ#C:<O|C:JO|C=IO|>IGI|:O@O|FOLO#>:>O|?:?O|;:G:J;K<L>L@KBJCGD|G:I;J<K>K@JBICGD|?DGDJEKFLHLKKMJNGO;O|GDIEJFKHKKJMINGO#J=K@K:J=H;E:C:@;>==?<B<G=J>L@NCOEOHNJLKJ|C:A;?=>?=B=G>J?LANCO#>:>O|?:?O|;:E:H;J=K?LBLGKJJLHNEO;O|E:G;I=J?KBKGJJILGNEO#>:>O|?:?O|E@EH|;:K:K@J:|?DED|;OKOKIJO#>:>O|?:?O|E@EH|;:K:K@J:|?DED|;OBO#J=K@K:J=H;E:C:@;>==?<B<G=J>L@NCOEOHNJL|C:A;?=>?=B=G>J?LANCO|JGJO|KGKO|GGNG#>:>O|?:?O|K:KO|L:LO|;:B:|H:O:|?DKD|;OBO|HOOO#>:>O|?:?O|;:B:|;OBO#C:CKBN@O>O<N;L;J<I=J<K|B:BKAN@O|?:F:#>:>O|?:?O|L:?G|DCLO|CCKO|;:B:|H:N:|;OBO|HONO#>:>O|?:?O|;:B:|;OJOJIIO#>:>O|?:EL|>:EO|L:EO|L:LO|M:MO|;:?:|L:P:|;OAO|IOPO#>:>O|?:KM|?<KO|K:KO|;:?:|H:N:|;OAO#C:@;>==?<C<F=J>L@NCOEOHNJLKJLFLCK?J=H;E:C:|C:A;?=>?=C=F>J?LANCO|EOGNILJJKFKCJ?I=G;E:#>:>O|?:?O|;:G:J;K<L>LAKCJDGE?E|G:I;J<K>KAJCIDGE|;OBO#C:@;>==?<C<F=J>L@NCOEOHNJLKJLFLCK?J=H;E:C:|C:A;?=>?=C=F>J?LANCO|EOGNILJJKFKCJ?I=G;E:|@M@LAJCIDIFJGLHSITKTLRLQ|GLHPIRJSKSLR#>:>O|?:?O|;:G:J;K<L>L@KBJCGD?D|G:I;J<K>K@JBICGD|;OBO|DDFEGFJMKNLNMM|FEGGINJOLOMMML#I=J:J@I=G;D:A:>;<=<?=A>B@CFEHFJH|<?>A@BFDHEIFJHJLHNEOBO?N=L<I<O=L#B:BO|C:CO|<:;@;:J:J@I:|?OFO#>:>I?LANDOFOINKLLIL:|?:?I@LBNDO|;:B:|I:O:#<:CO|=:CL|J:CO|::@:|F:L:#=:AO|>:AJ|E:AO|E:IO|F:IJ|M:IO|::A:|J:P:#<:IO|=:JO|J:<O|::@:|F:L:|:O@O|FOLO#<:CECO|=:DEDO|K:DE|::@:|G:M:|@OGO#I:<O|J:=O|=:<@<:J:|<OJOJIIO#=6=V|>6>V|=6D6|=VDV#9:GR#B6BV|C6CV|<6C6|<VCV#<HDCLH|<HDDLH#9VMV#=:B@|=:<;B@#>C>D=D=C>B@ADAFBGCHEHLINJO|GCGLHNJOKO|GEFF@G=H<J<L=N@OCOENGL|@G>H=J=L>N@O#>:>O|?:?O|?DABCAEAHBJDKGKIJLHNEOCOAN?L|EAGBIDJGJIILGNEO|;:?:#HDGEHFIEIDGBEABA?B=D<G<I=L?NBODOGNIL|BA@B>D=G=I>L@NBO#H:HO|I:IO|HDFBDABA?B=D<G<I=L?NBODOFNHL|BA@B>D=G=I>L@NBO|E:I:|HOLO#=GIGIEHCGBEABA?B=D<G<I=L?NBODOGNIL|HGHDGB|BA@B>D=G=I>L@NBO#C;B<C=D<D;C:A:?;>=>O|A:@;?=?O|;ACA|;OBO#AA?B>C=E=G>I?JAKCKEJFIGGGEFCEBCAAA|?B>D>H?J|EJFHFDEB|FCGBIAIBGB|>I=J<L<M=O@PEPHQIR|<M=N@OEOHPIRISHUEV?V<U;S;R<P?O#>:>O|?:?O|?DABDAFAIBJDJO|FAHBIDIO|;:?:|;OBO|FOMO#>:=;><?;>:|>A>O|?A?O|;A?A|;OBO#?:>;?<@;?:|@A@S?U=V;V:U:T;S<T;U|?A?S>U=V|<A@A#>:>O|?:?O|IA?K|DGJO|CGIO|;:?:|FALA|;OBO|FOLO#>:>O|?:?O|;:?:|;OBO#>A>O|?A?O|?DABDAFAIBJDJO|FAHBIDIO|JDLBOAQATBUDUO|QASBTDTO|;A?A|;OBO|FOMO|QOXO#>A>O|?A?O|?DABDAFAIBJDJO|FAHBIDIO|;A?A|;OBO|FOMO#BA?B=D<G<I=L?NBODOGNILJIJGIDGBDABA|BA@B>D=G=I>L@NBO|DOFNHLIIIGHDFBDA#>A>V|?A?V|?DABCAEAHBJDKGKIJLHNEOCOAN?L|EAGBIDJGJIILGNEO|;A?A|;VBV#HAHV|IAIV|HDFBDABA?B=D<G<I=L?NBODOFNHL|BA@B>D=G=I>L@NBO|EVLV#>A>O|?A?O|?G@DBBDAGAHBHCGDFCGB|;A?A|;OBO#FCGAGEFCEBCA?A=B<C<E=F?GDIFJGK|<D=E?FDHFIGJGMFNDO@O>N=M<K<O=M#>:>K?NAOCOENFL|?:?K@NAO|;ACA#>A>L?NBODOGNIL|?A?L@NBO|IAIO|JAJO|;A?A|FAJA|IOMO#<ABO|=ABM|HABO|:A@A|DAJA#=AAO|>AAL|EAAO|EAIO|FAIL|MAIO|:AAA|JAPA#=AHO|>AIO|IA=O|;AAA|EAKA|;OAO|EOKO#=ACO|>ACM|IACOAS?U=V<V;U<T=U|;AAA|EAKA#GA<O|HA=O|=A<E<AHA|<OHOHKGO#B6@7?8>:><?>@?AAAC?E|@7?9?;@=A>B@BBAD=FAHBJBLAN@O?Q?S@U|?GAIAK@M?N>P>R?T@UBV#=6=V#>6@7A8B:B<A>@??A?CAE|@7A9A;@=?>>@>B?DCF?H>J>L?N@OAQAS@U|AG?I?K@MANBPBRAT@U>V#<I<G=D?CACCDGGIHKHMGNE|<G=E?DADCEGHIIKIMHNENC#9:9O:O::;:;O<O<:=:=O>O>:?:?O@O@:A:AOBOB:C:CODOD:E:EOFOF:G:GOHOH:I:IO"};

    var FONT_LABELS = [
        { key: "futural", label: "Hershey Sans 1 (plain)" },
        { key: "futuram", label: "Hershey Sans 2 (medium)" },
        { key: "scripts", label: "Hershey Script 1 (handwriting)" },
        { key: "scriptc", label: "Hershey Script 2 (bold hand)" },
        { key: "timesr", label: "Hershey Roman (serif)" }
    ];

    var CAP_HEIGHT = 21;      // Hershey design units from baseline to cap
    var SPACE_ADVANCE = 10;   // design units for a space glyph

    /* ==================================================================
     *  Glyph decoding
     * ================================================================== */

    function decodePoint(a, i) {
        return [a.charCodeAt(i) - 57, a.charCodeAt(i + 1) - 57];
    }

    // Returns an array of strokes; each stroke is an array of [x, y].
    // Returns null when the character is outside the Hershey character set.
    function glyphStrokes(fontKey, ch) {
        var table = GLYPH_DATA[fontKey];
        if (!table) { return null; }
        var code = ch.charCodeAt(0);
        if (code < 33 || code > 126) { return null; }
        var all = table.split("#");
        var idx = code - 33;
        if (idx < 0 || idx >= all.length) { return null; }
        var packed = all[idx];
        if (!packed) { return []; }

        var parts = packed.split("|");
        var strokes = [];
        var i;
        for (i = 0; i < parts.length; i++) {
            var s = parts[i];
            var pts = [];
            var k;
            for (k = 0; k + 1 < s.length; k += 2) {
                pts.push(decodePoint(s, k));
            }
            if (pts.length > 0) { strokes.push(pts); }
        }
        return strokes;
    }

    function glyphWidth(strokes) {
        var maxX = 0;
        var i;
        var k;
        for (i = 0; i < strokes.length; i++) {
            for (k = 0; k < strokes[i].length; k++) {
                if (strokes[i][k][0] > maxX) { maxX = strokes[i][k][0]; }
            }
        }
        return maxX;
    }

    /* ==================================================================
     *  Colour helpers
     * ================================================================== */

    function hexToRgb(hex) {
        var h = hex;
        if (!h) { return [1, 1, 1]; }
        if (h.charAt(0) === "#") { h = h.substring(1); }
        if (h.length === 3) {
            h = h.charAt(0) + h.charAt(0) + h.charAt(1) + h.charAt(1) + h.charAt(2) + h.charAt(2);
        }
        if (h.length !== 6) { return [1, 1, 1]; }
        var r = parseInt(h.substring(0, 2), 16);
        var g = parseInt(h.substring(2, 4), 16);
        var b = parseInt(h.substring(4, 6), 16);
        if (isNaN(r) || isNaN(g) || isNaN(b)) { return [1, 1, 1]; }
        return [r / 255, g / 255, b / 255];
    }

    /* ==================================================================
     *  Settings persistence
     * ================================================================== */

    function readSetting(key, fallback) {
        try {
            if (app.settings.haveSetting(SET_SECTION, key)) {
                return app.settings.getSetting(SET_SECTION, key);
            }
        } catch (e) { /* ignore */ }
        return fallback;
    }

    function writeSetting(key, value) {
        try {
            app.settings.saveSetting(SET_SECTION, key, String(value));
        } catch (e) { /* ignore */ }
    }

    /* ==================================================================
     *  Layout
     * ================================================================== */

    // Turns the text into a list of positioned glyphs:
    // [{ch, strokes, x, y, advance}]
    function layoutText(text, fontKey, fontSize, trackingPct, lineHeightPct) {
        var scale = fontSize / CAP_HEIGHT;
        var lines = text.split("\n");
        var out = [];
        var unsupported = [];
        var li;
        var ci;

        var lineGap = fontSize * (lineHeightPct / 100);
        var totalHeight = (lines.length - 1) * lineGap;

        for (li = 0; li < lines.length; li++) {
            var line = lines[li];
            var advanceSum = 0;
            var items = [];

            for (ci = 0; ci < line.length; ci++) {
                var ch = line.charAt(ci);
                var strokes;
                var adv;

                if (ch === " ") {
                    strokes = [];
                    adv = SPACE_ADVANCE;
                } else {
                    strokes = glyphStrokes(fontKey, ch);
                    if (strokes === null) {
                        unsupported.push(ch);
                        adv = SPACE_ADVANCE;
                        strokes = [];
                    } else {
                        adv = glyphWidth(strokes);
                        if (adv < 1) { adv = 6; }
                    }
                }

                var track = adv * (trackingPct / 100);
                items.push({ ch: ch, strokes: strokes, adv: adv + track });
                advanceSum += adv + track;
            }

            var cursor = -advanceSum / 2;
            var baseY = -totalHeight / 2 + li * lineGap;

            for (ci = 0; ci < items.length; ci++) {
                out.push({
                    ch: items[ci].ch,
                    strokes: items[ci].strokes,
                    x: cursor,
                    y: baseY,
                    scale: scale
                });
                cursor += items[ci].adv;
            }
        }

        return { glyphs: out, unsupported: unsupported, scale: scale };
    }

    /* ==================================================================
     *  Shape layer construction
     * ================================================================== */

    function buildStrokeGroup(parentGroup) {
        var g = parentGroup.addProperty("ADBE Vector Group");
        return g;
    }

    function addPath(group, pts, scale, offsetX, offsetY) {
        var verts = [];
        var inTan = [];
        var outTan = [];
        var i;
        for (i = 0; i < pts.length; i++) {
            verts.push([offsetX + pts[i][0] * scale, offsetY + (pts[i][1] - CAP_HEIGHT) * scale]);
            inTan.push([0, 0]);
            outTan.push([0, 0]);
        }
        var shape = new Shape();
        shape.vertices = verts;
        shape.inTangents = inTan;
        shape.outTangents = outTan;
        shape.closed = false;

        var pathGroup = group.addProperty("ADBE Vector Shape - Group");
        pathGroup.property("ADBE Vector Shape").setValue(shape);
        return pathGroup;
    }

    function styleStroke(group, color, width) {
        var stroke = group.addProperty("ADBE Vector Graphic - Stroke");
        stroke.property("ADBE Vector Stroke Color").setValue([color[0], color[1], color[2]]);
        stroke.property("ADBE Vector Stroke Width").setValue(width);
        var cap = -1;
        try { cap = 2; stroke.property("ADBE Vector Stroke Line Cap").setValue(cap); } catch (eCap) { }
        try { stroke.property("ADBE Vector Stroke Line Join").setValue(2); } catch (eJoin) { }
        return stroke;
    }

    function keyTrim(trim, t0, t1, mode) {
        var startProp = trim.property("ADBE Vector Trim Start");
        var endProp = trim.property("ADBE Vector Trim End");
        var ease = new KeyframeEase(0, 66.67);

        if (mode === "off") {
            // erase: reverse the write-on ramp
            endProp.setValueAtTime(t0, 100);
            endProp.setValueAtTime(t1, 0);
            try {
                endProp.setInterpolationTypeAtKey(1, KeyframeInterpolationType.BEZIER, KeyframeInterpolationType.BEZIER);
                endProp.setInterpolationTypeAtKey(2, KeyframeInterpolationType.BEZIER, KeyframeInterpolationType.BEZIER);
                endProp.setTemporalEaseAtKey(1, [ease], [ease]);
                endProp.setTemporalEaseAtKey(2, [ease], [ease]);
            } catch (eEase) { }
            return;
        }

        endProp.setValueAtTime(t0, 0);
        endProp.setValueAtTime(t1, 100);
        try {
            endProp.setInterpolationTypeAtKey(1, KeyframeInterpolationType.BEZIER, KeyframeInterpolationType.BEZIER);
            endProp.setInterpolationTypeAtKey(2, KeyframeInterpolationType.BEZIER, KeyframeInterpolationType.BEZIER);
            endProp.setTemporalEaseAtKey(1, [ease], [ease]);
            endProp.setTemporalEaseAtKey(2, [ease], [ease]);
        } catch (eEase2) { }

        if (mode === "onoff") {
            // After the write completes, sweep Start 0 -> 100 to erase it.
            var t2 = t1 + (t1 - t0);
            startProp.setValueAtTime(t1, 0);
            startProp.setValueAtTime(t2, 100);
            try {
                startProp.setInterpolationTypeAtKey(1, KeyframeInterpolationType.LINEAR, KeyframeInterpolationType.LINEAR);
                startProp.setInterpolationTypeAtKey(2, KeyframeInterpolationType.LINEAR, KeyframeInterpolationType.LINEAR);
            } catch (eStart) { }
        }
    }

    /* ==================================================================
     *  Main generation
     * ================================================================== */

    function generate(comp, cfg) {
        var laid = layoutText(cfg.text, cfg.fontKey, cfg.fontSize, cfg.trackingPct, cfg.lineHeightPct);

        if (laid.glyphs.length === 0) {
            return { ok: false, message: "Nothing to write: the text is empty.", made: 0 };
        }

        var writable = 0;
        var i;
        for (i = 0; i < laid.glyphs.length; i++) {
            if (laid.glyphs[i].ch !== " " && laid.glyphs[i].strokes.length > 0) { writable++; }
        }
        if (writable === 0) {
            return {
                ok: false,
                message: "No drawable character: Hershey covers ASCII only (no CJK).", made: 0
            };
        }

        var fd = comp.frameDuration;
        var delay = Math.max(0, cfg.delayFrames) * fd;
        var dur = Math.max(1, cfg.durationFrames) * fd;
        var color = hexToRgb(cfg.color);
        var idx = 0;
        var made = 0;
        var skipped = 0;

        var failMsg = null;
        app.beginUndoGroup(SCRIPT_NAME + " - write text");

        try {
            for (i = 0; i < laid.glyphs.length; i++) {
                var g = laid.glyphs[i];
                if (g.ch === " ") { continue; }
                if (!g.strokes || g.strokes.length === 0) { skipped++; continue; }

                var layer = comp.layers.addShape();
                layer.name = g.ch;
                layer.comment = SCRIPT_NAME + " glyph";

                var root = layer.property("ADBE Root Vectors Group");
                var group = buildStrokeGroup(root);

                var k;
                for (k = 0; k < g.strokes.length; k++) {
                    addPath(group, g.strokes[k], g.scale, g.x, g.y);
                }

                var trim = group.addProperty("ADBE Vector Filter - Trim");
                styleStroke(group, color, cfg.strokeWidth);

                var t0 = idx * delay;
                var t1 = t0 + dur;
                keyTrim(trim, t0, t1, cfg.mode);

                // Every glyph layer sits on the comp centre; the path
                // coordinates already carry the layout offset.
                layer.property("ADBE Transform Group").property("ADBE Position")
                    .setValue([comp.width / 2, comp.height / 2]);

                idx++;
                made++;
            }
        } catch (err) {
            failMsg = err.toString();
        } finally {
            app.endUndoGroup();
        }
        if (failMsg) {
            return { ok: false, message: "Failed: " + failMsg, made: made };
        }

        var totalFrames = (made > 0 ? (made - 1) * cfg.delayFrames + cfg.durationFrames : 0);
        if (cfg.mode === "onoff") { totalFrames = totalFrames * 2; }

        var msg = "Wrote " + made + " glyph layer(s), " + skipped + " skipped.";
        msg += "\nAnimation spans " + totalFrames + " frames (" +
            (totalFrames * fd).toFixed(2) + "s).";
        if (totalFrames * fd > comp.duration) {
            msg += "\nWarning: longer than the comp (" + comp.duration.toFixed(2) + "s).";
        }
        if (laid.unsupported.length > 0) {
            var uniq = "";
            var seen = {};
            for (i = 0; i < laid.unsupported.length && i < 20; i++) {
                var c = laid.unsupported[i];
                if (seen[c]) { continue; }
                seen[c] = true;
                uniq += c;
            }
            msg += "\nSkipped characters outside the Hershey ASCII set: " + uniq;
        }

        return { ok: true, message: msg, made: made, frames: totalFrames };
    }

    /* ==================================================================
     *  UI
     * ================================================================== */

    function buildUI(thisObj) {
        var pal = (thisObj instanceof Panel) ? thisObj :
            new Window("palette", SCRIPT_NAME + " " + VERSION, undefined, { resizeable: true });
        pal.orientation = "column";
        pal.alignChildren = ["fill", "top"];
        pal.spacing = 8;
        pal.margins = 12;

        var info = pal.add("statictext", undefined,
            "Single-stroke write-on text (Hershey, public domain glyphs)." +
            "\nASCII only: no CJK.", { multiline: true });
        info.preferredSize.width = 340;

        var fontRow = pal.add("group");
        fontRow.alignment = ["fill", "top"];
        fontRow.add("statictext", undefined, "Typeface:").preferredSize.width = 70;
        var ddFont = fontRow.add("dropdownlist", undefined, []);
        var fi;
        for (fi = 0; fi < FONT_LABELS.length; fi++) { ddFont.add("item", FONT_LABELS[fi].label); }
        ddFont.selection = 0;

        var textBox = pal.add("panel", undefined, "Text");
        textBox.orientation = "column";
        textBox.alignChildren = ["fill", "top"];
        textBox.margins = 8;
        var edText = textBox.add("edittext", undefined, "Hello 2026", { multiline: true });
        edText.preferredSize = [330, 64];

        var sizeBox = pal.add("panel", undefined, "Layout");
        sizeBox.orientation = "column";
        sizeBox.alignChildren = ["left", "top"];
        sizeBox.margins = 8;
        sizeBox.spacing = 3;

        var r1 = sizeBox.add("group");
        r1.add("statictext", undefined, "Font size:").preferredSize.width = 90;
        var edSize = r1.add("edittext", undefined, "100");
        edSize.characters = 6;
        r1.add("statictext", undefined, "Tracking %:").preferredSize.width = 75;
        var edTrack = r1.add("edittext", undefined, "15");
        edTrack.characters = 5;

        var r2 = sizeBox.add("group");
        r2.add("statictext", undefined, "Line height %:").preferredSize.width = 90;
        var edLine = r2.add("edittext", undefined, "120");
        edLine.characters = 6;
        r2.add("statictext", undefined, "Stroke:").preferredSize.width = 75;
        var edStroke = r2.add("edittext", undefined, "6");
        edStroke.characters = 5;

        var r3 = sizeBox.add("group");
        r3.add("statictext", undefined, "Colour (hex):").preferredSize.width = 90;
        var edColor = r3.add("edittext", undefined, "FFFFFF");
        edColor.characters = 8;

        var animBox = pal.add("panel", undefined, "Write animation");
        animBox.orientation = "column";
        animBox.alignChildren = ["left", "top"];
        animBox.margins = 8;
        animBox.spacing = 3;

        var r4 = animBox.add("group");
        r4.add("statictext", undefined, "Delay per glyph (frames):").preferredSize.width = 155;
        var edDelay = r4.add("edittext", undefined, "2");
        edDelay.characters = 5;

        var r5 = animBox.add("group");
        r5.add("statictext", undefined, "Stroke time per glyph:").preferredSize.width = 155;
        var edDur = r5.add("edittext", undefined, "6");
        edDur.characters = 5;

        var r6 = animBox.add("group");
        var rbOn = r6.add("radiobutton", undefined, "Write on");
        var rbOff = r6.add("radiobutton", undefined, "Write off");
        var rbBoth = r6.add("radiobutton", undefined, "On then off");
        rbOn.value = true;

        var btnRow = pal.add("group");
        btnRow.alignment = ["fill", "top"];
        var btnGo = btnRow.add("button", undefined, "Write text");
        btnGo.preferredSize.width = 150;
        var btnDefaults = btnRow.add("button", undefined, "Reset defaults");

        var status = pal.add("statictext", undefined, "Ready.", { multiline: true });
        status.preferredSize.width = 340;

        function sel(a, b, c) {
            if (rbOff.value) { return "off"; }
            if (rbBoth.value) { return "onoff"; }
            return "on";
        }

        function readCfg() {
            return {
                fontKey: FONT_LABELS[ddFont.selection.index].key,
                text: edText.text,
                fontSize: parseFloat(edSize.text),
                trackingPct: parseFloat(edTrack.text),
                lineHeightPct: parseFloat(edLine.text),
                strokeWidth: parseFloat(edStroke.text),
                color: edColor.text,
                delayFrames: parseFloat(edDelay.text),
                durationFrames: parseFloat(edDur.text),
                mode: sel()
            };
        }

        function validate(cfg) {
            if (isNaN(cfg.fontSize) || cfg.fontSize <= 0) { return "Font size must be > 0."; }
            if (isNaN(cfg.trackingPct)) { return "Tracking must be a number."; }
            if (isNaN(cfg.lineHeightPct) || cfg.lineHeightPct <= 0) { return "Line height must be > 0."; }
            if (isNaN(cfg.strokeWidth) || cfg.strokeWidth <= 0) { return "Stroke width must be > 0."; }
            if (isNaN(cfg.delayFrames) || cfg.delayFrames < 0) { return "Delay must be >= 0."; }
            if (isNaN(cfg.durationFrames) || cfg.durationFrames < 1) { return "Stroke time must be >= 1 frame."; }
            if (!cfg.text || cfg.text.length === 0) { return "Type something first."; }
            if (cfg.text.length > 60) { return "Text longer than 60 characters: split it into several runs."; }
            return null;
        }

        btnGo.onClick = function () {
            if (!app.project) { status.text = "Open a project first."; return; }
            var comp = app.project.activeItem;
            if (!comp || !(comp instanceof CompItem)) { status.text = "Open a composition first."; return; }
            var cfg = readCfg();
            var bad = validate(cfg);
            if (bad) { status.text = bad; return; }
            status.text = "Writing...";
            var res = generate(comp, cfg);
            status.text = res.message;
            writeSetting("font", cfg.fontKey);
            writeSetting("size", cfg.fontSize);
        };

        btnDefaults.onClick = function () {
            edSize.text = "100";
            edTrack.text = "15";
            edLine.text = "120";
            edStroke.text = "6";
            edColor.text = "FFFFFF";
            edDelay.text = "2";
            edDur.text = "6";
            rbOn.value = true;
            status.text = "Defaults restored.";
        };

        // Restore last used font/size.
        try {
            var savedFont = readSetting("font", "");
            var si;
            for (si = 0; si < FONT_LABELS.length; si++) {
                if (FONT_LABELS[si].key === savedFont) { ddFont.selection = si; }
            }
            var savedSize = readSetting("size", "");
            if (savedSize !== "" && !isNaN(parseFloat(savedSize))) { edSize.text = savedSize; }
        } catch (eRestore) { /* first run */ }

        pal.onResizing = pal.onResize = function () { this.layout.resize(); };
        return pal;
    }

    var ui = buildUI(thisObj);
    if (ui instanceof Window) {
        ui.center();
        ui.show();
    } else {
        ui.layout.layout(true);
    }

})(this);
