# Easify 4 Clone（AE 端）

给关键帧批量套缓动预设、把一套缓动跨属性同步、做循环/整体偏移/均分。

- 版本：1.0.0｜文件：`main.jsx`｜类型：ScriptUI 面板
- 对应原商品：Easify 4（$49 Pro / 更低价 Essentials，作者 Leyero；AE + Premiere Pro 双端）

> **Clean-room 声明**：仅依据公开的功能对照表（缓动曲线、Speed Graph、多属性批量、跨属性同步、预设库、Back/Bounce/Elastic、循环、时间偏移、对齐均分）与通用 AE Scripting API 知识独立实现。未获取、阅读或参考原扩展的任何源码或资源。

---

## 一、范围（先说清不做什么）

| 原版能力 | 本复刻 | 说明 |
|---|---|---|
| 经典贝塞尔缓动预设 | ✅ | 9 个预设 |
| 多属性批量应用 | ✅ | 遍历 `comp.selectedProperties` |
| 跨属性缓动同步（时间自动缩放） | ✅ | 归一化 u 映射 |
| 循环（pingpong / offset） | ✅ | 键复制 |
| 关键帧时间偏移 | ✅ | 整体平移帧数 |
| 对齐与均分 | ✅ | 中间键均匀分布 |
| 多剪辑时间线（一屏多对象） | ❌ | 需要自绘时间线控件，本件用 AE 时间线的选择代替 |
| 可拖拽的 Speed Graph 画布 | ❌ | ScriptUI 命中测试成本过高；改用「预设 + 数值 influence」 |
| 一段内多控制点（多点曲线） | ⚠️ 采样近似 | Back/Bounce/Elastic 用逐帧采样烘焙，不是真正的多点手柄 |
| 复合曲线叠加 | ❌ | 官方语义无公开定义，硬猜会做出偏差版本 |
| 路径缓动 | ❌ | 需要路径长度参数化采样，性价比低 |
| **Premiere Pro 端** | ❌ | **PR 没有公开的关键帧缓动脚本 API**，原版 PR 侧是另一套实现；本件只做 AE |
| Wiggle / Impact 效果 | ❌ | 未公开参数语义，不做猜测式实现 |

## 二、使用方式

1. 打开合成，在时间线里选中若干关键帧（或整条属性）；
2. `File > Scripts > Run Script File...` 选 `main.jsx`；
3. 面板顶部实时显示「N 个动画属性、M 个选中键」；
4. 选预设 → `Apply preset`。一步 `Ctrl+Z` 回退。

## 三、预设表

| 预设 | 类型 | 段起点 out influence / 段终点 in influence |
|---|---|---|
| AE default (33 / 33) | 贝塞尔 | 33.33 / 33.33（AE 内置 Ease 的默认值） |
| Ease In Out (67 / 67) | 贝塞尔 | 66.67 / 66.67 |
| Ease Out - slow finish | 贝塞尔 | 0.1 / 66.67 |
| Ease In - slow start | 贝塞尔 | 66.67 / 0.1 |
| Maximum ease | 贝塞尔 | 100 / 100（AE influence 上限） |
| Linear | 插值类型 | 直接设 `LINEAR` |
| Back (overshoot) | 采样烘焙 | `1 + c3·p³ + c1·p²`（c1=1.70158） |
| Bounce | 采样烘焙 | 标准四段 bounce |
| Elastic | 采样烘焙 | `2^(-10t)·sin((10t-0.75)·2π/3)+1` |

**关键实现细节**：贝塞尔预设只改 `influence`，`speed` 取该段**实际斜率**（`(v₂-v₁)/(t₂-t₁)`，逐维度独立算）。这是整件里最容易做错的地方——如果把 speed 写成 0 或写死某个值，运动幅度和节奏都会变。面板上另有 `Flat handles (speed = 0)` 开关，打开即退回 AE 经典的「水平手柄」行为。

## 四、跨属性同步（本件的核心增量）

原版的卖点：**把 A 上已调好的缓动，套到 B 上，并按 B 自己的段长自动缩放时间**，不是照抄秒数。

实现：

1. `Set source`：取**第一个**选中属性，记下每个键的归一化位置 `u = (t - t₀) / (t₁ - t₀)` 和它的 in/out influence；
2. `Apply to others`：对其余每个选中属性，用 `t = t₀' + u·(t₁' - t₀')` 把源键位置映射到目标自己的时间跨度上；
3. 目标在该时刻先用 `valueAtTime` 取自身当前值再 `setValueAtTime` 建键——**保住目标原有的数值曲线**，只搬运缓动形状；
4. 每键按最近的 u 取源 influence，`speed` 归零（形状优先，避免幅度被改）。

因此 1 秒段上的缓动套到 0.5 秒段时，曲线形状按比例压缩，起止值不变——对应验收点 3。

## 五、循环 / 偏移 / 均分

- **Ping-pong**：每一轮以上一轮的末端为镜面翻转时间，来回振荡，转折点无跳变；
- **Repeat (offset)**：整段平移到后面，值不变；
- **Shift by frames**：所有键整体平移（读全键 → 删键 → 按新时间重建）；
- **Distribute keys evenly**：首末键时间固定，中间键等距（至少 3 个键才有意义）。

> 偏移和均分走的是「读全键 → `removeKey` 全部删掉 → 按新时间重建」的管线，所以**重建后键的缓动会回到默认值**。需要保留缓动就先应用缓动再偏移，或反过来先偏移再套预设。这是诚实的代价，不是 bug。

## 六、能力限制（诚实说明）

1. **只做 AE**。Premiere Pro 侧不做（无公开 API），也不会假装支持。
2. **没有可拖拽的速度图**。原版的 Speed Graph 是可点拖的曲线画布；本件是「预设下拉 + influence 数值」，改曲线靠换预设或换选项，不能直接拖点。
3. **多点曲线是采样近似**。Back/Bounce/Elastic 会往段里塞逐帧关键帧（段长 1 秒 / 25fps → 约 24 个新键），之后这些键是 `LINEAR` 的。键数会明显增加，且用户不能再"调曲线"，只能重跑。
4. **烘焙会跳过段内已有键**：段起点和终点之间如果还有别的键，`bakeSegment` 直接返回 -1（跳过该段），不会强行覆盖。状态栏不逐段报告跳过原因，只统计段数。
5. **跨属性同步的键数会变**：目标属性如果原本键数比源少/多，同步后会按源键的 u 位置新建键，最终键数接近源的键数（叠加目标原有的键）。不想加键就别用同步。
6. **同步后 speed 归零**：为了让形状优先、幅度不变，同步写入的 ease 一律 `speed = 0`。如果目标段本身很长、速度很慢，观感会比"按斜率"的缓动更"顿"。
7. **单键属性**：只有 1 个键时无法成段，只能对它自身设 in/out 手柄（预设按钮会走这个分支），不会报错。
8. **HOLD 键会被转成 BEZIER**（验收点要求不报错），但 HOLD 的"保持直到下一键"语义会丧失——这是预期行为，不是 bug。
9. **分离维度的 Position**：`layer.position` 是 PropertyGroup 不是 Property，用 `selectedProperties` 选中 X/Y 子属性才能作用，选中父级 group 会被忽略（`numKeys === undefined` 过滤掉）。
10. **没有预设库的保存/导入**：原版可自建无限预设库；本件预设写死在脚本里，改预设要改代码。`app.settings` 的持久化没做（避免污染用户配置）。
11. **多剪辑时间线视图没有**：一屏看多个对象的关键帧全靠 AE 自己的时间线。
12. **中文版 AE 未实测**：脚本 ASCII-only、UI 英文，理论不受本地化影响。

## 七、API 使用核对（白名单内）

- `app.project`、`app.project.activeItem`
- `CompItem.selectedProperties`（0-based 数组）、`comp.frameDuration`
- `Property`：`numKeys`、`keyTime(k)`、`keyValue(k)`、`selectedKeys`（元素为 1-based 索引）、`setValueAtTime`、`valueAtTime`、`removeKey`、`setTemporalEaseAtKey`、`setInterpolationTypeAtKey`、`keyInTemporalEase`、`keyOutTemporalEase`、`propertyValueType`、`name`
- `KeyframeEase`（构造与 `influence`）、`KeyframeInterpolationType.LINEAR / BEZIER`
- `PropertyValueType.OneD/TwoD/TwoD_SPATIAL/ThreeD/ThreeD_SPATIAL`
- `app.beginUndoGroup` / `app.endUndoGroup`
- ScriptUI 全套

**未使用** `deleteKey`（不存在，删键一律 `removeKey`）；枚举拼写用混合大小写 `TwoD/ThreeD`。

## 八、验收清单（对 spec 第 7 节）

1. 选一个 2 键属性点「Ease In Out」→ 曲线变化、**起止时间与数值不变**。✅ `easeSegment` 只写 ease，不碰 keyTime/keyValue。
2. 选 3 个属性共 12 个键批量应用 → 无异常、无丢键。✅ 逐属性逐段 try/catch，失败计数但不中断。
3. 跨属性同步：1 秒段的缓动套到 0.5 秒段 → 目标段内形状与源一致（按比例压缩），起止值不变。✅ 归一化 u 映射。
4. 循环 `pingpong` → 首尾连续、无跳变（转折点时间镜像）。
5. 对 HOLD / LINEAR 键应用 → 先自动转 BEZIER，不报错。✅ `setInterpolationTypeAtKey` 先于 ease 写入。
6. README 写明「只支持 AE、不支持 PR」「多点曲线用采样实现」。✅ 本文档第一节与第六节。

附加：`Flat handles` 打开后 speed=0、手柄水平；`Shift` 后键整体平移帧数；`Distribute` 首末键不动、中间等距。

## 九、文件

```
clones/easify4-clone/
├─ main.jsx
└─ README.md
```

静态检查：`node --check`（剥 `#target`）exit=0；ES3 扫描零命中；纯 ASCII、无 BOM；`deleteKey` / 全大写枚举零命中。
