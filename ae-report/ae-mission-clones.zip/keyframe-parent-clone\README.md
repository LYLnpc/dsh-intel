---
generated_at: 2026-11-14T12:40:00+08:00
task: ae-mission / clean-room 复刻 Keyframe Parent（关键帧组仿射变换工具），ExtendScript jsx
target_path: C:\Users\19894\ae-mission\clones\keyframe-parent-clone\README.md
input: intel/paid-list.md #16 Keyframe Parent（Xrayvision，$24.99/特价 $14.99，[未核实细节]）+ 任务下发的公开功能基线
---

# Keyframe Parent Clone（关键帧组「父化 / 平移 / 拉伸」· clean-room 复刻）

- 产出：`main.jsx`（ExtendScript，ES3，ScriptUI 单面板五区）
  - **本文件的目标绝对路径**：`C:\Users\19894\ae-mission\clones\keyframe-parent-clone\main.jsx`
  - 本次产出先落在会话工作区 `out\keyframe-parent-clone\`（该目录对本会话只读），**需搬运**：把 `main.jsx` 与 `README.md` 原样复制到上面的目标目录即可，无其它依赖、无配套资源文件。
- 输入依据：`intel/paid-list.md` 第 16 条原文为「在 AE 时间线里直接『父化、平移、拉伸』关键帧组（把一组关键帧当对象整体变换）。[未核实细节]」——**条目极简**。本克隆按任务下发的公开功能基线展开，推断部分在下表逐项注明，不声称覆盖原版未公开的全部交互。
- 实现方式：只用 AE 官方关键帧/属性 API（`docs/api-cheatsheet.md` 白名单），无 C++、无渲染引擎、无外部依赖。

## CLEAN-ROOM 声明

1. 仅依据公开商品页的功能描述与任务功能基线从零编写；**未反编译、未阅读、未复制**原插件任何代码/字节码/资源，也未在本机打开或运行原插件。
2. 全部数学（时间/值的三参数仿射映射、缓动速度的 `sV/sT` 换算、父键作支点）为自行推导的初等算术，见「数学说明」。
3. 仅供学习研究；Keyframe Parent 商标与著作权归其作者（Xrayvision）所有。需要完整功能请购买正版（aescripts.com，$24.99，特价 $14.99）。

## 原版功能 → 复刻状态对照

| # | 功能点（公开描述 / 任务基线） | 状态 | 实现说明 |
|---|---|---|---|
| 1 | 把一组关键帧当**对象整体**变换 | ✅ | 「组」= 当前时间线里所有选中的关键帧，可跨图层、跨属性；`comp.selectedProperties` 优先，取不到时回退遍历选中图层的属性树（深度 5 / 上限 40 属性） |
| 2 | **父化**：选一个键作父，其余键的时间/值随父键平移 | ✅ | 父键 = 支点 `(tP, vP)`。平移同时加在父键与子键上（偏移量守恒 → 子键随父键刚性平移）；「Move group so parent sits at T」把父键精确挪到指定秒数，子键整体跟随 |
| 3 | **整体平移**：时间偏移 | ✅ | `Δt`，滑杆 ±5 s + 数值框（0.001 s 精度）；负值即前移 |
| 4 | **整体平移**：值偏移 | ✅ | `Δv` 分 X/Y/Z 三轴（一维属性用 X，二维用 X/Y，三维用 X/Y/Z），滑杆 ±500 单位 |
| 5 | **整体拉伸**：时间缩放 | ✅ | `sT` 10%–400%，滑杆 + 数值框；以父键（未指定父键则各属性最早选中键）为时间支点 |
| 6 | **整体拉伸**：值缩放 | ✅ | `sV` 10%–400%，各分量等比（保持数值向量形状） |
| 7 | **可选保持比例** | ✅ | 勾选 `keep ratio` 后值缩放恒等于时间缩放（`sV = sT`，拉伸不改变形状比例） |
| 8 | 多图层 / 多属性批量 | ✅ | 一次捕获多个属性，逐属性独立变换、统一撤销组 |
| 9 | 数值输入框 + 滑杆实时预览 | ✅（有语义说明） | 拖滑杆时**数值框逐帧刷新**；**松手即写入 AE**（`onClick`），滑杆拖动过程中不写（ExtendJS 单线程，无节流定时器可用）。勾掉 `live preview` 则只更新数值，需按 Preview/Apply |
| 10 | 撤销组包裹 | ✅ | 每次写入 = 一个 `app.beginUndoGroup/endUndoGroup`（try/finally 成对），Ctrl+Z 一步回退整组属性 |
| 11 | 错误处理 | ✅ | 无合成 / 无选中键 / 目标时刻被非组内键占用 / 键会塌陷 / 单键插入失败 → 状态栏中文式英文报错 + 计数，**不静默丢键** |
| 12 | 还原（回到捕获时的原始布局） | ✅（本克隆增强） | `Restore` 把三个参数复位为恒等变换，从**原始快照**重算，逐键回到原时间/原值 |
| 13 | 原版可能存在的其它能力（时间线内手柄拖拽、吸附、曲线可视化、预设库等） | ❌ | 原版未公开细节，**未实现也不声称**。本克隆只做「选中键组 → 参数化变换 → 写入」这一条链路 |

## 安装

- 方式 A（可停靠面板）：把 `main.jsx` 放进 AE 安装目录 `Support Files\Scripts\ScriptUI Panels\`，重启 AE，`Window` 菜单里打开。
- 方式 B（临时运行）：`File > Scripts > Run Script File...` 选 `main.jsx`。
- 无需其它文件；面板 UI 为英文（避免 ScriptUI 在非 Unicode 环境下的中文字体/编码差异），README 为中文说明。

## 使用指南（中文）

1. **先选关键帧**：在时间线里选中要当作一个整体处理的全部关键帧（可跨图层、跨属性，Shift 框选即可）。
2. **Capture selection**：抓取快照。成功后面板显示「Captured N key(s) in M properties.」，`Scope` 行同步显示。此时三个参数都是恒等（Δt=0、Δv=0、缩放 100%），画面不动。
3. **（可选）定父键**：`2. Parent` 下拉里列出组内每个键（`#属性名 @ 时间`）。选一个 → `Set parent`。此后该键是缩放支点，且平移时作为「带头」的键：
   - `Move group so parent sits at [T] s` → 整组刚性平移，让父键正好落在 T 秒（做「对齐到节拍/标记」最省事）。
   - `Clear` → 回到「各属性以自己最早的选中键为支点」。
4. **平移**：`3. Translate group` 拖 `time offset (s)`（±5 s）或直接敲数值；`value X/Y/Z` 同理。
5. **拉伸**：`4. Stretch group` 拖 `time scale %` / `value scale %`；勾 `keep ratio` 让两者联动；`rescale ease speeds` 默认开（缓动速度随拉伸同步换算，曲线形状保持）。
6. **确认 / 回退**：`5. Preview / apply` 里 `Apply` 落定（其实松手已写，Apply 只是显式确认并打印统计），`Restore` 一键回到捕获时的原样，或直接 Ctrl+Z。
7. **继续编辑同一组**：快照留在内存里，可以一直拖；**若中途重选了别的关键帧，务必重新 `Capture`**（快照会整体替换）。

典型场景：

- *整段动画延后 12 帧*：选该属性全部键 → Capture → `time offset (s)` = 12/25（按工程帧率）→ 松手。
- *把 3 秒的入场拉成 6 秒且动作幅度不变*：Capture → `time scale %` = 200，`value scale %` 保持 100。
- *把一组键整体放大成「更夸张」的位移*：Capture → `value scale %` = 150（父键不动，其余键相对父键更远）。
- *把一整套键锚到第 2 秒起拍*：父键选组内首键 → 目标时间填 2 → `Move group so parent sits at`。

## 数学说明（自行推导）

三参数仿射映射，全部在**原始快照坐标**里计算（因此反复拖滑杆不会累积误差）：

```
t' = tP + (t - tP) * sT + Δt
v' = vP + (v - vP) * sV + Δv        (逐分量；颜色通道再 clamp 到 [0,1])
```

- `tP / vP`：父键的原始时间/值；未指定父键时用该属性最早选中键（保证每组都有确定的支点）。
- **父化的语义**：`Δt/Δv` 对所有键（含父键）等量相加，因此组内相对偏移守恒 —— 父键"走"多少，其余键就跟多少；缩放则围绕父键进行。这两条合起来正是「把一组键当成一个带枢轴的刚体/半刚体」。
- **缓动换算**：AE 的 `KeyframeEase.speed` 是 `dv/dt`，均匀拉伸把速度映射为 `sV/sT` 倍（influence 不变，仍 clamp 在 `[0.1, 100]`）。每次写入都从**原始** ease 重算，所以关掉开关即回到原速度。
- **写入管线（为什么必须删了重建）**：AE 没有「把键挪到另一个时间」的 API（`setValueAtKey` 只改值；在已占用时刻 `setValueAtTime` 会覆盖邻键）。所以：读原始快照 → 校验新时间序列 → 倒序 `removeKey` 删除组内键 → 正序 `setValueAtTime` 逐键重建 → 用 `nearestKeyIndex` 定位并回填插值类型、时间缓动、空间切线。

## 诚实限制（务必先读）

1. **未在 AE 实机验证**：本机没有 After Effects。API 名逐条对照 `docs/api-cheatsheet.md` 白名单（见自查记录），逻辑用 headless 桩测试跑过（见下），但**首次使用请先在副本工程上试**。
2. **重建式写入的附带损失**：`roving`（漫游）标记**不恢复**；空间切线（`keyIn/OutSpatialTangent`）按原值回填但**幅度不随缩放换算**；关键帧标签与"选中状态"不保留（重建后这些键不再处于选中态 —— 想继续操作同一组，请用面板里的快照继续拖，不要重新框选后忘了 Capture）。
3. **只支持数值 / 颜色属性**：`OneD / TwoD / ThreeD / TwoD_SPATIAL / ThreeD_SPATIAL / COLOR`。`SHAPE`（蒙版路径）、`TEXT_DOCUMENT`、`MARKER`、`CUSTOM_VALUE` 的值没有定义好的仿射语义，捕获时直接跳过并计数（这些属性请用 AE 自带方式改时间）。
4. **不做静默避让**：新时间与组外关键帧冲突（差 < 0.0005 s）时，**该属性整体放弃写入**并在状态栏报「target time ... is already used by a keyframe outside the group」；不会偷偷 +1 tick。同理，时间缩得太小导致相邻键间距 < 0.0005 s 时该属性放弃（防止键塌陷/覆盖）。
5. **部分失败是可能的**：`setValueAtTime` 单个键插入失败时该键会缺失（已计数报错），整步可用 Ctrl+Z 还原。构建校验（步骤 4）会先挡掉绝大多数可预见的失败。
6. **有表达式的属性**：AE 会用表达式覆盖写入值，看起来"没反应"。本工具**不读也不改表达式**。
7. **跨属性缩放没有统一物理意义**：值缩放逐分量等比作用在各自属性的原生单位上（Scale 是 %、Position 是 px、Opacity 是 %）。父键只对**它所属的那个属性**做值支点，其它属性用各自最早键做支点；跨属性"共享一个值支点"在数学上无意义，故不提供。
8. **拖动滑杆期间不写 AE**：只刷新数值框，松手才写。「实时预览」= 松手即刻生效 + 数值实时，不是逐帧拖动预览。
9. **预览也是真写入**：Preview/松手都会产生撤销步（一步一组），不是浮层预览；不想要就 `Restore` 或 Ctrl+Z。
10. **表外 API 登记**（两处，均包了 try/catch 并在失败时降级）：
    - `Property.name`：仅用于面板标签（失败显示 `property`）。
    - `Property.matchName`：仅用于跳过 `ADBE Effect Parade`（避免遍历巨大的效果链，失败则照常递归）。
    - 刻意**未用** `comp.time`（不在白名单）—— 因此"对齐当前播放头"改为手填目标秒数；也**未用** `Property.setSelectedAtKey`（不在白名单）—— 因此重建后键不再选中（见限制 2）。

## 自查记录（2026-11-14）

1. `node --check`（复制为 `.js` 后）：**通过**。
2. ES3 扫描（`let/const/class/=>/模板串/JSON/forEach/map/filter/reduce/indexOf/for-of/Object.keys/trim/Symbol/Promise`）：**0 命中**。
3. 文件纯 ASCII：**0 个非 ASCII 字节**（ScriptUI 无编码风险；中文只在 README）。
4. 括号配对：`node --check` 通过 + 手工复核 5 个 panel/组嵌套层级，无孤立括号。
5. API 白名单核对（逐个出现过的名字）：
   - `PropertyValueType.OneD / TwoD / TwoD_SPATIAL / ThreeD / ThreeD_SPATIAL / COLOR`（混合大小写，无 `ONE_D/TWO_D` 回归）
   - `selectedKeys`（1-based，手工插入排序）、`numKeys`、`keyTime`、`keyValue`
   - `keyInInterpolationType / keyOutInterpolationType`、`setInterpolationTypeAtKey`
   - `keyInTemporalEase / keyOutTemporalEase`、`setTemporalEaseAtKey`（**双侧恒传**，规避省略 out 被 in 覆盖）、`new KeyframeEase(speed, influence)`（influence clamp `[0.1..100]`）
   - `keyIn/OutSpatialTangent`、`setSpatialTangentsAtKey`（双侧恒传）
   - `setValueAtTime`、`removeKey`（**未用任何 delete 式方法**）、`nearestKeyIndex`
   - `comp.selectedProperties / selectedLayers`、`grp.property(i)` + `numProperties`（1-based）
   - `app.beginUndoGroup / endUndoGroup`（try/finally 成对）
   - 全部在白名单内；表外只有上文登记的 `name` / `matchName` 两处。
6. **Headless 桩测试**（`out\_selftest\harness.js`，node 运行；用桩 Property/CompItem/ScriptUI 驱动真实 main.jsx）：5 个场景 **全部通过**
   - 场景 1：2D Position 3 键，时间 200% → 0/2/4；值 50% → `[50,25]`；平移 +0.5 s → 0.5/2.5/4.5；Restore → 原样回位。
   - 场景 2：1D Opacity 4 键，Δv=+10 → 每键 +10；Restore 复原。
   - 场景 3：组外键占住 4 s，时间 200% 目标撞车 → **整组不被删除、键数不变**，状态栏报 "already used"。
   - 场景 4：两层两属性一次捕获，+1 s → 各自整组右移 1 s。
   - 场景 5：COLOR 值 200% → 支点键不变，另一键 `[1, 0, 0]`（clamp 生效）。
   - 全程 `alert` 0 次（无未处理异常）；每次写入都落在成对的 undo 组里。

## 搬运说明（给指挥）

本会话对 `C:\Users\19894\ae-mission\` 只读（越界写被 DSH 沙箱拒绝，且本会话审批被禁用）。请把以下两个文件**原样**复制落位：

```
out\keyframe-parent-clone\main.jsx    ->    C:\Users\19894\ae-mission\clones\keyframe-parent-clone\main.jsx
out\keyframe-parent-clone\README.md   ->    C:\Users\19894\ae-mission\clones\keyframe-parent-clone\README.md
```

`out\keyframe-parent-clone\` 下的 `main.jsx` 头部已写明目标绝对路径。`out\_selftest\harness.js` 只是自检桩，**不需要**落位（如需留档可放任务区，不要放进 clones 目录，以免混入交付物）。
