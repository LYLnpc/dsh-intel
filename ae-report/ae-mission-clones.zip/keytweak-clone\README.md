# KeyTweak Clone（clean-room 复刻）

> **CLEAN-ROOM 声明**：本项目为依据功能需求描述（`intel/paid-list.md` 第 11 条
> "KeyTweak"）从零独立编写的复刻实现。编写过程中未反编译原插件，未阅读、复制
> 或改写原插件的任何源代码、字节码或资源文件；仅依赖 Adobe After Effects 公开
> 脚本 API（docsforadobe 官方指南镜像核实版，见 `docs/api-cheatsheet.md` 白名
> 单）与需求文档。与原产品的相似性仅来自功能需求本身。仅供学习研究；
> KeyTweak 商标与著作权归 mamoworld（Mathias Möhl）所有，需完整功能请购买
> 正版（aescripts.com，$5.99 NYOP）。

- 原品：KeyTweak（mamoworld / Mathias Möhl，aescripts，$5.99 NYOP，jsx）
- 复刻：`main.jsx`（ExtendScript / ES3，单文件，约 400 行，UTF-8 带 BOM）
- 定位：对选中属性的关键帧做**时间维度批量编辑**——等距重排、时间缩放（重定时）、
  时间偏移、对齐吸附。原品另有值缩放/值偏移（值维度编辑），不在本次基线内。

---

## 一、功能对照表

### 已复刻（时间维度）

| 功能 | 说明 |
|------|------|
| 等距重排 | 选中的关键帧在**首尾选中键的跨度内**均匀重分布（N 个键 → N-1 等分）；多属性各自独立处理各自的选中键跨度 |
| 时间缩放 | 整体拉伸/压缩指定倍数，**以第一个选中关键帧为锚**（锚点不动）；倍数 >0（不支持 0/负数，见限制） |
| 时间偏移 | 整体平移 N 帧，正=后移、负=前移（帧长取合成 frameDuration） |
| 对齐 | 两种模式：**吸附到帧边界**（每个选中键取最近整帧）/**首键对齐到目标时间**（整组平移，使第一个选中键落在输入的目标秒数，组内相对间隔不变） |
| 批量作用 | 作用于时间线中全部选中属性的全部选中关键帧（`selectedProperties` + `selectedKeys`） |
| 保留关键帧属性 | 移动时间时逐键读出并回填：值、入/出插值类型、时间缓动（keyInTemporalEase/keyOutTemporalEase）、空间切线（仅 TwoD_SPATIAL/ThreeD_SPATIAL 属性）、roving/时间-空间 auto-bezier/continuous 开关 |
| 键安全机制 | 倒序 `removeKey` 删除选中键（剩余键索引不失效）→ 按新时间**正序** `setValueAtTime` 重插 → `nearestKeyIndex` 定位后回填；相邻键强制最小间隔（0.1ms）；落点撞上**未选中的既有键**时自动微移避让（防覆盖数据） |
| 参数记忆 | 倍数/帧数/对齐模式/目标时间经 `app.settings`（getHavingSaved 布尔判断 + getSetting 读值 + saveSetting 写入，官方合规两段式）持久化 |
| 防护 | 未激活合成/无选中属性/无选中关键帧弹窗中止；倍数非法（0/负/非数字）拦截；每次操作整体 Undo 组（try/finally 成对） |
| 面板双模式 | ScriptUI Panel 停靠 / Run Script File 浮动窗口 |

### 未复刻（与原品的差距）

| 功能 | 说明 |
|------|------|
| 值维度编辑 | 原品核心的值缩放/值偏移（"样本键 delta 映射到选中键集"）未复刻——本次基线限定时间维度 |
| 保持比例联动 | 原品的"值与时间保持比例"模式未复刻 |
| 样本键工作流 | 原品"只改 1–2 个样本键自动应用到其余"的交互范式未复刻（本复刻为直接数值输入） |
| 锚点关键帧特判 | 原品对锚点关键帧/空间属性单位换算的专门处理未做（本复刻直接按属性自身维度处理，不做单位换算） |

---

## 二、安装

1. **面板常驻（推荐）**：把 `main.jsx` 重命名为 `KeyTweakClone.jsx`，拷入：
   - Windows：`C:\Program Files\Adobe\Adobe After Effects <版本>\Support Files\Scripts\ScriptUI Panels\`
   - macOS：`/Applications/Adobe After Effects <版本>/Scripts/ScriptUI Panels/`
   **重启 AE**，`Window` 菜单底部勾选打开。
2. **临时运行**：`File > Scripts > Run Script File...` 选 `main.jsx`（浮动窗口，不可停靠）。
3. 参数记忆用到 `app.settings`（官方合规两段式），不写工程文件，无需勾选"允许脚本写文件"。
4. **未实机验证，建议先在测试工程试**（见第四节）。

## 三、使用

1. 时间线中选中一个或多个属性下的一个或多个关键帧（选中属性的关键帧，仅选图层无效）。
2. 点对应区按钮：
   - **等距重排**：无参数，首尾选中键跨度内均匀分布；
   - **时间缩放**：填倍数（如 2.00 = 时长翻倍、0.50 = 压缩一半），第一选中键不动；
   - **时间偏移**：填帧数（-12 = 整体前移 12 帧）；
   - **对齐**：选模式——"吸附到帧边界"逐键取最近整帧；"首键对齐到目标时间"填秒数（如 1.50），整组平移使首键落到 1.50s。
3. 状态行显示处理属性数/移动键数/跳过数；不满意一次 Ctrl+Z 整体撤销。

---

## 四、已知限制与不确定项（如实标注）

1. **未实机验证**：编写环境无 After Effects；已完成 node --check、ES3 扫描、API 白名单逐项核对（22 个 key*/set*AtKey/removeKey/PropertyValueType/app.settings 调用全部与 docs/api-cheatsheet.md 一致，无 deleteKey/全大写枚举等黑名单用法）。首用请先在测试工程试。
2. **删除-重插的风险窗口**：移动时间采用"读快照 → 倒序 removeKey → 正序 setValueAtTime 重插 → 回填属性"管线（AE 无直接改 keyTime 的官方 API）。若 AE 在此过程中途抛异常，该属性的关键帧可能只剩部分（Undo 组可整体恢复）。落点撞上未选中既有键时自动 +0.1ms 微移避让——**对齐到帧边界模式下若同帧已有未选中键，会失去精确对齐**（数据保护优先）。
3. **时间缩放不支持 0/负倍数**：负倍数会反转键序，值与时间的配对语义需原品式"保持比例"逻辑，未复刻。
4. **等距重排要求首尾跨度 > 0 且选中键 ≥ 2**：不满足时该属性被跳过并在状态行计数。
5. **HOLD 键**：插值类型原样保留；对 HOLD 键回写时间缓动 AE 会拒绝（自动跳过，不影响键移动本身）。
6. **空间切线不重算**：时间缩放/偏移只平移时间，空间切线向量原样保留——路径形状不变、节奏改变（这正是重定时预期）；roving 键重插后由 AE 自行重排。
7. **属性带表达式时**： ease/键移动被表达式覆盖的属性（如挂了摆动表达式）视觉上不生效，键本身仍会移动。
8. **Marker/Shape/TextDocument 关键帧**：同样支持移动（值对象原样读写）；这些类型的时间缓动读取失败会静默跳过。

## 五、自查记录（2026-11-14）

- `node --check`（剥离 `#target aftereffects` 行）：通过。
- ES3 扫描：干净（仅头注注释提及"无 let/const"字样；无箭头函数/模板串/JSON/ES5 数组方法/for-of/可选链）。
- 尾逗号：0 处。
- **API 白名单核对**（对照 docs/api-cheatsheet.md 逐个）：`keyTime/keyValue/keyInInterpolationType/keyOutInterpolationType/keyInTemporalEase/keyOutTemporalEase/keyInSpatialTangent/keyOutSpatialTangent/keyRoving/keyTemporalAutoBezier/keyTemporalContinuous/keySpatialAutoBezier/keySpatialContinuous/setInterpolationTypeAtKey/setTemporalEaseAtKey/setSpatialTangentsAtKey/setRovingAtKey/setTemporalAutoBezierAtKey/setTemporalContinuousAtKey/setSpatialAutoBezierAtKey/setSpatialContinuousAtKey/removeKey/nearestKeyIndex/setValueAtTime` 全部在册；`PropertyValueType.TwoD_SPATIAL/ThreeD_SPATIAL` 混合大小写正确；**无 deleteKey/无全大写枚举/无 baselineLocShift**；`app.settings` 采用 getHavingSaved(布尔)+getSetting+saveSetting 官方两段式。
- selectedKeys 排序使用自定义数值比较器（ES3 无默认数值比较，速查表要点）。
- 编码：UTF-8 带 BOM。
