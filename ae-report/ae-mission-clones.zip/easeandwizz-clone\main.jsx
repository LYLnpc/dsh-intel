﻿#target aftereffects
/**
 * ============================================================================
 *  EaseAndWizz Clone —— 缓动预设一键应用的 clean-room 复刻实现
 * ============================================================================
 *
 *  [CLEAN-ROOM 声明]
 *  本脚本依据功能需求描述（intel/paid-list.md 第 4 条 "EaseAndWizz"）从零独立
 *  编写。编写过程中未反编译原插件，未阅读、复制或改写原插件的任何源代码、
 *  字节码或资源文件；仅依赖 Adobe After Effects 公开脚本 API、公开的 Penner
 *  缓动曲线定义/标准贝塞尔近似表与需求文档。与原产品的相似性仅来自功能需求
 *  本身。仅供学习研究；EaseAndWizz 商标与著作权归其原作者所有，需完整功能请
 *  购买正版（aescripts.com，$29.99）。
 *
 *  功能概述：
 *    - 选中关键帧 → 预设下拉（26 条：Sine/Quad/Cubic/Quart/Quint/Expo/Circ
 *      七族各 In/Out/InOut 共 21 条缓动 + Back In/Back Out/Elastic Out/
 *      Bounce Out/Wizz Out 五条过冲类）→ 一键应用；
 *    - 缓动族经 KeyframeEase（speed+influence）写入相邻关键帧段
 *      （setTemporalEaseAtKey）；过冲族（值会超出关键帧值，时间缓动表达不了）
 *      逐帧采样插入中间关键帧烘焙；
 *    - wizz 特性：连续点击 Apply 自动递增强度倍率（3 秒内连续 = 倍率累加）；
 *    - 可选随机抖动（每次应用给倍率加 ±pct% 随机量）；批量作用于全部选中属性；
 *    - 整体 Undo 组；空选中防护。
 *
 *  与 flow-clone 的关系：同为"时间缓动手柄 + 过冲插帧"路线，但本实现独立
 *  编写——直接用 Penner 近似表查手柄（不做贝塞尔缩放函数），参数命名（ewz* /
 *  EAW_*）、UI 文案、过冲曲线采样与"连续递增强度"逻辑均为原创。
 *
 *  ExtendScript / ES3 兼容：无 let/const/箭头函数/模板字符串/JSON/ES5 数组方法。
 * ============================================================================
 */

(function (ewzThisObj) {

    var EAW_NAME = "EaseAndWizz Clone";
    var EAW_VER = "1.0.0";

    // wizz 连续递增状态：3 秒内连续 Apply 累加次数，超时/重置归零
    var ewzSeq = 0;
    var ewzLastApply = 0;
    // removeKey 兼容性标记：首次失败后本会话跳过段内清理
    var ewzRemoveKeyOK = true;

    /* ======================================================================
     *  ES3 基础工具
     * ==================================================================== */

    function ewzClamp(v, lo, hi) {
        if (v < lo) { return lo; }
        if (v > hi) { return hi; }
        return v;
    }

    function ewzNum(s, fallback) {
        var v = parseFloat(s);
        if (isNaN(v)) { return fallback; }
        return v;
    }

    function ewzFmt(x) {
        return "" + (Math.round(x * 1000) / 1000);
    }

    /* ======================================================================
     *  预设表
     *  kind "ease"：dir in/out/inout，用贝塞尔近似表 (x1,y1,x2,y2) 的手柄
     *  kind "sample"：过冲曲线，逐帧采样插中间关键帧（时间缓动无法过冲）
     *  近似表为公开标准（Penner 缓动 → cubic-bezier 常用近似）
     * ==================================================================== */

    var EAW_PRESETS = [
        { name: "Sine In",      kind: "ease", dir: "in",    bez: [0.12, 0, 0.39, 0] },
        { name: "Sine Out",     kind: "ease", dir: "out",   bez: [0.61, 1, 0.88, 1] },
        { name: "Sine InOut",   kind: "ease", dir: "inout", bez: [0.37, 0, 0.63, 1] },
        { name: "Quad In",      kind: "ease", dir: "in",    bez: [0.55, 0.085, 0.68, 0.53] },
        { name: "Quad Out",     kind: "ease", dir: "out",   bez: [0.25, 0.46, 0.45, 0.94] },
        { name: "Quad InOut",   kind: "ease", dir: "inout", bez: [0.455, 0.03, 0.515, 0.955] },
        { name: "Cubic In",     kind: "ease", dir: "in",    bez: [0.55, 0.055, 0.675, 0.19] },
        { name: "Cubic Out",    kind: "ease", dir: "out",   bez: [0.215, 0.61, 0.355, 1] },
        { name: "Cubic InOut",  kind: "ease", dir: "inout", bez: [0.645, 0.045, 0.355, 1] },
        { name: "Quart In",     kind: "ease", dir: "in",    bez: [0.895, 0.03, 0.685, 0.22] },
        { name: "Quart Out",    kind: "ease", dir: "out",   bez: [0.165, 0.84, 0.44, 1] },
        { name: "Quart InOut",  kind: "ease", dir: "inout", bez: [0.77, 0, 0.175, 1] },
        { name: "Quint In",     kind: "ease", dir: "in",    bez: [0.755, 0.05, 0.855, 0.06] },
        { name: "Quint Out",    kind: "ease", dir: "out",   bez: [0.23, 1, 0.32, 1] },
        { name: "Quint InOut",  kind: "ease", dir: "inout", bez: [0.86, 0, 0.07, 1] },
        { name: "Expo In",      kind: "ease", dir: "in",    bez: [0.95, 0.05, 0.795, 0.035] },
        { name: "Expo Out",     kind: "ease", dir: "out",   bez: [0.19, 1, 0.22, 1] },
        { name: "Expo InOut",   kind: "ease", dir: "inout", bez: [1, 0, 0, 1] },
        { name: "Circ In",      kind: "ease", dir: "in",    bez: [0.6, 0.04, 0.98, 0.335] },
        { name: "Circ Out",     kind: "ease", dir: "out",   bez: [0.075, 0.82, 0.165, 1] },
        { name: "Circ InOut",   kind: "ease", dir: "inout", bez: [0.785, 0.135, 0.15, 0.86] },
        { name: "Back In",      kind: "sample" },
        { name: "Back Out",     kind: "sample" },
        { name: "Elastic Out",  kind: "sample" },
        { name: "Bounce Out",   kind: "sample" },
        { name: "Wizz Out",     kind: "sample" }
    ];
    var EAW_DEFAULT_IDX = 7; // "Cubic Out"

    /* ======================================================================
     *  过冲曲线（归一化 f(0)=0, f(1)=1；均为公开标准公式或自研复合）
     * ==================================================================== */

    function ewzBackIn(t, k) {
        var c1 = 1.70158 * ewzClamp(k, 0.2, 3);
        var c3 = c1 + 1;
        return c3 * t * t * t - c1 * t * t;
    }

    function ewzBackOut(t, k) {
        var c1 = 1.70158 * ewzClamp(k, 0.2, 3);
        var c3 = c1 + 1;
        var u = t - 1;
        return 1 + c3 * u * u * u + c1 * u * u;
    }

    function ewzElasticOut(t, k) {
        if (t <= 0) { return 0; }
        if (t >= 1) { return 1; }
        return 1 + ewzClamp(k, 0.2, 3) * Math.pow(2, -10 * t) * Math.sin((t * 10 - 0.75) * 2.0943951);
    }

    function ewzBounceOut(t) {
        var n1 = 7.5625;
        var d1 = 2.75;
        if (t < 1 / d1) { return n1 * t * t; }
        if (t < 2 / d1) { t = t - 1.5 / d1; return n1 * t * t + 0.75; }
        if (t < 2.5 / d1) { t = t - 2.25 / d1; return n1 * t * t + 0.9375; }
        t = t - 2.625 / d1;
        return n1 * t * t + 0.984375;
    }

    // Wizz（自研"落座双弹"）：easeOutQuad 主趋势 + 后半段过冲→回压→归位，
    // 端点恒为 0/1；k 放大回弹幅度
    function ewzWizzOut(t, k) {
        var trend = 1 - (1 - t) * (1 - t);
        if (t <= 0.55) { return trend; }
        var s = (t - 0.55) / 0.45;
        var wob = ewzClamp(k, 0.2, 3) * 0.25 * Math.sin(s * 7.85398163) * (1 - s);
        return trend + wob;
    }

    function ewzSampleFn(name) {
        if (name === "Back In") { return ewzBackIn; }
        if (name === "Back Out") { return ewzBackOut; }
        if (name === "Elastic Out") { return ewzElasticOut; }
        if (name === "Bounce Out") { return ewzBounceOut; }
        return ewzWizzOut; // "Wizz Out"
    }

    /* ======================================================================
     *  关键帧读写
     * ==================================================================== */

    // 缓动数组长度：优先回读该键现有 ease 数组（不同维度属性的 AE 约定不同，
    // 回读最稳）；读不到再按 propertyValueType 粗略回退（1D→1，其余→2）。
    function ewzEaseDims(prop, idx) {
        try {
            var arr = prop.keyInTemporalEase(idx);
            if (arr != null && arr.length > 0) { return arr.length; }
        } catch (e1) {}
        try {
            var arr2 = prop.keyOutTemporalEase(idx);
            if (arr2 != null && arr2.length > 0) { return arr2.length; }
        } catch (e2) {}
        if (prop.propertyValueType === PropertyValueType.OneD) { return 1; }
        return 2;
    }

    function ewzValueDims(v) {
        if (v != null && typeof v.length === "number") { return v.length; }
        return 1;
    }

    function ewzValAt(v, d) {
        if (v != null && typeof v.length === "number") { return v[d]; }
        return v;
    }

    // 单侧 ease 应用。side "out"：以下一键为段尾；side "in"：以上一键为段头。
    // 返回 true=成功写入。
    function ewzApplySide(prop, idx, side, hx, hy, k) {
        var neighborIdx = (side === "out") ? (idx + 1) : (idx - 1);
        if (neighborIdx < 1 || neighborIdx > prop.numKeys) { return false; }
        var tA = prop.keyTime(idx);
        var tB = prop.keyTime(neighborIdx);
        var D = tB - tA;
        if (!(D > 0)) { return false; }
        var vA = prop.keyValue(idx);
        var vB = prop.keyValue(neighborIdx);
        var dims = ewzEaseDims(prop, idx);
        var vDims = Math.max(ewzValueDims(vA), ewzValueDims(vB));
        var influence = ewzClamp(hx * k * 100, 0.1, 99.95);
        var inArr = null;
        var outArr = null;
        var d;
        var spd;
        if (side === "out") {
            outArr = [];
            for (d = 0; d < dims; d++) {
                var dd = (d < vDims) ? d : (vDims - 1); // 缺失维回退到源末维
                var delta = ewzValAt(vB, dd) - ewzValAt(vA, dd);
                spd = (Math.abs(delta) < 1e-9) ? 0 : (hy * k * delta) / (hx * D);
                outArr.push(new KeyframeEase(spd, influence));
            }
            try { inArr = prop.keyInTemporalEase(idx); } catch (e1) { inArr = null; }
        } else {
            inArr = [];
            for (d = 0; d < dims; d++) {
                var dd2 = (d < vDims) ? d : (vDims - 1);
                var delta2 = ewzValAt(vA, dd2) - ewzValAt(vB, dd2);
                spd = (Math.abs(delta2) < 1e-9) ? 0 : (hy * k * delta2) / (hx * D);
                inArr.push(new KeyframeEase(spd, influence));
            }
            try { outArr = prop.keyOutTemporalEase(idx); } catch (e2) { outArr = null; }
        }
        if (inArr === null || outArr === null) { return false; }
        prop.setTemporalEaseAtKey(idx, inArr, outArr);
        return true;
    }

    // 过冲预设：清掉段内旧中间键（removeKey，兼容失败则跳过清理），
    // 逐帧采样插入 LINEAR 中间键烘焙曲线。
    function ewzApplySample(prop, idx, fn, k, fd) {
        if (idx >= prop.numKeys) { return false; }
        var tA = prop.keyTime(idx);
        var tB = prop.keyTime(idx + 1);
        var D = tB - tA;
        if (!(D > 0) || !(fd > 0)) { return false; }
        var vA = prop.keyValue(idx);
        var vB = prop.keyValue(idx + 1);
        var vDims = Math.max(ewzValueDims(vA), ewzValueDims(vB));
        var frames = Math.round(D / fd);
        if (frames < 2) { return false; }
        var insert = frames - 1;
        if (insert > 300) { insert = 300; } // 长段烘焙上限，防失控

        var i;
        if (ewzRemoveKeyOK) {
            var nBetween = 0;
            try {
                for (i = idx + 1; i <= prop.numKeys; i++) {
                    if (prop.keyTime(i) >= tB) { break; }
                    nBetween++;
                }
                for (i = idx + nBetween; i >= idx + 1; i--) {
                    prop.removeKey(i);
                }
            } catch (e0) {
                ewzRemoveKeyOK = false; // 本环境不支持 removeKey：跳过清理
            }
        }

        for (i = 1; i <= insert; i++) {
            var t = tA + (D * i) / (insert + 1);
            var tt = (t - tA) / D;
            var f = fn(tt, k);
            var val;
            if (vDims === 1) {
                val = ewzValAt(vA, 0) + f * (ewzValAt(vB, 0) - ewzValAt(vA, 0));
            } else {
                val = [];
                for (var d = 0; d < vDims; d++) {
                    var dd = (d < vDims) ? d : (vDims - 1);
                    val.push(ewzValAt(vA, dd) + f * (ewzValAt(vB, dd) - ewzValAt(vA, dd)));
                }
            }
            prop.setValueAtTime(t, val);
            try {
                // 官方枚举为 KeyframeInterpolationType（无 InterpolationType 全局）
                prop.setInterpolationTypeAtKey(idx + i, KeyframeInterpolationType.LINEAR, KeyframeInterpolationType.LINEAR);
            } catch (e1) {}
        }
        return true;
    }

    /* ======================================================================
     *  应用主流程
     * ==================================================================== */

    function ewzCollectProps(comp) {
        var out = [];
        var sel = comp.selectedProperties;
        if (sel == null) { return out; }
        for (var i = 0; i < sel.length; i++) {
            var p = sel[i];
            try {
                if (String(p.propertyType) === "PROPERTY" && p.numKeys > 0 && p.selectedKeys.length > 0) {
                    out.push(p);
                }
            } catch (e) {}
        }
        return out;
    }

    function ewzApplyAll(comp, preset, k, statusText) {
        var props = ewzCollectProps(comp);
        if (props.length === 0) {
            alert("请先在时间线中选中关键帧（选中属性下的一个或多个关键帧）。", EAW_NAME);
            return;
        }
        var applied = 0;
        var skipped = 0;
        var errors = 0;
        var lastErr = "";
        app.beginUndoGroup(EAW_NAME + ": " + preset.name);
        try {
            for (var pi = 0; pi < props.length; pi++) {
                var prop = props[pi];
                var keys = prop.selectedKeys;
                // 防索引漂移：采样预设会在段内插键，selectedKeys 的索引随之失效；
                // 先快照关键帧时间，每轮用 nearestKeyIndex(time) 重新解析索引。
                var keyTimes = [];
                var kt;
                for (kt = 0; kt < keys.length; kt++) {
                    keyTimes.push(prop.keyTime(keys[kt]));
                }
                var i;
                for (var ki = 0; ki < keyTimes.length; ki++) {
                    var idx = prop.nearestKeyIndex(keyTimes[ki]);
                    if (idx < 1 || idx > prop.numKeys) { skipped++; continue; }
                    var did = false;
                    try {
                        if (preset.kind === "ease") {
                            if ((preset.dir === "in" || preset.dir === "inout") && idx < prop.numKeys) {
                                // In 侧：本键的出方向（x1,y1 手柄）
                                did = ewzApplySide(prop, idx, "out", preset.bez[0], preset.bez[1], k) || did;
                            }
                            if ((preset.dir === "out" || preset.dir === "inout") && idx > 1) {
                                // Out 侧：本键的入方向（1-x2, 1-y2 手柄）
                                did = ewzApplySide(prop, idx, "in", 1 - preset.bez[2], 1 - preset.bez[3], k) || did;
                            }
                        } else {
                            did = ewzApplySample(prop, idx, ewzSampleFn(preset.name), k, comp.frameDuration);
                        }
                    } catch (eK) {
                        errors++;
                        lastErr = eK.toString();
                        continue;
                    }
                    if (did) { applied++; } else { skipped++; }
                }
            }
        } finally {
            app.endUndoGroup();
        }
        var msg = preset.name + " ×" + ewzFmt(k) + "：应用 " + applied + " 个关键帧";
        if (skipped > 0) { msg += "，跳过 " + skipped + "（无相邻段/段时长为 0）"; }
        if (errors > 0) { msg += "，错误 " + errors + "（" + lastErr + "）"; }
        statusText.text = msg;
        if (errors > 0) { alert(msg, EAW_NAME); }
    }

    /* ======================================================================
     *  UI（ScriptUI，可停靠面板，ES3）
     * ==================================================================== */

    function ewzBuildUI(thisObj) {
        var win = (thisObj instanceof Panel) ? thisObj :
            new Window("palette", EAW_NAME + " v" + EAW_VER, undefined, { resizeable: true });
        win.orientation = "column";
        win.alignChildren = ["fill", "top"];
        win.spacing = 6;
        win.margins = 12;

        win.add("statictext", undefined, EAW_NAME + " v" + EAW_VER + "（clean-room）");

        var titles = [];
        for (var ti = 0; ti < EAW_PRESETS.length; ti++) { titles.push(EAW_PRESETS[ti].name); }
        var dd = win.add("dropdownlist", undefined, titles);
        dd.selection = EAW_DEFAULT_IDX;
        dd.helpTip = "缓动预设：七族 In/Out/InOut 走时间缓动手柄，Back/Elastic/Bounce/Wizz 走逐帧烘焙";

        var rowK = win.add("group");
        rowK.orientation = "row";
        rowK.alignChildren = ["left", "center"];
        rowK.add("statictext", undefined, "基础倍率:");
        var sK = rowK.add("slider", undefined, 100, 20, 300);
        sK.preferredSize.width = 130;
        var eK = rowK.add("edittext", undefined, "1.00");
        eK.characters = 6;
        eK.helpTip = "基础强度倍率 0.2–3.0；实际倍率 = 基础 × 连续次数 × 抖动";

        var rowSeq = win.add("group");
        rowSeq.orientation = "row";
        rowSeq.alignChildren = ["left", "center"];
        var cbSeq = rowSeq.add("checkbox", undefined, "连续点击自动加倍（wizz 特性）");
        cbSeq.value = true;
        cbSeq.helpTip = "3 秒内连续点 Apply：第 1 次基础倍率，第 2 次 ×2，第 3 次 ×3……间隔超 3 秒或点重置则回到 ×1";
        var btnReset = rowSeq.add("button", undefined, "重置");
        btnReset.preferredSize.width = 44;

        var rowJ = win.add("group");
        rowJ.orientation = "row";
        rowJ.alignChildren = ["left", "center"];
        rowJ.add("statictext", undefined, "随机抖动 %:");
        var eJ = rowJ.add("edittext", undefined, "0");
        eJ.characters = 5;
        eJ.helpTip = "每次应用给总倍率加 ±pct% 随机量；0 = 关闭";
        rowJ.add("statictext", undefined, "  （0 = 关）");

        var btnApply = win.add("button", undefined, "Apply 应用到选中关键帧", { name: "ok" });
        btnApply.preferredSize.height = 32;

        var status = win.add("statictext", undefined, "就绪。选中关键帧后点 Apply。", { multiline: true });
        status.preferredSize = [320, 40];

        // 滑杆与输入框联动
        sK.onChanging = function () {
            try { eK.text = (this.value / 100).toFixed(2); } catch (e1) {}
        };
        sK.onChange = function () {
            try { eK.text = (this.value / 100).toFixed(2); } catch (e2) {}
        };
        eK.onChange = function () {
            try {
                var v = ewzClamp(ewzNum(eK.text, 1), 0.2, 3);
                sK.value = v * 100;
                eK.text = v.toFixed(2);
            } catch (e3) {}
        };

        btnReset.onClick = function () {
            ewzSeq = 0;
            ewzLastApply = 0;
            status.text = "连续计数已重置（下次 Apply 从 ×基础 开始）。";
        };

        btnApply.onClick = function () {
            try {
                var comp = app.project ? app.project.activeItem : null;
                if (comp === null || !(comp instanceof CompItem)) {
                    alert("请先激活一个合成。", EAW_NAME);
                    return;
                }
                var preset = (dd.selection !== null) ? EAW_PRESETS[dd.selection.index] : EAW_PRESETS[EAW_DEFAULT_IDX];
                var base = ewzClamp(ewzNum(eK.text, 1), 0.2, 3);
                // wizz 连续递增：3 秒内连续 Apply，倍率次数累加
                var now = (new Date()).getTime();
                if (cbSeq.value && (now - ewzLastApply) < 3000) {
                    ewzSeq++;
                } else {
                    ewzSeq = 1;
                }
                ewzLastApply = now;
                var k = base * ewzSeq;
                // 随机抖动
                var pct = ewzNum(eJ.text, 0);
                if (pct > 0) {
                    k = k * (1 + (Math.random() * 2 - 1) * pct / 100);
                }
                k = ewzClamp(k, 0.1, 9);
                var seqNote = cbSeq.value ? ("（连续第 " + ewzSeq + " 次）") : "";
                status.text = "应用中 " + preset.name + " 总倍率 ×" + ewzFmt(k) + seqNote + " …";
                ewzApplyAll(comp, preset, k, status);
            } catch (eX) {
                alert("应用失败：" + eX.toString(), EAW_NAME);
            }
        };

        win.onResizing = win.onResize = function () {
            this.layout.resize();
        };

        if (win instanceof Window) {
            win.center();
            win.show();
        } else {
            win.layout.layout(true);
            win.layout.resize();
        }
        return win;
    }

    /* ======================================================================
     *  入口
     * ==================================================================== */

    function ewzMain() {
        if (typeof app === "undefined" || app.project == null) {
            alert("请先打开一个 After Effects 工程。", EAW_NAME);
            return;
        }
        ewzBuildUI(ewzThisObj);
    }

    ewzMain();

})(this);
