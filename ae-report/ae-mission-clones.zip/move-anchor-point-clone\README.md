# Move Anchor Point Clone（jsx 版）

一键把图层锚点移到内容边界框的 9 个位置或任意自定义百分比，同时补偿 Position，画面不跳。

- 版本：1.0.0｜文件：`main.jsx`｜类型：ScriptUI 面板
- 对应原商品：Move Anchor Point 4（$29.99，v4 已是 aex 原生插件；本件复刻的是其 **jsx 可完全实现的核心逻辑**，不含 aex 的性能/交互形态）

> **Clean-room 声明**：仅依据公开的功能描述（「一键把图层锚点移到几何中心/边角/顶点等，同时补偿 position 保持画面不动」）与通用 AE Scripting API 知识独立实现。未获取、阅读或参考原插件/脚本的源码或资源。

---

## 一、功能对照

| 原版能力 | 本复刻 |
|---|---|
| 锚点吸附到 9 个位置（四角/四边中点/中心） | ✅ 3×3 按钮网格 |
| 锚点吸附到任意点 | ✅ 自定义 X/Y（0–1 相对内容边界） |
| 移到「视觉中心」而非「包围盒中心」 | ❌ 只做包围盒（见限制 1） |
| 保持画面位置不动 | ✅ 用 toComp 差分反算 position，含缩放/旋转/父级/3D |
| 一键裁剪 comp 到内容（v4 附加功能） | ✅ 另有独立件 `trim-comp-clone` |
| aex 原生性能/实时预览 | ❌ jsx 无此能力 |

## 二、使用方式

1. 打开合成，在时间线里选中 1 个或多个图层；
2. `File > Scripts > Run Script File...` 选 `main.jsx`；
3. 点 3×3 网格里任一格（按钮上标的是 `0,0` ~ `1,1` 的相对坐标），或填自定义 X/Y 后点 `Apply`；
4. 状态栏显示 `Moved N, failed M.`，失败原因逐条列出；
5. `Ctrl+Z` 一步回退整批。

网格含义（X 向右、Y 向下，与 AE 屏幕坐标一致）：

```
0,0   0.5,0   1,0     左上   上中   右上
0,0.5 0.5,0.5 1,0.5   中左   中心   中右
0,1   0.5,1   1,1     左下   下中   右下
```

## 三、算法（这是本件最值得看的部分）

朴素做法是「新 anchor = 老 anchor + 偏移、position += 同一偏移」，这在**有缩放/旋转/父级/3D 朝向**的图层上会错位。本复刻改成三步差分法，全部交给 AE 自己的矩阵算：

1. **量目标点**：`rect = layer.sourceRectAtTime(comp.time, false)` 拿到内容包围盒（layer 空间，原点 = 当前锚点），算出目标点 `T = (rect.left + fx*rect.width, rect.top + fy*rect.height)`。
2. **设新锚点**：`anchor = 旧锚点 + T`。此时图层原点就落在目标点上。
3. **反算 Position**：
   - 移动前：`compBefore = layer.toComp(T)`（目标点在合成空间的位置）
   - 移动后：`compAfter = layer.toComp([0,0])`（原点现在就是目标点）
   - 差值 `d = compBefore - compAfter` 是「合成空间」的偏移，而 `position` 活在「父图层空间」（无父级时就是合成空间），所以要反向套一次变换：对父层调 `parent.fromComp()` 分别换算两个点再求差，无父级直接用 `d`。
   - `position += 换算后的差值`。

这样缩放、旋转（含 3D 的 X/Y/Z 旋转）、skew、父级链全部自动正确，不需要自己推旋转矩阵，也不用关心 AE 的旋转顺序。

## 四、能力限制（诚实说明）

1. **锚点对齐的是「内容包围盒」，不是「视觉中心」**。`sourceRectAtTime` 给的是 bbox，不感知像素透明度：一个左侧有大量透明的文字层，bbox 中心 ≠ 视觉重心。原版是否有「视觉中心」模式未公开，本复刻不做图像采样（jsx 读像素代价高且慢）。
2. **在「当前时间」取样一次**。如果图层内容随时间变化（文字打字机、形状变形、缩放动画），锚点只按播放头那一刻的包围盒计算，不会跟着动画走。想要逐帧对齐得对每帧单独跑。
3. **有关键帧的属性会被打关键帧**：`anchorPoint`/`position` 已有 keyframe 时，`setValue()` 会抛异常，所以脚本改用 `setValueAtTime(comp.time, …)` 在当前位置写键。这是保守策略，但**会在时间线上留下新键**，状态栏会提示 `N layer(s) had keyframes`。
4. **分离维度的 Position / Anchor 不支持**：AE 里 X/Y 分离后 `layer.position` 变成 PropertyGroup 而不是 Property，本件检测到就跳过该层并报明原因（不会静默错算）。
5. **自动定向（Auto-Orient）图层**：本算法靠 position 差分，而 Auto-Orient 的朝向是「由运动路径决定的」，改 position 会改变朝向，理论上存在极小的残余偏差。实际使用中通常无感，但严格的相机/追踪层请手动核对。
6. **摄像机/灯光图层**没有 `sourceRectAtTime` 内容框，会被拒绝并提示。
7. **只处理 2D 内容框**：3D 图层（`ThreeD_SPATIAL` 锚点）只改 X/Y，Z 锚点保持原值；不会把锚点推到 3D 空间的前后方向。
8. **不支持「锚点吸附到蒙版/形状单个顶点」**（原版 v4 可能有，未公开确认；本件不做）。

## 五、白名单外 API 声明 ⚠️

本节按项目规范强制披露。以下 API 不在 `docs/api-cheatsheet.md` 白名单内：

| API | 用途 | 替代做法（若不用它） |
|---|---|---|
| `Layer.sourceRectAtTime(time, includeExtents)` | 取内容包围盒 | 只能用 `layer.source.width/height` + 假设内容居中，对文字层/形状层/裁剪过的素材完全不准；或手工让用户输入尺寸。质量不可接受，故采用官方 API |
| `Layer.toComp(point)` | layer → comp 空间变换 | 自己推 `scale/rotation/3D 旋转顺序/skew` 的仿射矩阵，易错且 3D 旋转顺序难保证 |
| `Layer.fromComp(point)` | comp → parent 空间变换 | 同上，需自己实现父级链求逆 |
| `Property.setValueAtTime(time, value)` | 给有关键帧的属性写值 | 白名单内只有 `setValue`，但它对有关键帧的属性会抛异常；不用它就等于不支持带动画的图层 |

四个都是 **官方 After Effects Scripting Guide 收录的 API**（`sourceRectAtTime`、`toComp`、`fromComp`、`setValueAtTime` 均在指南的 Layer / Property 章节），只是本地白名单未列。使用处均包 try/catch，失败会写进状态栏而不是崩面板。

## 六、API 使用核对

白名单内：`app.project`、`CompItem.selectedLayers`、`comp.time`、`Layer.name`、`Layer.parent`、`Property.value`、`Property.numKeys`、`Property.setValue`、`app.beginUndoGroup`/`app.endUndoGroup`、ScriptUI 全套。
白名单外：见第五节。

## 七、验收清单

1. 纯色层（1920×1080，锚点默认中心）→ 点 `0,0`，锚点变 (0,0)，position 变 (-960,-540)，画面纹丝不动。
2. 同层加 Scale 50% + Rotation 30° → 点 `1,1`，画面仍不动（这是最容易错的位置）。
3. 有父级 Null（父级带旋转）的子层 → 点 `0.5,0`，画面不动。
4. 3D 层（X 旋转 45°）→ 点中心，position 三轴都正确补偿，Z 锚点不变。
5. 文字层（bbox 小于 comp）→ 点 `0.5,0.5`，锚点落在文字块中心。
6. 有关键帧的层 → 状态栏提示 keyed，undo 后关键帧消失。
7. 分离维度 position 的层 → 被跳过并报错说明，不影响其他层。
8. 未选中图层 → `Select at least one layer`。
9. 自定义 X=0.25, Y=0.75 → 锚点落在内容框 1/4、3/4 处。

## 八、文件

```
clones/move-anchor-point-clone/
├─ main.jsx
└─ README.md
```

静态检查：`node --check` 通过、ES3 扫描无命中、纯 ASCII、无 BOM。
