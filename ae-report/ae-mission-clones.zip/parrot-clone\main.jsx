/*******************************************************************************
 * Parrot Clone (animation relay / follow-through) - main.jsx
 * generated_at: 2026-11-14T08:24:00+08:00
 * task: clean-room 复刻 Parrot（aescripts, Mike Overbeck, $29.99）核心功能：
 *       把驱动图层的动画"接力"到后续图层（延迟复现），参数=延迟帧数/值偏移/
 *       时间偏移/接力次数（输入 = intel/paid-list.md 第 13 条功能性描述，
 *       不反编译不抄原代码）
 *
 * CLEAN-ROOM 声明：
 * 1. 本脚本为清室（clean-room）独立实现。实现者未反编译、未阅读、未复制
 *    Parrot 的任何原始代码；仅依据公开的功能性描述与 AE 公开脚本 API 从零
 *    编写（API 对照 docs/api-cheatsheet.md 白名单）。
 * 2. 实现路线：给每个接力图层写 valueAtTime(time - delaySec) 采样表达式
 *    （官方文档化方法，Property.valueAtTime(time, preExpression)），
 *    延迟 = 层序 k × 每级延迟帧数（可关闭递增），采样值加值偏移。
 *    表达式模板由 Node 自查脚本逐字提取执行验证（见 README）。
 * 3. ES3 (ExtendScript) 编写：无 let/const/箭头函数/JSON.stringify。
 *
 * 语义：
 *   - 选中第 1 个图层 = 驱动层（Driver），其余按时间线顺序为接力层；
 *   - 接力层 k（1-based）延迟 = k × 每级延迟帧数（勾选"递增延迟"）或固定延迟；
 *   - 应用属性可选 Position（2D/3D 均支持）或 Rotation；
 *   - 有父级的接力层跳过（避免父层坐标系错位）；undo 组包裹。
 ******************************************************************************/

(function (thisObj) {

    var SCRIPT_NAME = "Parrot Clone";
    var SCRIPT_VER = "1.0.0";

    // ------------------------------------------------------------------
    // 小工具（ES3）
    // ------------------------------------------------------------------
    function toInt(v, fallback, min) {
        var x = parseInt(v, 10);
        if (isNaN(x)) { x = fallback; }
        if (x < min) { x = min; }
        return x;
    }

    function toNum2(v, fallback) {
        var x = parseFloat(v);
        if (isNaN(x)) { return fallback; }
        return x;
    }

    // ------------------------------------------------------------------
    // 表达式模板（PARROT-EXPR 标记块：Node 自查逐字提取执行）
    // ------------------------------------------------------------------

    // >>> PARROT-EXPR-START（接力表达式模板：Node 自查从本块逐字提取执行验证）
    function escName(n) {
        // review-4 fix: escape backslash BEFORE quotes (invalid literal otherwise)
        return ("" + n).replace(/\\/g, "\\\\").replace(/"/g, "\\\"");
    }

    function buildRelayExprPos(driverName, delayFrames, ox, oy) {
        var L = [];
        L.push("// === Parrot Clone (clean-room) v1.0.0 : relay position ===");
        L.push("var drv = thisComp.layer(\"" + escName(driverName) + "\");");
        // review-4 fix: delay in frames x thisComp.frameDuration so a later
        // frame-rate change keeps the relay timing correct
        L.push("var sv = drv.transform.position.valueAtTime(time - (" + delayFrames + " * thisComp.frameDuration));");
        L.push("(sv.length > 2) ? [sv[0] + " + ox + ", sv[1] + " + oy + ", sv[2]] : [sv[0] + " + ox + ", sv[1] + " + oy + "];");
        return L.join("\n");
    }

    function buildRelayExprRot(driverName, delayFrames, od) {
        var L = [];
        L.push("// === Parrot Clone (clean-room) v1.0.0 : relay rotation ===");
        L.push("var drv = thisComp.layer(\"" + escName(driverName) + "\");");
        L.push("var sv = drv.transform.rotation.valueAtTime(time - (" + delayFrames + " * thisComp.frameDuration));");
        L.push("sv + " + od + ";");
        return L.join("\n");
    }
    // <<< PARROT-EXPR-END

    // ------------------------------------------------------------------
    // 主流程
    // ------------------------------------------------------------------
    function doRelay(cfg) {
        if (app.project === null) { alert("没有打开的项目。"); return; }
        var comp = app.project.activeItem;
        if (comp === null || !(comp instanceof CompItem)) {
            alert("请先激活一个合成。"); return;
        }
        var sel = comp.selectedLayers;
        if (sel.length < 2) {
            alert("请先选中至少 2 个图层：第 1 个 = 驱动层，其余 = 接力层（按时间线顺序接力）。");
            return;
        }
        // 时间线自上而下排序：第 1 个 = 驱动层
        var sorted = sel.slice(0);
        sorted.sort(function (a, b) { return a.index - b.index; });
        var driver = sorted[0];
        // review-4 note: delay now embeds frames x thisComp.frameDuration in
        // the expression itself, so no script-side frameRate read is needed

        // 接力层数量：接力次数 0 = 全部后续层
        var followerCount = sorted.length - 1;
        if (cfg.relayCount > 0 && cfg.relayCount < followerCount) {
            followerCount = cfg.relayCount;
        }

        app.beginUndoGroup("Parrot Clone: Relay");
        var report = { applied: 0, warnings: [] };
        var k;
        try {
            for (k = 1; k <= followerCount; k++) {
                var follower = sorted[k]; // 时间线第 k+1 个 = 第 k 级接力
                var delayFrames = cfg.incremental ? (k * cfg.delayFrames) : cfg.delayFrames;

                var prop = null;
                var expr = "";
                if (cfg.mode === "rot") {
                    try {
                        prop = follower.property("ADBE Transform Group").property("ADBE Rotate Z");
                    } catch (eR) {
                        report.warnings.push("[" + follower.name + "] 无 rotation 属性，跳过。");
                        continue;
                    }
                    expr = buildRelayExprRot(driver.name, delayFrames, cfg.offsetRot);
                } else {
                    try {
                        prop = follower.property("ADBE Transform Group").property("ADBE Position");
                    } catch (eP) {
                        report.warnings.push("[" + follower.name + "] 无 position 属性，跳过。");
                        continue;
                    }
                    expr = buildRelayExprPos(driver.name, delayFrames, cfg.offsetX, cfg.offsetY);
                }

                // 父级防护：position 是父层坐标，采样值是合成坐标，直接写会错位
                var hasParent = false;
                try { hasParent = (follower.parent !== null); } catch (ePar) { hasParent = false; }
                if (hasParent && cfg.mode === "pos") {
                    report.warnings.push("[" + follower.name + "] 有父级，跳过（避免坐标系错位）。");
                    continue;
                }

                try {
                    prop.expression = expr;
                    report.applied++;
                } catch (eE) {
                    report.warnings.push("[" + follower.name + "] 表达式写入失败：" + eE.toString());
                }
            }
        } catch (eMain) {
            report.warnings.push("执行异常：" + eMain.toString());
        }
        app.endUndoGroup();

        var msg = "完成：为 " + report.applied + " 个接力层写入表达式（驱动层 [" + driver.name + "]，" +
            (cfg.incremental ? "递增延迟 " + cfg.delayFrames + " 帧/级" : "固定延迟 " + cfg.delayFrames + " 帧") + "）。";
        if (report.warnings.length > 0) {
            var max = Math.min(report.warnings.length, 6);
            msg += "\n---- 提示 " + report.warnings.length + " 条 ----";
            for (var w = 0; w < max; w++) { msg += "\n" + report.warnings[w]; }
            if (report.warnings.length > max) { msg += "\n…… 其余从略"; }
        }
        alert(msg, SCRIPT_NAME);
    }

    function clearRelay(comp) {
        var sel = comp.selectedLayers;
        if (sel.length === 0) { alert("请先选中要清除表达式的图层。"); return; }
        app.beginUndoGroup("Parrot Clone: Clear");
        var i, cleared = 0;
        try {
            for (i = 0; i < sel.length; i++) {
                try {
                    var tg = sel[i].property("ADBE Transform Group");
                    var pp = tg.property("ADBE Position");
                    var pr = tg.property("ADBE Rotate Z");
                    // review-4 fix: only clear OUR expressions (marker check),
                    // never destroy user-written expressions
                    var hit = false;
                    if (pp.expression.indexOf("Parrot Clone (clean-room)") >= 0) {
                        pp.expression = "";
                        hit = true;
                    }
                    if (pr.expression.indexOf("Parrot Clone (clean-room)") >= 0) {
                        pr.expression = "";
                        hit = true;
                    }
                    if (hit) { cleared++; }
                } catch (e1) { /* 个别层无 transform */ }
            }
        } finally {
            app.endUndoGroup();
        }
        alert("已清除 " + cleared + " 个图层的 position/rotation 表达式。", SCRIPT_NAME);
    }

    // ------------------------------------------------------------------
    // UI（ScriptUI，可停靠）
    // ------------------------------------------------------------------
    function buildUI(thisObj) {
        var win = (thisObj instanceof Panel) ? thisObj : new Window("palette", SCRIPT_NAME, undefined, { resizeable: true });
        win.orientation = "column";
        win.alignChildren = ["fill", "top"];
        win.spacing = 6;
        win.margins = 12;

        win.add("statictext", undefined, SCRIPT_NAME + " v" + SCRIPT_VER + "（clean-room）");
        var tip = win.add("statictext", undefined, "最上层的选中图层 = 驱动层，其余按时间线顺序接力（选择点击顺序不可靠，见 README）。");
        try {
            tip.graphics.foregroundColor = tip.graphics.newPen(win.graphics.PenType.SOLID_COLOR, [0.5, 0.5, 0.5], 1);
        } catch (ePen1) { /* 着色失败不影响功能 */ }

        var rowMode = win.add("group");
        rowMode.orientation = "row";
        rowMode.add("statictext", undefined, "应用属性:");
        var ddMode = rowMode.add("dropdownlist", undefined, ["Position 位置", "Rotation 旋转"]);
        ddMode.selection = 0;
        rowMode.add("statictext", undefined, " 接力次数(0=全部):");
        var etRelay = rowMode.add("edittext", undefined, "0");
        etRelay.characters = 4;

        var rowDelay = win.add("group");
        rowDelay.orientation = "row";
        rowDelay.add("statictext", undefined, "延迟帧数:");
        var etDelay = rowDelay.add("edittext", undefined, "3");
        etDelay.characters = 4;
        var cbInc = rowDelay.add("checkbox", undefined, "逐级递增");
        cbInc.value = true;

        var rowOff = win.add("group");
        rowOff.orientation = "row";
        rowOff.add("statictext", undefined, "值偏移X:");
        var etOx = rowOff.add("edittext", undefined, "0");
        etOx.characters = 5;
        rowOff.add("statictext", undefined, " Y:");
        var etOy = rowOff.add("edittext", undefined, "0");
        etOy.characters = 5;
        rowOff.add("statictext", undefined, " 角度:");
        var etOr = rowOff.add("edittext", undefined, "0");
        etOr.characters = 5;

        var gBtn = win.add("group");
        gBtn.orientation = "row";
        var btnGo = gBtn.add("button", undefined, "Relay 接力", { name: "ok" });
        var btnClr = gBtn.add("button", undefined, "Clear 清除");

        var note = win.add("statictext", undefined, "ES3；表达式=valueAtTime(t-delay) 采样+值偏移。");
        try {
            note.graphics.foregroundColor = note.graphics.newPen(win.graphics.PenType.SOLID_COLOR, [0.5, 0.5, 0.5], 1);
        } catch (ePen2) { /* 着色失败不影响功能 */ }

        btnGo.onClick = function () {
            try {
                doRelay({
                    mode: (ddMode.selection !== null && ddMode.selection.index === 1) ? "rot" : "pos",
                    relayCount: toInt(etRelay.text, 0, 0),
                    delayFrames: Math.max(0, toNum2(etDelay.text, 3)),
                    incremental: cbInc.value,
                    offsetX: toNum2(etOx.text, 0),
                    offsetY: toNum2(etOy.text, 0),
                    offsetRot: toNum2(etOr.text, 0)
                });
            } catch (e) {
                alert("Relay 失败: " + e.toString());
            }
        };
        btnClr.onClick = function () {
            try {
                if (app.project !== null && app.project.activeItem instanceof CompItem) {
                    clearRelay(app.project.activeItem);
                } else {
                    alert("请先激活一个合成。");
                }
            } catch (e2) {
                alert("Clear 失败: " + e2.toString());
            }
        };

        win.layout.layout(true);
        if (win instanceof Window) {
            win.center();
            win.show();
        }
        return win;
    }

    buildUI(thisObj);

})(this);
