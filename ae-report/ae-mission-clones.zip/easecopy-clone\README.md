# EaseCopy Clone（clean-room 复刻）

一个 After Effects ExtendScript (.jsx) 小工具：在**不动关键帧值**的前提下，把关键帧的
temporal ease（缓动曲线的 speed + influence）在属性之间拷贝/粘贴；并支持"整段动画"
拷贝，粘贴时按目标关键帧间隔自动缩放时间。

> **Clean-room 声明**：本脚本仅依据商业脚本 EaseCopy（作者 Mike Overbeck，
> aescripts.com 上架）的**公开功能描述**与书面功能基线从零重写；未获取、未查看、
> 未反编译原作的任何源代码、安装包或资源文件。仅用于学习与互操作目的。
> 源文件 `main.jsx` 顶部亦有同样声明。

## 功能对照

| EaseCopy 公开功能 | 本复刻 | 说明 |
| --- | --- | --- |
| 拷贝/粘贴关键帧缓动（speed + influence），不覆盖关键帧值 | 已复刻 | `Copy 1-4` 存槽位，`Paste 1-4` 应用到所有选中关键帧 |
| 多槽位 | 已复刻 | 4 个独立槽位，各自显示已存内容（维度、方向、speed/inf） |
| 仅拷贝入方向 / 仅拷贝出方向 | 已复刻 | `In only` / `Out only` checkbox；两边都勾或都不勾 = 拷入+出 |
| 多维属性逐维 ease（如 2D/3D 位置、缩放每维一组） | 已复刻 | `keyInTemporalEase`/`keyOutTemporalEase` 按 `propertyValueType` 得到每维一组；粘贴时按目标属性维度重建数组 |
| 跨属性粘贴（不同属性类型/维度之间） | 已复刻（近似） | 维度按索引映射：缺失维回退到源末维；1D→nD 复制该值；nD→1D 取第一维 |
| 整段动画拷贝，粘贴时按目标关键帧间隔缩放时间 | 已复刻 | `Copy Animation` 记录全部关键帧的相对时间、值、入/出插值类型与 ease；`Paste Animation` 以"目标选中关键帧首尾跨度 / 源跨度"为缩放比：关键帧时间 × scale，ease speed × 1/scale，influence 不变 |
| 槽位跨会话持久化（重开 AE 仍在） | **未复刻** | 槽位仅存内存，关闭面板/重启 AE 后清空 |
| 曲线可视化 / 预设库 / 许可证更新器 | **未复刻** | 不在本次基线内 |

## 安装

1. 把 `main.jsx` 放入 AE 脚本面板目录：
   `C:\Program Files\Adobe\Adobe After Effects <版本>\Support Files\Scripts\ScriptUI Panels\`
2. 重启 After Effects，在 `Window` 菜单底部找到 **main.jsx**（面板名取自文件名，可自行改名如 `EaseCopyClone.jsx`），勾选即可停靠。
3. 或不安装，直接 `File > Scripts > Run Script File...` 运行（此方式为浮动窗口，不能停靠）。
4. 若首次使用脚本提示安全设置，到 `Edit > Preferences > Scripting & Expressions` 勾选允许脚本运行。

## 使用

- **缓动拷贝**：在时间轴选中源关键帧（多选时取**第一个**选中关键帧的 ease），点 `Copy 1..4`。
- **缓动粘贴**：选中目标属性的一个或多个关键帧，点 `Paste 1..4`。粘贴只改 ease，不改值；
  只存了单侧方向时（`In only`/`Out only`），另一侧保留目标关键帧原有 ease。
- **仅入/仅出**：勾选后 `Copy N` 只记录对应方向的 ease。
- **整段动画**：在时间轴**选中属性**（点属性名即可，无需选关键帧）→ `Copy Animation`；
  在目标属性上选中用于定义新时间跨度的关键帧 → `Paste Animation`。
  目标跨度为 0（只选了一个关键帧）或源只有单关键帧时，按原时长 1:1 从该关键帧位置开始写。
- 所有修改操作包裹在 undo group 中，一次 Ctrl+Z 可整体撤销。

## 已知限制

1. **无持久化**：槽位内容仅存在于内存，重启 AE / 关闭面板即丢失（原作的跨会话保存未复刻）。
2. **整段粘贴是"叠加"而非"替换"**：写入新关键帧时不删除目标区间内已有的其他关键帧，可能产生冗余键，请自行清理。
3. **空间曲线不缩放**：位置类空间切线（spatial tangents）、roving、temporal auto-bezier 标志不记录也不还原；缩放只作用于时间与 temporal ease。
4. **Hold 关键帧**：对 hold 关键帧写入 ease 时 AE 会拒绝，脚本按计数跳过；hold 状态本身通过插值类型还原。
5. **influence 钳制**：写入前钳制到 AE 接受范围 [0.1, 100]。
6. **多目标配对规则**：`Paste Animation` 按选中顺序把第 i 个目标属性映射到第 i mod N 个源属性；目标数多于源数时循环复用。
7. **生效范围**：仅对"时间轴中被选中的属性"生效（`comp.selectedProperties`）；只选中图层而未选中属性不会生效。
8. **颜色属性**：COLOR 类型 ease 维度按 1 处理；颜色→标量等异构粘贴会因值结构不匹配被跳过并计数提示。
9. 顶部/末尾关键帧的入/出 ease 写入后 AE 不显示对应曲线段，属 AE 本身行为。

## 实现要点（源码索引）

- `dimFromValueType()`：由 `propertyValueType` 推导 ease 维度（multidimensional 属性每维一组 ease）。
- `cloneEaseArray()` / `buildEaseForDims()`：把 `keyInTemporalEase()`/`keyOutTemporalEase()` 读出的 KeyframeEase 数组克隆为纯对象存槽位；粘贴时按目标维度重建 `new KeyframeEase(speed, influence)` 数组供 `setTemporalEaseAtKey()` 使用。
- `copyEaseToSlot()` / `pasteEaseFromSlot()`：单侧粘贴时用 `keyInTemporalEase(ki)`/`keyOutTemporalEase(ki)` 回读当前 ease 传入另一侧参数，避免覆盖保留侧。
- `copyAnimationToSlot()` / `pasteAnimationFromSlot()`：整段动画以 `t0` 相对时间记录；粘贴用 `setValuesAtTimes()` 写键，再用 `nearestKeyIndex(time)` 定位新键，回填 `setInterpolationTypeAtKey()` 与缩放后的 `setTemporalEaseAtKey()`。
- 全脚本 ES3（ExtendScript 兼容）：无 `let/const`、箭头函数、`JSON.stringify`、ES5+ 数组方法；文件为纯 ASCII（ExtendScript 对无 BOM 文件按系统代码页解码，非 ASCII 注释会乱码）。

## 自查记录

- 语法：去除 `#target` 预处理行后通过 `node --check` 解析（括号/圆括号配平由解析保证）。
- ES3 审查：grep 确认无 `let`/`const`/`=>`/`JSON.stringify`/`.map(`/`.filter(`/`.forEach(`/`.indexOf(`/`Object.keys`/尾逗号/非 ASCII 字符。
- 未在真实 AE 中逐项回归测试（无环境）；所有 AE API 调用均有 try/catch 防护并计入跳过数。
