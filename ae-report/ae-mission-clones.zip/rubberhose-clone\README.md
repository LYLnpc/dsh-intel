---
generated_at: 2026-11-14T07:30:00+08:00
task: clean-room 复刻 RubberHose/Limber 类两骨 IK 绑定脚本（law of cosines 两骨解算 + hose 三点贝塞尔软管），ExtendScript jsx；输入 = intel/paid-list.md #8/#9 功能性描述，不反编译不参考原代码
---

# TwoBone IK Clone（RubberHose 风格两骨 IK + 软管 · clean-room 复刻）

- 产出：`main.jsx`（ExtendScript，ES3）
- 输入依据：`C:\Users\19894\ae-mission\intel\paid-list.md` 第 8 条 RubberHose 3、第 9 条 Limber 2 的**功能性描述**与复刻要点（"已知根/梢位置与肢体总长 → 膝点"、"IK + 肢体轮廓 + 端点控制器"）
- 实现方式：初中几何 **law of cosines（余弦定理）** 独立推导，公式块在 main.jsx 中以 `IK-CORE` 标记隔离，由 Node 自查脚本**逐字提取**执行验证

## CLEAN-ROOM 声明

1. 本复刻为清室实现：未反编译、未阅读、未复制 RubberHose（Battle Axe, $65）、Limber（Mike Overbeck, $65）或任何同类商业脚本的原始代码；仅依据公开商品页的功能性描述与通用几何知识从零编写。
2. 核心数学为公开知识：两骨 IK 的余弦定理解（`A1 = acos((L1² + d² − L2²) / (2·L1·d))`，肘点 `M = R + L1·[cos(θ + s·A1), sin(θ + s·A1)]`，`θ = atan2(dy, dx)`），配 AE 表达式通用惯例（`toComp`、`createPath`）。
3. 仅供学习研究；RubberHose / Limber 商标与著作权归各自作者所有。需要完整功能（样式替换、squash & stretch、自动打键等）请购买正版。

## 功能对照（复刻范围）

| RubberHose/Limber 功能点（paid-list 描述） | 本复刻状态 | 说明 |
|---|---|---|
| 两骨 IK：已知根/梢位置与肢体总长 → 膝/肘点 | ✅ 已实现 | 余弦定理解内角，可达域钳制（d 上限 L1+L2、下限 \|L1−L2\|），零除保护 |
| 两端控制器 | ✅ | 生成 2 个 null：`IKC: Upper`（上层旋转=atan2+acos）、`IKC: Elbow`（肘/膝位置+下层旋转）；末端控制器 = 用户提供的末端控制层 |
| 关节自动弯折 + 弯向 | ✅ | `IKC: Bend Flip` Checkbox（勾选=弯向另一侧） |
| hose 肢体形状层（软管弯曲） | ✅ 基线版 | 三点贝塞尔（根关节→肘→末端）`createPath` 表达式；描边宽度由 `IKC: Thickness` Slider 驱动；圆头圆角 |
| hose 长度参数 | ✅ | `IKC: L1` / `IKC: L2` Slider（挂在 Elbow null，随时可调） |
| 长度自动测量 | ✅ | 按当前根/末层位置测距离 d，取 L1=L2=0.6d（总长 1.2d 留弯曲余量）；可切手动输入 |
| 弯折半径/柔度（RubberBend 类） | ⚠️ 简化 | 软管弯部圆润度以常量切线系数近似（kElb=0.5），未做独立可调参数 |
| squash & stretch / 弹性弯（Limber） | ❌ 未实现 | 基线不含 |
| 自定义样式替换（Rubberize）/ 分层配色 | ❌ 未实现 | 基线仅描边软管；用户可自绘 artwork 父化到两个 null 替代 |
| 自动打关键帧 / Rig once 发布 | ❌ 未实现 | — |

## 安装

- 方式 A（可停靠面板）：`main.jsx` 放入 `Support Files\Scripts\ScriptUI Panels\`，重启 AE，Window 菜单打开。
- 方式 B：`File > Scripts > Run Script File...` 直接运行。
- 版本要求：Hose 的 `createPath()` 表达式需 **AE 15.0 (CC2018)+**；IK 部分兼容更早版本。需在 `Edit > Preferences > Scripting & Expressions` 允许脚本运行（新 AE 默认允许）。

## 使用

1. **Create IK**：时间线先选中根关节层（髋/肩），再加选末端控制层（脚/手）→ 点 Create IK。
   - 约定：图层的**锚点（Anchor Point）即关节位置**（表达式用 `toComp(anchorPoint)` 换算，兼容父化/缩放/旋转）。末端控制层通常是一个 null（锚点默认 [0,0]，拖它即驱动）。
   - 生成：`IKC: Upper`（位置跟随根关节层，旋转=上层骨角）、`IKC: Elbow`（位置=肘/膝解点，旋转=下层骨角，携带 L1/L2/Bend Flip 效果）。根/末层名写入 Elbow 的 comment 供 Hose 使用。
   - **装配**：大腿/上肢 artwork **父化到 IKC: Upper**，小腿/下肢 artwork **父化到 IKC: Elbow**；artwork 旋转 0 时骨骼沿 +X 方向、锚点位于关节。
2. **调弯向**：Elbow 层效果面板 `IKC: Bend Flip` 勾选切换肘/膝朝向。
3. **调骨长**：Elbow 层 `IKC: L1` / `IKC: L2`（自动模式初始值 = 0.6×当前根末距离）。
4. **Create Hose**：点按即生成 `IKC: Hose` 形状层（三点贝塞尔软管）；粗细用其上的 `IKC: Thickness` Slider。可与 artwork 并用（软管在 artwork 后面时拖动图层顺序）。
5. **Remove**：删除全部 `IKC:` 图层；用户 artwork 的父化随 null 删除自动解除，不会被改动。

## 数学原理（自行推导）

- 已知根关节 R、末端 E、两骨长 L1、L2，目标距 d = |E − R|。
- 可达域钳制：`dc = clamp(d, |L1−L2|, L1+L2)`（不可达时伸直、过近时折叠，杜绝 acos 定义域越界与除零——dMin 下限 0.0001）。
- 根关节内角（余弦定理）：`A1 = acos((L1² + dc² − L2²) / (2·L1·dc))`，clamp 到 [−1, 1]。
- 弯向符号 s（Checkbox ±1）：`θ = atan2(Ey−Ry, Ex−Rx)`，肘点 `M = R + L1·[cos(θ + s·A1), sin(θ + s·A1)]`。
- 上层旋转（度）= `(θ + s·A1)·180/π`；下层旋转 = `atan2(E−M)·180/π`（零向量保护）。AE 坐标 Y 向下，atan2(dy,dx) 与 AE 旋转正方向（顺时针）一致，无需翻转。
- Hose 路径：`createPath([R, M, E])`，端部切线 = 骨向 × 0.35，弯部切线 = 骨向 × 0.5，近似软管圆弯。

## 自查记录（2026-11-14）

1. **数学自查**（Node 从 main.jsx `IK-CORE-START/END` 标记块逐字提取公式执行，保证与 AE 表达式完全一致）：8 组用例全部 PASS——
   - T1 直角三角形 3-4-5（L1=3, L2=4, d=5）：M=(1.8, 2.4)，|M−R|=3、|M−E|=4 精确成立；s=−1 得镜像 (1.8, −2.4)
   - T2 等腰（5, 5, 6）：M=(3, 4)，不变量成立
   - T3 一般三角形（7, 6, 8）：不变量成立 + 三内角和=π
   - T4 不可达 d=20：钳制伸直，肘在 R→E 连线上，无 NaN
   - T5 过近 d=0.5：钳制折叠，无 NaN
   - T6 旋转一致性：`ang·180/π` 转回方向向量与 R→M 单位向量逐分量相等
   - T7 极小 L1（0.0001 保护路径）：结果有限
   - T8 斜向目标：不变量坐标无关成立
2. `node --check`：通过（复制为 .js 检查）。
3. ES3 扫描（排除注释行）：`let/const/箭头函数/JSON.stringify/模板串/forEach/map/filter/includes/for-of` 零命中。

## 限制（如实说明）

1. **未在 AE 实机测试**：本环境无 After Effects。数学/语法/ES3 已验证；AE 内需实测的点：`ADBE Vector Shape - Path` matchName 兼容性（脚本已做多 matchName 依次尝试 + try/catch 兜底）、`createPath` 表达式在新旧 JS 引擎下的行为、null 表达式驱动性能。
2. Hose 仅基线：无弯折半径独立参数（切线系数为常量）、无 squash & stretch、无端点缩放（Buttcapper 类）、无样式替换。
3. 单合成仅支持一套 IK（图层名固定 `IKC: Upper / IKC: Elbow / IKC: Hose`）；重命名会断开表达式引用。
4. 自动测骨长读取的是图层 position 当前值（父化场景以表达式 toComp 为准，二者在复杂父化下可能略有出入）；手动模式可规避。
5. 下层骨骼无 squash/stretch：不可达时软管/下肢会被视觉拉直而非压缩。
6. 3D 图层仅取 XY 平面（Z 被忽略）；根/末层重度嵌套父化时建议实机验证 toComp 链路。
