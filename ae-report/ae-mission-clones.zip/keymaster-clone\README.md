---
generated_at: 2026-11-14T08:12:00+08:00
task: ae-mission / clean-room 复刻 KeyMaster（关键帧批量管理工具），ExtendScript jsx；输入 = intel/paid-list.md #17 KeyMaster 条目（[未核实细节]）+ 任务下发的公开功能基线，不反编译不参考原代码
---

# KM Clone（KeyMaster 风格关键帧批量管理 · clean-room 复刻）

- 产出：`main.jsx`（ExtendScript，ES3，ScriptUI 四区面板）
- 输入依据：`intel/paid-list.md` #17 "KeyMaster"（Owain Street，$25/特价 $18.99）原文功能为"跨多图层精确选中关键帧（按时间范围/属性过滤），成组移动/重定时 [未核实细节]"——**条目简略**。本克隆按任务下发的公开功能基线展开实现，**推断范围已在下表逐项注明**，不声称覆盖原版未公开的全部能力。
- 实现方式：AE 官方关键帧 API（`setValueAtKey`/`removeKey`/`setInterpolationTypeAtKey`/`setTemporalEaseAtKey`/`setTemporalAutoBezierAtKey`），API 名全部对照 `docs/api-cheatsheet.md` 白名单。

## CLEAN-ROOM 声明

1. 本复刻为清室实现：未反编译、未阅读、未复制 KeyMaster 原始代码，仅依据公开商品页的功能性描述与任务功能基线从零编写。
2. 全部数学（时间镜像 `t' = t0 + t1 − t`、速度镜像 `dv/dt → −dv/dt`、ease in/out 互换）为初等推导；表达式与脚本结构均为原创。
3. 仅供学习研究；KeyMaster 商标与著作权归 Owain Street 所有。需要完整功能请购买正版（aescripts.com，$25，特价 $18.99）。

## 功能对照（任务基线 vs 本克隆；推断范围注明）

| 功能点（任务功能基线） | 本克隆状态 | 说明 |
|---|---|---|
| 时间翻转：选中键段首尾镜像 | ✅ | `newTime = t0 + t1 − t`（t0/t1 = 选中键最早/最晚时间）；**快照→倒序 removeKey→重建**，重建后用 `nearestKeyIndex` 定位恢复插值与 ease；**in/out 插值互换**，**ease speed 取反 + in/out 互换**（时间镜像 = 反向播放）；镜像目标时间与未选中键冲突时跳过该键并计数 |
| 值取反 ×(−1) | ✅ | `keyValue` 读值 → 分量取反 → `setValueAtKey(k, nv)` 写回；**ease speed 在相同分量同步取反**（influence 不变，clamp [0.1..100]）；多维属性支持 all / x / y / z 分量选择；COLOR 等非数值类型跳过并计数 |
| 插值统一 Linear / Auto-Bezier | ✅ | `setInterpolationTypeAtKey(k, LINEAR, LINEAR)`；Auto-Bezier = `BEZIER + setTemporalAutoBezierAtKey(k, true)`（Easy-Ease 风格）；执行前扫描 HOLD 键数量并一次性 alert 预警"hold 特性将丢失" |
| 批量删除冗余键 | ✅ | 选中键按时间排序后，与前键间隔 < N×frameDuration 的键标记，**倒序 removeKey**（索引不失效）；N 由 UI 输入（帧） |
| 作用对象 | ✅ | `comp.selectedProperties` 中有选中关键帧的属性优先，否则遍历选中图层属性树（深度 5 / 40 属性上限）；无选中关键帧 → alert 防护 |
| （未推断实现）跨多图层按时间范围/属性过滤选中 | ❌ | 原版描述的"按时间范围/属性过滤选中"未实现——本克隆操作的是用户已选中的关键帧；成组移动/重定时同样不在基线内 |

## 安装

- 方式 A（可停靠面板）：`main.jsx` 放入 `Support Files\Scripts\ScriptUI Panels\`，重启 AE，Window 菜单打开。
- 方式 B：`File > Scripts > Run Script File...` 直接运行。

## 使用（上手第一个动作）

1. 在时间线选中若干关键帧（可跨图层、跨属性）。
2. **时间翻转**：点 Zone 1 "Flip time" → 选中段整体镜像（如 0-1-2-3 变 3-2-1-0 时间布局，形状反向播放）。
3. **值取反**：Zone 2 选分量 → "Negate" → 选中键值变号、速度同步变号（曲线形状上下镜像）。典型用途：把"向右飞出"改成"向左飞出"。
4. **插值统一**：Zone 3 "All Linear" / "All Auto-Bezier" → 选中键插值归一（含 HOLD 预警）。
5. **抽稀**：Zone 4 输入 N=2 → "Remove redundant" → 间距小于 2 帧的冗余键被清掉（K 帧手抖急救）。

## 数学说明（自行推导）

- **时间镜像**：`t' = t0 + t1 − t`。值形状不变；对时间求导得速度镜像 `dv/dt' = −dv/dt`，且镜像点的"进入速度"来自原点的"离开速度"——故恢复 ease 时 **in/out 两组 KeyframeEase 互换 + speed 全体取负**（influence 不变）。HOLD 键无速度语义，恢复插值类型但跳过 ease 写入。
- **值取反**：`v → −v` 时 `dv/dt → −dv/dt`，故 in/out ease 的 speed 在**被取反的分量**上同步取负；分量选择（x/y/z）与值取反的分量集合一致。
- **抽稀**：以"删前相邻间隔"为判定（一次遍历），首个选中键永不删除，故至少保留 1 键；间隔均按原始时间计算，不做链式重算（README 明示该语义）。

## 限制（如实说明）

1. **未在 AE 实机验证**（本环境无 After Effects）；API 名与签名对照 docs/api-cheatsheet.md 白名单，`setValueAtKey(k, value[, time])` 为官方指南收录方法。
2. 时间翻转采用"快照→删除→重建"而非 `setValueAtKey(k, v, newT)` 逐键改时间：翻转必然打乱关键帧时间顺序（索引重排 + 同时刻冲突），重建法以时间重定位规避索引漂移。代价：**roving 关键帧、空间切线（keyIn/OutSpatialTangent）不随镜像恢复**（形状层路径等空间插值可能变形），相关键请谨慎使用。
3. 时间翻转后镜像时间与**未选中键**时间冲突（差 < 1e-5 s）时跳过该键并计数；与选中键彼此无冲突（一一映射）。
4. 值取反对 COLOR/文本/蒙版路径等非数值属性自动跳过（计数显示）。
5. Auto-Bezier 的 `setTemporalAutoBezierAtKey` 包 try/catch（个别属性类型可能不支持，失败仅计数不影响插值类型写入）。
6. 抽稀只对**选中的关键帧**生效且按"原始相邻间隔"判定，不做删后重算；如需"全属性抽稀"先全选该属性关键帧。
7. 本克隆不实现原版描述的跨图层过滤选中与成组移动/重定时（见功能对照表末行，推断范围外）。

## 自查记录（2026-11-14）

1. `node --check`：通过（复制为 .js 检查）。
2. ES3 扫描（let/const/箭头/JSON.stringify/模板串/forEach/map/filter/for-of/Object.keys/trim）：代码零命中。
3. API 对照 api-cheatsheet.md：`setValueAtKey(k, v[, time])`、`removeKey`（未用 deleteKey）、`keyValue`、`keyTime`、`keyIn/OutInterpolationType`、`setInterpolationTypeAtKey`、`setTemporalAutoBezierAtKey`、`keyIn/OutTemporalEase`、`setTemporalEaseAtKey`（双侧恒传，规避省略 out 被 in 覆盖）、`nearestKeyIndex`、`KeyframeEase(speed, influence)` clamp [0.1..100]、`KeyframeInterpolationType.LINEAR/BEZIER/HOLD`、`selectedKeys` 1-based + 手工数值排序、undo 组 try/finally 成对——全部在白名单内。

## 交叉评审记录（review-4，2026-11-14）

- 表外 API 登记：`Property.propertyType`（PropertyType.PROPERTY 嗅探）不在速查表白名单，已包 try/catch 并提供 numProperties-undefined 回退（原为裸用，未登记——已补）。
- 已修复真 bug 1：面板以 palette 方式运行（File > Scripts）时从未调用 `win.show()`，窗口不显示；现 Window 模式 center+show。
- 已修复真 bug 2：Thin 工具注释与实现不一致——原实现按"上一个原始键"比较，密集键链会被过度删除；已改为按"上一个保留键"（lastKeptT）。
- 已修复数据丢失风险 3：Time flip 原实现先删全部选中键再重建，镜像落点与未选中键冲突的键被静默丢弃（仅计数 skipped）；现改为冲突解析（不可移动键原位保留），镜像互换对仍可移动。
