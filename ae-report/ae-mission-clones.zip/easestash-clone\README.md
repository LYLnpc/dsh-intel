# Ease Stash Clone（clean-room 复刻）

> **CLEAN-ROOM 声明**：本项目为依据功能需求描述（`intel/paid-list.md` 第 19 条
> "Ease Stash"）从零独立编写的复刻实现。编写过程中未反编译原插件，未阅读、
> 复制或改写原插件的任何源代码、字节码或资源文件；仅依赖 Adobe After Effects
> 公开脚本 API（docs/api-cheatsheet.md 白名单）与需求文档。与原产品的相似性
> 仅来自功能需求本身。仅供学习研究；Ease Stash 商标与著作权归 null1 lab 所有，
> 需完整功能请购买正版（aescripts.com，$35）。

- 原品：Ease Stash（null1 lab，aescripts，$35，jsx）
- 复刻：`main.jsx`（ExtendScript / ES3，单文件，约 470 行，UTF-8 带 BOM）
- **推断范围声明**：原品情报条目仅一句"把关键帧选择（含缓动）存入槽位，一键
  召回并应用到任意 comp"（未核实细节）。本复刻据此展开的公开功能基线为：
  **保存选中关键帧的缓动为命名预设（持久化文件库）→ 浏览列表 → 一键应用回
  选中关键帧（维度适配 + 倍率）**。原品的槽位数量、分组/标签、跨库导出导入
  等细节无情报支撑，均未实现，也不声称与原品一致。

---

## 一、功能对照表

### 已复刻

| 功能 | 说明 |
|------|------|
| Stash 收存 | 读取第一个选中属性的第一个选中关键帧的 `keyInTemporalEase/keyOutTemporalEase`（含每维 speed/influence），存为命名预设；同名自动更新该条 |
| 持久化文件库 | 写入脚本同目录 `presets.json`（自产严格格式：魔数头 `EASESTASH_V1` + 单表达式）；不用 app.settings 存大 JSON（避免长度限制）；脚本路径不可用时兜底到 `clones/easestash-clone/presets.json` |
| Apply 应用 | 预设下拉选择 → 对**全部选中属性的全部选中关键帧** `setTemporalEaseAtKey` 回写（双侧覆盖：in+out 一起写） |
| 维度适配 | 目标维度回读该键现有 ease 数组长度；映射规则：**目标 1D → 取预设第一维**；单维预设 → 复制到目标全部维；多维 → 逐维映射、缺失维回退预设末维 |
| 倍率滑杆 | 0.2–3.0（默认 1.00）：应用时 speed 与 influence 同乘倍率（influence 钳制 AE 合法范围 [0.1, 100]）；倍率值持久记忆 |
| Delete | 删除下拉中选中的预设并持久化 |
| 同名覆盖 | Stash 命名与现有条目同名时更新该条（不产生重复项） |
| 信息行 | 显示所选预设的维度/来源属性/首维 speed·influence |
| 防护 | 未激活合成/无选中属性/无选中关键帧/未选预设分别弹窗中止；每次 Apply 整体 Undo 组（try/finally） |
| ES3 / 白名单 | 无 let/const/箭头函数/JSON 对象/ES5 数组方法；API 名全部对照 docs/api-cheatsheet.md 白名单 |

### 未复刻（与原品的差距，含推断边界）

| 功能 | 说明 |
|------|------|
| 多键序列预设 | 本复刻一条预设 = 一个关键帧的缓动快照；原品若支持"整段多键序列存取"则未实现（无情报支撑） |
| 槽位/分组/标签管理 | 无情报支撑，未实现 |
| 库导入导出/分享 | 未实现（文件本身即库，可手动拷贝 presets.json） |
| 曲线预览 | 无 |
| 仅入/仅出方向选项 | Apply 固定双侧覆盖（in+out 一起写） |

---

## 二、presets.json 格式与安全说明

- **ExtendScript 无 JSON 对象**（ES3），持久化采用**自产严格格式**：
  ```
  EASESTASH_V1
  ({v:1,presets:[
  {name:"弹簧入",from:"Shape Layer 1.位置",dims:2,inE:[{s:120,i:66.6},{s:80,i:55.5}],outE:[{s:-45,i:70},{s:0,i:33.3}]},
  {name:"...",from:"",dims:1,inE:[{s:0.0001,i:100}],outE:[{s:999.9999,i:0.1}]}
  ]})
  ```
- **eval 陷阱的对策**（任务指出的风险点）：解析只 `eval` **本工具自产文件**——
  魔数校验 → BOM 剥离 → 体积上限 256KB → eval → 逐字段类型清洗（名称仅接受
  字符串、数字强制 `Number()`+`isFinite`、influence 钳制 [0.1,100]、维度 1–8、
  数组长度必须等于 dims，任一字段不合法整条弃置）。序列化时名称经转义
  （反斜杠/引号/换行），数字经有限性清洗——**不解析任何外部来源的同形文件**。
- **round-trip 实测**（node 复算）：中文名/含引号名/多维数组/边界数值（0.0001、
  999.9999）序列化→解析逐值一致；BOM 文件、魔数不符、非对象、维度错配、
  NaN 注入、超维、空库七类用例行为符合预期。

## 三、安装

1. **面板常驻（推荐）**：把 `main.jsx` 重命名为 `EaseStashClone.jsx`，拷入：
   - Windows：`C:\Program Files\Adobe\Adobe After Effects <版本>\Support Files\Scripts\ScriptUI Panels\`
   - macOS：`/Applications/Adobe After Effects <版本>/Scripts/ScriptUI Panels/`
   **重启 AE**，`Window` 菜单底部勾选打开。
2. **临时运行**：`File > Scripts > Run Script File...` 选 `main.jsx`。
3. **写文件权限**：presets.json 读写需要 `Edit > Preferences > Scripting & Expressions`
   勾选 **Allow Scripts to Write Files and Access Network**——不勾则收存/删除
   仅本次会话有效（弹窗提示写入失败）。
4. **库文件位置**：脚本同目录 `presets.json`（ScriptUI Panels 目录通常需要管理
   员权限写入——若写入失败，可把脚本放到用户可写目录再用，或手动把
   `clones/easestash-clone/presets.json` 放到脚本同目录）。
5. **未实机验证，建议先在测试工程试**（见第四节）。

## 四、使用

1. **收存**：时间线选中属性的关键帧 → 输入名称（留空自动"预设 N"）→ 点
   **Stash 收存**。同名单条会被更新。
2. **应用**：在任意 comp 选中目标关键帧 → 下拉选预设 → 调倍率 → 点 **Apply
   应用**。倍率 1.00 = 原样回写；2.00 = speed 与 influence 同乘 2（influence
   超过 100 自动钳到 100）。
3. **删除**：下拉选中条目 → **Delete 删除**。
4. 不满意一次 Ctrl+Z 整体撤销（Apply 的键缓动修改）。

---

## 五、已知限制（如实标注）

1. **未实机验证**：编写环境无 After Effects；已完成 node --check、ES3 扫描、
   API 白名单核对与序列化/映射 round-trip 仿真。首用请先在测试工程试。
2. **单键快照**：一条预设只存**第一个选中属性的第一个选中键**的缓动（多选时
   其余键忽略，状态行提示来源）；想收存不同维度的缓动需分别 Stash。
3. **Apply 双侧覆盖**：目标键的入/出方向都被预设覆盖——只想改一侧请先手工记
   录另一侧（无 In only/Out only 选项）。
4. **eval 边界**：解析仅信任自产魔数文件并逐字段清洗，但 eval 本身仍是
   ExtendScript 的动态求值——**不要手工把来历不明的文件改名成 presets.json
   放进目录**（清洗能挡住结构异常，挡不住伪装成合法结构的恶意字符串内容；
   清洗后所有字段都要求是 number/string 且重build，风险已尽量压缩）。
5. **写权限**：ScriptUI Panels 目录通常只读（Program Files），写入失败时预设
   仅会话有效——推荐把脚本放用户可写目录，或接受"库文件放 clones 目录"的
   兜底路径（脚本目录不可用时的行为）。
6. **HOLD 关键帧**：AE 拒绝写缓动，按错误计数跳过。
7. **带表达式属性**：缓动被表达式覆盖的属性，Apply 后视觉不生效（键 ease 已改）。

## 六、自查记录（2026-11-14）

- `node --check`（剥离 `#target aftereffects` 行）：通过。
- ES3 扫描：干净（仅头注注释提及"无 let/const"字样）。
- 尾逗号 0；保留字黑名单 0 命中。
- API 白名单核对：`keyInTemporalEase/keyOutTemporalEase/setTemporalEaseAtKey/
  keyRoving(未用)/PropertyValueType.OneD/app.settings.getHavingSaved+getSetting+
  saveSetting` 全部照表；无 deleteKey/全大写枚举/`app.settings.save` 等黑名单用法。
- 序列化 round-trip 与七类坏文件用例、三种维度映射规则：全部符合预期（见第二节）。
- 编码：main.jsx 为 UTF-8 带 BOM（中文 UI）；presets.json 为 UTF-8 无 BOM 数据文件。
