/*******************************************************************************
 * Native Presets Clone (B-class approximations) - main.jsx
 * generated_at: 2026-11-14T08:42:00+08:00
 * task: B 类近似包（最后一个产出件）——用原生效果组合+表达式近似三个收费
 *       效果：软发光（Deep Glow 2）、长阴影（LongShadow 2）、线条沸腾
 *       （LineBoil 免费做法）。输入 = intel/paid-list.md 第 33/32/48 条的
 *       近似路径与复刻要点，不反编译不抄原代码；不写 C++。
 *
 * CLEAN-ROOM 声明：
 * 1. 本脚本为清室（clean-room）独立实现：未反编译、未阅读、未复制任何原品
 *    代码；仅依据公开的功能性描述与 AE 原生效果（自带效果 + 表达式）从零
 *    组合编写。API 与效果 matchName 对照 docs/api-cheatsheet.md 政策：
 *    - 已核实 matchName（官方指南命中）：ADBE Glo2 / ADBE Drop Shadow /
 *      ADBE Set Matte3 / ADBE Turbulent Displace / ADBE Posterize Time
 *    - 效果参数名（Glow Threshold 等）为显示名，中文 AE 下可能失配——
 *      全部 try/catch 并在 README 登记，失败计入提示不中断。
 * 2. ES3 (ExtendScript) 编写：无 let/const/箭头函数/JSON.stringify。
 *
 * 用法：选中图层 → 三个按钮任选。全部操作包 undo 组（try/finally）。
 ******************************************************************************/

(function (npThisObj) {

    var SCRIPT_NAME = "Native Presets Clone";
    var SCRIPT_VER = "1.0.0";
    var PFX = "NP:";

    // ------------------------------------------------------------------
    // 小工具（ES3）
    // ------------------------------------------------------------------
    function toNum2(s, fallback, min) {
        var v = parseFloat(s);
        if (isNaN(v)) { v = fallback; }
        if (v < min) { v = min; }
        return v;
    }

    function getComp() {
        if (app.project === null) { return null; }
        var it = app.project.activeItem;
        return (it !== null && it instanceof CompItem) ? it : null;
    }

    // 效果按 matchName → 显示名逐级尝试添加（addProperty 两者皆可接受）
    function addEffectSafe(layer, matchName, displayName, warnings) {
        var parade = layer.property("ADBE Effect Parade");
        try { return parade.addProperty(matchName); }
        catch (e1) { /* 尝试显示名 */ }
        try { return parade.addProperty(displayName); }
        catch (e2) {
            warnings.push("效果 [" + displayName + "] 添加失败：" + e2.toString());
            return null;
        }
    }

    // 参数表达式写入：参数显示名逐个尝试（matchName 表外，按政策 try/catch + 登记）
    function setParamExpr(fx, paramNames, expr, layerName, warnings, label) {
        var i;
        for (i = 0; i < paramNames.length; i++) {
            try {
                var p = fx.property(paramNames[i]);
                if (p !== null && p !== undefined) {
                    p.expression = expr;
                    return true;
                }
            } catch (e1) { /* 尝试下一个名字 */ }
        }
        warnings.push("[" + layerName + "] " + label + " 参数表达式写入失败（非英文 AE 显示名失配？）。");
        return false;
    }

    function ensureSlider(layer, name, def) {
        var effects = layer.property("ADBE Effect Parade");
        var i;
        for (i = 1; i <= effects.numProperties; i++) {
            if (effects.property(i).name === name) { return effects.property(i); }
        }
        var fx = effects.addProperty("ADBE Slider Control");
        fx.name = name;
        fx.property("Slider").setValue(def);
        return fx;
    }

    function collectLayers(comp) {
        return comp.selectedLayers;
    }

    function sliderRef(name) {
        return "effect(\"" + name + "\")(\"Slider\")";
    }

    // ------------------------------------------------------------------
    // 按钮 1：软发光（Deep Glow 2 近似 = 3 层 Glow 递进叠放）
    // ------------------------------------------------------------------
    // >>> NP-GLOW-EXPR-START（Node 自查逐字提取验证三层递进算术）
    function buildGlowExpr(baseThreshold, baseRadius, baseIntensity) {
        var th = sliderRef(PFX + " Glow 阈值%");
        var rr = sliderRef(PFX + " Glow 半径倍率");
        var it = sliderRef(PFX + " Glow 强度");
        var L = [];
        L.push("// NP glow tier: th=" + baseThreshold + " r=" + baseRadius + " i=" + baseIntensity);
        L.push("var thS = " + th + " / 100;");
        L.push("var rrS = " + rr + " / 100;");
        L.push("var itS = " + it + " / 100;");
        L.push("Math.max(0, Math.min(100, " + baseThreshold + " * thS)) ;"); // Glow Threshold 0..100
        return L.join("\n");
    }

    function buildGlowRadiusExpr(baseRadius) {
        var rr = sliderRef(PFX + " Glow 半径倍率");
        return "Math.max(1, " + baseRadius + " * ((" + rr + ") / 100));";
    }

    function buildGlowIntensityExpr(baseIntensity) {
        var it = sliderRef(PFX + " Glow 强度");
        return "Math.max(0, " + baseIntensity + " * ((" + it + ") / 100));";
    }
    // <<< NP-GLOW-EXPR-END

    function doGlow(comp) {
        var layers = collectLayers(comp);
        var warnings = [];
        var done = 0;
        var i;
        app.beginUndoGroup(SCRIPT_NAME + ": Soft Glow");
        try {
            for (i = 0; i < layers.length; i++) {
                var layer = layers[i];
                ensureSlider(layer, PFX + " Glow 阈值%", 60);
                ensureSlider(layer, PFX + " Glow 半径倍率", 100);
                ensureSlider(layer, PFX + " Glow 强度", 100);
                // 三层递进：底(紧贴轮廓) → 中 → 晕(大半径低强度)
                var tiers = [
                    { th: 60, r: 10, it: 1.0, label: "Glow A (base)" },
                    { th: 42, r: 30, it: 0.8, label: "Glow B (mid)" },
                    { th: 24, r: 80, it: 0.5, label: "Glow C (halo)" }
                ];
                var t;
                for (t = 0; t < tiers.length; t++) {
                    var fx = addEffectSafe(layer, "ADBE Glo2", "Glow", warnings);
                    if (fx === null) { continue; }
                    try { fx.name = PFX + " " + tiers[t].label; } catch (eN) { /* 忽略 */ }
                    setParamExpr(fx, ["Glow Threshold", "阈值"],
                        buildGlowExpr(tiers[t].th, tiers[t].r, tiers[t].it), layer.name, warnings, tiers[t].label + ".Threshold");
                    setParamExpr(fx, ["Glow Radius", "半径"],
                        buildGlowRadiusExpr(tiers[t].r), layer.name, warnings, tiers[t].label + ".Radius");
                    setParamExpr(fx, ["Glow Intensity", "强度"],
                        buildGlowIntensityExpr(tiers[t].it), layer.name, warnings, tiers[t].label + ".Intensity");
                }
                done++;
            }
        } catch (eMain) {
            warnings.push("执行异常：" + eMain.toString());
        } finally {
            app.endUndoGroup();
        }
        finish("软发光", done, warnings);
    }

    // ------------------------------------------------------------------
    // 按钮 2：长阴影（LongShadow 2 近似 = 纯色层 + Set Matte + 4 层 Drop Shadow 递进）
    // ------------------------------------------------------------------
    function doLongShadow(comp) {
        var layers = collectLayers(comp);
        var warnings = [];
        var done = 0;
        var i;
        app.beginUndoGroup(SCRIPT_NAME + ": Long Shadow");
        try {
            for (i = 0; i < layers.length; i++) {
                var src = layers[i];
                var shadowName = PFX + " Long Shadow - " + src.name;
                var solid = comp.layers.addSolid([0, 0, 0], shadowName, comp.width, comp.height, comp.pixelAspect, comp.duration);
                try { solid.moveAfter(src); } catch (eMv) { /* 顺序失败不阻断 */ }

                // Set Matte：影子轮廓 = 源层 alpha
                var matte = addEffectSafe(solid, "ADBE Set Matte3", "Set Matte", warnings);
                if (matte !== null) {
                    try { matte.property("Use Layer for Matte").setValue(src.index); }
                    catch (eU) { warnings.push("[" + src.name + "] Set Matte 源层设置失败（显示名失配？）。"); }
                }

                // 影子角度/长度/透明度滑杆
                ensureSlider(solid, PFX + " 影子角度", 45);
                ensureSlider(solid, PFX + " 影子长度", 150);
                ensureSlider(solid, PFX + " 影子透明度", 35);

                // 4 层 Drop Shadow：距离 = 长度×i/4，重叠自然形成近深远浅渐变
                var ang = sliderRef(PFX + " 影子角度");
                var len = sliderRef(PFX + " 影子长度");
                var opa = sliderRef(PFX + " 影子透明度");
                var k;
                for (k = 1; k <= 4; k++) {
                    var ds = addEffectSafe(solid, "ADBE Drop Shadow", "Drop Shadow", warnings);
                    if (ds === null) { continue; }
                    try { ds.name = PFX + " Shadow step " + k; } catch (eDn) { /* 忽略 */ }
                    setParamExpr(ds, ["Direction", "方向"], "(" + ang + ");", src.name, warnings, "step" + k + ".Direction");
                    setParamExpr(ds, ["Distance", "距离"],
                        "(" + len + ") * " + k + " / 4;", src.name, warnings, "step" + k + ".Distance");
                    setParamExpr(ds, ["Opacity", "不透明度"],
                        "(" + opa + ");", src.name, warnings, "step" + k + ".Opacity");
                    try { ds.property("Shadow Color").setValue([0, 0, 0]); } catch (eC) { /* 默认黑 */ }
                }
                done++;
            }
        } catch (eMain) {
            warnings.push("执行异常：" + eMain.toString());
        } finally {
            app.endUndoGroup();
        }
        finish("长阴影", done, warnings);
    }

    // ------------------------------------------------------------------
    // 按钮 3：线条沸腾（LineBoil 免费做法 = Turbulent Displace 帧量化随机 + Posterize Time）
    // ------------------------------------------------------------------
    // >>> NP-BOIL-EXPR-START（Node 自查逐字提取执行：帧量化随机确定性）
    function buildBoilEvolutionExpr() {
        var L = [];
        L.push("var fps = Math.max(0.01, " + sliderRef(PFX + " 沸腾帧率") + ");");
        L.push("var q = Math.floor(time * fps);");
        L.push("var s1 = Math.sin(q * 12.9898) * 43758.5453;");
        L.push("var r1 = s1 - Math.floor(s1);");
        L.push("r1 * 720;");
        return L.join("\n");
    }
    // <<< NP-BOIL-EXPR-END

    function doBoil(comp) {
        var layers = collectLayers(comp);
        var warnings = [];
        var done = 0;
        var i;
        app.beginUndoGroup(SCRIPT_NAME + ": Line Boil");
        try {
            for (i = 0; i < layers.length; i++) {
                var layer = layers[i];
                ensureSlider(layer, PFX + " 沸腾帧率", 12);
                ensureSlider(layer, PFX + " 扰动量", 15);

                var td = addEffectSafe(layer, "ADBE Turbulent Displace", "Turbulent Displace", warnings);
                if (td !== null) {
                    setParamExpr(td, ["Amount", "数量"],
                        sliderRef(PFX + " 扰动量") + ";", layer.name, warnings, "TD.Amount");
                    setParamExpr(td, ["Evolution", "演化"],
                        buildBoilEvolutionExpr(), layer.name, warnings, "TD.Evolution");
                }

                // 经典沸腾配方第二半：整层帧率量化（Posterize Time）
                var pt = addEffectSafe(layer, "ADBE Posterize Time", "Posterize Time", warnings);
                if (pt !== null) {
                    setParamExpr(pt, ["Frame Rate", "帧速率"],
                        sliderRef(PFX + " 沸腾帧率") + ";", layer.name, warnings, "PT.FrameRate");
                }
                done++;
            }
        } catch (eMain) {
            warnings.push("执行异常：" + eMain.toString());
        } finally {
            app.endUndoGroup();
        }
        finish("线条沸腾", done, warnings);
    }

    // ------------------------------------------------------------------
    // 公共收尾提示
    // ------------------------------------------------------------------
    function finish(actionName, count, warnings) {
        var msg = actionName + " 完成：处理 " + count + " 个图层。";
        if (warnings.length > 0) {
            var max = Math.min(warnings.length, 6);
            msg += "\n---- 提示 " + warnings.length + " 条 ----";
            for (var w = 0; w < max; w++) { msg += "\n" + warnings[w]; }
            if (warnings.length > max) { msg += "\n…… 其余从略"; }
        }
        alert(msg, SCRIPT_NAME);
    }

    // ------------------------------------------------------------------
    // UI（ScriptUI，可停靠）
    // ------------------------------------------------------------------
    function buildUI(thisObj) {
        var win = (thisObj instanceof Panel) ? thisObj : new Window("palette", SCRIPT_NAME, undefined, { resizeable: true });
        win.orientation = "column";
        win.alignChildren = ["fill", "top"];
        win.spacing = 6;
        win.margins = 12;

        win.add("statictext", undefined, SCRIPT_NAME + " v" + SCRIPT_VER + "（B 类近似包）");
        var tip = win.add("statictext", undefined, "选中图层 → 三按钮：原生效果组合近似收费效果。");
        tip.graphics.foregroundColor = tip.graphics.newPen(win.graphics.PenType.SOLID_COLOR, [0.5, 0.5, 0.5], 1);

        var b1 = win.add("button", undefined, "1. 软发光（Deep Glow 近似：3 层 Glow 递进）");
        var b2 = win.add("button", undefined, "2. 长阴影（LongShadow 近似：Set Matte + 4 层 Drop Shadow）");
        var b3 = win.add("button", undefined, "3. 线条沸腾（LineBoil 近似：Turbulent Displace + Posterize Time）");
        var note = win.add("statictext", undefined, "参数经 NP: 滑杆暴露实时可调；ES3；效果参数名失配时计入提示。");
        note.graphics.foregroundColor = note.graphics.newPen(win.graphics.PenType.SOLID_COLOR, [0.5, 0.5, 0.5], 1);

        b1.onClick = function () {
            var comp = getComp();
            if (comp === null) { alert("请先激活一个合成。", SCRIPT_NAME); return; }
            if (collectLayers(comp).length === 0) { alert("请先选中图层。", SCRIPT_NAME); return; }
            try { doGlow(comp); } catch (e1) { alert("软发光失败: " + e1.toString()); }
        };
        b2.onClick = function () {
            var comp = getComp();
            if (comp === null) { alert("请先激活一个合成。", SCRIPT_NAME); return; }
            if (collectLayers(comp).length === 0) { alert("请先选中图层。", SCRIPT_NAME); return; }
            try { doLongShadow(comp); } catch (e2) { alert("长阴影失败: " + e2.toString()); }
        };
        b3.onClick = function () {
            var comp = getComp();
            if (comp === null) { alert("请先激活一个合成。", SCRIPT_NAME); return; }
            if (collectLayers(comp).length === 0) { alert("请先选中图层。", SCRIPT_NAME); return; }
            try { doBoil(comp); } catch (e3) { alert("线条沸腾失败: " + e3.toString()); }
        };

        win.layout.layout(true);
        if (win instanceof Window) {
            win.center();
            win.show();
        }
        return win;
    }

    buildUI(thisObj);

})(this);
