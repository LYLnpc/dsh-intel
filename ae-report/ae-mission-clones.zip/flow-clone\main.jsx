/**
 * ============================================================================
 *  Flow Clone (clean-room re-implementation)  -  v1.0.0
 * ============================================================================
 *
 *  CLEAN-ROOM DECLARATION
 *  ----------------------
 *  This script is an independent, clean-room re-implementation of the core
 *  feature set that is publicly described for "Flow" (a commercial After
 *  Effects script sold on aescripts + aeplugins): a preset easing-curve
 *  library that applies easing to selected keyframes, with adjustable
 *  intensity / speed parameters.
 *
 *  It was written ONLY from public feature descriptions, standard publicly
 *  documented easing mathematics (cubic-bezier easing definitions, Penner-style
 *  easing equations as published in common public easing references, CSS
 *  cubic-bezier preset values) and Adobe's official public After Effects
 *  scripting API documentation.
 *
 *  No source code, decompiled output, internal data files, or any other
 *  material of the original Flow script was used, viewed, or copied. Any
 *  similarity in behaviour is limited to what is inherent to the public
 *  feature description and to standard mathematics.
 *
 *  ----------------------------------------------------------------------------
 *  WHAT IT DOES
 *  ----------------------------------------------------------------------------
 *  - 16 built-in easing presets (bezier presets + overshoot/spring/bounce
 *    curve functions), see FLC_PRESETS below and README.md.
 *  - Select keyframes in the timeline, pick a preset, press Apply: the script
 *    recomputes the easing and writes it back with setTemporalEaseAtKey()
 *    (one KeyframeEase per property dimension).
 *  - Overshoot / Spring / Bounce presets cannot be represented by temporal
 *    ease between two keys (value overshoot is impossible with timing-only
 *    easing), so they are realised by sampling the curve function at every
 *    frame position inside the segment and inserting in-between keyframes.
 *  - Global Intensity / Speed sliders (0.2 - 3.0) shape the curves; details
 *    in README.md.
 *  - Runs as a dockable ScriptUI Panel (put in "ScriptUI Panels" folder) and
 *    as a floating palette (run via File > Scripts > Run Script File).
 *  - Headless/command-line mode via --flc-* launch arguments (experimental),
 *    plus a small public API on $.global for other scripts.
 *
 *  ----------------------------------------------------------------------------
 *  ES3 COMPATIBILITY
 *  ----------------------------------------------------------------------------
 *  Written for ExtendScript (ES3): no let/const, no arrow functions, no
 *  JSON object, no Array.prototype.indexOf/forEach/map, no template strings.
 * ============================================================================
 */

(function (flcThisObj) {

    var FLC_SCRIPT_NAME = "Flow Clone";
    var FLC_VERSION = "1.0.0";

    // ========================================================================
    // PURE MATH (no AE dependencies; extracted verbatim for automated checks)
    // ==== FLC-PURE-MATH-BEGIN ====

    function flc_clamp(v, lo, hi) {
        if (v < lo) { return lo; }
        if (v > hi) { return hi; }
        return v;
    }

    function flc_has(s, sub) {
        // manual substring test (avoid relying on indexOf)
        if (s === null || s === undefined) { return false; }
        s = String(s);
        sub = String(sub);
        var n = s.length, m = sub.length;
        if (m === 0 || m > n) { return false; }
        for (var i = 0; i <= n - m; i++) {
            var ok = true;
            for (var j = 0; j < m; j++) {
                if (s.charAt(i + j) !== sub.charAt(j)) { ok = false; break; }
            }
            if (ok) { return true; }
        }
        return false;
    }

    // Convert a normalized cubic-bezier ease (x1,y1,x2,y2 in 0..1 space)
    // plus global intensity/speed into the control-handle fractions AE needs:
    //   a    = out-influence fraction of the start key   (x extent of CP1)
    //   yy1  = progress fraction of CP1                  (y extent of CP1)
    //   b    = in-influence fraction of the end key      (1 - x extent of CP2)
    //   yy2  = progress fraction of CP2
    // Intensity k scales the handle offsets away from the segment corners;
    // Speed s compresses the time extents (higher = snappier response).
    // Returns [a, yy1, b, yy2].
    function flc_scaleBezier(x1, y1, x2, y2, intensity, speed) {
        var k = flc_clamp(intensity, 0.2, 3);
        var s = flc_clamp(speed, 0.2, 3);
        var a = (x1 * k) / s;
        var b = ((1 - x2) * k) / s;
        var yy1 = y1 * k;
        var yy2 = 1 - ((1 - y2) * k);
        if (a < 0.001) { a = 0.001; }
        if (a > 0.9995) { a = 0.9995; }
        if (b < 0.001) { b = 0.001; }
        if (b > 0.9995) { b = 0.9995; }
        // AE constraint: out-influence + in-influence must not exceed ~100%
        var sum = a + b;
        if (sum > 0.999) {
            var f = 0.999 / sum;
            a = a * f;
            b = b * f;
        }
        yy1 = flc_clamp(yy1, 0, 1);
        yy2 = flc_clamp(yy2, 0, 1);
        return [a, yy1, b, yy2];
    }

    // Cubic bezier point on P0(0,0) P1(a,yy1) P2(1-b,yy2) P3(1,1) at param t
    function flc_bezierXY(sc, t) {
        var x1 = sc[0], yy1 = sc[1], x2 = 1 - sc[2], yy2 = sc[3];
        var mt = 1 - t;
        var w0 = mt * mt * mt;
        var w1 = 3 * mt * mt * t;
        var w2 = 3 * mt * t * t;
        var w3 = t * t * t;
        return [(w1 * x1 + w2 * x2 + w3), (w1 * yy1 + w2 * yy2 + w3)];
    }

    // --- overshoot / oscillating curve functions (public standard math) ---

    function flc_easeOutBack(t, k) {
        var c1 = 1.70158 * flc_clamp(k, 0.2, 3);
        var c3 = c1 + 1;
        var u = t - 1;
        return 1 + c3 * u * u * u + c1 * u * u;
    }

    function flc_easeInOutBack(t, k) {
        var c1 = 1.70158 * flc_clamp(k, 0.2, 3);
        var c2 = c1 * 1.525;
        var p;
        if (t < 0.5) {
            p = 2 * t;
            return (p * p * ((c2 + 1) * p - c2)) / 2;
        }
        p = 2 * t - 2;
        return (p * p * ((c2 + 1) * p + c2) + 2) / 2;
    }

    // Normalized damped cosine: f(0)=0, f(1)=1 for any damping/frequency.
    // intensity k scales damping (higher k = more / larger oscillation),
    // speed s scales the oscillation frequency (higher s = more cycles).
    function flc_spring(t, k, s) {
        var damp = 6.0 / flc_clamp(k, 0.2, 3);
        var freq = 12.0 * flc_clamp(s, 0.2, 3);
        var denom = 1 - Math.exp(-damp) * Math.cos(freq);
        if (denom < 0.05) { denom = 0.05; }
        return (1 - Math.exp(-damp * t) * Math.cos(freq * t)) / denom;
    }

    // Standard public bounce-out equation (Penner-style constants).
    function flc_bounceOut(t) {
        var n1 = 7.5625, d1 = 2.75, tt = t;
        if (tt < 1 / d1) { return n1 * tt * tt; }
        if (tt < 2 / d1) { tt -= 1.5 / d1; return n1 * tt * tt + 0.75; }
        if (tt < 2.5 / d1) { tt -= 2.25 / d1; return n1 * tt * tt + 0.9375; }
        tt -= 2.625 / d1;
        return n1 * tt * tt + 0.984375;
    }

    // intensity k blends linear -> full bounce (k=1 is the standard bounce).
    function flc_bounce(t, k) {
        var kk = flc_clamp(k, 0, 1);
        var b = flc_bounceOut(t);
        return t + (b - t) * kk;
    }

    // fn signature: f(t, intensity, speed) with f(0)=0, f(1)=1.
    function flc_sampleFn(preset, u, intensity, speed) {
        var uu = flc_clamp(u, 0, 1);
        return preset.fn(uu, intensity, speed);
    }

    // ------------------------------------------------------------------
    // Built-in preset library (16 presets: 12 bezier + 4 curve functions)
    // ------------------------------------------------------------------
    var FLC_PRESETS = [
        { name: "Linear (reference)",          kind: "bez", bez: [0, 0, 1, 1] },
        { name: "Smooth - Light  (inOutSine)", kind: "bez", bez: [0.37, 0, 0.63, 1] },
        { name: "Smooth - Medium (inOutCubic)", kind: "bez", bez: [0.645, 0.045, 0.355, 1] },
        { name: "Smooth - Strong (inOutExpo)", kind: "bez", bez: [1, 0, 0, 1] },
        { name: "Ease In - Light  (inQuad)",   kind: "bez", bez: [0.55, 0.085, 0.68, 0.53] },
        { name: "Ease In - Medium (inCubic)",  kind: "bez", bez: [0.55, 0.055, 0.675, 0.19] },
        { name: "Ease In - Strong (inExpo)",   kind: "bez", bez: [0.95, 0.05, 0.795, 0.035] },
        { name: "Ease Out - Light (outQuad)",  kind: "bez", bez: [0.25, 0.46, 0.45, 0.94] },
        { name: "Ease Out - Medium (outCubic)", kind: "bez", bez: [0.215, 0.61, 0.355, 1] },
        { name: "Ease Out - Strong (outExpo)", kind: "bez", bez: [0.19, 1, 0.22, 1] },
        { name: "Snappy - Light",              kind: "bez", bez: [0.3, 0.75, 0.25, 1] },
        { name: "Snappy - Strong",             kind: "bez", bez: [0.05, 0.9, 0.1, 1] },
        { name: "Overshoot (back out)",        kind: "fn",  fn: function (t, k) { return flc_easeOutBack(t, k); } },
        { name: "Overshoot In-Out (back inOut)", kind: "fn", fn: function (t, k) { return flc_easeInOutBack(t, k); } },
        { name: "Spring (damped oscillation)", kind: "fn",  fn: function (t, k, s) { return flc_spring(t, k, s); } },
        { name: "Bounce (settle)",             kind: "fn",  fn: function (t, k) { return flc_bounce(t, k); } }
    ];

    function flc_findPreset(name) {
        for (var i = 0; i < FLC_PRESETS.length; i++) {
            if (FLC_PRESETS[i].name === name) { return FLC_PRESETS[i]; }
        }
        return null;
    }

    function flc_presetTitles() {
        var out = [];
        for (var i = 0; i < FLC_PRESETS.length; i++) { out.push(FLC_PRESETS[i].name); }
        return out;
    }

    // ==== FLC-PURE-MATH-END ====

    // ========================================================================
    // AE HELPERS
    // ========================================================================

    function flc_propDims(prop) {
        // Property dimensions: 1 / 2 / 3, or -1 when unsupported (color,
        // text, shape, marker, gradient ...). Every dimension gets its own
        // KeyframeEase when calling setTemporalEaseAtKey().
        var vt = null;
        try { vt = prop.propertyValueType; } catch (e0) { return -1; }
        try {
            if (vt === PropertyValueType.OneD) { return 1; }
            if (vt === PropertyValueType.TwoD) { return 2; }
            if (vt === PropertyValueType.ThreeD) { return 3; }
        } catch (e1) { /* enum names unavailable - fall through */ }
        // Fallback: enum name string, then value shape.
        // 官方指南枚举成员为混合大小写（OneD/TwoD/ThreeD），注意大小写敏感。
        try {
            if (flc_has(String(vt), "OneD")) { return 1; }
            if (flc_has(String(vt), "TwoD")) { return 2; }
            if (flc_has(String(vt), "ThreeD")) { return 3; }
        } catch (e2) { /* ignore */ }
        // 非数值维度类型（颜色/文本/形状/标记）不做时间缓动，防止被
        // 值形状回退误判成多维（COLOR 的 value 是 [r,g,b,a]）。
        try {
            var vtName = String(vt);
            if (flc_has(vtName, "COLOR") || flc_has(vtName, "MARKER") ||
                flc_has(vtName, "SHAPE") || flc_has(vtName, "TEXT")) { return -1; }
        } catch (e2b) { /* ignore */ }
        try {
            var v = prop.value;
            if (typeof v === "number") { return 1; }
            if (v && typeof v.length === "number" && v.length >= 1 && typeof v[0] === "number") { return v.length; }
        } catch (e3) { /* ignore */ }
        return -1;
    }

    function flc_dimDelta(v0, v1, d, dims) {
        if (dims === 1) { return v1 - v0; }
        var a = (v0 && v0.length > d) ? v0[d] : 0;
        var b = (v1 && v1.length > d) ? v1[d] : 0;
        return b - a;
    }

    function flc_dimValue(v, d, dims) {
        if (dims === 1) { return v; }
        if (v && v.length > d) { return v[d]; }
        return 0;
    }

    function flc_forceBezierInterp(prop, keyIndex) {
        try {
            if (prop.isInterpolationTypeOK(KeyframeInterpolationType.BEZIER, keyIndex)) {
                prop.setInterpolationTypeAtKey(keyIndex, KeyframeInterpolationType.BEZIER);
            }
        } catch (e) { /* keep current interpolation */ }
    }

    function flc_tryAutoBezierAtTime(prop, t) {
        try {
            var ki = prop.nearestKeyIndex(t);
            if (Math.abs(prop.keyTime(ki) - t) > 0.0005) { return; }
            if (prop.isInterpolationTypeOK(KeyframeInterpolationType.AUTO_BEZIER, ki)) {
                prop.setInterpolationTypeAtKey(ki, KeyframeInterpolationType.AUTO_BEZIER);
            }
        } catch (e) { /* keep linear */ }
    }

    function flc_getEaseArrays(prop, k0, k1, a, yy1, b, yy2, report) {
        // Build per-dimension in/out KeyframeEase arrays for a segment.
        // Temporal ease model: value = lerp(v0, v1, u), u(time) shaped by the
        // handles. speed is expressed in value-units per second, influence in
        // percent of segment duration.
        var t0 = prop.keyTime(k0);
        var t1 = prop.keyTime(k1);
        var D = t1 - t0;
        var dims = flc_propDims(prop);
        if (D <= 0 || dims < 1) { return null; }
        var v0 = prop.keyValue(k0);
        var v1 = prop.keyValue(k1);
        var outBase = yy1 / (a * D);          // progress per second at start
        var inBase = (1 - yy2) / (b * D);     // progress per second at end
        var outArr = [], inArr = [], d, dv, absTotal = 0;
        for (d = 0; d < dims; d++) {
            dv = flc_dimDelta(v0, v1, d, dims);
            absTotal += Math.abs(dv);
            outArr.push(new KeyframeEase(outBase * dv, a * 100));
            inArr.push(new KeyframeEase(inBase * dv, b * 100));
        }
        if (absTotal === 0) { return null; } // keys identical - nothing to ease
        return { inArr: inArr, outArr: outArr };
    }

    function flc_applyScaledEase(prop, k0, k1, a, yy1, b, yy2, report) {
        try {
            var arrays = flc_getEaseArrays(prop, k0, k1, a, yy1, b, yy2, report);
            if (arrays === null) { report.skipped++; return; }
            flc_forceBezierInterp(prop, k0);
            flc_forceBezierInterp(prop, k1);
            var oldIn = null, oldOut = null;
            try { oldIn = prop.keyInTemporalEase(k0); } catch (e1) { oldIn = null; }
            try { oldOut = prop.keyOutTemporalEase(k1); } catch (e2) { oldOut = null; }
            if (oldIn === null || oldOut === null) {
                // Cannot preserve the untouched side; give it a neutral ease.
                var dims = flc_propDims(prop);
                if (oldIn === null) {
                    oldIn = [];
                    for (var i = 0; i < dims; i++) { oldIn.push(new KeyframeEase(0, 33.33)); }
                }
                if (oldOut === null) {
                    oldOut = [];
                    for (var j = 0; j < dims; j++) { oldOut.push(new KeyframeEase(0, 33.33)); }
                }
            }
            prop.setTemporalEaseAtKey(k1, arrays.inArr, oldOut);   // end key: in-ease
            prop.setTemporalEaseAtKey(k0, oldIn, arrays.outArr);   // start key: out-ease
            report.segments++;
        } catch (e) {
            report.errors++;
            report.lastError = String(e);
        }
    }

    function flc_applyBezierSegment(prop, k0, k1, preset, intensity, speed, report) {
        var sc = flc_scaleBezier(preset.bez[0], preset.bez[1], preset.bez[2], preset.bez[3], intensity, speed);
        flc_applyScaledEase(prop, k0, k1, sc[0], sc[1], sc[2], sc[3], report);
    }

    function flc_applyBezierHalves(prop, k, preset, intensity, speed, report) {
        // Single (non-adjacent) selected key: shape its incoming half with the
        // curve end and its outgoing half with the curve start.
        var sc = flc_scaleBezier(preset.bez[0], preset.bez[1], preset.bez[2], preset.bez[3], intensity, speed);
        var n = prop.numKeys;
        if (k > 1) {
            var a0 = flc_scaleBezier(preset.bez[0], preset.bez[1], preset.bez[2], preset.bez[3], intensity, speed);
            // incoming: only the end handle (b, yy2) - approximate start handle
            // by mirroring the curve so the segment keeps a plausible shape.
            var tPrev = prop.keyTime(k - 1);
            var tK = prop.keyTime(k);
            var D = tK - tPrev;
            if (D > 0) {
                var bIn = a0[2], y2In = a0[3];
                var y1In = flc_clamp((1 - y2In) * 0.5, 0, 1);
                var aIn = flc_clamp(bIn, 0.001, 0.9995);
                var sumIn = aIn + bIn;
                if (sumIn > 0.999) { var fi = 0.999 / sumIn; aIn *= fi; bIn *= fi; }
                try {
                    var arrsIn = flc_getEaseArrays(prop, k - 1, k, aIn, y1In, bIn, y2In, report);
                    if (arrsIn !== null) {
                        var oldOutK = null;
                        try { oldOutK = prop.keyOutTemporalEase(k); } catch (e1) { oldOutK = null; }
                        if (oldOutK === null) { oldOutK = arrsIn.inArr; }
                        flc_forceBezierInterp(prop, k);
                        prop.setTemporalEaseAtKey(k, arrsIn.inArr, oldOutK);
                        report.segments++;
                    } else { report.skipped++; }
                } catch (e) { report.errors++; report.lastError = String(e); }
            }
        }
        if (k < n) {
            // outgoing: only the start handle (a, yy1)
            var tK2 = prop.keyTime(k);
            var tNext = prop.keyTime(k + 1);
            var D2 = tNext - tK2;
            if (D2 > 0) {
                var aOut = sc[0], y1Out = sc[1];
                var y2Out = flc_clamp(y1Out * 0.5, 0, 1);
                var bOut = flc_clamp(sc[2], 0.001, 0.9995);
                var sumOut = aOut + bOut;
                if (sumOut > 0.999) { var fo = 0.999 / sumOut; aOut *= fo; bOut *= fo; }
                try {
                    var arrsOut = flc_getEaseArrays(prop, k, k + 1, aOut, y1Out, bOut, y2Out, report);
                    if (arrsOut !== null) {
                        var oldInK = null;
                        try { oldInK = prop.keyInTemporalEase(k); } catch (e2) { oldInK = null; }
                        if (oldInK === null) { oldInK = arrsOut.outArr; }
                        flc_forceBezierInterp(prop, k);
                        prop.setTemporalEaseAtKey(k, oldInK, arrsOut.outArr);
                        report.segments++;
                    } else { report.skipped++; }
                } catch (e3) { report.errors++; report.lastError = String(e3); }
            }
        }
    }

    function flc_clearInteriorKeys(prop, t0, t1) {
        // Delete any key strictly between t0 and t1 (indices shift on delete,
        // hence the rescan loop). Used by the sampling presets so re-applying
        // never stacks stale in-betweens.
        var guard = 0;
        var removed = 0;
        while (guard < 5000) {
            guard++;
            var found = -1;
            var n = prop.numKeys;
            for (var i = 1; i <= n; i++) {
                var tt = prop.keyTime(i);
                if (tt > t0 + 0.0005 && tt < t1 - 0.0005) { found = i; break; }
            }
            if (found < 0) { break; }
            prop.removeKey(found); // 官方指南方法名：Property.removeKey(keyIndex)
            removed++;
        }
        return removed;
    }

    function flc_fnFallbackSegment(prop, k0, k1, preset, intensity, speed, report) {
        // Segment shorter than 2 frames: approximate the curve with a single
        // bezier built from numeric end slopes.
        var eps = 0.01;
        var s0 = (preset.fn(eps, intensity, speed) - preset.fn(0, intensity, speed)) / eps;
        var s1 = (preset.fn(1, intensity, speed) - preset.fn(1 - eps, intensity, speed)) / eps;
        var a = 0.25, b = 0.25;
        var yy1 = flc_clamp(s0 * a * flc_clamp(speed, 0.2, 3), 0, 1);
        var yy2 = 1 - flc_clamp(s1 * b * flc_clamp(speed, 0.2, 3), 0, 1);
        flc_applyScaledEase(prop, k0, k1, a, yy1, b, yy2, report);
    }

    function flc_applySamplingSegment(prop, fps, k0, k1, t0, t1, v0, v1, dims, preset, intensity, speed, report) {
        // Overshoot / Spring / Bounce: temporal ease between two keys cannot
        // overshoot the end value, so sample the curve function at every frame
        // position and insert in-between keyframes.
        try {
            var D = t1 - t0;
            if (D <= 0) { report.skipped++; return; }
            if (fps <= 0) { fps = 25; }
            var frames = Math.round(D * fps);
            if (frames < 2) {
                // Segment shorter than 2 frames: no room for in-betweens, fall
                // back to a bezier approximation of the curve end slopes.
                flc_fnFallbackSegment(prop, k0, k1, preset, intensity, speed, report);
                return;
            }
            flc_clearInteriorKeys(prop, t0, t1);
            var inserts = [];
            for (var i = 1; i < frames; i++) {
                var tt = t0 + i / fps;
                if (tt < t1 - 0.0001) { inserts.push(tt); }
            }
            var d, u, sv, val, arr;
            for (i = 0; i < inserts.length; i++) {
                u = (inserts[i] - t0) / D;
                sv = flc_sampleFn(preset, u, intensity, speed);
                if (dims === 1) {
                    val = v0 + (v1 - v0) * sv;
                } else {
                    arr = [];
                    for (d = 0; d < dims; d++) {
                        arr.push(flc_dimValue(v0, d, dims) + (flc_dimValue(v1, d, dims) - flc_dimValue(v0, d, dims)) * sv);
                    }
                    val = arr;
                }
                prop.setValueAtTime(inserts[i], val);
                report.keysAdded++;
            }
            report.segments++;
        } catch (e) {
            report.errors++;
            report.lastError = String(e);
        }
    }

    // ========================================================================
    // SELECTION HANDLING
    // ========================================================================

    function flc_collectFromGroup(grp, out) {
        try {
            var n = grp.numProperties;
            for (var i = 1; i <= n; i++) {
                var p = grp.property(i);
                if (!p) { continue; }
                if (p.numKeys !== undefined && p.numKeys > 0 && p.propertyValueType !== undefined) {
                    out.push(p);
                } else if (p.propertyType === PropertyType.PROPERTYGROUP ||
                           p.propertyType === PropertyType.INDEXED_GROUP ||
                           p.propertyType === PropertyType.NAMED_GROUP) {
                    flc_collectFromGroup(p, out);
                }
            }
        } catch (e) { /* skip unreadable group */ }
    }

    function flc_collectProps(comp) {
        var out = [];
        var sel = null;
        try { sel = comp.selectedProperties; } catch (e) { return out; }
        if (!sel) { return out; }
        for (var i = 0; i < sel.length; i++) {
            var it = sel[i];
            if (!it) { continue; }
            if (it.numKeys !== undefined && it.numKeys > 0 && it.propertyValueType !== undefined) {
                // A Property with keyframes
                out.push(it);
            } else if (it.selectedProperties !== undefined) {
                // A Layer (feature-detected): collect its selected properties
                var lsel = null;
                try { lsel = it.selectedProperties; } catch (e1) { lsel = null; }
                if (lsel) {
                    for (var j = 0; j < lsel.length; j++) {
                        var lp = lsel[j];
                        if (!lp) { continue; }
                        if (lp.numKeys !== undefined && lp.numKeys > 0 && lp.propertyValueType !== undefined) {
                            out.push(lp);
                        } else if (lp.propertyType !== undefined && lp.numKeys === undefined) {
                            flc_collectFromGroup(lp, out);
                        }
                    }
                }
            } else if (it.propertyType === PropertyType.PROPERTYGROUP ||
                       it.propertyType === PropertyType.INDEXED_GROUP ||
                       it.propertyType === PropertyType.NAMED_GROUP) {
                // A selected property group: ease all animated props inside
                flc_collectFromGroup(it, out);
            }
        }
        return out;
    }

    function flc_selectedKeysOf(prop, allowAllFallback, report) {
        var sk = null;
        try { sk = prop.selectedKeys; } catch (e) { sk = null; }
        if (sk && sk.length > 0) { return sk; }
        if (allowAllFallback) {
            // Older AE versions do not expose Property.selectedKeys; fall
            // back to all keys of the selected property.
            var all = [];
            var n = prop.numKeys;
            for (var i = 1; i <= n; i++) { all.push(i); }
            report.fallbackProps++;
            return all;
        }
        return null;
    }

    function flc_processPropertyBezier(prop, preset, intensity, speed, keys, report) {
        var n = prop.numKeys;
        var inPair = {};
        var pairs = [];
        var i;
        for (i = 0; i < keys.length - 1; i++) {
            if (keys[i + 1] === keys[i] + 1 && keys[i] >= 1 && keys[i + 1] <= n) {
                pairs.push([keys[i], keys[i + 1]]);
                inPair[keys[i]] = true;
                inPair[keys[i + 1]] = true;
            }
        }
        for (i = 0; i < pairs.length; i++) {
            flc_applyBezierSegment(prop, pairs[i][0], pairs[i][1], preset, intensity, speed, report);
        }
        for (i = 0; i < keys.length; i++) {
            var k = keys[i];
            if (!inPair[k] && k >= 1 && k <= n) {
                flc_applyBezierHalves(prop, k, preset, intensity, speed, report);
            }
        }
    }

    function flc_processPropertyFn(prop, comp, preset, intensity, speed, keys, report) {
        // Time-based processing (indices shift while keys are inserted).
        var n = prop.numKeys;
        var dims = flc_propDims(prop);
        if (dims < 1) { report.skipped++; return; }
        var fps = 25;
        try { fps = comp.frameRate; } catch (e) { fps = 25; }
        var i, k;
        // Single selected keys cannot get a partial shape from a sampled
        // curve; require both keys of a segment to be selected (adjacent).
        var singles = 0;
        var inPair = {};
        var jobs = [];
        var keyT = [], keyV = [];
        for (i = 0; i < keys.length; i++) {
            k = keys[i];
            keyT.push(prop.keyTime(k));
            keyV.push(prop.keyValue(k));
        }
        for (i = 0; i < keys.length - 1; i++) {
            if (keys[i + 1] === keys[i] + 1 && keys[i] >= 1 && keys[i + 1] <= n) {
                jobs.push({ k0: keys[i], t0: keyT[i], v0: keyV[i], k1: keys[i + 1], t1: keyT[i + 1], v1: keyV[i + 1] });
                inPair[i] = true;
                inPair[i + 1] = true;
            }
        }
        for (i = 0; i < keys.length; i++) {
            if (!inPair[i]) { singles++; }
        }
        if (singles > 0) { report.fnSinglesSkipped += singles; }
        for (i = 0; i < jobs.length; i++) {
            flc_applySamplingSegment(prop, fps, jobs[i].k0, jobs[i].k1, jobs[i].t0, jobs[i].t1, jobs[i].v0, jobs[i].v1,
                                     dims, preset, intensity, speed, report);
        }
        // Fix interpolation of endpoints and inserted keys (by time).
        for (i = 0; i < jobs.length; i++) {
            flc_forceBezierInterp(prop, prop.nearestKeyIndex(jobs[i].t0));
            flc_forceBezierInterp(prop, prop.nearestKeyIndex(jobs[i].t1));
        }
        // Smooth the sampled curve through the inserted keys.
        var frames, fps2 = fps, D;
        for (i = 0; i < jobs.length; i++) {
            D = jobs[i].t1 - jobs[i].t0;
            frames = Math.round(D * fps2);
            for (var j = 1; j < frames; j++) {
                var tt = jobs[i].t0 + j / fps2;
                if (tt < jobs[i].t1 - 0.0001) { flc_tryAutoBezierAtTime(prop, tt); }
            }
        }
    }

    // ========================================================================
    // ORCHESTRATION
    // ========================================================================

    function flc_newReport() {
        return { segments: 0, keysAdded: 0, skipped: 0, errors: 0,
                 props: 0, fallbackProps: 0, fnSinglesSkipped: 0, lastError: "" };
    }

    function flc_reportText(rep) {
        var s = rep.segments + " segment(s) eased";
        if (rep.keysAdded > 0) { s += ", " + rep.keysAdded + " in-between key(s) added"; }
        if (rep.skipped > 0) { s += ", " + rep.skipped + " skipped"; }
        if (rep.fnSinglesSkipped > 0) {
            s += ", " + rep.fnSinglesSkipped + " single key(s) ignored (spring/bounce need both keys selected)";
        }
        if (rep.fallbackProps > 0) { s += " [all-keys fallback x" + rep.fallbackProps + "]"; }
        if (rep.errors > 0) { s += ", " + rep.errors + " error(s)"; }
        return s;
    }

    function flc_applyByName(presetName, intensity, speed, allowAllFallback, compOverride) {
        var preset = flc_findPreset(String(presetName));
        if (preset === null) {
            throw new Error("Flow Clone: unknown preset \"" + presetName + "\". Use flcListPresets().");
        }
        if (intensity === undefined || intensity === null) { intensity = 1; }
        if (speed === undefined || speed === null) { speed = 1; }
        if (allowAllFallback === undefined || allowAllFallback === null) { allowAllFallback = true; }

        var comp = compOverride || app.project.activeItem;
        if (comp === null || comp === undefined || !(comp instanceof CompItem)) {
            throw new Error("Flow Clone: select a composition (with selected keyframes) first.");
        }

        var rep = flc_newReport();
        var props = flc_collectProps(comp);
        app.beginUndoGroup("Flow Clone: " + preset.name);
        try {
            for (var i = 0; i < props.length; i++) {
                var prop = props[i];
                rep.props++;
                var keys = flc_selectedKeysOf(prop, allowAllFallback, rep);
                if (keys === null || keys.length === 0) { continue; }
                keys = keys.slice(0);
                keys.sort(function (x, y) { return x - y; });
                if (preset.kind === "bez") {
                    flc_processPropertyBezier(prop, preset, intensity, speed, keys, rep);
                } else {
                    flc_processPropertyFn(prop, comp, preset, intensity, speed, keys, rep);
                }
            }
        } finally {
            app.endUndoGroup();
        }
        return rep;
    }

    // ========================================================================
    // CLI / LOG HELPERS
    // ========================================================================

    function flc_writeCliLog(msg) {
        try {
            var f = new File($.fileName);
            var lf = new File(f.parent.fsName + "/flc-cli-log.txt");
            lf.encoding = "UTF-8";
            lf.open("w");
            lf.write(msg);
            lf.close();
        } catch (e) { /* headless without write access - ignore */ }
    }

    function flc_tryCommandLine() {
        var args = null;
        try { args = app.getCommandLineArguments(); } catch (e) { args = null; }
        if (!args || args.length === 0) { return false; }
        var presetName = null, intensity = 1, speed = 1, found = false;
        for (var i = 0; i < args.length; i++) {
            var a = String(args[i]);
            if (a.substring(0, 13) === "--flc-preset=") {
                presetName = a.substring(13);
                found = true;
            } else if (a.substring(0, 16) === "--flc-intensity=") {
                intensity = parseFloat(a.substring(16));
            } else if (a.substring(0, 12) === "--flc-speed=") {
                speed = parseFloat(a.substring(12));
            }
        }
        if (!found) { return false; }
        try {
            var rep = flc_applyByName(presetName, intensity, speed, true, null);
            flc_writeCliLog("OK " + presetName + " i=" + intensity + " s=" + speed + " :: " + flc_reportText(rep));
        } catch (e) {
            flc_writeCliLog("ERROR: " + String(e));
        }
        return true;
    }

    // ========================================================================
    // UI (ScriptUI Panel / palette)
    // ========================================================================

    function flc_helpText() {
        var s = "";
        s += FLC_SCRIPT_NAME + " " + FLC_VERSION + " (clean-room)\n\n";
        s += "1. Select keyframes in the timeline (select BOTH keys of a segment).\n";
        s += "2. Pick a preset, adjust Intensity / Speed (0.2 - 3.0).\n";
        s += "3. Apply.\n\n";
        s += "Bezier presets (Linear, Smooth, Ease In/Out, Snappy) reshape the\n";
        s += "temporal ease handles of the keys (one KeyframeEase per dimension).\n\n";
        s += "Overshoot / Spring / Bounce cannot be done with temporal ease alone\n";
        s += "(values cannot overshoot between two keys), so they sample the curve\n";
        s += "at every frame and add in-between keyframes. They need both keys of a\n";
        s += "segment selected; Speed only affects Spring (oscillation frequency).\n\n";
        s += "If no keys are selected and the checkbox is on, all keys of the\n";
        s += "selected properties are used (fallback for AE versions without\n";
        s += "Property.selectedKeys support).";
        return s;
    }

    function flc_buildUI(thisObj) {
        var pal;
        try {
            pal = (thisObj instanceof Panel) ? thisObj : new Window("palette", FLC_SCRIPT_NAME, undefined, { resizeable: true });
        } catch (e) {
            pal = new Window("palette", FLC_SCRIPT_NAME);
        }
        pal.orientation = "column";
        pal.alignChildren = ["fill", "top"];
        pal.spacing = 6;
        pal.margins = 10;

        var title = pal.add("statictext", undefined, FLC_SCRIPT_NAME + " " + FLC_VERSION + " - easing presets (clean-room)");

        // curve preview (ScriptUI graphics; degrades silently if unsupported)
        var preview = pal.add("statictext", undefined, "curve preview");
        preview.preferredSize = [230, 84];
        preview.helpTip = "Shape of the selected preset with current Intensity / Speed";

        var titles = flc_presetTitles();
        var dd = pal.add("dropdownlist", undefined, titles);
        dd.selection = 8; // "Ease Out - Medium" as a sensible default
        dd.helpTip = "Preset curve";

        var rowI = pal.add("group");
        rowI.orientation = "row";
        rowI.alignChildren = ["left", "center"];
        rowI.spacing = 6;
        rowI.add("statictext", undefined, "Intensity");
        var sI = rowI.add("slider", undefined, 100, 20, 300);
        sI.preferredSize.width = 140;
        var eI = rowI.add("edittext", undefined, "1.00");
        eI.characters = 6;

        var rowS = pal.add("group");
        rowS.orientation = "row";
        rowS.alignChildren = ["left", "center"];
        rowS.spacing = 6;
        rowS.add("statictext", undefined, "Speed    ");
        var sS = rowS.add("slider", undefined, 100, 20, 300);
        sS.preferredSize.width = 140;
        var eS = rowS.add("edittext", undefined, "1.00");
        eS.characters = 6;

        var cbAll = pal.add("checkbox", undefined, "No keys selected: use all keys of selected properties");
        cbAll.value = true;

        var rowB = pal.add("group");
        rowB.orientation = "row";
        rowB.alignment = ["fill", "top"];
        var btn = rowB.add("button", undefined, "Apply to selected keyframes", { name: "ok" });
        btn.alignment = ["fill", "center"];
        var btnHelp = rowB.add("button", undefined, "?");
        btnHelp.preferredSize.width = 28;

        var status = pal.add("statictext", undefined, "Ready. Select keyframes, pick a preset, Apply.");

        // ---- preview drawing ----
        function drawCurve() {
            try {
                var preset = (dd.selection !== null) ? FLC_PRESETS[dd.selection.index] : FLC_PRESETS[8];
                var inten = parseFloat(eI.text) || 1;
                var spd = parseFloat(eS.text) || 1;
                var g = preview.graphics;
                var W = 210, H = 70, X0 = 26, Y0 = 74, XS = 176, YS = 60;
                var bg = g.newBrush(g.BrushType.SOLID_COLOR, [0.13, 0.13, 0.15, 1]);
                var bgPath = g.newPath();
                bgPath.moveTo(0, 0);
                bgPath.lineTo(W, 0);
                bgPath.lineTo(W, H);
                bgPath.lineTo(0, H);
                bgPath.closePath();
                g.fillPath(bg, bgPath);
                var grid = g.newPen(g.PenType.SOLID_COLOR, [0.45, 0.45, 0.48, 1], 1);
                var axis = g.newPath();
                axis.moveTo(X0, Y0);
                axis.lineTo(X0 + XS, Y0);
                axis.moveTo(X0, Y0);
                axis.lineTo(X0, Y0 - YS);
                g.strokePath(grid, axis);
                var pen = g.newPen(g.PenType.SOLID_COLOR, [0.35, 0.72, 1, 1], 2);
                var path = g.newPath();
                var STEPS = 36;
                var first = true;
                for (var i = 0; i <= STEPS; i++) {
                    var t = i / STEPS;
                    var pt;
                    if (preset.kind === "bez") {
                        var sc = flc_scaleBezier(preset.bez[0], preset.bez[1], preset.bez[2], preset.bez[3], inten, spd);
                        pt = flc_bezierXY(sc, t);
                    } else {
                        pt = [t, flc_sampleFn(preset, t, inten, spd)];
                    }
                    var px = X0 + pt[0] * XS;
                    var py = Y0 - pt[1] * (YS / 1.4);
                    if (py < 4) { py = 4; }
                    if (py > Y0) { py = Y0; }
                    if (first) { path.moveTo(px, py); first = false; } else { path.lineTo(px, py); }
                }
                g.strokePath(pen, path);
            } catch (e) {
                // ScriptUI graphics unavailable on this AE build - keep text.
            }
        }

        function redrawPreview() {
            try { preview.notify("onDraw"); } catch (e1) {
                try { pal.layout.layout(true); } catch (e2) { /* ignore */ }
            }
        }

        preview.onDraw = function () { drawCurve(); };

        // ---- slider / edittext sync ----
        function wireSlider(slider, edit) {
            slider.onChanging = function () {
                try { edit.text = (this.value / 100).toFixed(2); redrawPreview(); } catch (e) { /* ignore */ }
            };
            slider.onChange = function () {
                try { edit.text = (this.value / 100).toFixed(2); } catch (e) { /* ignore */ }
            };
            edit.onChange = function () {
                try {
                    var v = parseFloat(edit.text);
                    if (isNaN(v)) { v = 1; }
                    v = flc_clamp(v, 0.2, 3);
                    slider.value = v * 100;
                    edit.text = v.toFixed(2);
                    redrawPreview();
                } catch (e) { /* ignore */ }
            };
        }
        wireSlider(sI, eI);
        wireSlider(sS, eS);

        dd.onChange = function () { redrawPreview(); };

        // ---- apply ----
        btn.onClick = function () {
            try {
                var idx = (dd.selection !== null) ? dd.selection.index : 8;
                var preset = FLC_PRESETS[idx];
                var inten = parseFloat(eI.text) || 1;
                var spd = parseFloat(eS.text) || 1;
                status.text = "Applying " + preset.name + " ...";
                var rep = flc_applyByName(preset.name, inten, spd, cbAll.value, null);
                status.text = preset.name + ": " + flc_reportText(rep);
                if (rep.errors > 0) {
                    alert("Flow Clone finished with errors:\n" + rep.lastError + "\n\n(" + flc_reportText(rep) + ")");
                }
            } catch (e) {
                status.text = "Error: " + String(e);
                alert("Flow Clone error:\n" + String(e));
            }
        };

        btnHelp.onClick = function () { alert(flc_helpText()); };

        pal.onResizing = pal.onResize = function () { this.layout.resize(); };

        if (pal instanceof Window) {
            pal.center();
            pal.show();
        } else {
            pal.layout.layout(true);
            pal.layout.resize();
            pal.onResizing = pal.onResize = function () { this.layout.resize(); };
        }
        redrawPreview();
        return pal;
    }

    // ========================================================================
    // ENTRY
    // ========================================================================

    // Public API for other scripts / CLI wrappers (ExtendScript console):
    //   flcApplyPreset("Ease Out - Strong", 1.5, 1.0, true)  -> report object
    //   flcListPresets()                                     -> array of names
    try {
        $.global.flcApplyPreset = flc_applyByName;
        $.global.flcListPresets = flc_presetTitles;
        $.global.flcPresets = FLC_PRESETS;
    } catch (gErr) { /* ignore */ }

    function flc_main() {
        if (typeof app === "undefined") {
            alert("Flow Clone requires Adobe After Effects.");
            return;
        }
        if (flc_tryCommandLine()) { return; } // headless CLI run handled
        flc_buildUI(flcThisObj);
    }

    flc_main();

})(this);
