---
generated_at: 2026-11-14T08:55:00+08:00
task: B 类近似包（收官产出件）——原生效果组合+表达式近似三个收费效果：软发光（Deep Glow 2 #33）、长阴影（LongShadow 2 #32）、线条沸腾（LineBoil 免费做法 #48）；输入 = intel/paid-list.md B 类条目的近似路径与复刻要点，不写 C++
---

# Native Presets Clone（B 类原生效果近似包 · clean-room）

- 产出：`main.jsx`（ExtendScript，ES3，一脚本三按钮）
- 输入依据：`intel/paid-list.md` B 类条目（#33 Deep Glow 2、#32 LongShadow 2、#48 LineBoil 免费做法）的**近似路径与复刻要点**；#34 Hawaiki Keyer 见下文"未覆盖项"
- API 政策（docs/api-cheatsheet.md）：效果 matchName（ADBE Glo2 / ADBE Drop Shadow / ADBE Set Matte3 / ADBE Turbulent Displace / ADBE Posterize Time）均经官方指南 grep **[官方核实]**；效果**参数**名（Glow Threshold、Direction 等）为显示名、matchName 表外 → 全部 try/catch 逐名尝试并计入提示，README 登记

## CLEAN-ROOM 声明

1. 本脚本为清室实现：未反编译、未阅读、未复制 Deep Glow 2 / LongShadow 2 / LineBoil 相关任何原品代码；仅依据公开的功能性描述，用 AE 自带效果与表达式从零组合。
2. 仅供学习研究；上述商标与著作权归各自作者所有。B 类近似按 paid-list 评级定义为"原生效果组合可到 ~80% 观感"，非复刻品。

## 功能对照（复刻范围 / 推断范围）

| 收费效果 | 近似实现 | 状态 | 说明 |
|---|---|---|---|
| Deep Glow 2（多层可分离模糊管线、threshold/radius/exposure/色调映射） | 软发光：**3 层 Glow 递进**（阈值 60/42/24、半径 10/30/80、强度 1.0/0.8/0.5） | ✅ 基线 | 阈值/半径倍率/强度三滑杆暴露（`NP: Glow 阈值% / 半径倍率 / 强度`），经参数表达式驱动三层 Glow 联动（Node 验证递进算术） |
| Teamax 式叠加（辅助通道） | ⚠️ 手动 | ❌ 未自动化 | 手动法：复制目标层→第二层 Glow 设 Glow Operation=Add→叠在上方；未脚本化（Glow Operation 枚举序未核实，不盲写） |
| LongShadow 2（角度/长度硬边长投影） | 长阴影：**纯色层 + Set Matte（取源层 alpha）+ 4 层 Drop Shadow**（距离=长度×k/4，k=1..4，重叠自然形成近深远浅渐变） | ✅ 基线 | 角度/长度/透明度三滑杆暴露于影子层；影子层 `moveAfter` 到源层下方 |
| LineBoil（线条沸腾：边缘抖动 + 逐帧 Hold） | 线条沸腾：**Turbulent Displace（Amount=扰动量滑杆；Evolution=帧量化伪随机表达式）+ Posterize Time（帧率=沸腾帧率滑杆）** | ✅ 基线 | Evolution 表达式 `r1×720`（q=⌊time×帧率⌉ 的确定性伪随机，Node 验证同帧恒定/跨帧跳变/范围 0..720）→ 手绘线条顿挫感；Posterize Time 把整层量化到沸腾帧率 |
| Hawaiki Keyer 5（一键抠像+边缘修复+spill） | ❌ 未覆盖 | — | paid-list 近似路径 = AE 内置 Keylight(1.2) + Key Cleaner + Advanced Spill Suppressor（CC2014+ 自带，可达 ~80%）；三按钮不含抠像，后续可加第四按钮（效果组合直接顺序堆叠即可） |
| 随机化/逐层独立控制/纹理（原品细节） | ❌ 未复刻 | — | paid-list 标注 [未核实细节] 的部分均在推断范围外 |

## 安装

`main.jsx` 放入 ScriptUI Panels 目录重启 AE 从 Window 菜单打开（可停靠），或 `File > Scripts > Run Script File...` 直接运行。

## 使用

1. **软发光**：选中图层 → 按钮 1。生成 `NP: Glow A/B/C` 三层 Glow；调 `NP: Glow 阈值% / 半径倍率 / 强度` 滑杆，三层联动。
2. **长阴影**：选中源层 → 按钮 2。生成 `NP: Long Shadow - <层名>` 黑色纯色层（置于源层下方），含 Set Matte（alpha 取自源层）+ 4 步 Drop Shadow；调影子层的 `NP: 影子角度 / 影子长度 / 影子透明度` 滑杆。
3. **线条沸腾**：选中形状/文本/图片层 → 按钮 3。加 Turbulent Displace（扰动量滑杆 + Evolution 帧量化随机）+ Posterize Time（帧率=沸腾帧率滑杆）；调 `NP: 沸腾帧率 / 扰动量`。
4. 每按钮独立 undo 组（try/finally）；空选中/未激活合成弹窗拒绝；效果/参数添加失败会计入弹窗提示（不中断）。

## 自查记录（2026-11-14）

1. `node --check`：通过（复制为 .js）；ES3 扫描（排除注释行）：零命中。
2. **表达式标记块逐字验证**（NP-GLOW-EXPR / NP-BOIL-EXPR 标记块提取执行）：12 项断言 ALL PASS——三层阈值递进（50% 滑杆 → 30/21/12）、半径倍率与下限 1、强度倍率与下限 0、沸腾 Evolution 同帧确定性/跨帧跳变/范围 0..720。
3. matchName 官方核实：Glo2×2、Drop Shadow×1、Set Matte3×1、Turbulent Displace×1、Posterize Time×1（docsforadobe 指南全文 grep）；`velocityAtTime` 0 命中故全脚本未使用。
4. 自查修复：三个 do* 函数的 undo 组改为 try/finally（异常时组闭合）。

## 限制（如实说明）

1. **未在 AE 实机测试**。重点实机验证项：Glow/Drop Shadow 参数显示名在当前 AE 版本是否一致（参数表达式写入失败会有明确提示计数）、Set Matte 的 "Use Layer for Matte" 参数名与按索引引用、Posterize Time 对预合成的行为。
2. **本地化风险**：效果参数按**英文显示名**查找（官方指南惯例），中文版 AE 参数名不同时对应参数表达式会写入失败（计入提示）；效果本体用 matchName 添加不受本地化影响。
3. **近似口径**：三层 Glow 是 Deep Glow 多级管线的粗化近似（paid-list 评级 ~80% 观感），无 exposure/色调映射/chromatic aberration；长阴影为 4 步离散逼近（步数固定），非连续渐变；沸腾为整层 Posterize（含内容帧率），非仅边缘。
4. Set Matte 按源层**索引**引用：源层重排/删除后影子蒙版失效，需重跑按钮。
5. **Hawaiki Keyer 近似未自动化**（内置抠像三件套为手动堆叠路线，见功能对照）。
6. Teamax 叠加未自动化（Glow Operation 枚举序未核实，避免盲写；README 给出手动步骤）。
