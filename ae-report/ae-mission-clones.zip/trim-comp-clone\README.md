# Trim Comp to Contents Clone

一个 After Effects 脚本（`.jsx`，ExtendScript/ES3），把选中/当前合成的时长裁到（或延长到）恰好包住图层内容。

- 版本：1.0.0
- 文件：`main.jsx`（单文件，无外部依赖）
- 类型：ScriptUI 面板

> **Clean-room 声明**：本件只依据公开的商品一句话描述「Trim or extend comp duration to fit layer contents」以及通用的 After Effects Scripting API 知识独立实现。没有获取、阅读、反编译或参考原商业化脚本的任何源码、安装包、二进制或资源文件。UI 文案除通用术语外均为自拟。

---

## 一、对应原插件的功能

原商品（aescripts 上 $4.99 / NYOP，作者 Zack Lovatt）的核心行为，按公开描述可拆成两点：

1. **Trim**：把合成时长压到刚好等于图层内容的时间跨度，去掉头尾空白。
2. **Extend**：内容超出当前合成时长时（例如预合成里塞了更长的动画、图层 outPoint 被短合成裁掉），把合成时长加长到能容纳全部内容。

本复刻实现的就是这两点，并额外暴露了几个选项和尾部留白的帧数控制。

## 二、使用方式

1. AE 里打开目标合成，或选中项目面板里的合成；
2. 菜单 `File > Scripts > Run Script File...` 选中 `main.jsx`（想常驻就把文件丢进 `Scripts/ScriptUI Panels/`，重启 AE 后在 `Window` 菜单里调出）；
3. 面板顶部 `Refresh` 会实时显示：内容起点/终点、当前时长、按当前选项算出的目标时长；
4. 点 `Trim to Contents` 执行。整个操作包在一个撤销组里，`Ctrl+Z` 一步回退。

`Refresh` 只是读取，不改任何东西，可以先用它确认目标时长是否就是你要的。

## 三、选项说明

| 选项 | 默认 | 作用 |
|---|---|---|
| Ignore guide layers | 开 | 参考层不参与内容范围计算（参考层常放超长素材，会撑大范围） |
| Ignore disabled layers | 关 | 关闭眼睛的图层不参与计算。想「只保留可见内容」时打开 |
| Follow nested precomp length | 开 | 预合成图层的 outPoint 已经被过短的合成裁掉时，用「源合成时长 × stretch」推算真实内容尾端。**这是本脚本相对「直接读 inPoint/outPoint」的关键差别** |
| Slide contents to start at 0 | 关 | 内容起点晚于 0 时，把所有图层整体前移，让内容从 0 帧开始；时长同步只取内容跨度 |
| Only selected layers (if any selected) | 关 | 时间线里有选中图层时只按选中图层算范围，否则按全合成 |
| Tail padding (frames) | 0 | 内容尾部额外留 N 帧（正数向上取整到整帧，负数会把结尾提前） |

## 四、实现要点（供验收核对）

- **内容范围**：`layer.inPoint` / `layer.outPoint` 取并集；预合成图层若 `outPoint` 已被合成时长夹住，改用 `startTime + source.duration * stretch` 推算；时间重映射开启的图层直接采信 `outPoint`（因为重映射后源时长不再决定画面长度）。
- **执行顺序**（重要）：① 先整体平移图层（此时合成还是原长度，不会被裁）→ ② 需要变长就先 `comp.duration = 新值`（加长永不丢关键帧）→ ③ 重设工作区为 `0 ~ comp.duration` → ④ 最后才缩短 `comp.duration`（缩短会裁掉超出部分的图层数据，这正是 trim 的语义）。
- **帧对齐**：所有时长按 `comp.frameDuration` 四舍五入到整帧，避免出现 12.4999s 这种非整帧时长。
- **撤销**：`app.beginUndoGroup()` / `app.endUndoGroup()` 成对，`try/finally` 保证异常时也闭合。
- **错误处理**：没有打开的合成、空合成、计算结果 ≤ 0、锁定图层平移失败、`comp.duration` 赋值异常，都有对应提示，不会静默失败。

## 五、能力限制（诚实说明）

1. **缩短合成会裁剪图层数据，且 AE 里不可逆**（除撤销外）。如果某个图层 outPoint 超出新时长，它的后半段关键帧会被丢弃。脚本会先加长再缩短，但没有「预览差异」这一步——用 `Refresh` 看目标时长再决定。
2. **不识别表达式造成的「视觉内容」**：一个 2 秒图层配上 `loopOut()` 表达式，画面可以一直延伸，但它的 `outPoint` 只有 2 秒。本脚本按时间线的实际长度算，不按表达式推算。
3. **不处理摄像机/灯光以外的特殊条目**：色彩管理、字幕、时间码等图层按普通图层处理。
4. **预合成递归只做一层**：`Follow nested precomp length` 取的是直接源合成自己的 `duration`，不递归进它内部的预合成。原商业版是否有递归未公开说明，本复刻选择保守的一层，避免把无关的长素材算进来。
5. **「内容」的口径是时间跨度，不是「画面上的非透明像素」**。一张 1920×1080 全黑的 10 秒素材仍算 10 秒内容。
6. **不修改图层 inPoint/outPoint 本身**（除整体平移），只改合成时长与工作区。所以「把每个图层也裁到内容边界」这种行为不在本脚本范围内。
7. 平移模式（Slide contents to start at 0）会把**所有**图层一起前移，包括锁定层（锁定层会平移失败并被跳过，面板不会报错指出是哪一层，只在失败时不移动它）。

## 六、API 使用核对（全部在白名单内）

- `app.project`、`app.project.activeItem`
- `CompItem`：`numLayers`、`layer(i)`、`duration`（可写）、`frameDuration`、`workAreaStart`、`workAreaDuration`、`selectedLayers`、`name`
- `Layer`：`inPoint`、`outPoint`、`startTime`（可写）、`stretch`、`source`、`timeRemapEnabled`、`enabled`、`guideLayer`
- `app.beginUndoGroup` / `app.endUndoGroup`
- ScriptUI：`Window`/`Panel`、`add("group"/"panel"/"statictext"/"checkbox"/"edittext"/"button")`、`onClick`、`onChanging`、`onResizing`

未使用白名单以外的 API。整帧换算直接用 `comp.frameRate`（白名单内）计算，不经过任何自定义时间工具。`instanceof CompItem`、`instanceof Window`、`instanceof Panel` 为 ExtendScript 原生判断，非 API 调用。

## 七、验收清单（建议实测）

1. 3 层内容分别占 1s~4s、2s~6s、0s~3s，合成时长 10s → Trim 后应为 6s。
2. 预合成 A 时长 5s，在主合成里 inPoint=1s，主合成时长 3s（outPoint 被裁到 3s）→ 打开 `Follow nested precomp length` 后目标应为 1+5=6s；关掉则 3s。
3. 内容从 2s 开始 → 勾 `Slide contents to start at 0`，图层全部前移 2s，时长只取跨度。
4. 空合成 → 面板提示 `(no layers)`，点 Trim 提示 `No usable layer found`。
5. 尾部填 12 帧 → 目标时长比内容多 12 帧（整帧对齐）。
6. 撤销一次应完整回退（时长、工作区、图层位置）。
7. AE 2019 / 2020 / 2022 各跑一次，确认无报错。

## 八、文件

```
clones/trim-comp-clone/
├─ main.jsx   # 脚本本体
└─ README.md  # 本文件
```

- 测试方式（静态）：`node --check`（剥离 `#target` 行后）通过；ES3 构造扫描无命中；源码纯 ASCII。
