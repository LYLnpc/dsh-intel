/**
 * KFP Clone (clean-room) -- keyframe-group affine transform tools for After Effects.
 * ============================================================================
 * DELIVERY NOTE -- target path of this file:
 *   C:\Users\19894\ae-mission\clones\keyframe-parent-clone\main.jsx
 * It was written into the session workspace (out\keyframe-parent-clone\) only
 * because that target folder is read-only to this session. Copy it there
 * unchanged; nothing else in the file depends on its location.
 * ============================================================================
 * CLEAN-ROOM NOTICE:
 *   Written from the written feature description only (intel/paid-list.md
 *   entry #16 "Keyframe Parent", Xrayvision, aescripts, $24.99: "parent,
 *   translate and stretch groups of keyframes inside the AE timeline, treating
 *   a group of keyframes as one object"; details flagged as unverified) plus the
 *   public feature baseline handed down with this task. No decompilation, no
 *   original source, no original resources were used or inspected. All code,
 *   math and structure below are original. "Keyframe Parent" is a commercial
 *   product of its author; this clone is for learning / interoperability
 *   research only.
 *
 * WHAT IT DOES
 *   A "group" = every keyframe currently selected in the timeline, across any
 *   number of layers and properties (numeric and colour properties). The group
 *   is transformed as one rigid/semi-rigid object with a three-parameter
 *   affine map, in *original* coordinates:
 *
 *       time  : t' = tP + (t - tP) * sT + dT
 *       value : v' = vP + (v - vP) * sV + dV      (per component)
 *
 *   tP/vP = the "parent" (anchor) key: either a key the user pins explicitly,
 *   or, per property, that property's earliest selected key. Because dT moves
 *   the parent too, pinning a parent makes the other keys follow it rigidly --
 *   that is the parenting behaviour this tool is named after; sT/sV then
 *   stretch the group *around* the parent.
 *
 *   Tool zones:
 *     1. Capture   -- snapshot the current timeline keyframe selection.
 *     2. Parent    -- pin a key as anchor; snap the group so the anchor key
 *                     lands on a typed time (rigid move, children follow).
 *     3. Translate -- dT (seconds) and dV (x/y/z value units).
 *     4. Stretch   -- sT and sV in percent, optional "keep ratio" link.
 *     5. Commit    -- live preview / apply / restore.
 *
 * IMPLEMENTATION NOTE (why delete + rebuild):
 *   AE exposes no "move this keyframe to another time" call; setValueAtKey()
 *   only changes the value, and setValueAtTime() at an occupied time would
 *   overwrite a neighbouring key. So every write snapshots the group, removes
 *   the selected keys (descending index), re-creates them at the computed
 *   times and then restores interpolation + temporal ease (+ spatial tangents
 *   where applicable). The snapshot is immutable: every preview is recomputed
 *   from the ORIGINAL keys, so repeated slider releases never compound.
 *
 * API NOTE: every AE name used below is cross-checked against
 *   docs/api-cheatsheet.md -- propertyValueType (OneD/TwoD/TwoD_SPATIAL/
 *   ThreeD/ThreeD_SPATIAL/COLOR), selectedKeys (1-based, manual sort), numKeys,
 *   keyTime, keyValue, keyIn/OutInterpolationType, keyIn/OutTemporalEase,
 *   keyIn/OutSpatialTangent, setInterpolationTypeAtKey, setTemporalEaseAtKey
 *   (both sides always passed), setSpatialTangentsAtKey, setValueAtTime,
 *   removeKey (the only documented removal call), nearestKeyIndex,
 *   KeyframeEase(speed, influence), beginUndoGroup/endUndoGroup in
 *   try/finally pairs.
 *   Roving keys are deliberately NOT restored (see README limitations).
 *
 * ES3 / ExtendScript. Run from File > Scripts or install as a ScriptUI Panel.
 * ============================================================================
 */

(function KPClone(thisObj) {

    var SCRIPT_NAME = 'Keyframe Parent Clone';
    var SCRIPT_VER = '1.0.0';
    var ORIG_NAME = 'Keyframe Parent (Xrayvision, aescripts, $24.99)';

    var MIN_GAP = 0.0005; // smallest allowed gap between two keyframes (seconds)
    var MAX_KEYS = 600;   // safety cap: keys per capture
    var MAX_PROPS = 40;   // safety cap: properties per capture

    // ------------------------------------------------------------------
    // state
    // ------------------------------------------------------------------
    // S.groups[] = {
    //     p        : Property
    //     name     : display label ("#1 Position")
    //     kind     : 'numeric' | 'color'
    //     dim      : 1..3 (runtime dimension, colour = 3)
    //     spatial  : bool (2D/3D spatial -> tangents exist)
    //     orig     : immutable snapshot [{t, v, inT, outT, inE, outE, inS, outS}]
    //     cur      : live index map [{k, t}] used to delete before a rebuild
    // }
    var S = {
        groups: [],
        parentG: -1,
        parentI: -1,
        dT: 0, dX: 0, dY: 0, dZ: 0,
        sT: 1, sV: 1,
        captured: false
    };

    // UI control bag (filled by buildUI)
    var ui = {};

    // ------------------------------------------------------------------
    // small utils
    // ------------------------------------------------------------------

    function getComp() {
        var it = null;
        try { it = app.project ? app.project.activeItem : null; } catch (e) { it = null; }
        if (it !== null && it !== undefined && it instanceof CompItem) { return it; }
        return null;
    }

    function num(s, fallback) {
        var v = parseFloat(String(s));
        return isNaN(v) ? fallback : v;
    }

    function fmtn(x, dec) {
        var m = Math.pow(10, dec);
        var r = Math.round(x * m) / m;
        return String(r);
    }

    function timeStr(t) {
        var sign = (t < 0) ? '-' : '';
        var a = Math.abs(t);
        var m = Math.floor(a / 60);
        var s = a - m * 60;
        var ss = (Math.round(s * 1000) / 1000);
        return sign + m + ':' + (ss < 10 ? '0' : '') + ss;
    }

    function clamp(x, lo, hi) {
        if (x < lo) { return lo; }
        if (x > hi) { return hi; }
        return x;
    }

    // ------------------------------------------------------------------
    // property type helpers
    // ------------------------------------------------------------------

    function valueTypeOf(p) {
        try { return p.propertyValueType; } catch (e) { return null; }
    }

    function kindOf(p) {
        var vt = valueTypeOf(p);
        if (vt === PropertyValueType.OneD || vt === PropertyValueType.TwoD ||
            vt === PropertyValueType.TwoD_SPATIAL || vt === PropertyValueType.ThreeD ||
            vt === PropertyValueType.ThreeD_SPATIAL) {
            return 'numeric';
        }
        if (vt === PropertyValueType.COLOR) { return 'color'; }
        return 'other'; // SHAPE / TEXT_DOCUMENT / MARKER / CUSTOM_VALUE / NO_VALUE
    }

    function dimOf(p) {
        var vt = valueTypeOf(p);
        if (vt === PropertyValueType.OneD) { return 1; }
        if (vt === PropertyValueType.TwoD || vt === PropertyValueType.TwoD_SPATIAL) { return 2; }
        if (vt === PropertyValueType.ThreeD || vt === PropertyValueType.ThreeD_SPATIAL) { return 3; }
        if (vt === PropertyValueType.COLOR) { return 3; }
        return 0;
    }

    function isSpatialType(p) {
        var vt = valueTypeOf(p);
        return vt === PropertyValueType.TwoD_SPATIAL || vt === PropertyValueType.ThreeD_SPATIAL;
    }

    function labelOf(p, gi) {
        var nm = '';
        try { nm = String(p.name); } catch (e) { nm = 'property'; }
        return '#' + (gi + 1) + ' ' + nm;
    }

    // ------------------------------------------------------------------
    // collecting the selection
    // ------------------------------------------------------------------

    function addIfKeyed(p, out) {
        if (p === null || p === undefined) { return; }
        var sk = null;
        try { sk = p.selectedKeys; } catch (e) { return; }
        if (sk !== null && sk !== undefined && sk.length > 0) { out.push(p); }
    }

    function walkProps(group, depth, out) {
        if (depth > 5 || out.length >= MAX_PROPS) { return; }
        var n = 0;
        try { n = group.numProperties; } catch (e) { return; }
        var i;
        for (i = 1; i <= n; i++) {
            var p = null;
            try { p = group.property(i); } catch (e2) { continue; }
            if (p === null || p === undefined) { continue; }
            var nk = undefined;
            try { nk = p.numKeys; } catch (e3) { nk = undefined; }
            if (typeof nk === 'number') {
                if (nk > 0) { addIfKeyed(p, out); }
            } else {
                // a PropertyGroup: recurse, but never into effect parades
                // (they can be huge; selected effects still show up through
                // comp.selectedProperties above)
                var mn = '';
                try { mn = String(p.matchName); } catch (e4) { mn = ''; }
                if (mn !== 'ADBE Effect Parade') { walkProps(p, depth + 1, out); }
            }
        }
    }

    // Selected properties that actually carry a keyframe selection. Prefers
    // comp.selectedProperties (keeps layers/effects context) and falls back to
    // walking the selected layers' property trees.
    function collectProps(comp) {
        var out = [];
        var sel = null;
        try { sel = comp.selectedProperties; } catch (e) { sel = null; }
        var i;
        if (sel !== null && sel !== undefined && sel.length > 0) {
            for (i = 0; i < sel.length; i++) { addIfKeyed(sel[i], out); }
        }
        if (out.length === 0) {
            var layers = null;
            try { layers = comp.selectedLayers; } catch (e2) { layers = null; }
            if (layers !== null && layers !== undefined) {
                for (i = 0; i < layers.length; i++) {
                    try { walkProps(layers[i], 0, out); } catch (e3) { /* skip layer */ }
                }
            }
        }
        return out;
    }

    // ------------------------------------------------------------------
    // snapshot
    // ------------------------------------------------------------------

    function sortItemsByTime(items) {
        var i, j;
        for (i = 1; i < items.length; i++) {
            var cur = items[i];
            j = i - 1;
            while (j >= 0 && items[j].t > cur.t) { items[j + 1] = items[j]; j--; }
            items[j + 1] = cur;
        }
    }

    function snapGroup(p, gi) {
        var kind = kindOf(p);
        if (kind === 'other') { return null; }   // value transform undefined -> skip
        var sk = null;
        try { sk = p.selectedKeys; } catch (e) { return null; }
        if (sk === null || sk === undefined || sk.length === 0) { return null; }

        var items = [];
        var i;
        for (i = 0; i < sk.length; i++) {
            var k = sk[i];
            // keep the keyframe index on the item itself: the array is sorted by
            // time right below, so a positional mapping back to sk[] would break.
            var it = { k: k, t: 0, v: null, inT: null, outT: null, inE: null, outE: null, inS: null, outS: null };
            try { it.t = p.keyTime(k); } catch (eT) { continue; }
            try { it.v = p.keyValue(k); } catch (eV) { continue; }
            try { it.inT = p.keyInInterpolationType(k); } catch (e1) { it.inT = null; }
            try { it.outT = p.keyOutInterpolationType(k); } catch (e2) { it.outT = null; }
            try { it.inE = p.keyInTemporalEase(k); } catch (e3) { it.inE = null; }
            try { it.outE = p.keyOutTemporalEase(k); } catch (e4) { it.outE = null; }
            items.push(it);
        }
        if (items.length === 0) { return null; }
        sortItemsByTime(items);

        var g = {
            p: p,
            name: labelOf(p, gi),
            kind: kind,
            dim: dimOf(p),
            spatial: isSpatialType(p),
            orig: items,
            cur: []
        };

        for (i = 0; i < items.length; i++) { g.cur.push({ k: items[i].k, t: items[i].t }); }

        // spatial tangents are only readable on 2D/3D spatial properties
        if (g.spatial) {
            for (i = 0; i < items.length; i++) {
                try { items[i].inS = p.keyInSpatialTangent(items[i].k); } catch (e5) { items[i].inS = null; }
                try { items[i].outS = p.keyOutSpatialTangent(items[i].k); } catch (e6) { items[i].outS = null; }
            }
        }
        return g;
    }

    // ------------------------------------------------------------------
    // affine map
    // ------------------------------------------------------------------

    function pivotTimeOf(g, gi) {
        if (S.parentG === gi && S.parentI >= 0 && S.parentI < g.orig.length) {
            return g.orig[S.parentI].t;
        }
        return g.orig[0].t;
    }

    function pivotValueOf(g, gi) {
        if (S.parentG === gi && S.parentI >= 0 && S.parentI < g.orig.length) {
            return g.orig[S.parentI].v;
        }
        return g.orig[0].v;
    }

    function xfValue(v, pv, g) {
        var sv = S.sV;
        if (v === null || v === undefined) { return v; }

        if (g.kind === 'color') {
            var arr = [];
            var n = (v.length !== undefined) ? v.length : 3;
            var c;
            for (c = 0; c < n; c++) {
                if (c === 3) { arr.push(v[3]); continue; } // keep alpha untouched
                var pvc = (pv !== null && pv !== undefined && pv.length !== undefined && pv.length > c) ? pv[c] : v[c];
                var val = pvc + (v[c] - pvc) * sv + S.dX;
                arr.push(clamp(val, 0, 1));
            }
            return arr;
        }

        if (g.kind !== 'numeric') { return v; }

        if (g.dim <= 1) { return pv + (v - pv) * sv + S.dX; }

        var out = [];
        var i;
        for (i = 0; i < g.dim; i++) {
            var vi = (v.length !== undefined) ? v[i] : 0;
            var base = (pv !== null && pv !== undefined && pv.length !== undefined && pv.length > i) ? pv[i] : vi;
            var off = (i === 0) ? S.dX : ((i === 1) ? S.dY : S.dZ);
            out.push(base + (vi - base) * sv + off);
        }
        return out;
    }

    // Ease speeds are dv/dt; a uniform stretch maps them by sV/sT.
    function xfEase(list, ratio) {
        if (list === null || list === undefined) { return null; }
        var out = [];
        var i;
        for (i = 0; i < list.length; i++) {
            var e = list[i];
            var spd = e.speed;
            if (ratio !== 1) { spd = spd * ratio; }
            var inf = e.influence;
            if (!(inf >= 0.1)) { inf = 0.1; }
            if (inf > 100) { inf = 100; }
            out.push(new KeyframeEase(spd, inf));
        }
        return out;
    }

    function buildPlan(g, gi) {
        var pt = pivotTimeOf(g, gi);
        var pv = pivotValueOf(g, gi);
        var plan = [];
        var i;
        for (i = 0; i < g.orig.length; i++) {
            var it = g.orig[i];
            plan.push({
                src: it,
                t: pt + (it.t - pt) * S.sT + S.dT,
                v: xfValue(it.v, pv, g)
            });
        }
        return plan;
    }

    // Times of keyframes that are NOT part of the group (they will stay put
    // and must not be overwritten).
    function otherTimes(g) {
        var out = [];
        var n = 0;
        try { n = g.p.numKeys; } catch (e) { return out; }
        var i, j;
        for (i = 1; i <= n; i++) {
            var isSel = false;
            for (j = 0; j < g.cur.length; j++) {
                if (g.cur[j].k === i) { isSel = true; break; }
            }
            if (!isSel) {
                try { out.push(g.p.keyTime(i)); } catch (e2) { /* ignore */ }
            }
        }
        return out;
    }

    // Returns an error string or null.
    function validatePlan(g, plan) {
        var i, j;
        for (i = 1; i < plan.length; i++) {
            if (!(plan[i].t - plan[i - 1].t >= MIN_GAP)) {
                return 'time scale too small: keyframes would collide (raise the time scale)';
            }
        }
        var others = otherTimes(g);
        for (i = 0; i < plan.length; i++) {
            for (j = 0; j < others.length; j++) {
                if (Math.abs(others[j] - plan[i].t) < MIN_GAP) {
                    return 'target time ' + timeStr(plan[i].t) +
                        ' is already used by a keyframe outside the group';
                }
            }
        }
        return null;
    }

    // ------------------------------------------------------------------
    // write one property
    // ------------------------------------------------------------------

    function rescaleEaseOn() {
        if (ui.rescaleEase === undefined || ui.rescaleEase === null) { return false; }
        return !!ui.rescaleEase.value;
    }

    function writeGroup(g, gi, stats) {
        var plan = buildPlan(g, gi);
        var bad = validatePlan(g, plan);
        if (bad !== null) {
            stats.errors.push(g.name + ': ' + bad);
            return false;
        }

        // 1. remove the current keys, highest index first
        var ks = [];
        var i;
        for (i = 0; i < g.cur.length; i++) { ks.push(g.cur[i].k); }
        ks.sort(function (a, b) { return b - a; });
        for (i = 0; i < ks.length; i++) {
            try {
                g.p.removeKey(ks[i]);
            } catch (eD) {
                stats.errors.push(g.name + ': removeKey(' + ks[i] + ') ' + eD.toString());
            }
        }

        var ratio = 1;
        if (rescaleEaseOn()) {
            if (S.sT > 0) { ratio = S.sV / S.sT; }
        }

        // 2. re-create at the computed times, ascending
        var newCur = [];
        for (i = 0; i < plan.length; i++) {
            var e = plan[i];
            var nt = e.t;
            var ni = -1;

            try {
                g.p.setValueAtTime(nt, e.v);
            } catch (eW) {
                stats.errors.push(g.name + ': insert @' + timeStr(nt) + ' ' + eW.toString());
                continue;
            }
            try { ni = g.p.nearestKeyIndex(nt); } catch (eN) { ni = -1; }
            if (ni < 0) {
                stats.errors.push(g.name + ': key lost after insert @' + timeStr(nt));
                continue;
            }
            var got = -1;
            try { got = g.p.keyTime(ni); } catch (eG) { got = -1; }
            if (Math.abs(got - nt) > 0.01) {
                stats.errors.push(g.name + ': key not found at ' + timeStr(nt) + ' after insert');
                continue;
            }

            // 3. restore interpolation, temporal ease, spatial tangents
            if (e.src.inT !== null && e.src.outT !== null) {
                try { g.p.setInterpolationTypeAtKey(ni, e.src.inT, e.src.outT); } catch (eI) { /* hold/rules */ }
            }
            if (e.src.inE !== null && e.src.outE !== null) {
                var inE = xfEase(e.src.inE, ratio);
                var outE = xfEase(e.src.outE, ratio);
                if (inE !== null && outE !== null) {
                    try { g.p.setTemporalEaseAtKey(ni, inE, outE); } catch (eE) { /* HOLD keys */ }
                }
            }
            if (g.spatial && e.src.inS !== null && e.src.outS !== null) {
                try { g.p.setSpatialTangentsAtKey(ni, e.src.inS, e.src.outS); } catch (eT) { /* ignored */ }
            }

            newCur.push({ k: ni, t: nt });
            stats.keys++;
        }

        g.cur = newCur;
        stats.props++;
        return true;
    }

    // ------------------------------------------------------------------
    // top-level apply
    // ------------------------------------------------------------------

    function applyAll(label) {
        var stats = { keys: 0, props: 0, errors: [] };
        if (!S.captured || S.groups.length === 0) {
            return { ok: false, msg: 'Nothing captured yet -- select keyframes, then press Capture.', errors: [] };
        }
        app.beginUndoGroup(SCRIPT_NAME + ': ' + label);
        try {
            var gi;
            for (gi = 0; gi < S.groups.length; gi++) {
                var g = S.groups[gi];
                try {
                    writeGroup(g, gi, stats);
                } catch (eG) {
                    stats.errors.push(g.name + ': ' + eG.toString());
                }
            }
        } finally {
            app.endUndoGroup();
        }
        return {
            ok: true,
            msg: stats.keys + ' key(s) in ' + stats.props + ' propert' + (stats.props === 1 ? 'y' : 'ies'),
            errors: stats.errors
        };
    }

    // ------------------------------------------------------------------
    // capture
    // ------------------------------------------------------------------

    function doCapture() {
        S.groups = [];
        S.parentG = -1;
        S.parentI = -1;
        S.captured = false;
        S.dT = 0; S.dX = 0; S.dY = 0; S.dZ = 0;
        S.sT = 1; S.sV = 1;

        var comp = getComp();
        if (comp === null) { return { ok: false, msg: 'Open a composition first.' }; }

        var props = collectProps(comp);
        if (props.length === 0) {
            return { ok: false, msg: 'No keyframes selected in the timeline. Select keyframes first.' };
        }

        var skipped = 0;
        var total = 0;
        var i;
        for (i = 0; i < props.length && S.groups.length < MAX_PROPS; i++) {
            var g = null;
            try { g = snapGroup(props[i], S.groups.length); } catch (e) { g = null; }
            if (g === null) { skipped++; continue; }
            if (total + g.orig.length > MAX_KEYS) { skipped++; continue; }
            total += g.orig.length;
            S.groups.push(g);
        }

        S.captured = (S.groups.length > 0);
        S.parentG = 0;
        S.parentI = 0;

        var msg = S.captured
            ? 'Captured ' + total + ' key(s) in ' + S.groups.length + ' properties.'
            : 'Nothing usable selected (only numeric / colour properties are supported).';
        if (skipped > 0) { msg += ' ' + skipped + ' unsupported property(ies) skipped.'; }
        return { ok: S.captured, msg: msg };
    }

    // ------------------------------------------------------------------
    // UI
    // ------------------------------------------------------------------

    // One numeric row: label + edittext + slider. row.key indexes S;
    // row.mul converts the displayed number into the state unit
    // (0.01 for percentages), row.sliderScale converts it to slider ticks.
    function makeNumRow(parent, label, key, mul, sliderScale, sliderMin, sliderMax, dec) {
        var row = parent.add('group');
        row.orientation = 'row';
        row.alignChildren = ['left', 'center'];
        row.spacing = 4;

        var lab = row.add('statictext', undefined, label);
        lab.preferredSize.width = 96;

        var ed = row.add('edittext', undefined, '0');
        ed.characters = 8;

        var sl = row.add('slider', undefined, 0, 0, sliderMin, sliderMax);
        sl.preferredSize.width = 132;

        var rec = {
            key: key, mul: mul, sliderScale: sliderScale,
            min: sliderMin / sliderScale, max: sliderMax / sliderScale,
            dec: dec, edit: ed, slider: sl, lastUser: 0
        };

        ed.onChange = function () {
            var user = num(ed.text, rec.lastUser);
            user = clamp(user, rec.min, rec.max);
            rec.lastUser = user;
            S[rec.key] = user * rec.mul;
            if (key === 'sT' && ui.chkLink !== undefined && ui.chkLink.value) {
                S.sV = S.sT;
            }
            refreshFields();
            doCommit('edit');
        };

        sl.onChanging = function () {
            var user = sl.value / rec.sliderScale;
            rec.lastUser = user;
            ed.text = fmtn(user, dec);
        };

        sl.onClick = function () {
            var user = sl.value / rec.sliderScale;
            rec.lastUser = user;
            ed.text = fmtn(user, dec);
            S[rec.key] = user * rec.mul;
            if (key === 'sT' && ui.chkLink !== undefined && ui.chkLink.value) {
                S.sV = S.sT;
            }
            refreshFields();
            doCommit('slider');
        };

        return rec;
    }

    function refreshFields() {
        var rows = [ui.rowT, ui.rowX, ui.rowY, ui.rowZ, ui.rowST, ui.rowSV];
        var i;
        for (i = 0; i < rows.length; i++) {
            var r = rows[i];
            if (r === undefined || r === null) { continue; }
            var user = S[r.key] / r.mul;
            r.lastUser = user;
            r.edit.text = fmtn(user, r.dec);
            var tick = Math.round(user * r.sliderScale);
            r.slider.value = clamp(tick, r.slider.minvalue, r.slider.maxvalue);
        }
    }

    function renderStatus(r) {
        var s;
        if (!r.ok) {
            s = r.msg;
        } else {
            s = r.msg +
                '\n dT ' + fmtn(S.dT, 3) + 's   dV ' + fmtn(S.dX, 1) + ' / ' + fmtn(S.dY, 1) + ' / ' + fmtn(S.dZ, 1) +
                '\n scale  time ' + fmtn(S.sT * 100, 1) + '%   value ' + fmtn(S.sV * 100, 1) + '%' +
                '\n parent  ' + parentLabel();
            if (r.errors && r.errors.length > 0) {
                s += '\n! ' + r.errors.length + ' issue(s): ' + r.errors[0];
                if (r.errors.length > 1) { s += '  (+' + (r.errors.length - 1) + ' more)'; }
            }
        }
        ui.status.text = s;
    }

    function parentLabel() {
        if (S.parentG < 0 || S.parentG >= S.groups.length) { return '(auto: earliest key)'; }
        var g = S.groups[S.parentG];
        if (S.parentI < 0 || S.parentI >= g.orig.length) { return '(auto: earliest key)'; }
        return g.name + ' @ ' + timeStr(g.orig[S.parentI].t);
    }

    // Live preview is a write, so it is gated by the checkbox; explicit
    // buttons (Preview / Apply / Restore / parent actions) always write.
    function doCommit(label) {
        if (ui.chkLink !== undefined && ui.chkLink !== null && ui.chkLink.value) { S.sV = S.sT; }
        var gated = (label === 'edit' || label === 'slider');
        if (gated && ui.chkLive !== undefined && ui.chkLive !== null && !ui.chkLive.value) {
            renderStatus({ ok: true, msg: 'Pending (live preview off) -- press Preview or Apply.', errors: [] });
            return;
        }
        try {
            var r = applyAll(label);
            renderStatus(r);
        } catch (e) {
            renderStatus({ ok: false, msg: 'Write failed: ' + e.toString(), errors: [] });
        }
    }

    function refreshParentList() {
        var dd = ui.parentDD;
        dd.removeAll();
        ui.flat = [];
        dd.add('item', '(auto) earliest key of each property');
        var gi, i;
        for (gi = 0; gi < S.groups.length; gi++) {
            var g = S.groups[gi];
            for (i = 0; i < g.orig.length; i++) {
                ui.flat.push({ g: gi, i: i });
                dd.add('item', g.name + '  @ ' + timeStr(g.orig[i].t));
            }
        }
        dd.selection = 0;
        if (S.parentG >= 0 && S.parentG < S.groups.length) {
            var j;
            for (j = 0; j < ui.flat.length; j++) {
                if (ui.flat[j].g === S.parentG && ui.flat[j].i === S.parentI) {
                    dd.selection = j + 1;
                    break;
                }
            }
        }
    }

    function buildUI(thisObj) {
        var win = (thisObj instanceof Panel) ? thisObj
            : new Window('palette', SCRIPT_NAME + ' v' + SCRIPT_VER, undefined, { resizeable: true });
        win.orientation = 'column';
        win.alignChildren = ['fill', 'top'];
        win.spacing = 5;
        win.margins = 10;

        var decl = win.add('statictext', undefined,
            'Clean-room reimplementation inspired by the public description of ' + ORIG_NAME + '. No original code used.',
            { truncate: true });
        decl.maximumSize.width = 420;

        // ---- zone 1: capture ----
        var p1 = win.add('panel', undefined, '1. Scope');
        p1.orientation = 'column';
        p1.alignChildren = ['left', 'top'];
        p1.margins = [10, 6, 10, 8];
        p1.spacing = 4;
        var g1a = p1.add('group');
        g1a.orientation = 'row';
        g1a.alignChildren = ['left', 'center'];
        g1a.spacing = 6;
        var btnCap = g1a.add('button', undefined, 'Capture selection');
        btnCap.preferredSize = [130, 26];
        var lblScope = g1a.add('statictext', undefined, 'nothing captured yet');
        lblScope.preferredSize.width = 240;
        ui.lblScope = lblScope;

        // ---- zone 2: parent ----
        var p2 = win.add('panel', undefined, '2. Parent (anchor key)');
        p2.orientation = 'column';
        p2.alignChildren = ['left', 'top'];
        p2.margins = [10, 6, 10, 8];
        p2.spacing = 4;

        var g2a = p2.add('group');
        g2a.orientation = 'row';
        g2a.alignChildren = ['left', 'center'];
        g2a.spacing = 6;
        var l2 = g2a.add('statictext', undefined, 'key');
        l2.preferredSize.width = 30;
        var ddParent = g2a.add('dropdownlist', undefined, ['(auto) earliest key of each property']);
        ddParent.preferredSize.width = 300;
        ddParent.selection = 0;
        ui.parentDD = ddParent;
        ui.flat = [];

        var g2b = p2.add('group');
        g2b.orientation = 'row';
        g2b.alignChildren = ['left', 'center'];
        g2b.spacing = 6;
        var btnSetParent = g2b.add('button', undefined, 'Set parent');
        btnSetParent.preferredSize = [100, 26];
        var btnClearParent = g2b.add('button', undefined, 'Clear');
        btnClearParent.preferredSize = [70, 26];
        var btnSnap = g2b.add('button', undefined, 'Move group so parent sits at');
        btnSnap.preferredSize = [200, 26];
        var etTarget = g2b.add('edittext', undefined, '0.00');
        etTarget.characters = 7;
        var lbS = g2b.add('statictext', undefined, 's');
        lbS.preferredSize.width = 10;
        ui.etTarget = etTarget;

        // ---- zone 3: translate ----
        var p3 = win.add('panel', undefined, '3. Translate group');
        p3.orientation = 'column';
        p3.alignChildren = ['left', 'top'];
        p3.margins = [10, 6, 10, 8];
        p3.spacing = 4;
        ui.rowT = makeNumRow(p3, 'time offset (s)', 'dT', 1, 100, -500, 500, 3);
        ui.rowX = makeNumRow(p3, 'value X', 'dX', 1, 1, -500, 500, 2);
        ui.rowY = makeNumRow(p3, 'value Y', 'dY', 1, 1, -500, 500, 2);
        ui.rowZ = makeNumRow(p3, 'value Z', 'dZ', 1, 1, -500, 500, 2);

        // ---- zone 4: stretch ----
        var p4 = win.add('panel', undefined, '4. Stretch group');
        p4.orientation = 'column';
        p4.alignChildren = ['left', 'top'];
        p4.margins = [10, 6, 10, 8];
        p4.spacing = 4;
        ui.rowST = makeNumRow(p4, 'time scale %', 'sT', 0.01, 1, 10, 400, 1);
        ui.rowSV = makeNumRow(p4, 'value scale %', 'sV', 0.01, 1, 10, 400, 1);

        var g4c = p4.add('group');
        g4c.orientation = 'row';
        g4c.alignChildren = ['left', 'center'];
        g4c.spacing = 12;
        var chkLink = g4c.add('checkbox', undefined, 'keep ratio (value scale = time scale)');
        ui.chkLink = chkLink;
        var chkEase = g4c.add('checkbox', undefined, 'rescale ease speeds');
        chkEase.value = true;
        ui.rescaleEase = chkEase;

        // ---- zone 5: commit ----
        var p5 = win.add('panel', undefined, '5. Preview / apply');
        p5.orientation = 'column';
        p5.alignChildren = ['left', 'top'];
        p5.margins = [10, 6, 10, 8];
        p5.spacing = 4;
        var g5a = p5.add('group');
        g5a.orientation = 'row';
        g5a.alignChildren = ['left', 'center'];
        g5a.spacing = 6;
        var btnPreview = g5a.add('button', undefined, 'Preview');
        btnPreview.preferredSize = [90, 26];
        var btnApply = g5a.add('button', undefined, 'Apply');
        btnApply.preferredSize = [90, 26];
        var btnRestore = g5a.add('button', undefined, 'Restore');
        btnRestore.preferredSize = [90, 26];
        var chkLive = g5a.add('checkbox', undefined, 'live preview on slider release');
        chkLive.value = true;
        ui.chkLive = chkLive;

        var status = win.add('statictext', undefined,
            SCRIPT_NAME + ' v' + SCRIPT_VER + ' ready. Original: ' + ORIG_NAME, { multiline: true });
        status.preferredSize = [420, 80];
        ui.status = status;

        // ---- wiring ----
        btnCap.onClick = function () {
            try {
                var r = doCapture();
                if (!r.ok) { status.text = r.msg; alert(r.msg); return; }
                refreshParentList();
                refreshFields();
                lblScope.text = r.msg;
                status.text = r.msg + '\nAdjust the sliders, then Apply.';
            } catch (e) {
                status.text = 'Capture failed: ' + e.toString();
            }
        };

        btnSetParent.onClick = function () {
            if (!S.captured) { alert('Capture a keyframe group first.'); return; }
            var sel = ddParent.selection;
            if (sel === null || sel === undefined) { return; }
            var idx = sel.index;
            if (idx === 0) {
                S.parentG = -1;
                S.parentI = -1;
            } else {
                var f = ui.flat[idx - 1];
                if (f === undefined) { return; }
                S.parentG = f.g;
                S.parentI = f.i;
            }
            doCommit('set parent');
        };

        btnClearParent.onClick = function () {
            S.parentG = -1;
            S.parentI = -1;
            if (ddParent.items.length > 0) { ddParent.selection = 0; }
            doCommit('clear parent');
        };

        btnSnap.onClick = function () {
            if (!S.captured) { alert('Capture a keyframe group first.'); return; }
            if (S.parentG < 0) { alert('Pin a parent key first: pick one in the list and press Set parent.'); return; }
            var t = num(etTarget.text, NaN);
            if (isNaN(t)) { alert('Target time must be a number (seconds).'); return; }
            var g = S.groups[S.parentG];
            if (S.parentI < 0 || S.parentI >= g.orig.length) { alert('Parent key is out of range; Set parent again.'); return; }
            S.dT = t - g.orig[S.parentI].t;
            refreshFields();
            doCommit('snap parent to ' + fmtn(t, 3) + 's');
        };

        btnPreview.onClick = function () { doCommit('preview'); };

        btnApply.onClick = function () {
            if (!S.captured) { alert('Capture a keyframe group first.'); return; }
            doCommit('apply');
        };

        btnRestore.onClick = function () {
            if (!S.captured) { alert('Capture a keyframe group first.'); return; }
            S.dT = 0; S.dX = 0; S.dY = 0; S.dZ = 0;
            S.sT = 1; S.sV = 1;
            refreshFields();
            doCommit('restore');
        };

        refreshFields();

        if (win instanceof Window) {
            win.center();
            win.show();
        } else {
            win.layout.layout(true);
            win.layout.resize();
        }
        win.onResizing = win.onResize = function () { this.layout.resize(); };
        return win;
    }

    // ------------------------------------------------------------------
    // main
    // ------------------------------------------------------------------

    function kpMain() {
        if (typeof app === 'undefined' || app === null || app.project === null) {
            alert('Open an After Effects project first.', SCRIPT_NAME);
            return;
        }
        try {
            buildUI(thisObj);
        } catch (e) {
            alert(SCRIPT_NAME + ' failed to start:\n' + e.toString(), SCRIPT_NAME);
        }
    }

    kpMain();

})(this);
