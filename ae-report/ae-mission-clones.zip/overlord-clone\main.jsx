#target aftereffects

/**************************************************************************
 * Overlord Clone (one-way: SVG -> AE shapes)  v1.0.0
 * ------------------------------------------------------------------------
 * CLEAN-ROOM REIMPLEMENTATION NOTICE:
 * Written from scratch from the public documentation of the commercial
 * tool (help.battleaxe.co/overlord: shapes not files, fill/stroke/name/
 * group/hierarchy preserved, update shapes in place) plus general AE
 * Scripting API knowledge. No original source, installer, binary or
 * resource of the product was obtained, inspected or referenced.
 *
 * SCOPE: ONE WAY ONLY, SVG -> AE shape layers.
 *   The Ai -> AE CEP channel, the AE -> Ai direction, and the Photoshop /
 *   Figma channels are out of scope (they need a second host extension).
 *   Input is an .svg file or pasted SVG markup.
 * ------------------------------------------------------------------------
 * ES3 / ExtendScript only. ASCII-only source on purpose.
 * There is no DOMParser in ExtendScript, so the whole SVG parser here is
 * hand written: a tag tokenizer + a mini path-data interpreter.
 **************************************************************************/

(function overlordClone(thisObj) {

    var SCRIPT_NAME = "Overlord Clone (SVG to AE)";
    var VERSION = "1.0.0";

    /* ==================================================================
     *  Matrix helpers  [a b c d e f]
     * ================================================================== */

    function matMul(m1, m2) {
        // result = m1 after m2
        return [
            m1[0] * m2[0] + m1[2] * m2[1],
            m1[1] * m2[0] + m1[3] * m2[1],
            m1[0] * m2[2] + m1[2] * m2[3],
            m1[1] * m2[2] + m1[3] * m2[3],
            m1[0] * m2[4] + m1[2] * m2[5] + m1[4],
            m1[1] * m2[4] + m1[3] * m2[5] + m1[5]
        ];
    }

    function xfPoint(m, p) {
        return [m[0] * p[0] + m[2] * p[1] + m[4], m[1] * p[0] + m[3] * p[1] + m[5]];
    }

    function xfVector(m, p) {
        return [m[0] * p[0] + m[2] * p[1], m[1] * p[0] + m[3] * p[1]];
    }

    function parseNumberList(s) {
        var out = [];
        var re = /[-+]?(?:\d*\.\d+|\d+\.?)(?:[eE][-+]?\d+)?/g;
        var m;
        while ((m = re.exec(s)) !== null) {
            out.push(parseFloat(m[0]));
        }
        return out;
    }

    function parseTransform(str, warn) {
        var m = [1, 0, 0, 1, 0, 0];
        if (!str) { return m; }
        var re = /([a-zA-Z]+)\s*\(([^)]*)\)/g;
        var hit;
        while ((hit = re.exec(str)) !== null) {
            var fn = hit[1].toLowerCase();
            var a = parseNumberList(hit[2]);
            var t = [1, 0, 0, 1, 0, 0];
            if (fn === "translate") {
                t = [1, 0, 0, 1, a[0] || 0, a.length > 1 ? a[1] : 0];
            } else if (fn === "scale") {
                var sx = (a[0] === undefined) ? 1 : a[0];
                var sy = (a.length > 1) ? a[1] : sx;
                t = [sx, 0, 0, sy, 0, 0];
            } else if (fn === "rotate") {
                var ang = (a[0] || 0) * Math.PI / 180;
                var cx = a.length > 2 ? a[1] : 0;
                var cy = a.length > 2 ? a[2] : 0;
                var cos = Math.cos(ang);
                var sin = Math.sin(ang);
                t = [cos, sin, -sin, cos, cx - cos * cx + sin * cy, cy - sin * cx - cos * cy];
            } else if (fn === "matrix" && a.length >= 6) {
                t = [a[0], a[1], a[2], a[3], a[4], a[5]];
            } else if (fn === "skewx" || fn === "skewy") {
                warn("skew transform downgraded to identity");
            }
            m = matMul(m, t);
        }
        return m;
    }

    /* ==================================================================
     *  Tag tokenizer + tree
     * ================================================================== */

    function stripNoise(src) {
        var s = src;
        s = s.replace(/<!--[\s\S]*?-->/g, "");
        s = s.replace(/<\?[\s\S]*?\?>/g, "");
        s = s.replace(/<!DOCTYPE[^>]*>/gi, "");
        return s;
    }

    function parseAttrs(tagText) {
        var attrs = {};
        var re = /([A-Za-z_:][-A-Za-z0-9_:.]*)\s*=\s*("([^"]*)"|'([^']*)')/g;
        var m;
        while ((m = re.exec(tagText)) !== null) {
            var key = m[1];
            var val = (m[3] !== undefined) ? m[3] : (m[4] !== undefined ? m[4] : "");
            attrs[key] = val;
        }
        return attrs;
    }

    // Returns a tree of {name, attrs, children}.
    function parseSvg(src) {
        var text = stripNoise(src);
        var root = { name: "#root", attrs: {}, children: [] };
        var stack = [root];
        var re = /<(\/?)([A-Za-z][A-Za-z0-9:_.-]*)((?:"[^"]*"|'[^']*'|[^>"'])*?)(\/?)>/g;
        var m;
        while ((m = re.exec(text)) !== null) {
            var closing = (m[1] === "/");
            var name = m[2];
            var attrs = closing ? {} : parseAttrs(m[3]);
            var selfClose = (m[4] === "/");

            if (closing) {
                // pop to matching element
                var i;
                for (i = stack.length - 1; i > 0; i--) {
                    if (stack[i].name === name) {
                        stack.length = i;
                        break;
                    }
                }
                continue;
            }

            var node = { name: name, attrs: attrs, children: [] };
            stack[stack.length - 1].children.push(node);
            if (!selfClose) { stack.push(node); }
        }
        return root;
    }

    function firstChildByName(node, name) {
        var i;
        for (i = 0; i < node.children.length; i++) {
            if (node.children[i].name === name) { return node.children[i]; }
        }
        return null;
    }

    function findAll(node, name, out) {
        var i;
        for (i = 0; i < node.children.length; i++) {
            if (node.children[i].name === name) { out.push(node.children[i]); }
            findAll(node.children[i], name, out);
        }
        return out;
    }

    /* ==================================================================
     *  Path data interpreter
     * ================================================================== */

    function tokenizePath(d) {
        var re = /([MmLlHhVvCcSsQqTtAaZz])|([-+]?(?:\d*\.\d+|\d+\.?)(?:[eE][-+]?\d+)?)/g;
        var out = [];
        var cur = null;
        var m;
        while ((m = re.exec(d)) !== null) {
            if (m[1]) {
                cur = { cmd: m[1], args: [] };
                out.push(cur);
            } else if (m[2] !== undefined && cur) {
                cur.args.push(parseFloat(m[2]));
            }
        }
        return out;
    }

    function makeContour() {
        return { v: [], inT: [], outT: [], closed: false };
    }

    function pushPoint(c, p) {
        c.v.push(p);
        c.inT.push([0, 0]);
        c.outT.push([0, 0]);
    }

    function lastPoint(c) {
        return c.v[c.v.length - 1];
    }

    function isCommandName(tok) {
        return tok.cmd !== undefined;
    }

    // Converts SVG path data into contour objects with cubic tangents.
    function parsePathData(d, warn) {
        var toks = tokenizePath(d);
        var contours = [];
        var c = null;
        var cx = 0;
        var cy = 0;
        var startX = 0;
        var startY = 0;
        var prevCtrl = null;
        var prevCmd = "";
        var i = 0;

        function ensureContour() {
            if (!c) {
                c = makeContour();
                contours.push(c);
                pushPoint(c, [cx, cy]);
            }
            return c;
        }

        function cubic(p1, p2, p3) {
            ensureContour();
            var last = c.v.length - 1;
            c.outT[last] = [p1[0] - c.v[last][0], p1[1] - c.v[last][1]];
            pushPoint(c, p3);
            var idx = c.v.length - 1;
            c.inT[idx] = [p2[0] - p3[0], p2[1] - p3[1]];
        }

        while (i < toks.length) {
            var tok = toks[i];
            var cmd = tok.cmd;
            var rel = (cmd >= "a" && cmd <= "z");
            var up = cmd.toUpperCase();
            var a = tok.args;
            var n = 0;
            i++;

            if (up === "M") {
                n = 2;
                while (a.length >= 2) {
                    var mx = a[0] + (rel ? cx : 0);
                    var my = a[1] + (rel ? cy : 0);
                    c = makeContour();
                    contours.push(c);
                    pushPoint(c, [mx, my]);
                    cx = mx; cy = my;
                    startX = mx; startY = my;
                    a = a.slice(2);
                    // subsequent pairs are implicit lineto
                    if (a.length >= 2) {
                        while (a.length >= 2) {
                            var lx = a[0] + (rel ? cx : 0);
                            var ly = a[1] + (rel ? cy : 0);
                            pushPoint(c, [lx, ly]);
                            cx = lx; cy = ly;
                            a = a.slice(2);
                        }
                    }
                }
                prevCtrl = null;
            } else if (up === "L") {
                while (a.length >= 2) {
                    var lx2 = a[0] + (rel ? cx : 0);
                    var ly2 = a[1] + (rel ? cy : 0);
                    ensureContour();
                    pushPoint(c, [lx2, ly2]);
                    cx = lx2; cy = ly2;
                    a = a.slice(2);
                }
                prevCtrl = null;
            } else if (up === "H") {
                while (a.length >= 1) {
                    var hx = a[0] + (rel ? cx : 0);
                    ensureContour();
                    pushPoint(c, [hx, cy]);
                    cx = hx;
                    a = a.slice(1);
                }
                prevCtrl = null;
            } else if (up === "V") {
                while (a.length >= 1) {
                    var vy = a[0] + (rel ? cy : 0);
                    ensureContour();
                    pushPoint(c, [cx, vy]);
                    cy = vy;
                    a = a.slice(1);
                }
                prevCtrl = null;
            } else if (up === "C") {
                while (a.length >= 6) {
                    var p1 = [a[0] + (rel ? cx : 0), a[1] + (rel ? cy : 0)];
                    var p2 = [a[2] + (rel ? cx : 0), a[3] + (rel ? cy : 0)];
                    var p3 = [a[4] + (rel ? cx : 0), a[5] + (rel ? cy : 0)];
                    cubic(p1, p2, p3);
                    cx = p3[0]; cy = p3[1];
                    prevCtrl = p2;
                    a = a.slice(6);
                }
            } else if (up === "S") {
                while (a.length >= 4) {
                    var s2 = [a[0] + (rel ? cx : 0), a[1] + (rel ? cy : 0)];
                    var s3 = [a[2] + (rel ? cx : 0), a[3] + (rel ? cy : 0)];
                    var rc = prevCtrl ? [2 * cx - prevCtrl[0], 2 * cy - prevCtrl[1]] : [cx, cy];
                    cubic(rc, s2, s3);
                    cx = s3[0]; cy = s3[1];
                    prevCtrl = s2;
                    a = a.slice(4);
                }
            } else if (up === "Q") {
                while (a.length >= 4) {
                    var q1 = [a[0] + (rel ? cx : 0), a[1] + (rel ? cy : 0)];
                    var q3 = [a[2] + (rel ? cx : 0), a[3] + (rel ? cy : 0)];
                    var c1 = [cx + 2 / 3 * (q1[0] - cx), cy + 2 / 3 * (q1[1] - cy)];
                    var c2 = [q3[0] + 2 / 3 * (q1[0] - q3[0]), q3[1] + 2 / 3 * (q1[1] - q3[1])];
                    cubic(c1, c2, q3);
                    cx = q3[0]; cy = q3[1];
                    prevCtrl = q1;
                    a = a.slice(4);
                }
            } else if (up === "T") {
                while (a.length >= 2) {
                    var t3 = [a[0] + (rel ? cx : 0), a[1] + (rel ? cy : 0)];
                    var rq = prevCtrl ? [2 * cx - prevCtrl[0], 2 * cy - prevCtrl[1]] : [cx, cy];
                    var tc1 = [cx + 2 / 3 * (rq[0] - cx), cy + 2 / 3 * (rq[1] - cy)];
                    var tc2 = [t3[0] + 2 / 3 * (rq[0] - t3[0]), t3[1] + 2 / 3 * (rq[1] - t3[1])];
                    cubic(tc1, tc2, t3);
                    cx = t3[0]; cy = t3[1];
                    prevCtrl = rq;
                    a = a.slice(2);
                }
            } else if (up === "A") {
                // Arc: downgraded to a straight line, per README limitation.
                warn("arc command (A) downgraded to a straight segment");
                while (a.length >= 7) {
                    var ax = a[5] + (rel ? cx : 0);
                    var ay = a[6] + (rel ? cy : 0);
                    ensureContour();
                    pushPoint(c, [ax, ay]);
                    cx = ax; cy = ay;
                    a = a.slice(7);
                }
            } else if (up === "Z") {
                if (c) { c.closed = true; }
                cx = startX; cy = startY;
                prevCtrl = null;
            }
            prevCmd = up;
        }

        // Drop degenerate contours.
        var out = [];
        var k;
        for (k = 0; k < contours.length; k++) {
            if (contours[k].v.length >= 2) { out.push(contours[k]); }
        }
        return out;
    }

    /* ==================================================================
     *  Colour helpers
     * ================================================================== */

    function parseColor(str, warn) {
        if (!str) { return null; }
        var s = str.replace(/^\s+|\s+$/g, "");
        if (s === "none") { return null; }
        if (s.charAt(0) === "#") {
            var h = s.substring(1);
            if (h.length === 3) {
                h = h.charAt(0) + h.charAt(0) + h.charAt(1) + h.charAt(1) + h.charAt(2) + h.charAt(2);
            }
            if (h.length !== 6) { return null; }
            var r = parseInt(h.substring(0, 2), 16);
            var g = parseInt(h.substring(2, 4), 16);
            var b = parseInt(h.substring(4, 6), 16);
            if (isNaN(r) || isNaN(g) || isNaN(b)) { return null; }
            return [r / 255, g / 255, b / 255];
        }
        var m = /rgb\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)/.exec(s);
        if (m) {
            return [parseInt(m[1], 10) / 255, parseInt(m[2], 10) / 255, parseInt(m[3], 10) / 255];
        }
        if (s === "black") { return [0, 0, 0]; }
        if (s === "white") { return [1, 1, 1]; }
        if (s === "red") { return [1, 0, 0]; }
        if (s === "green") { return [0, 128 / 255, 0]; }
        if (s === "blue") { return [0, 0, 1]; }
        if (s.charAt(0) === "u" || s.charAt(0) === "U") {
            warn("gradient paint downgraded to flat colour");
            return null;
        }
        return null;
    }

    /* ==================================================================
     *  Shape layer building
     * ================================================================== */

    function shapeFromContour(contour, m) {
        var s = new Shape();
        var i;
        var verts = [];
        var inT = [];
        var outT = [];
        for (i = 0; i < contour.v.length; i++) {
            verts.push(xfPoint(m, contour.v[i]));
            inT.push(xfVector(m, contour.inT[i]));
            outT.push(xfVector(m, contour.outT[i]));
        }
        s.vertices = verts;
        s.inTangents = inT;
        s.outTangents = outT;
        s.closed = contour.closed;
        return s;
    }

    function addFill(vecGrp, color) {
        var f = vecGrp.addProperty("ADBE Vector Graphic - Fill");
        f.property("ADBE Vector Fill Color").setValue([color[0], color[1], color[2]]);
        return f;
    }

    function addStroke(vecGrp, color, width) {
        var st = vecGrp.addProperty("ADBE Vector Graphic - Stroke");
        st.property("ADBE Vector Stroke Color").setValue([color[0], color[1], color[2]]);
        st.property("ADBE Vector Stroke Width").setValue(width);
        try { st.property("ADBE Vector Stroke Line Cap").setValue(2); } catch (eCap) { }
        try { st.property("ADBE Vector Stroke Line Join").setValue(2); } catch (eJoin) { }
        return st;
    }

    /* ==================================================================
     *  Converter: SVG tree -> shape layer
     * ================================================================== */

    function Converter(comp, opts, warnFn) {
        this.comp = comp;
        this.opts = opts;
        this.warn = warnFn;
        this.warnings = [];
        this.counts = { paths: 0, rects: 0, ellipses: 0, groups: 0, skipped: 0 };
    }

    Converter.prototype.w = function (msg) {
        this.warnings.push(msg);
        if (this.warn) { this.warn(msg); }
    };

    // Root vectors group of the layer.
    Converter.prototype.buildChildren = function (svgNode, parentVecGrp, parentM, style) {
        var i;
        for (i = 0; i < svgNode.children.length; i++) {
            var child = svgNode.children[i];
            var name = child.name;

            if (name === "defs" || name === "linearGradient" || name === "radialGradient" ||
                name === "style" || name === "title" || name === "desc" || name === "metadata") {
                continue;
            }

            var localM = parseTransform(child.attrs.transform, this.warnOf());
            var m = matMul(parentM, localM);
            var st = this.inherit(child.attrs, style);

            if (name === "g") {
                var grp = parentVecGrp.addProperty("ADBE Vector Group");
                var gname = child.attrs["inkscape:label"] || child.attrs.id || "Group";
                grp.name = gname;
                this.counts.groups++;
                var innerVec = grp.property("ADBE Vectors Group");
                this.buildChildren(child, innerVec, m, st);
                continue;
            }

            if (name === "path") {
                var d = child.attrs.d;
                if (!d) { continue; }
                var contours = parsePathData(d, this.warnOf());
                if (contours.length === 0) { continue; }
                var elemVec = this.openElemGroup(parentVecGrp, child.attrs.id || "Path");
                var j;
                for (j = 0; j < contours.length; j++) {
                    var pg = elemVec.addProperty("ADBE Vector Shape - Group");
                    pg.name = (child.attrs.id || "Path") + (j > 0 ? (" " + (j + 1)) : "");
                    pg.property("ADBE Vector Shape").setValue(shapeFromContour(contours[j], m));
                }
                // Fill / stroke live inside this element's own group, so two
                // paths with different colours no longer fight each other.
                this.applyPaint(elemVec, st, m);
                this.counts.paths++;
                continue;
            }

            if (name === "rect") {
                this.addRect(parentVecGrp, child, m, st);
                continue;
            }

            if (name === "circle" || name === "ellipse") {
                this.addEllipse(parentVecGrp, child, m, st);
                continue;
            }

            if (name === "polygon" || name === "polyline") {
                this.addPoly(parentVecGrp, child, m, st);
                continue;
            }

            if (name === "text") {
                this.w("text element skipped - outline it in Illustrator first");
                this.counts.skipped++;
                continue;
            }

            if (name === "image" || name === "use") {
                this.w("<" + name + "> skipped");
                this.counts.skipped++;
                continue;
            }
        }
    };

    Converter.prototype.warnOf = function () {
        var self = this;
        return function (msg) { self.w(msg); };
    };

    // Style inheritance: attributes on the element win over the group's.
    Converter.prototype.inherit = function (attrs, parent) {
        var out = {
            fill: (attrs.fill !== undefined) ? attrs.fill : parent.fill,
            stroke: (attrs.stroke !== undefined) ? attrs.stroke : parent.stroke,
            strokeWidth: (attrs["stroke-width"] !== undefined) ? attrs["stroke-width"] : parent.strokeWidth,
            fillRule: (attrs["fill-rule"] !== undefined) ? attrs["fill-rule"] : parent.fillRule
        };
        return out;
    };

    // m already carries the viewBox scale, so the stroke width must use the
    // matrix scale factor - never opts.scale again (that would double-scale).
    Converter.prototype.applyPaint = function (vecGrp, style, m) {
        var fillCol = parseColor(style.fill, this.warnOf());
        if (fillCol) { addFill(vecGrp, fillCol); }
        var strokeCol = parseColor(style.stroke, this.warnOf());
        if (strokeCol) {
            var w = parseFloat(style.strokeWidth);
            if (isNaN(w) || w <= 0) { w = 1; }
            var sx = Math.sqrt(m[0] * m[0] + m[1] * m[1]);
            addStroke(vecGrp, strokeCol, w * sx);
        }
    };

    // Every drawable element gets its own sub group, so each path keeps its
    // own fill / stroke instead of stacking duplicate paint attributes on
    // the parent group.
    Converter.prototype.openElemGroup = function (parentVecGrp, name) {
        var g = parentVecGrp.addProperty("ADBE Vector Group");
        g.name = name;
        return g.property("ADBE Vectors Group");
    };

    Converter.prototype.addRect = function (parentVecGrp, node, m, style) {
        var x = parseFloat(node.attrs.x || "0");
        var y = parseFloat(node.attrs.y || "0");
        var w = parseFloat(node.attrs.width || "0");
        var h = parseFloat(node.attrs.height || "0");
        if (isNaN(w) || isNaN(h) || w <= 0 || h <= 0) { return; }

        var rx = node.attrs.rx ? parseFloat(node.attrs.rx) : 0;
        var ry = node.attrs.ry ? parseFloat(node.attrs.ry) : rx;

        var elemVec = this.openElemGroup(parentVecGrp, node.attrs.id || "Rectangle");

        if (this.isRotated(m)) {
            // Parametric rect cannot express rotation: emit four points.
            this.w("rotated <rect> converted to a bezier path");
            var pts = [[x, y], [x + w, y], [x + w, y + h], [x, y + h]];
            var cr = makeContour();
            var i;
            for (i = 0; i < 4; i++) { pushPoint(cr, xfPoint(m, pts[i])); }
            cr.closed = true;
            var pg = elemVec.addProperty("ADBE Vector Shape - Group");
            pg.name = node.attrs.id || "Rect";
            pg.property("ADBE Vector Shape").setValue(shapeFromContour(cr, [1, 0, 0, 1, 0, 0]));
            this.applyPaint(elemVec, style, m);
            this.counts.rects++;
            return;
        }

        var center = xfPoint(m, [x + w / 2, y + h / 2]);
        // m already contains the viewBox scale; multiplying by opts.scale
        // again would double-scale every parametric rect.
        var sx = Math.sqrt(m[0] * m[0] + m[1] * m[1]);
        var sy = Math.sqrt(m[2] * m[2] + m[3] * m[3]);

        var rectProp = elemVec.addProperty("ADBE Vector Shape - Rect");
        rectProp.name = node.attrs.id || "Rectangle";
        rectProp.property("ADBE Vector Rect Position").setValue([center[0], center[1]]);
        rectProp.property("ADBE Vector Rect Size").setValue([w * sx, h * sy]);
        if (rx > 0 || ry > 0) {
            try { rectProp.property("ADBE Vector Rect Roundness").setValue(rx * sx); } catch (eR) { }
        }
        this.applyPaint(elemVec, style, m);
        this.counts.rects++;
    };

    Converter.prototype.addEllipse = function (parentVecGrp, node, m, style) {
        var cx;
        var cy;
        var rx;
        var ry;
        if (node.name === "circle") {
            cx = parseFloat(node.attrs.cx || "0");
            cy = parseFloat(node.attrs.cy || "0");
            rx = parseFloat(node.attrs.r || "0");
            ry = rx;
        } else {
            cx = parseFloat(node.attrs.cx || "0");
            cy = parseFloat(node.attrs.cy || "0");
            rx = parseFloat(node.attrs.rx || "0");
            ry = parseFloat(node.attrs.ry || "0");
        }
        if (isNaN(rx) || isNaN(ry) || rx <= 0 || ry <= 0) { return; }

        var elemVec = this.openElemGroup(parentVecGrp, node.attrs.id || "Ellipse");
        var center = xfPoint(m, [cx, cy]);
        var sx = Math.sqrt(m[0] * m[0] + m[1] * m[1]);
        var sy = Math.sqrt(m[2] * m[2] + m[3] * m[3]);

        var el = elemVec.addProperty("ADBE Vector Shape - Ellipse");
        el.name = node.attrs.id || "Ellipse";
        el.property("ADBE Vector Ellipse Position").setValue([center[0], center[1]]);
        el.property("ADBE Vector Ellipse Size").setValue([rx * 2 * sx, ry * 2 * sy]);
        this.applyPaint(elemVec, style, m);
        this.counts.ellipses++;
    };

    Converter.prototype.addPoly = function (parentVecGrp, node, m, style) {
        var nums = parseNumberList(node.attrs.points || "");
        if (nums.length < 4) { return; }
        var cr = makeContour();
        var i;
        for (i = 0; i + 1 < nums.length; i += 2) {
            pushPoint(cr, xfPoint(m, [nums[i], nums[i + 1]]));
        }
        cr.closed = (node.name === "polygon");
        var elemVec = this.openElemGroup(parentVecGrp, node.attrs.id || "Polygon");
        var pg = elemVec.addProperty("ADBE Vector Shape - Group");
        pg.name = node.attrs.id || "Polygon";
        pg.property("ADBE Vector Shape").setValue(shapeFromContour(cr, [1, 0, 0, 1, 0, 0]));
        this.applyPaint(elemVec, style, m);
    };

    Converter.prototype.isRotated = function (m) {
        // Pure translate+uniform-scale matrices have b == c == 0.
        return Math.abs(m[1]) > 0.00001 || Math.abs(m[2]) > 0.00001;
    };

    /* ==================================================================
     *  Top level: parse + build
     * ================================================================== */

    function readSvgSize(svgNode) {
        var vb = svgNode.attrs.viewBox;
        var w = parseFloat(svgNode.attrs.width || "0");
        var h = parseFloat(svgNode.attrs.height || "0");
        if (vb) {
            var nums = parseNumberList(vb);
            if (nums.length >= 4) {
                return { x: nums[0], y: nums[1], w: nums[2], h: nums[3] };
            }
        }
        if (w > 0 && h > 0) { return { x: 0, y: 0, w: w, h: h }; }
        return { x: 0, y: 0, w: 512, h: 512 };
    }

    function buildLayer(comp, svgText, opts) {
        var root = parseSvg(svgText);
        var svgNode = firstChildByName(root, "svg");
        if (!svgNode) {
            // Some pasted snippets omit the <svg> wrapper.
            svgNode = root;
        }

        var size = readSvgSize(svgNode);
        var scale;
        var offX;
        var offY;

        if (opts.fit) {
            scale = Math.min(comp.width / size.w, comp.height / size.h);
        } else {
            scale = 1;
        }
        // Map the viewBox centre onto the layer origin (comp centre).
        offX = -(size.x + size.w / 2) * scale;
        offY = -(size.y + size.h / 2) * scale;

        var viewM = [scale, 0, 0, scale, offX, offY];

        var layer = comp.layers.addShape();
        layer.name = opts.layerName || "SVG Import";
        layer.comment = opts.comment || "";

        var conv = new Converter(comp, { scale: scale }, null);
        var rootVec = layer.property("ADBE Root Vectors Group");
        conv.buildChildren(svgNode, rootVec, viewM, { fill: "#000000", stroke: null, strokeWidth: "1", fillRule: "nonzero" });

        return {
            layer: layer,
            counts: conv.counts,
            warnings: conv.warnings,
            scale: scale,
            size: size
        };
    }

    /* ==================================================================
     *  Update an existing layer from the same SVG
     * ================================================================== */

    function updateLayer(comp, layer, fallbackSvg, opts) {
        // Prefer the SVG file recorded in the layer comment, so "Update"
        // really is "re-pull from the same source" (the original workflow).
        var svgText = fallbackSvg;
        var c = "";
        try { c = layer.comment || ""; } catch (eC) { c = ""; }
        var prefix = "svg-clone|";
        if (c.indexOf(prefix) === 0) {
            var recorded = c.substring(prefix.length);
            if (recorded) {
                var f = new File(recorded);
                if (f.exists) {
                    f.encoding = "UTF-8";
                    f.open("r");
                    var t = f.read();
                    f.close();
                    if (t && t.length > 0) { svgText = t; }
                }
            }
        }
        if (!svgText) {
            return { ok: false, message: layer.name + ": no SVG source recorded and none supplied." };
        }

        // Rebuild into a temporary layer, then copy the first path's geometry
        // over the target layer's first path. Keeps fills / strokes intact.
        var res = buildLayer(comp, svgText, opts);
        var tmp = res.layer;

        var srcRoot = tmp.property("ADBE Root Vectors Group");
        var dstRoot = layer.property("ADBE Root Vectors Group");

        var srcPath = findFirstShape(srcRoot);
        var dstPath = findFirstShape(dstRoot);

        if (!srcPath || !dstPath) {
            tmp.remove();
            return { ok: false, message: layer.name + ": no path found to update." };
        }

        var newShape = srcPath.property("ADBE Vector Shape").value;
        var target = dstPath.property("ADBE Vector Shape");

        if (opts.autoKey) {
            target.setValueAtTime(comp.time, newShape);
        } else {
            target.setValue(newShape);
        }

        tmp.remove();

        return {
            ok: true,
            message: "Updated the first path of \"" + layer.name + "\"" + (opts.autoKey ? " at the current frame." : ".")
        };
    }

    function findFirstShape(group) {
        var i;
        var mn = "";
        for (i = 1; i <= group.numProperties; i++) {
            var p = group.property(i);
            try { mn = p.matchName; } catch (e) { mn = ""; }
            if (mn === "ADBE Vector Shape - Group" || mn === "ADBE Vector Shape - Rect" ||
                mn === "ADBE Vector Shape - Ellipse") {
                return p;
            }
            if (mn === "ADBE Vector Group" || mn === "ADBE Vectors Group") {
                var inner = null;
                try { inner = p.property("ADBE Vectors Group"); } catch (e2) { inner = null; }
                if (inner) {
                    var found = findFirstShape(inner);
                    if (found) { return found; }
                }
            }
        }
        return null;
    }

    /* ==================================================================
     *  UI
     * ================================================================== */

    function buildUI(thisObj) {
        var pal = (thisObj instanceof Panel) ? thisObj :
            new Window("palette", SCRIPT_NAME + " " + VERSION, undefined, { resizeable: true });
        pal.orientation = "column";
        pal.alignChildren = ["fill", "top"];
        pal.spacing = 8;
        pal.margins = 12;

        var head = pal.add("statictext", undefined,
            "One-way SVG -> AE shape layers." +
            "\nIn Illustrator: File > Save a Copy > SVG, or copy the art and paste below.",
            { multiline: true });
        head.preferredSize.width = 350;

        var fileRow = pal.add("group");
        fileRow.alignment = ["fill", "top"];
        var edPath = fileRow.add("edittext", undefined, "");
        edPath.preferredSize.width = 240;
        var btnBrowse = fileRow.add("button", undefined, "Browse...");
        btnBrowse.preferredSize.width = 90;

        var pasteBox = pal.add("panel", undefined, "Or paste SVG markup");
        pasteBox.orientation = "column";
        pasteBox.alignChildren = ["fill", "top"];
        pasteBox.margins = 8;
        var edSvg = pasteBox.add("edittext", undefined, "", { multiline: true });
        edSvg.preferredSize = [340, 80];

        var optBox = pal.add("panel", undefined, "Options");
        optBox.orientation = "column";
        optBox.alignChildren = ["left", "top"];
        optBox.margins = 8;
        optBox.spacing = 4;
        var rbFit = optBox.add("radiobutton", undefined, "Fit to comp (keep aspect)");
        var rbOrig = optBox.add("radiobutton", undefined, "Original size (1 unit = 1 px)");
        rbFit.value = true;
        var cbKey = optBox.add("checkbox", undefined, "Update with keyframe at current time");
        cbKey.value = false;

        var btnRow = pal.add("group");
        btnRow.alignment = ["fill", "top"];
        var btnGo = btnRow.add("button", undefined, "Build shape layer");
        btnGo.preferredSize.width = 160;
        var btnUpdate = btnRow.add("button", undefined, "Update selected layer");

        var status = pal.add("statictext", undefined, "Ready.", { multiline: true });
        status.preferredSize.width = 360;

        function currentSvg() {
            var pasted = edSvg.text;
            if (pasted && pasted.replace(/\s/g, "").length > 0) { return pasted; }
            var p = edPath.text;
            if (!p) { return null; }
            var f = new File(p);
            if (!f.exists) { return null; }
            f.encoding = "UTF-8";
            f.open("r");
            var txt = f.read();
            f.close();
            return txt;
        }

        btnBrowse.onClick = function () {
            var f = File.openDialog("Choose an SVG file", "*.svg");
            if (f) { edPath.text = f.fsName; }
        };

        btnGo.onClick = function () {
            var comp = getActiveComp();
            if (!comp) { status.text = "Open a composition first."; return; }
            var src = currentSvg();
            if (!src) { status.text = "Pick an SVG file or paste SVG markup."; return; }
            var opts = {
                fit: rbFit.value,
                autoKey: false,
                layerName: "SVG Import",
                comment: "svg-clone|" + edPath.text
            };
            var res = null;
            var failMsg = null;
            app.beginUndoGroup(SCRIPT_NAME + " - build");
            try {
                res = buildLayer(comp, src, opts);
            } catch (err) {
                failMsg = err.toString();
            } finally {
                app.endUndoGroup();
            }
            if (failMsg) {
                status.text = "Failed: " + failMsg;
                return;
            }

            var msg = "Built \"" + res.layer.name + "\": " +
                res.counts.groups + " group(s), " + res.counts.paths + " path(s), " +
                res.counts.rects + " rect(s), " + res.counts.ellipses + " ellipse(s).";
            if (res.counts.skipped > 0) { msg += " Skipped " + res.counts.skipped + "."; }
            if (res.warnings.length > 0) {
                msg += "\nWarnings: " + res.warnings.slice(0, 4).join("; ");
                if (res.warnings.length > 4) { msg += " ..."; }
            }
            status.text = msg;
        };

        btnUpdate.onClick = function () {
            var comp = getActiveComp();
            if (!comp) { status.text = "Open a composition first."; return; }
            var sel = comp.selectedLayers;
            if (!sel || sel.length === 0) { status.text = "Select the shape layer to update."; return; }
            var src = currentSvg();
            if (!src) { status.text = "Pick an SVG file or paste SVG markup."; return; }

            var opts = { fit: rbFit.value, autoKey: cbKey.value, layerName: "tmp", comment: "" };
            var msg = "";
            var i;
            app.beginUndoGroup(SCRIPT_NAME + " - update");
            try {
                for (i = 0; i < sel.length; i++) {
                    if (!(sel[i] instanceof ShapeLayer)) { continue; }
                    var r = updateLayer(comp, sel[i], src, opts);
                    msg += (msg === "" ? "" : "\n") + r.message;
                }
            } catch (err2) {
                msg = "Failed: " + err2.toString();
            } finally {
                app.endUndoGroup();
            }
            status.text = msg === "" ? "No shape layer selected." : msg;
        };

        pal.onResizing = pal.onResize = function () { this.layout.resize(); };
        return pal;
    }

    function getActiveComp() {
        if (!app.project) { return null; }
        var it = app.project.activeItem;
        if (!it || !(it instanceof CompItem)) { return null; }
        return it;
    }

    var ui = buildUI(thisObj);
    if (ui instanceof Window) {
        ui.center();
        ui.show();
    } else {
        ui.layout.layout(true);
    }

})(this);
