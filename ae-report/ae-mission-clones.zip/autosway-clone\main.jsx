/*******************************************************************************
 * AS Spring Clone (AutoSway-style secondary-motion rig) - main.jsx
 * generated_at: 2026-11-14T07:12:00+08:00
 * task: clean-room 复刻 AutoSway 核心功能（弹簧摆动链），基于物理知识独立实现
 *
 * CLEAN-ROOM 声明：
 * 1. 本脚本为清室（clean-room）独立实现。实现者未反编译、未阅读、未复制
 *    AutoSway（aescripts.com, $39.99）的任何原始代码；仅依据公开的功能性描述
 *    （"对图层链生成弹簧式二次运动绑定，上级运动传导为滞后摆动"）与通用物理
 *    知识（欠阻尼弹簧微分方程）从零编写。
 * 2. 表达式核心为标准 Verlet（Störmer-Verlet）离散化（自行推导）：
 *        x[n] = 2*x[n-1] - x[n-2] + (dt^2/m) * ( k*(target - x[n-1]) - c*v )
 *        v    = (x[n-1] - x[n-2]) / dt
 *    通过 AE 内置 thisProperty.valueAtTime 采样自身前帧状态递推，
 *    历史深度受 "AS: Memory" 限制以控制递归开销。
 * 3. 本脚本按 ES3 (ExtendScript) 编写：无 let/const/箭头函数/JSON.stringify。
 *
 * 兼容：After Effects（ExtendScript 脚本引擎）；表达式为 ES3 写法，
 *       新旧 JS 表达式引擎均可运行。
 * 用法：ScriptUI Panels 目录安装后从 Window 菜单打开；或 File > Scripts >
 *       Run Script File... 直接运行。选中若干图层（时间线自上而下顺序视为
 *       链的根→梢），点 Apply。
 ******************************************************************************/

(function (thisObj) {

    var SCRIPT_NAME = "AS Spring Clone";
    var SCRIPT_VER = "1.0.0";
    var FX_PREFIX = "AS:";

    // ------------------------------------------------------------------
    // 默认参数（UI 可改）
    // ------------------------------------------------------------------
    var DEF = {
        stiffness: 150,     // 刚度 k
        damping: 8,         // 阻尼 c（欠阻尼典型值：c < 2*sqrt(k*m)）
        mass: 1,            // 质量 m
        windStrength: 8,    // 风力振幅（旋转=度 / 位置=像素）
        windFreq: 0.5,      // 风频（默认按秒=Hz；勾选后按帧=周期/帧）
        inherit: 60,        // 链传导权重 %（子层继承父层摆动量的比例）
        safety: 30,         // 单帧位移钳制（稳定性保险丝）
        memory: 120         // 弹簧历史采样帧数上限（递归深度上限）
    };

    // ------------------------------------------------------------------
    // 小工具
    // ------------------------------------------------------------------
    function toNum(s, fallback) {
        var v = parseFloat(s);
        if (isNaN(v)) { return fallback; }
        return v;
    }

    // 转义图层名中的双引号，保证写入表达式字符串后仍合法
    function escName(n) {
        return ("" + n).replace(/"/g, "\\\"");
    }

    // 在图层上查找已存在的具名效果，找不到则新建并命名、赋默认值
    function ensureFx(layer, matchName, fxName, valuePropName, defaultValue) {
        var effects = layer.property("ADBE Effect Parade");
        var fx = null;
        var i;
        for (i = 1; i <= effects.numProperties; i++) {
            var p = effects.property(i);
            if (p.name === fxName) { fx = p; break; }
        }
        if (fx === null) {
            fx = effects.addProperty(matchName);
            fx.name = fxName;
            if (defaultValue !== null && defaultValue !== undefined) {
                fx.property(valuePropName).setValue(defaultValue);
            }
        }
        return fx;
    }

    // 要驱动的旋转属性：2D 图层的 rotation 与 3D 图层的 zRotation
    // 共用 matchName "ADBE Rotate Z"
    function getRotProp(layer) {
        return layer.property("ADBE Transform Group").property("ADBE Rotate Z");
    }

    function getPosProp(layer) {
        return layer.property("ADBE Transform Group").property("ADBE Position");
    }

    // 把源属性的状态复制到目标控件属性（保留关键帧时间与值；
    // 缓动曲线不迁移 —— 见 README 限制）
    function copyKeys(srcProp, dstProp) {
        var i;
        if (srcProp.numKeys > 0) {
            for (i = 1; i <= srcProp.numKeys; i++) {
                dstProp.setValueAtTime(srcProp.keyTime(i), srcProp.keyValue(i));
            }
        } else {
            dstProp.setValue(srcProp.value);
        }
    }

    // ------------------------------------------------------------------
    // 表达式生成（全部为运行时字符串拼接，ES3 安全）
    // ------------------------------------------------------------------

    // 公共头：参数读取 + 风力函数。mode: "rot" | "pos"
    function exprHeader(mode) {
        var L = [];
        L.push("// === AS Spring Clone (clean-room) v" + SCRIPT_VER + " ===");
        L.push("// Verlet spring, per-dim: x[n]=2*x[n-1]-x[n-2]+(dt^2/m)*(k*(tgt-x[n-1])-c*v)");
        L.push("var f = thisComp.frameDuration;");
        L.push("var t = time;");
        L.push("var t0 = thisComp.displayStartTime;");
        L.push("var m = Math.max(0.0001, effect(\"" + FX_PREFIX + " Mass\")(\"Slider\"));");
        L.push("var k = Math.max(0, effect(\"" + FX_PREFIX + " Stiffness\")(\"Slider\"));");
        L.push("var c = Math.max(0, effect(\"" + FX_PREFIX + " Damping\")(\"Slider\"));");
        L.push("var maxStep = Math.max(0.001, effect(\"" + FX_PREFIX + " Safety\")(\"Slider\"));");
        L.push("var mem = Math.max(2, effect(\"" + FX_PREFIX + " Memory\")(\"Slider\"));");
        L.push("var wS = effect(\"" + FX_PREFIX + " Wind Strength\")(\"Slider\");");
        L.push("var wF = Math.max(0, effect(\"" + FX_PREFIX + " Wind Frequency\")(\"Slider\"));");
        L.push("var fpf = (effect(\"" + FX_PREFIX + " Freq per Frame\")(\"Checkbox\") == 1);");
        L.push("var inh = effect(\"" + FX_PREFIX + " Inherit\")(\"Slider\") / 100;");
        L.push("var u = (fpf ? (1 / f) : 1);"); // 每帧频率 -> 相位换算系数
        if (mode === "pos") {
            L.push("function windAt(tt) {");
            L.push("  var ph = tt * 2 * Math.PI * wF * u;");
            L.push("  var s = wS * Math.sin(ph);");
            L.push("  return [s, 0];"); // 风沿 X 轴（见 README）
            L.push("}");
        } else {
            L.push("function windAt(tt) {");
            L.push("  var ph = tt * 2 * Math.PI * wF * u;");
            L.push("  return wS * Math.sin(ph);");
            L.push("}");
        }
        return L.join("\n");
    }

    // 公共尾：Verlet 递推（标量/数组统一按维度处理；
    // 含零除保护、非有限值保护、单帧位移钳制、历史上限、
    // 以及 k/c 数值稳定域自动收缩。Verlet 稳定条件 a+2b<4
    // （a=k*dt^2/m, b=c*dt/m）：把 a 限到 <=2.25，再把 b 限到
    // (3.6-a)/2，整体留 0.4 裕量，任何极端参数都有界收敛）
    function exprFooter() {
        var L = [];
        L.push("var kMax = m * 2.25 / (f * f);");   // m*(1.5/f)^2
        L.push("var k2 = Math.min(k, kMax);");
        L.push("var aK = k2 * f * f / m;");
        L.push("var bC = Math.min(c * f / m, (3.6 - aK) / 2);");
        L.push("var cE = bC * m / f;");
        L.push("function dimStep(a1, a2, tg, i) {");
        L.push("  var v = (a1[i] - a2[i]) / f;");
        L.push("  if (!isFinite(v)) { v = 0; }");
        L.push("  var acc = (k2 * (tg[i] - a1[i]) - cE * v) / m;");
        L.push("  var xn = 2 * a1[i] - a2[i] + acc * f * f;");
        L.push("  var dx = xn - a1[i];");
        L.push("  if (dx > maxStep) { dx = maxStep; }");
        L.push("  if (dx < -maxStep) { dx = -maxStep; }");
        L.push("  return dx;");
        L.push("}");
        L.push("if (f <= 0) { targetAt(t); }");
        L.push("else if ((t - t0) < 2 * f || (t - t0) > mem * f) { targetAt(t); }");
        L.push("else {");
        L.push("  var x1 = thisProperty.valueAtTime(t - f);");
        L.push("  var x2 = thisProperty.valueAtTime(t - 2 * f);");
        L.push("  var tg = targetAt(t - f);");
        L.push("  var a1 = (typeof x1.length === \"number\") ? x1 : [x1];");
        L.push("  var a2 = (typeof x2.length === \"number\") ? x2 : [x2];");
        L.push("  var at = (typeof tg.length === \"number\") ? tg : [tg];");
        L.push("  var out = [];");
        L.push("  for (var i = 0; i < a1.length; i++) { out[i] = a1[i] + dimStep(a1, a2, at, i); }");
        L.push("  (typeof x1.length === \"number\") ? out : out[0];");
        L.push("}");
        return L.join("\n");
    }

    // 根层表达式（无父层传导）：目标 = Base + 风力
    function buildRootExpr(mode) {
        var L = [];
        L.push(exprHeader(mode));
        if (mode === "pos") {
            L.push("function targetAt(tt) {");
            L.push("  var b = effect(\"" + FX_PREFIX + " Base Pos\")(\"Point\").valueAtTime(tt);");
            L.push("  var w = windAt(tt);");
            L.push("  return [b[0] + w[0], b[1] + w[1]];");
            L.push("}");
        } else {
            L.push("function targetAt(tt) {");
            L.push("  return effect(\"" + FX_PREFIX + " Base\")(\"Angle\").valueAtTime(tt) + windAt(tt);");
            L.push("}");
        }
        L.push(exprFooter());
        return L.join("\n");
    }

    // 子层表达式：目标 = Base + 风力 + 父层摆动量 x Inherit%
    // 父层摆动量 = 父层当前(含表达式)值 - 父层 Base 值
    function buildChildExpr(mode, prevLayerName) {
        var pn = escName(prevLayerName);
        var L = [];
        L.push(exprHeader(mode));
        L.push("var par = thisComp.layer(\"" + pn + "\");");
        if (mode === "pos") {
            L.push("function parDelta(tt) {");
            L.push("  var pr = par.transform.position.valueAtTime(tt);");
            L.push("  var pb = par.effect(\"" + FX_PREFIX + " Base Pos\")(\"Point\").valueAtTime(tt);");
            L.push("  return [inh * (pr[0] - pb[0]), inh * (pr[1] - pb[1])];");
            L.push("}");
            L.push("function targetAt(tt) {");
            L.push("  var b = effect(\"" + FX_PREFIX + " Base Pos\")(\"Point\").valueAtTime(tt);");
            L.push("  var w = windAt(tt);");
            L.push("  var d = parDelta(tt);");
            L.push("  return [b[0] + w[0] + d[0], b[1] + w[1] + d[1]];");
            L.push("}");
        } else {
            L.push("function parDelta(tt) {");
            L.push("  var pr = par.transform.rotation.valueAtTime(tt);");
            L.push("  var pb = par.effect(\"" + FX_PREFIX + " Base\")(\"Angle\").valueAtTime(tt);");
            L.push("  return inh * (pr - pb);");
            L.push("}");
            L.push("function targetAt(tt) {");
            L.push("  return effect(\"" + FX_PREFIX + " Base\")(\"Angle\").valueAtTime(tt) + windAt(tt) + parDelta(tt);");
            L.push("}");
        }
        L.push(exprFooter());
        return L.join("\n");
    }

    // ------------------------------------------------------------------
    // 应用 / 移除
    // ------------------------------------------------------------------
    function applySway(cfg) {
        if (app.project === null) { alert("没有打开的项目。"); return; }
        var comp = app.project.activeItem;
        if (comp === null || !(comp instanceof CompItem)) {
            alert("请先激活一个合成（CompItem）。"); return;
        }
        var sel = comp.selectedLayers;
        if (sel.length === 0) {
            alert("请先在时间线中选中至少 1 个图层（自上而下顺序为链根→梢）。"); return;
        }

        // 按时间线顺序（layerIndex 升序）排列，决定链的方向
        var layers = sel.slice(0);
        layers.sort(function (a, b) { return a.index - b.index; });

        // 链深度限制（0 = 全部）
        var n = layers.length;
        if (cfg.chainDepth > 0 && cfg.chainDepth < n) { n = cfg.chainDepth; }

        var i3d;
        if (cfg.mode === "pos") {
            for (i3d = 0; i3d < n; i3d++) {
                if (layers[i3d].threeDLayer) {
                    alert("位置模式暂不支持 3D 图层（[" + layers[i3d].name + "]）。请改用旋转模式或关闭 3D。");
                    return;
                }
            }
        }

        app.beginUndoGroup("AS Spring Clone: Apply");
        var i, layer, err = [];
        try {
            for (i = 0; i < n; i++) {
                layer = layers[i];
                var prev = (i > 0) ? layers[i - 1] : null;

                // 1) 参数控制效果（已有则跳过）
                ensureFx(layer, "ADBE Slider Control", FX_PREFIX + " Stiffness", "Slider", cfg.stiffness);
                ensureFx(layer, "ADBE Slider Control", FX_PREFIX + " Damping", "Slider", cfg.damping);
                ensureFx(layer, "ADBE Slider Control", FX_PREFIX + " Mass", "Slider", cfg.mass);
                ensureFx(layer, "ADBE Slider Control", FX_PREFIX + " Wind Strength", "Slider", cfg.windStrength);
                ensureFx(layer, "ADBE Slider Control", FX_PREFIX + " Wind Frequency", "Slider", cfg.windFreq);
                ensureFx(layer, "ADBE Checkbox Control", FX_PREFIX + " Freq per Frame", "Checkbox", cfg.freqPerFrame ? 1 : 0);
                ensureFx(layer, "ADBE Slider Control", FX_PREFIX + " Inherit", "Slider", cfg.inherit);
                ensureFx(layer, "ADBE Slider Control", FX_PREFIX + " Safety", "Slider", cfg.safety);
                ensureFx(layer, "ADBE Slider Control", FX_PREFIX + " Memory", "Slider", cfg.memory);

                // 2) Base 控件（旋转=Angle / 位置=Point），迁移原属性状态
                if (cfg.mode === "pos") {
                    var basePos = ensureFx(layer, "ADBE Point Control", FX_PREFIX + " Base Pos", "Point", null);
                    var posProp = getPosProp(layer);
                    copyKeys(posProp, basePos.property("Point"));
                    posProp.expression = (prev === null)
                        ? buildRootExpr("pos")
                        : buildChildExpr("pos", prev.name);
                } else {
                    var baseAng = ensureFx(layer, "ADBE Angle Control", FX_PREFIX + " Base", "Angle", null);
                    var rotProp = getRotProp(layer);
                    copyKeys(rotProp, baseAng.property("Angle"));
                    rotProp.expression = (prev === null)
                        ? buildRootExpr("rot")
                        : buildChildExpr("rot", prev.name);
                }
            }
        } catch (e) {
            err.push("图层 [" + (layer ? layer.name : "?") + "]: " + e.toString());
        }
        app.endUndoGroup();

        if (err.length > 0) {
            alert("部分图层处理失败：\n" + err.join("\n"));
        } else {
            alert("完成：已为 " + n + " 个图层生成弹簧链（" + (cfg.mode === "pos" ? "位置" : "旋转") + " 模式）。\n" +
                "链根：" + (layers.length > 0 ? layers[0].name : "?") +
                "\n手动驱动：给 [AS: " + (cfg.mode === "pos" ? "Base Pos" : "Base") + "] 打关键帧；风力由 Wind Strength/Frequency 控制。");
        }
    }

    function removeSway() {
        if (app.project === null) { return; }
        var comp = app.project.activeItem;
        if (comp === null || !(comp instanceof CompItem)) {
            alert("请先激活一个合成。"); return;
        }
        var sel = comp.selectedLayers;
        if (sel.length === 0) { alert("请先选中图层。"); return; }

        app.beginUndoGroup("AS Spring Clone: Remove");
        var i, j, layer, effects;
        for (i = 0; i < sel.length; i++) {
            layer = sel[i];
            try {
                getRotProp(layer).expression = "";
                getPosProp(layer).expression = "";
            } catch (e2) { /* 个别属性不可写表达式，忽略 */ }
            effects = layer.property("ADBE Effect Parade");
            for (j = effects.numProperties; j >= 1; j--) {
                if (effects.property(j).name.indexOf(FX_PREFIX) === 0) {
                    effects.property(j).remove();
                }
            }
        }
        app.endUndoGroup();
        alert("已移除选中图层的 AS Spring Clone 绑定。");
    }

    // ------------------------------------------------------------------
    // UI（ScriptUI，可停靠面板）
    // ------------------------------------------------------------------
    function buildUI(thisObj) {
        var win = (thisObj instanceof Panel) ? thisObj : new Window("palette", SCRIPT_NAME, undefined, { resizeable: true });

        win.orientation = "column";
        win.alignChildren = ["fill", "top"];
        win.spacing = 6;
        win.margins = 12;

        win.add("statictext", undefined, SCRIPT_NAME + " v" + SCRIPT_VER + "（clean-room）");
        var tip = win.add("statictext", undefined, "选中图层(自上而下=根→梢)后 Apply。");
        tip.graphics.foregroundColor = tip.graphics.newPen(win.graphics.PenType.SOLID_COLOR, [0.5, 0.5, 0.5], 1);

        // 模式与链深度
        var rowMode = win.add("group");
        rowMode.orientation = "row";
        rowMode.alignChildren = ["left", "center"];
        rowMode.add("statictext", undefined, "应用到:");
        var ddMode = rowMode.add("dropdownlist", undefined, ["Rotation 旋转", "Position 位置"]);
        ddMode.selection = 0;
        rowMode.add("statictext", undefined, " 链深度(0=全部):");
        var etDepth = rowMode.add("edittext", undefined, "0");
        etDepth.characters = 5;

        // 参数行（两列）
        function paramRow(label1, key1, label2, key2) {
            var g = win.add("group");
            g.orientation = "row";
            g.alignChildren = ["left", "center"];
            g.add("statictext", undefined, label1);
            var e1 = g.add("edittext", undefined, "" + DEF[key1]);
            e1.characters = 6;
            g.add("statictext", undefined, "   " + label2);
            var e2 = g.add("edittext", undefined, "" + DEF[key2]);
            e2.characters = 6;
            return [e1, e2];
        }

        var r1 = paramRow("Stiffness 刚度:", "stiffness", "Damping 阻尼:", "damping");
        var r2 = paramRow("Mass 质量:", "mass", "Wind Strength 风力:", "windStrength");
        var r3 = paramRow("Wind Frequency 风频:", "windFreq", "Inherit 传导%:", "inherit");
        var r4 = paramRow("Safety 单帧钳制:", "safety", "Memory 历史帧:", "memory");

        var cbFrame = win.add("checkbox", undefined, "频率按帧（勾选）/ 按秒（不勾选）");
        cbFrame.value = false;

        var gBtn = win.add("group");
        gBtn.orientation = "row";
        var btnApply = gBtn.add("button", undefined, "Apply 应用", { name: "ok" });
        var btnRemove = gBtn.add("button", undefined, "Remove 移除");

        var note = win.add("statictext", undefined, "ES3/ExtendScript；表达式=Verlet+valueAtTime 递推。");
        note.graphics.foregroundColor = note.graphics.newPen(win.graphics.PenType.SOLID_COLOR, [0.5, 0.5, 0.5], 1);

        function collectCfg() {
            var modeSel = (ddMode.selection !== null) ? ddMode.selection.index : 0;
            return {
                mode: (modeSel === 1) ? "pos" : "rot",
                chainDepth: Math.max(0, Math.round(toNum(etDepth.text, 0))),
                stiffness: toNum(r1[0].text, DEF.stiffness),
                damping: toNum(r1[1].text, DEF.damping),
                mass: Math.max(0.0001, toNum(r2[0].text, DEF.mass)),
                windStrength: toNum(r2[1].text, DEF.windStrength),
                windFreq: Math.max(0, toNum(r3[0].text, DEF.windFreq)),
                inherit: toNum(r3[1].text, DEF.inherit),
                safety: Math.max(0.001, toNum(r4[0].text, DEF.safety)),
                memory: Math.max(2, Math.round(toNum(r4[1].text, DEF.memory))),
                freqPerFrame: cbFrame.value
            };
        }

        btnApply.onClick = function () {
            try {
                applySway(collectCfg());
            } catch (e) {
                alert("Apply 失败: " + e.toString());
            }
        };
        btnRemove.onClick = function () {
            try {
                removeSway();
            } catch (e) {
                alert("Remove 失败: " + e.toString());
            }
        };

        win.layout.layout(true);

        if (win instanceof Window) {
            win.center();
            win.show();
        }
        return win;
    }

    buildUI(thisObj);

})(this);
