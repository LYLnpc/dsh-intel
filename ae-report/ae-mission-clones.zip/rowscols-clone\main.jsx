/*******************************************************************************
 * Rows and Columns Clone (layer grid arrangement) - main.jsx
 * generated_at: 2026-11-14T08:16:00+08:00
 * task: clean-room 复刻 Rows and Columns（aescripts，价格未核实）核心功能：
 *       选中图层按 R×C 网格排列（行/列/间距/对齐），支持复制填充与循环排入
 *       （输入 = intel/paid-list.md 第 30 条的功能性描述，不反编译不抄原代码）
 *
 * CLEAN-ROOM 声明：
 * 1. 本脚本为清室（clean-room）独立实现。实现者未反编译、未阅读、未复制
 *    Rows and Columns 的任何原始代码；仅依据公开的功能性描述（"把选中图层
 *    按行/列网格排列：行列数、间距、对齐"）与 AE 公开脚本 API 从零编写。
 * 2. API 全部取自 docs/api-cheatsheet.md 白名单：Layer.width/height、
 *    Layer.sourceRectAtTime(timeT, extents)、anchorPoint、setValue（有关键帧
 *    时抛异常）、KeyframeInterpolationType、comp.width/height 均为 [官方核实]。
 * 3. 布局核心为纯函数 rcComputeLayout（RC-LAYOUT 标记块），由 Node 自查脚本
 *    逐字提取验证（3×3 间距/混合尺寸/居中模式）。
 * 4. ES3 (ExtendScript) 编写：无 let/const/箭头函数/JSON.stringify。
 *
 * 语义：
 *   - 复制填充开：以选中图层为源循环复制直到填满 R×C 格（1 个源 → 复制
 *     R×C-1 份；N 个源 → 前 N 格用原图层，其余格循环复制）。
 *   - 复制填充关：仅前 min(N, R×C) 格用选中图层（N > R×C 时多余层不动）。
 *   - 格子尺寸 = 列内最大内容宽 / 行内最大内容高（列优先紧凑排布）。
 *   - 对齐：左上 = 网格左上角锚定第 1 格图层的内容包围盒左上角；
 *           Comp 居中 = 网格整体在合成中居中。
 *   - z 序不变：不移动图层顺序，按时间线自上而下顺序行主序填格。
 *
 * 用法：File > Scripts > Run Script File... 或放入 ScriptUI Panels 目录。
 ******************************************************************************/

(function (thisObj) {

    var SCRIPT_NAME = "Rows and Columns Clone";
    var SCRIPT_VER = "1.0.0";
    var MAX_CELLS = 200; // R×C 上限

    // >>> RC-LAYOUT-START（布局核心纯函数：Node 自查从本块逐字提取验证）
    function rcComputeLayout(sizes, cols, gapX, gapY, originX, originY) {
        var n = sizes.length;
        var rows = Math.ceil(n / cols);
        var colW = [], rowH = [], i;
        for (i = 0; i < cols; i++) { colW.push(0); }
        for (i = 0; i < rows; i++) { rowH.push(0); }
        for (i = 0; i < n; i++) {
            var r = Math.floor(i / cols), c = i % cols;
            if (sizes[i][0] > colW[c]) { colW[c] = sizes[i][0]; }
            if (sizes[i][1] > rowH[r]) { rowH[r] = sizes[i][1]; }
        }
        var colX = [], rowY = [];
        var x = originX, y = originY;
        for (i = 0; i < cols; i++) { colX.push(x); x = x + colW[i] + gapX; }
        for (i = 0; i < rows; i++) { rowY.push(y); y = y + rowH[i] + gapY; }
        var centers = [];
        for (i = 0; i < n; i++) {
            var rr = Math.floor(i / cols), cc = i % cols;
            centers.push([colX[cc] + colW[cc] / 2, rowY[rr] + rowH[rr] / 2]);
        }
        return { centers: centers, gridW: x - gapX - originX, gridH: y - gapY - originY };
    }
    // <<< RC-LAYOUT-END

    // ------------------------------------------------------------------
    // 小工具（ES3）
    // ------------------------------------------------------------------
    function toInt(v, fallback, min) {
        var x = parseInt(v, 10);
        if (isNaN(x)) { x = fallback; }
        if (x < min) { x = min; }
        return x;
    }

    function toNum2(v, fallback, min) {
        var x = parseFloat(v);
        if (isNaN(x)) { x = fallback; }
        if (x < min) { x = min; }
        return x;
    }

    // 图层内容包围盒（源空间 {left,top,width,height}）：
    // 优先 sourceRectAtTime（官方核实，文本/形状/素材通用），失败回退 width/height
    function contentRect(layer, comp) {
        try {
            var rect = layer.sourceRectAtTime(comp.time, false);
            if (rect !== null && rect.width > 0 && rect.height > 0) { return rect; }
        } catch (e0) { /* 空文本/空形状等 → 回退 */ }
        var w = 0, h = 0;
        try { w = layer.width; h = layer.height; } catch (e1) { w = 0; h = 0; }
        if (!(w > 0)) { w = comp.width; }
        if (!(h > 0)) { h = comp.height; }
        return { left: 0, top: 0, width: w, height: h };
    }

    // ------------------------------------------------------------------
    // 主流程
    // ------------------------------------------------------------------
    function doArrange(cfg) {
        if (app.project === null) { alert("没有打开的项目。"); return; }
        var comp = app.project.activeItem;
        if (comp === null || !(comp instanceof CompItem)) {
            alert("请先激活一个合成。"); return;
        }
        var sel = comp.selectedLayers;
        if (sel.length === 0) {
            alert("请先在时间线中选中至少 1 个图层。"); return;
        }
        var total = cfg.rows * cfg.cols;
        if (total > MAX_CELLS) {
            alert("行列乘积超过上限 " + MAX_CELLS + "（当前 " + cfg.rows + "×" + cfg.cols + "）。");
            return;
        }

        // 时间线自上而下排序（保持原 z 序，行主序填格）
        var sorted = sel.slice(0);
        sorted.sort(function (a, b) { return a.index - b.index; });

        app.beginUndoGroup("Rows and Columns Clone: Arrange");
        var report = { moved: 0, warnings: [] };
        var i;
        try {
            // 1) 组装 R×C 个"实例"（图层对象）
            var instances = [];
            if (cfg.copyFill) {
                for (i = 0; i < total; i++) {
                    if (i < sorted.length) {
                        instances.push(sorted[i]);
                    } else {
                        try {
                            var src = sorted[i % sorted.length];
                            var dup = src.duplicate();
                            try { dup.name = src.name + "_g" + (i + 1); } catch (eN) { /* 保留默认名 */ }
                            instances.push(dup);
                        } catch (eD) {
                            report.warnings.push("第 " + (i + 1) + " 格复制失败：" + eD.toString());
                            instances.push(null);
                        }
                    }
                }
            } else {
                if (sorted.length < total) {
                    report.warnings.push("选中 " + sorted.length + " 个 < 格子 " + total + " 个，仅排前 " + sorted.length + " 格（勾选复制填充可铺满）。");
                }
                for (i = 0; i < total; i++) {
                    if (i < sorted.length) { instances.push(sorted[i]); } else { instances.push(null); }
                }
            }

            // 2) 收集各格内容尺寸（源空间），并计算内容中心相对锚点的偏移
            var sizes = [];
            var meta = [];
            for (i = 0; i < total; i++) {
                var lay = instances[i];
                if (lay === null) { sizes.push([0, 0]); meta.push(null); continue; }
                var rect = contentRect(lay, comp);
                sizes.push([rect.width, rect.height]);
                var anchor = [0, 0];
                try {
                    anchor = lay.property("ADBE Transform Group").property("ADBE Anchor Point").value;
                } catch (eA) { anchor = [0, 0]; }
                meta.push({
                    layer: lay,
                    offX: rect.left + rect.width / 2 - anchor[0],   // 内容中心-锚点（源空间，忽略旋转/缩放）
                    offY: rect.top + rect.height / 2 - anchor[1],
                    is3D: lay.threeDLayer === true,
                    hasPosKeys: false
                });
                try {
                    var posCheck = lay.property("ADBE Transform Group").property("ADBE Position");
                    meta[meta.length - 1].hasPosKeys = (posCheck.numKeys > 0);
                } catch (eP) { /* 无 transform 的层跳过 */ }
            }

            // 3) 两遍布局：先原点 (0,0) 求网格总尺寸，再按对齐方式定原点
            var pass1 = rcComputeLayout(sizes, cfg.cols, cfg.gapX, cfg.gapY, 0, 0);
            var originX, originY;
            if (cfg.centerInComp) {
                originX = (comp.width - pass1.gridW) / 2;
                originY = (comp.height - pass1.gridH) / 2;
            } else {
                // 左上：锚定第 1 格图层的内容包围盒左上角（合成空间）
                var first = meta[0];
                if (first !== null && first.layer !== null) {
                    try {
                        var pos0 = first.layer.property("ADBE Transform Group").property("ADBE Position").value;
                        var rect0 = contentRect(first.layer, comp);
                        var anch0 = [0, 0];
                        try { anch0 = first.layer.property("ADBE Transform Group").property("ADBE Anchor Point").value; } catch (eAn) {}
                        originX = pos0[0] + rect0.left - anch0[0];
                        originY = pos0[1] + rect0.top - anch0[1];
                    } catch (ePos) {
                        originX = 0;
                        originY = 0;
                        report.warnings.push("读取首层位置失败，网格原点落在合成原点。");
                    }
                } else {
                    originX = 0;
                    originY = 0;
                }
            }
            var layout = rcComputeLayout(sizes, cfg.cols, cfg.gapX, cfg.gapY, originX, originY);

            // 4) 逐格落位（z 序不变；3D 保留 z；有关键帧/父级/分离维度则跳过该格）
            for (i = 0; i < total; i++) {
                var m = meta[i];
                if (m === null || m.layer === null) { continue; }
                if (m.hasPosKeys) {
                    report.warnings.push("[" + m.layer.name + "] position 有关键帧，跳过（不破坏动画）。");
                    continue;
                }
                try {
                    var hasParent = false;
                    try { hasParent = (m.layer.parent !== null); } catch (ePa) { hasParent = false; }
                    if (hasParent) {
                        report.warnings.push("[" + m.layer.name + "] 有父级（position 为父层坐标），跳过。");
                        continue;
                    }
                    var posProp = m.layer.property("ADBE Transform Group").property("ADBE Position");
                    var oldPos = posProp.value;
                    var targetX = layout.centers[i][0] - m.offX;
                    var targetY = layout.centers[i][1] - m.offY;
                    var newPos;
                    if (oldPos.length > 2) {
                        newPos = [targetX, targetY, oldPos[2]];
                    } else {
                        newPos = [targetX, targetY];
                    }
                    posProp.setValue(newPos);
                    report.moved++;
                } catch (eSet) {
                    report.warnings.push("[" + m.layer.name + "] 落位失败（可能为分离维度）：" + eSet.toString());
                }
            }

            // 5) 选中新实例副本，便于后续操作
            for (i = 0; i < total; i++) {
                var mi = meta[i];
                if (mi !== null && mi.layer !== null) {
                    try { mi.layer.selected = true; } catch (eSel) { /* 忽略 */ }
                }
            }
        } catch (eMain) {
            report.warnings.push("执行异常：" + eMain.toString());
        }
        app.endUndoGroup();

        var msg = "完成：落位 " + report.moved + " / " + total + " 格。";
        if (report.warnings.length > 0) {
            var max = Math.min(report.warnings.length, 6);
            msg += "\n---- 提示 " + report.warnings.length + " 条 ----";
            for (var w = 0; w < max; w++) { msg += "\n" + report.warnings[w]; }
            if (report.warnings.length > max) { msg += "\n…… 其余从略"; }
        }
        alert(msg, SCRIPT_NAME);
    }

    // ------------------------------------------------------------------
    // UI（ScriptUI，可停靠）
    // ------------------------------------------------------------------
    function buildUI(thisObj) {
        var win = (thisObj instanceof Panel) ? thisObj : new Window("palette", SCRIPT_NAME, undefined, { resizeable: true });
        win.orientation = "column";
        win.alignChildren = ["fill", "top"];
        win.spacing = 6;
        win.margins = 12;

        win.add("statictext", undefined, SCRIPT_NAME + " v" + SCRIPT_VER + "（clean-room）");
        var tip = win.add("statictext", undefined, "选中图层 → 行主序排入 R×C 网格（z 序不变）。");
        try {
            tip.graphics.foregroundColor = tip.graphics.newPen(win.graphics.PenType.SOLID_COLOR, [0.5, 0.5, 0.5], 1);
        } catch (ePen1) { /* 着色失败不影响功能 */ }

        var rowGrid = win.add("group");
        rowGrid.orientation = "row";
        rowGrid.add("statictext", undefined, "行数:");
        var etRows = rowGrid.add("edittext", undefined, "3");
        etRows.characters = 4;
        rowGrid.add("statictext", undefined, " 列数:");
        var etCols = rowGrid.add("edittext", undefined, "3");
        etCols.characters = 4;
        rowGrid.add("statictext", undefined, " 横间距:");
        var etGapX = rowGrid.add("edittext", undefined, "20");
        etGapX.characters = 5;
        rowGrid.add("statictext", undefined, " 纵间距:");
        var etGapY = rowGrid.add("edittext", undefined, "20");
        etGapY.characters = 5;

        var rowAlign = win.add("group");
        rowAlign.orientation = "row";
        rowAlign.add("statictext", undefined, "对齐:");
        var ddAlign = rowAlign.add("dropdownlist", undefined, ["左上（首层内容左上角）", "Comp 居中"]);
        ddAlign.selection = 0;

        var cbCopy = win.add("checkbox", undefined, "复制填充（不足的格子循环复制源图层）");
        cbCopy.value = false;

        var countText = win.add("statictext", undefined, "将排列 9 格");
        function updateCount() {
            var r = toInt(etRows.text, 3, 1);
            var c = toInt(etCols.text, 3, 1);
            countText.text = "将排列 " + (r * c) + " 格";
        }
        etRows.onChange = updateCount;
        etCols.onChange = updateCount;

        var gBtn = win.add("group");
        gBtn.orientation = "row";
        var btnGo = gBtn.add("button", undefined, "Arrange 排列", { name: "ok" });

        var note = win.add("statictext", undefined, "ES3；格子=列内最大宽/行内最大高；z 序与动画不破坏。");
        try {
            note.graphics.foregroundColor = note.graphics.newPen(win.graphics.PenType.SOLID_COLOR, [0.5, 0.5, 0.5], 1);
        } catch (ePen2) { /* 着色失败不影响功能 */ }

        btnGo.onClick = function () {
            try {
                doArrange({
                    rows: toInt(etRows.text, 3, 1),
                    cols: toInt(etCols.text, 3, 1),
                    gapX: toNum2(etGapX.text, 20, 0),
                    gapY: toNum2(etGapY.text, 20, 0),
                    centerInComp: (ddAlign.selection !== null && ddAlign.selection.index === 1),
                    copyFill: cbCopy.value
                });
            } catch (e) {
                alert("Arrange 失败: " + e.toString());
            }
        };

        win.layout.layout(true);
        if (win instanceof Window) {
            win.center();
            win.show();
        }
        return win;
    }

    buildUI(thisObj);

})(this);
