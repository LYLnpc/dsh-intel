---
generated_at: 2026-11-14T08:45:00+08:00
task: 最后一批自主选件 clean-room 复刻 WobbleBox（aescripts, Mike Overbeck, $5 NYOP，预设+表达式）——图层运动时盒体果冻式弹性反应；输入 = intel/paid-list.md 第 15 条功能性描述，不反编译不参考原代码
---

# WobbleBox Clone（果冻盒跟随 · clean-room 复刻）

- 产出：`main.jsx`（ExtendScript，ES3）
- **选件理由**（收官件自主选件）：前 15 个 A 类条目中未被覆盖的只剩 Limber 2 与 WobbleBox——Limber 与 rubberhose-clone 的两骨 IK 重叠且描述为摘要级；WobbleBox 功能域（果冻盒跟随）独特，复刻要点明确（"纯表达式 spring（临界阻尼可调）绑定到 position/velocity 采样"），纯 jsx/表达式可实现。
- 输入依据：`intel/paid-list.md` 第 15 条 WobbleBox 功能性描述
- API 全部取自 `docs/api-cheatsheet.md` 白名单：`layer.parent`、`sourceRectAtTime`（不在白名单→try/catch+回退，按政策登记）、`ADBE Vector Shape - Group`、`new Shape()`+`vertices/closed`、`ADBE Vector Graphic - Stroke`、`ADBE Slider Control`、`valueAtTime`、`thisComp.frameDuration/displayStartTime` 均 `[官方核实]` 或按未收录政策处理

## CLEAN-ROOM 声明

1. 本复刻为清室实现：未反编译、未阅读、未复制 WobbleBox 的任何原始代码；仅依据公开的功能性描述与 AE 公开脚本 API 从零编写。
2. 仅供学习研究；WobbleBox 商标与著作权归原作者所有（$5 NYOP），需要完整功能请支持正版。

## 功能对照（复刻范围 / 推断范围）

| WobbleBox 功能点（paid-list 描述） | 本复刻状态 | 说明 |
|---|---|---|
| 图层运动时盒体果冻式弹性反应 | ✅ 已复刻 | 为每个选中层创建"果冻盒"形状层，`layer.parent` 到目标层（位置/旋转刚性跟随），scale 写 Verlet 弹簧表达式 |
| spring 表达式（阻尼可调）绑定 position/velocity 采样 | ✅ 已复刻 | 弹簧目标幅度由**父层 position 相邻帧位移**（`valueAtTime(time)`−`valueAtTime(time−fd)`，仅白名单 API，不用 velocityAtTime）换算的速度驱动；Stiffness/Damping Slider 实时可调，数值稳定域自动钳制（k≤2.25m/f²，bC≤(3.6−aK)/2） |
| 盒体 | ✅ | 矩形描边盒（白色 60% 描边、圆角连接），尺寸=目标层内容包围盒（`sourceRectAtTime` 回退 `width/height`）+ 内边距 |
| 弯折（bend） | ❌ 未复刻 | 基线仅做 scale 果冻（拉伸/压缩），无弯折变形 |
| 按运动方向对齐挤压轴 | ⚠️ 简化 | squash 沿盒子自身 X/Y 轴（不随速度方向旋转挤压轴），见限制 |
| 触发自适应/临界阻尼切换 | ⚠️ 简化 | Stiffness/Damping 连续可调（欠阻尼过冲→过阻尼平滑），非原版的"临界阻尼开关" |
| 反向运动回弹 | ✅（速度符号自然包含） | 速度由相邻帧位移实测，减速/反向时目标幅度自动变化，弹簧产生回弹 |

**推断范围声明**：paid-list 对 WobbleBox 仅一行描述（[已核实-摘要级]，含"复刻要点：纯表达式 spring（临界阻尼可调）绑定到 position/velocity 采样"），上表"⚠️ 简化/❌ 未复刻"各项均为基于这一行描述的**推断基线**，与原品实际参数集可能不同；未复刻项不代表原品没有。

## 安装

`main.jsx` 放入 ScriptUI Panels 目录重启 AE 从 Window 菜单打开（可停靠），或 `File > Scripts > Run Script File...` 直接运行。

## 使用

1. 时间线选中 1 个以上图层（图片/实拍/预合成/形状/文本均可）。
2. 面板设置：内边距(px)、增益（每 1000px/s 速度对应 gain/100 的拉伸比例）、最大幅度%、刚度、阻尼。
3. 点 **Create 创建**：每层生成一个 `WB: Jelly - <层名>` 果冻盒（父级到目标层），scale 自动写弹簧表达式；整批 undo 组。
4. 播放合成：目标层移动时盒子果冻式拉伸/回弹；参数在果冻盒图层的 `WB: Gain / Max Amp / Stiffness / Damping` 效果上实时可调。
5. 点 **Remove 移除**：按 `WB: Jelly - ` 前缀删除全部果冻盒（目标层不受影响）。

### 弹簧数学（自行推导）

scale 每维做 Verlet 弹簧：`x[n] = 2x[n-1] − x[n-2] + (dt²/m)·(k(target − x[n-1]) − c·v)`，`v = (x[n-1] − x[n-2])/dt`；目标 `[100×(1+tgt), 100/(1+tgt)]`（体积守恒近似），`tgt = min(ampMax, (速度/1000)×(gain/100))`。数值稳定域钳制与 autosway-clone 同源（a+2b<4 留裕量），单帧变化钳制 ±8（scale 百分点）。起步/超出历史窗口（300 帧）直接落到目标静态值。

## 自查记录（2026-11-14）

1. `node --check`：通过（复制为 .js）；ES3 扫描（排除注释行）：零命中。
2. **表达式逐字执行仿真**：Node 从 main.jsx 提取 `buildJellyScaleExpr` 生成表达式字符串，配桩（父层 200px/s 线速轨迹、Slider 桩、`thisProperty.valueAtTime` 递归求值+memo）实际执行，5 项断言 ALL PASS：
   - T1 稳态精确收敛 [112, 89.29]（tgt=min(0.25,0.12)=0.12）
   - T2 起步静态分支直达目标
   - T3 全程 75 帧有界无 NaN
   - T4 无父级异常 → 回退静态 scale=100
   - T5 极端刚度 5000（超稳定域）→ 自动钳制后有界
3. 自查过程中修复 1 处真实缺陷：初版增益公式量纲错误（`sp×gain/1000` 在 200px/s 时 =12，恒触发 Max Amp 上限，Gain 滑杆失效）→ 改为 `(sp/1000)×(gain/100)`。
4. API 对照：黑名单（deleteKey/全大写枚举/keyTemporalEase/ADBE Mask Group/InterpolationType. 前缀）零命中；非白名单 API 仅 `sourceRectAtTime`（try/catch+回退，已登记）。

## 限制（如实说明）

1. **未在 AE 实机测试**：需实机验证——形状层 Path 属性 matchName 兜底链（同 sliceitup-clone 路线）、父级链下 valueAtTime 的递归开销（历史窗口 300 帧封顶）、表达式在新旧 JS 引擎下的行为。
2. 挤压轴固定为盒子自身 X/Y：目标层旋转时，盒子跟随旋转但 squash 轴不随速度方向对齐（原版可能有方向对齐，属推断范围未覆盖）。
3. 目标层删除父级/改名/移除会导致果冻盒表达式报错或失联（盒按名无引用，但 parent 链断裂时表达式走异常回退为静态盒）。
4. 3D 目标层：盒仍为 2D 形状层（跟随 3D 位置投影，z 轴不模拟）。
5. 盒体尺寸在创建时固化（源内容矩形），目标层内容动画变化时盒不跟随内容变化（跟随的是图层变换）。
6. 弹簧历史窗口 300 帧：超长合成在窗口外退化为静态目标（防递归失控的代价）。
