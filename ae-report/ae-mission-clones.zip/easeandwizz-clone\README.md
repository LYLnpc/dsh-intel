# EaseAndWizz Clone（clean-room 复刻）

> **CLEAN-ROOM 声明**：本项目为依据功能需求描述（`intel/paid-list.md` 第 4 条
> "EaseAndWizz"）从零独立编写的复刻实现。编写过程中未反编译原插件，未阅读、
> 复制或改写原插件的任何源代码、字节码或资源文件；仅依赖 Adobe After Effects
> 公开脚本 API、公开的 Penner 缓动曲线定义与标准贝塞尔近似表。与原产品的
> 相似性仅来自功能需求本身。仅供学习研究；需完整功能请购买正版
> （aescripts.com，$29.99）。

- 原品：EaseAndWizz（aescripts，$29.99，jsx，表达式生成型脚本）
- 复刻：`main.jsx`（ExtendScript / ES3，单文件，479 行，UTF-8 带 BOM）
- 定位：选中关键帧 → 下拉选预设 → 一键应用缓动。与 flow-clone 同为"时间缓动
  手柄 + 过冲插帧"路线，但本实现独立编写（直接查 Penner 近似表取手柄，不做
  贝塞尔缩放函数；参数命名 ewz*/EAW_*、UI 文案、过冲曲线与"连续递增强度"
  逻辑均为原创）。

---

## 一、功能对照表

### 已复刻

| 功能 | 说明 |
|------|------|
| 26 条预设下拉 | 七族（Sine/Quad/Cubic/Quart/Quint/Expo/Circ）各 In/Out/InOut 共 21 条缓动 + Back In/Back Out/Elastic Out/Bounce Out/Wizz Out 五条过冲类（默认 Cubic Out） |
| 时间缓动应用 | 缓动族经 `KeyframeEase(speed, influence)` 写入相邻关键帧段（`setTemporalEaseAtKey`）；In 预设写键的出方向、Out 写入方向、InOut 两侧都写；多维属性按维度重建 ease 数组（尺寸回读该键现有 ease 数组匹配） |
| 过冲类烘焙 | Back/Elastic/Bounce/Wizz 的值会超出关键帧值，时间缓动无法表达——逐帧采样插入 LINEAR 中间关键帧（上限 300 帧/段），先清段内旧中间键（可重复应用） |
| wizz 连续递增强度 | 3 秒内连续点 Apply：第 1 次基础倍率、第 2 次 ×2、第 3 次 ×3……间隔超 3 秒或点「重置」回到 ×1；状态行显示当前倍率与连续次数 |
| 基础倍率 | 滑杆/输入框 0.2–3.0，同时放大缓动的时长占比（influence）与速度；实际倍率 = 基础 × 连续次数 × 抖动系数 |
| 随机抖动 | 输入 ±pct%（默认 0=关）：每次应用给总倍率加随机量（对应原品"可选随机化"） |
| 批量应用 | 作用于时间线中**全部选中属性**的**全部选中关键帧** |
| 空选中防护 | 未激活合成 / 无选中关键帧时弹窗提示并中止，不做任何修改 |
| Undo 组 | 每次 Apply 整体包在 `beginUndoGroup/endUndoGroup`，一次 Ctrl+Z 撤销 |
| 面板双模式 | ScriptUI Panel 停靠 / Run Script File 浮动窗口 |

### 未复刻（与原品的差距）

| 功能 | 说明 |
|------|------|
| 表达式生成型实现 | 原品往属性**写表达式**（Penner 公式按关键帧索引取段实时计算），改关键帧值后缓动跟随；本复刻改写 ease/插帧——改关键帧值后需重新应用（缓动类）或重插帧（过冲类） |
| 数十种全家族 | 原品数十种预设；本复刻 26 条（七族 21 向 + 5 过冲），未覆盖全部家族组合 |
| 烘焙模式开关 | 原品可选"表达式或烘焙"；本复刻缓动类固定走 ease、过冲类固定插帧 |
| 预设自定义/收藏 | 无自定义预设保存 |

---

## 二、安装

1. **面板常驻（推荐）**：把 `main.jsx` 重命名为 `EaseAndWizzClone.jsx`，拷入：
   - Windows：`C:\Program Files\Adobe\Adobe After Effects <版本>\Support Files\Scripts\ScriptUI Panels\`
   - macOS：`/Applications/Adobe After Effects <版本>/Scripts/ScriptUI Panels/`
   **重启 AE**，`Window` 菜单底部勾选打开。
2. **临时运行**：`File > Scripts > Run Script File...` 选 `main.jsx`（浮动窗口，不可停靠）。
3. 不写文件、不联网，无需勾选"允许脚本写文件"；首次运行若弹脚本安全提示按提示允许即可。
4. **未实机验证，建议先在测试工程试**（见第四节）。

## 三、使用

1. 时间线中选中一个或多个属性下的一个或多个关键帧（支持多属性批量）。
2. 下拉选预设，调基础倍率（默认 1.00）；需要"越点越强"保持「连续点击自动加倍」勾选。
3. 点 **Apply**。3 秒内再点一次 = ×2、再点 = ×3……点「重置」或隔 3 秒回到 ×1。
4. 缓动族只改 ease 不改值；过冲族会在段内插帧（先清旧中间键）——不满意 Ctrl+Z 一次全撤。

---

## 四、已知限制与不确定项（如实标注）

1. **未实机验证**：编写环境无 After Effects，仅完成 `node --check`、ES3 扫描、预设计数与保留字自查。首次使用请先在测试工程试。
2. **ease 数组尺寸约定（中置信度）**：不同维度属性的 temporal ease 数组长度约定未实机确认——实现上**优先回读该键现有 `keyInTemporalEase/keyOutTemporalEase` 数组长度**来匹配（规避猜测）；两处 getter 名为文档知识（与 setter `setTemporalEaseAtKey` 对称，任务提示亦印证），若个别 AE 版本异常会走"1D→1、其余→2"回退并可能报错计数。
3. **removeKey 兼容性（中置信度）**：过冲类清段内旧键依赖 `Property.removeKey(index)`；首次调用失败会置标志、本会话跳过清理（表现为重复应用可能叠键）——建议用 Undo 而不是重复应用来调整过冲效果。
4. **缓动不能过冲（AE 本质限制）**：Back/Elastic/Bounce/Wizz 的过冲必须靠插帧；插帧会把段内用户手动打的中间键清掉（可 Undo 恢复）。
5. **带表达式的属性看不出效果**：属性挂了表达式时 ease/插帧被表达式覆盖（原品是表达式方案，恰好相反——在表达式属性上原品有效而本复刻无效）。
6. **Expo InOut 极端**：近似表 (1,0,0,1) 是"保持后瞬移"的极端形状，influence 钳制到 99.95% 后表现为近似骤变，属预期。
7. **Hold 关键帧**：对 hold 键写 ease 可能被 AE 拒绝（按错误计数跳过，不影响其他键）。
8. **随机抖动为整次应用级**：每次 Apply 抽一个随机系数作用于总倍率，不做逐键独立随机。

## 五、自查记录（2026-11-14）

- `node --check`（剥离 `#target aftereffects` 行）：通过。
- ES3 扫描：干净（仅头注注释提及"无 let/const"字样；无箭头函数/模板串/JSON/ES5 数组方法/for-of/可选链）。
- 预设计数：ease 21 + sample 5 = 26 ✓。
- 尾逗号：0 处；保留字扫描：干净。
- 编码：UTF-8 带 BOM（中文 Windows 下 ExtendScript 无 BOM 会按系统码页误读中文字符串）。
- 数学端点自检（推导）：Back In/Out、Bounce Out、Wizz Out 均满足 f(0)=0、f(1)=1；Elastic Out 端点特殊处理。
