﻿#target aftereffects
/**
 * ============================================================================
 *  True Comp Dup Clone —— True Comp Duplicator 的 clean-room 复刻实现
 * ============================================================================
 *
 *  [CLEAN-ROOM 声明]
 *  本脚本依据功能需求描述（intel/paid-list.md 第 10 条 "True Comp Duplicator"）
 *  从零独立编写。编写过程中未反编译原插件，未阅读、复制或改写原插件的任何
 *  源代码、字节码、资源文件；仅依赖 Adobe After Effects 公开脚本 API
 *  （After Effects Scripting Guide）与需求文档。与原产品的相似性仅来自
 *  功能需求本身。
 *
 *  功能概述：
 *    - 递归复制选中 Comp 的整个依赖层级树（嵌套预合成闭包），而非 AE 自带浅复制；
 *    - 生成带递增后缀的唯一命名副本；
 *    - 可选同时复制引用的 Footage 素材；
 *    - 可选按原文件夹结构镜像存放副本；
 *    - UI 提供复制数量预览、排除列表（点击切换）、后缀名输入。
 *
 *  实现要点：
 *    - 图层复制优先使用 layer.copyToComp（API 存在时），并做 source 重映射
 *      （Layer.replaceSource）与父级重链接；copyToComp 不存在时走逐属性
 *      克隆回退路径（clonePropertySpecification / setValue 思路的纯脚本实现）。
 *    - 关键帧（值/时间/插值/时间缓动/空间切线/roving）逐键复制，
 *      表达式字符串原样带过（不重写表达式内的 comp 名称引用）。
 *    - ExtendScript / ES3 兼容：无 let/const/箭头函数/JSON/ES5 数组方法。
 *
 *  兼容环境：After Effects（脚本引擎 ExtendScript），File > Scripts > Run Script File
 *  或放入 ScriptUI Panels 目录。
 * ============================================================================
 */

(function () {

    var SCRIPT_NAME = "True Comp Dup Clone";
    var SCRIPT_VERSION = "1.0.0";
    var SETTINGS_SECTION = "trueCompDupClone";
    var KEY_SUFFIX = "suffix";
    var KEY_FOOTAGE = "copyFootage";
    var KEY_MIRROR = "mirrorFolders";

    /* ======================================================================
     *  基础工具（ES3）
     * ==================================================================== */

    // 数组查找（ES3 没有 Array.prototype.indexOf）
    function esIndexOf(arr, v) {
        for (var i = 0; i < arr.length; i++) {
            if (arr[i] === v) return i;
        }
        return -1;
    }

    function approxEq(a, b) {
        return Math.abs(a - b) < 0.000001;
    }

    function errText(e) {
        var s = "未知错误";
        try {
            if (e != null && e.message != null && e.message !== "") {
                s = e.message;
            } else if (e != null) {
                s = e.toString();
            }
        } catch (e2) {
            s = "未知错误";
        }
        return s;
    }

    /* ======================================================================
     *  设置持久化（app.settings，失败则静默降级为不记忆）
     * ==================================================================== */

    function loadSetting(key, fallback) {
        // 官方指南：getHavingSaved 返回布尔（是否已保存），getSetting 读值
        // （缺失时抛异常）。两段式读取，失败静默降级为 fallback。
        try {
            if (app.settings.getHavingSaved(SETTINGS_SECTION, key)) {
                return app.settings.getSetting(SETTINGS_SECTION, key);
            }
        } catch (e1) {
            // 未保存或读取失败 → fallback
        }
        return fallback;
    }

    function saveSetting(key, value) {
        try {
            app.settings.save(SETTINGS_SECTION, key, value);
        } catch (e1) {}
        try {
            app.settings.saveToDisk();
        } catch (e2) {}
    }

    /* ======================================================================
     *  项目扫描
     * ==================================================================== */

    function getSelectedComps() {
        var out = [];
        try {
            var sel = app.project.selection;
            if (sel != null) {
                for (var i = 0; i < sel.length; i++) {
                    if (sel[i] instanceof CompItem) out.push(sel[i]);
                }
            }
        } catch (e) {}
        return out;
    }

    function getProjectComps() {
        var out = [];
        var numItems = app.project.numItems;
        for (var i = 1; i <= numItems; i++) {
            var it = app.project.item(i);
            if (it instanceof CompItem) out.push(it);
        }
        return out;
    }

    // 单个 comp 的直接依赖：逐图层检查 AVLayer 的 source
    function compDirectDeps(comp) {
        var comps = [];
        var footage = [];
        var n = 0;
        try { n = comp.numLayers; } catch (e0) { n = 0; }
        for (var i = 1; i <= n; i++) {
            var lay = null;
            try { lay = comp.layer(i); } catch (e1) { lay = null; }
            if (lay == null) continue;
            var src = null;
            try { src = lay.source; } catch (e2) { src = null; }
            if (src == null) continue; // 文本/形状/空对象/摄像机/灯光无 source
            if (src instanceof CompItem) {
                comps.push(src);
            } else if (src instanceof FootageItem) {
                footage.push(src);
            }
        }
        return { comps: comps, footage: footage };
    }

    /* ======================================================================
     *  依赖闭包收集：从选中 comp 出发 DFS（后序 = 依赖在前，可按此顺序复制）
     *  excludedIds：String(item.id) -> true；被排除的 comp 不复制也不递归
     * ==================================================================== */

    function collectClosure(rootComps, excludedIds, copyFootage) {
        var compSeen = {};
        var footSeen = {};
        var order = [];

        function visitComp(comp) {
            var cid = String(comp.id);
            if (compSeen[cid]) return;
            compSeen[cid] = true;
            var deps = compDirectDeps(comp);
            var i;
            for (i = 0; i < deps.comps.length; i++) {
                var dc = deps.comps[i];
                var did = String(dc.id);
                if (compSeen[did]) continue;
                if (excludedIds[did]) continue;
                visitComp(dc);
            }
            if (copyFootage) {
                for (i = 0; i < deps.footage.length; i++) {
                    footSeen[String(deps.footage[i].id)] = true;
                }
            }
            order.push(comp);
        }

        for (var r = 0; r < rootComps.length; r++) {
            if (excludedIds[String(rootComps[r].id)]) continue;
            visitComp(rootComps[r]);
        }

        // footage 列表按项目面板顺序输出，保证稳定
        var footageList = [];
        if (copyFootage) {
            var numItems = app.project.numItems;
            for (var j = 1; j <= numItems; j++) {
                var it = app.project.item(j);
                if ((it instanceof FootageItem) && footSeen[String(it.id)]) {
                    footageList.push(it);
                }
            }
        }
        return { comps: order, footage: footageList };
    }

    /* ======================================================================
     *  文件夹镜像：按 parentFolder 链重建（以 item.id 记忆，多 comp 共享）
     * ==================================================================== */

    function resolveFolder(origFolder, folderMap, mirrorOn) {
        if (!mirrorOn || origFolder == null) return null;
        var key = String(origFolder.id);
        if (folderMap[key] != null) return folderMap[key];
        var parentClone = resolveFolder(origFolder.parentFolder, folderMap, mirrorOn);
        var nf = null;
        // 统一在工程根创建，再挂到镜像父文件夹（Item.parentFolder 可写，最稳妥）
        try { nf = app.project.items.addFolder(origFolder.name); } catch (e1) { nf = null; }
        if (nf != null && parentClone != null) {
            try { nf.parentFolder = parentClone; } catch (e2) {}
        }
        if (nf != null) folderMap[key] = nf;
        return nf;
    }

    /* ======================================================================
     *  唯一命名：base + 后缀；若重名则递增 " n"
     * ==================================================================== */

    function nameExists(name) {
        var numItems = app.project.numItems;
        for (var i = 1; i <= numItems; i++) {
            if (app.project.item(i).name === name) return true;
        }
        return false;
    }

    function uniqueName(base) {
        if (!nameExists(base)) return base;
        var n = 2;
        while (n <= 999) {
            var cand = base + " " + n;
            if (!nameExists(cand)) return cand;
            n++;
        }
        return base + "_" + (new Date()).getTime();
    }

    /* ======================================================================
     *  图层匹配（copyToComp 插入位置探测用）：名称 + 入出点近似相等
     * ==================================================================== */

    function layerMatches(lay, ref) {
        try {
            if (lay.name !== ref.name) return false;
            if (!approxEq(lay.inPoint, ref.inPoint)) return false;
            if (!approxEq(lay.outPoint, ref.outPoint)) return false;
            return true;
        } catch (e) {
            return false;
        }
    }

    // copyToComp 后定位"新加的那个图层"（不同 AE 版本插在顶部或底部）
    function pickCopiedRef(newComp, src, modeRef) {
        var after = newComp.numLayers;
        if (after <= 0) return null;
        if (after === 1) return newComp.layer(1);
        if (modeRef.mode === null) {
            if (layerMatches(newComp.layer(after), src)) {
                modeRef.mode = "bottom";
            } else if (layerMatches(newComp.layer(1), src)) {
                modeRef.mode = "top";
            } else {
                modeRef.mode = "bottom";
            }
        }
        if (modeRef.mode === "bottom") return newComp.layer(after);
        return newComp.layer(1);
    }

    /* ======================================================================
     *  source 重映射 / 父级重链接
     * ==================================================================== */

    function remapLayerSource(srcLayer, dstLayer, ctx) {
        var src = null;
        try { src = srcLayer.source; } catch (e) { src = null; }
        if (src == null) return;
        var mapped = ctx.itemMap[String(src.id)];
        if (mapped == null || mapped === src) return;
        try {
            if (dstLayer.replaceSource != null) {
                dstLayer.replaceSource(mapped, true);
            }
        } catch (e2) {}
    }

    function remapLayerParent(srcLayer, dstLayer, newLayers) {
        var pIdx = 0;
        try { pIdx = srcLayer.parent.index; } catch (e0) { pIdx = 0; }
        if (pIdx < 1) return;
        var tgt = newLayers[pIdx];
        if (tgt == null || tgt === dstLayer) return;
        try { dstLayer.parent = tgt; } catch (e1) {}
    }

    /* ======================================================================
     *  属性级复制（copyToComp 不可用时的回退路径）
     * ==================================================================== */

    // TextDocument 克隆：逐字段 try/catch，兼容不同 AE 版本的属性名差异
    function cloneTextDocument(srcTD) {
        if (srcTD == null) return null;
        var td = null;
        try { td = new TextDocument(srcTD.text); } catch (e0) { td = null; }
        if (td == null) return null;
        try { td.font = srcTD.font; } catch (e1) {}
        try { td.fontSize = srcTD.fontSize; } catch (e2) {
            try { td.textSize = srcTD.textSize; } catch (e2b) {}
        }
        try { td.applyFill = srcTD.applyFill; } catch (e3) {}
        try { td.applyStroke = srcTD.applyStroke; } catch (e4) {}
        try { td.fillColor = srcTD.fillColor; } catch (e5) {}
        try { td.strokeColor = srcTD.strokeColor; } catch (e6) {}
        try { td.strokeWidth = srcTD.strokeWidth; } catch (e6b) {}
        try { td.tracking = srcTD.tracking; } catch (e7) {}
        try { td.leading = srcTD.leading; } catch (e8) {}
        try { td.baselineShift = srcTD.baselineShift; } catch (e8b) {
            try { td.baselineLocShift = srcTD.baselineLocShift; } catch (e8c) {}
        }
        try { td.justification = srcTD.justification; } catch (e9) {}
        try { td.autoLeading = srcTD.autoLeading; } catch (e10) {}
        try {
            if (srcTD.boxText) {
                td.boxText = true;
                try { td.boxSize = srcTD.boxSize; } catch (e11b) {}
            }
        } catch (e11) {}
        try { td.fauxBold = srcTD.fauxBold; } catch (e12) {}
        try { td.fauxItalic = srcTD.fauxItalic; } catch (e13) {}
        try { td.allCaps = srcTD.allCaps; } catch (e14) {}
        try { td.smallCaps = srcTD.smallCaps; } catch (e15) {}
        try { td.paragraphJustification = srcTD.paragraphJustification; } catch (e16) {}
        return td;
    }

    // 表达式字符串原样带过
    function copyExpression(srcProp, tgtProp) {
        var expr = null;
        try { expr = srcProp.expression; } catch (e) { expr = null; }
        if (expr == null || expr === "") return;
        try { tgtProp.expression = expr; } catch (e2) {}
    }

    // 时间缓动（KeyframeEase 数组）。官方读取接口为 keyInTemporalEase /
    // keyOutTemporalEase（每维一组 KeyframeEase）；读取失败（如不支持时间
    // 缓动的属性类型）则跳过该键的缓动，值/时间/插值仍由 copyKeyframes 复制。
    function copyTemporalEase(srcProp, tgtProp, k) {
        var inEase = null;
        var outEase = null;
        try { inEase = srcProp.keyInTemporalEase(k); } catch (eA) { inEase = null; }
        try { outEase = srcProp.keyOutTemporalEase(k); } catch (eB) { outEase = null; }
        if (inEase == null && outEase == null) return;
        try { tgtProp.setTemporalEaseAtKey(k, inEase, outEase); } catch (eC) {}
    }

    // 逐键复制：先按时间顺序落键，再补插值/缓动/空间切线/各类开关
    function copyKeyframes(srcProp, tgtProp) {
        var n = 0;
        try { n = srcProp.numKeys; } catch (e0) { n = 0; }
        if (n <= 0) return;
        var i;
        for (i = 1; i <= n; i++) {
            try {
                var t = srcProp.keyTime(i);
                var v = srcProp.keyValue(i);
                tgtProp.setValueAtTime(t, v);
            } catch (e1) {}
        }
        for (i = 1; i <= n; i++) {
            try {
                tgtProp.setInterpolationTypeAtKey(i, srcProp.keyInInterpolationType(i), srcProp.keyOutInterpolationType(i));
            } catch (e2) {}
            try { if (srcProp.keyTemporalAutoBezier(i)) tgtProp.setTemporalAutoBezierAtKey(i, true); } catch (e3) {}
            try { if (srcProp.keyTemporalContinuous(i)) tgtProp.setTemporalContinuousAtKey(i, true); } catch (e4) {}
            try { if (srcProp.keySpatialAutoBezier(i)) tgtProp.setSpatialAutoBezierAtKey(i, true); } catch (e5) {}
            try { if (srcProp.keySpatialContinuous(i)) tgtProp.setSpatialContinuousAtKey(i, true); } catch (e6) {}
            try { if (srcProp.keyRoving(i)) tgtProp.setRovingAtKey(i, true); } catch (e7) {}
            copyTemporalEase(srcProp, tgtProp, i);
            try {
                var tin = srcProp.keyInSpatialTangent(i);
                var tout = srcProp.keyOutSpatialTangent(i);
                if (tin != null && tout != null) tgtProp.setSpatialTangentsAtKey(i, tin, tout);
            } catch (e8) {}
        }
    }

    // Source Text（ADBE Text Document）：文本框文档克隆 + 文本关键帧
    function copySourceTextProp(srcProp, tgtProp) {
        var hasKeys = false;
        try { hasKeys = (srcProp.numKeys > 0); } catch (e0) { hasKeys = false; }
        if (hasKeys) {
            try { copyKeyframes(srcProp, tgtProp); } catch (e1) {}
        } else {
            try {
                var td = cloneTextDocument(srcProp.value);
                if (td != null) tgtProp.setValue(td);
            } catch (e2) {}
        }
        copyExpression(srcProp, tgtProp);
    }

    // 叶子属性：有关键帧走逐键复制，否则整体 setValue（维度由值对象自带）
    function copyLeafProperty(srcProp, tgtProp) {
        var mn = null;
        try { mn = srcProp.matchName; } catch (e0) { mn = null; }
        if (mn === "ADBE Text Document") {
            copySourceTextProp(srcProp, tgtProp);
            return;
        }
        var hasKeys = false;
        try { hasKeys = (srcProp.numKeys > 0); } catch (e1) { hasKeys = false; }
        if (hasKeys) {
            copyKeyframes(srcProp, tgtProp);
            copyExpression(srcProp, tgtProp);
            return;
        }
        try {
            var v = srcProp.value;
            if (v != null) tgtProp.setValue(v);
        } catch (e2) {}
        copyExpression(srcProp, tgtProp);
    }

    // 按 matchName 递归克隆属性树；目标缺失的组尝试 addProperty（效果/蒙版/形状）
    function walkPropertyGroup(srcGroup, tgtGroup, isLayerRoot) {
        var n = 0;
        try { n = srcGroup.numProperties; } catch (e0) { n = 0; }
        for (var i = 1; i <= n; i++) {
            var child = null;
            try { child = srcGroup.property(i); } catch (e1) { child = null; }
            if (child == null) continue;
            var mn = null;
            try { mn = child.matchName; } catch (e2) { mn = null; }
            if (mn == null) continue;
            if (isLayerRoot && mn === "ADBE Marker Parade") continue; // 标记单独处理
            var childIsGroup = false;
            try { childIsGroup = (child.numProperties !== undefined); } catch (e3) {}
            var tgtChild = null;
            try { tgtChild = tgtGroup.property(mn); } catch (e4) { tgtChild = null; }
            if (tgtChild == null) {
                if (childIsGroup) {
                    try {
                        if (tgtGroup.canAddProperty != null && tgtGroup.canAddProperty(mn)) {
                            tgtChild = tgtGroup.addProperty(mn);
                        }
                    } catch (e5) {
                        tgtChild = null;
                    }
                }
                if (tgtChild == null) continue;
            }
            if (childIsGroup) {
                walkPropertyGroup(child, tgtChild, false);
                try { tgtChild.name = child.name; } catch (e6) {}
            } else {
                copyLeafProperty(child, tgtChild);
            }
        }
    }

    // 层标记（ADBE Marker Parade）：new MarkerValue 值拷贝 + 尽力设置时间
    function copyLayerMarkers(srcLayer, dstLayer) {
        var srcMarkers = null;
        var dstMarkers = null;
        try { srcMarkers = srcLayer.property("ADBE Marker Parade"); } catch (e0) { srcMarkers = null; }
        if (srcMarkers == null) return;
        try { dstMarkers = dstLayer.property("ADBE Marker Parade"); } catch (e1) { dstMarkers = null; }
        if (dstMarkers == null) return;
        var n = 0;
        try { n = srcMarkers.numProperties; } catch (e2) { n = 0; }
        for (var i = 1; i <= n; i++) {
            var sm = null;
            try { sm = srcMarkers.property(i); } catch (e3) { sm = null; }
            if (sm == null) continue;
            var added = null;
            try { added = dstMarkers.addProperty("ADBE Marker"); } catch (e4) { added = null; }
            if (added == null) continue;
            try {
                var mv = sm.value;
                added.setValue(mv);
                try {
                    var cur = added.value;
                    try { cur.comment = mv.comment; } catch (c1) {}
                    try { cur.duration = mv.duration; } catch (c2) {}
                    try { cur.label = mv.label; } catch (c3) {}
                    try { cur.chapter = mv.chapter; } catch (c4) {}
                    try { cur.url = mv.url; } catch (c5) {}
                    try { cur.cuePointName = mv.cuePointName; } catch (c6) {}
                    added.setValue(cur);
                } catch (eP) {}
                try { added.startTime = sm.startTime; } catch (eT) {}
            } catch (e5) {}
        }
    }

    // 图层级属性（手动路径收尾）；locked 必须最后设置
    function copyLayerAttrs(src, dst) {
        try { dst.name = src.name; } catch (a1) {}
        try { dst.label = src.label; } catch (a2) {}
        try { dst.comment = src.comment; } catch (a3) {}
        try { dst.quality = src.quality; } catch (a4) {}
        try { dst.enabled = src.enabled; } catch (a5) {}
        try { dst.solo = src.solo; } catch (a6) {}
        try { dst.shy = src.shy; } catch (a7) {}
        try { dst.guideLayer = src.guideLayer; } catch (a8) {}
        try { dst.blendingMode = src.blendingMode; } catch (a9) {}
        try { dst.trackMatteType = src.trackMatteType; } catch (a10) {}
        try { dst.preserveTransparency = src.preserveTransparency; } catch (a11) {}
        try { dst.motionBlur = src.motionBlur; } catch (a12) {}
        try { dst.effectsMotionBlur = src.effectsMotionBlur; } catch (a13) {}
        try { dst.audioEnabled = src.audioEnabled; } catch (a14) {}
        try { dst.autoOrient = src.autoOrient; } catch (a15) {}
        try { dst.selected = false; } catch (a16) {}
        try { dst.startTime = src.startTime; } catch (b1) {}
        try { dst.stretch = src.stretch; } catch (b2) {}
        try { dst.inPoint = src.inPoint; } catch (b3) {}
        try { dst.outPoint = src.outPoint; } catch (b4) {}
        try { dst.locked = src.locked; } catch (b5) {}
    }

    // 手动逐属性克隆整个图层（copyToComp 不可用时的回退）
    function copyLayerManual(src, comp, ctx) {
        var newLayer = null;
        var isText = false;
        var isShape = false;
        var isCam = false;
        var isLight = false;
        try { isText = (src instanceof TextLayer); } catch (eA) {}
        try { isShape = (!isText && src instanceof ShapeLayer); } catch (eB) {}
        try { isCam = (src instanceof CameraLayer); } catch (eC) {}
        try { isLight = (src instanceof LightLayer); } catch (eD) {}

        var flagNull = false;
        var flagAdj = false;
        var flag3D = false;
        var flagTR = false;
        var flagEnv = false;
        try { flagNull = src.nullLayer; } catch (eF1) {}
        try { flagAdj = src.adjustmentLayer; } catch (eF2) {}
        try { flag3D = src.threeDLayer; } catch (eF3) {}
        try { flagTR = src.timeRemapEnabled; } catch (eF4) {}
        try { flagEnv = src.environmentLayer; } catch (eF5) {}

        var srcItem = null;
        try { srcItem = src.source; } catch (eF6) { srcItem = null; }

        if (isText) {
            var td = null;
            try { td = cloneTextDocument(src.text.sourceText.value); } catch (eT) { td = null; }
            if (td != null) {
                try { newLayer = comp.layers.addText(td); } catch (eT2) { newLayer = null; }
            }
            if (newLayer == null) {
                // TextDocument 克隆失败时至少保住纯文本内容
                var rawText = "";
                try { rawText = String(src.text.sourceText.value.text); } catch (eT3) { rawText = ""; }
                newLayer = comp.layers.addText(rawText);
            }
        } else if (isCam) {
            var cp = [comp.width / 2, comp.height / 2];
            try {
                var pv = src.property("ADBE Transform Group").property("ADBE Position").value;
                if (pv != null && pv.length >= 2) cp = [pv[0], pv[1]];
            } catch (eP) {}
            newLayer = comp.layers.addCamera(src.name, cp);
        } else if (isLight) {
            var lp = [comp.width / 2, comp.height / 2];
            try {
                var lv = src.property("ADBE Transform Group").property("ADBE Position").value;
                if (lv != null && lv.length >= 2) lp = [lv[0], lv[1]];
            } catch (eQ) {}
            newLayer = comp.layers.addLight(src.name, lp);
        } else if (isShape) {
            newLayer = comp.layers.addShape();
        } else {
            if (flagNull) {
                newLayer = comp.layers.addNull(comp.duration);
            } else if (flagAdj && srcItem == null) {
                newLayer = comp.layers.addSolid([1, 1, 1], src.name, comp.width, comp.height, comp.pixelAspect, comp.duration);
            } else if (srcItem != null) {
                var mapped = ctx.itemMap[String(srcItem.id)];
                newLayer = comp.layers.add(mapped != null ? mapped : srcItem);
            } else {
                newLayer = comp.layers.addSolid([1, 1, 1], src.name, comp.width, comp.height, comp.pixelAspect, comp.duration);
            }
        }
        if (newLayer == null) {
            throw new Error("图层创建失败: " + src.name);
        }

        // 结构开关先行：决定属性树里存在哪些组（3D 材质选项 / 时间重映射等）
        if (!isCam && !isLight) {
            try { if (flag3D) newLayer.threeDLayer = true; } catch (g1) {}
        }
        try { if (flagTR) newLayer.timeRemapEnabled = true; } catch (g2) {}
        try { if (flagEnv) newLayer.environmentLayer = true; } catch (g3) {}
        try { if (flagAdj) newLayer.adjustmentLayer = true; } catch (g4) {}

        walkPropertyGroup(src, newLayer, true);
        copyLayerMarkers(src, newLayer);
        copyLayerAttrs(src, newLayer);
        return newLayer;
    }

    /* ======================================================================
     *  Comp 级复制
     * ==================================================================== */

    function copyCompAttributes(orig, nc) {
        try { nc.bgColor = orig.bgColor; } catch (e1) {}
        try { nc.label = orig.label; } catch (e2) {}
        try { nc.comment = orig.comment; } catch (e3) {}
        try { nc.motionBlur = orig.motionBlur; } catch (e4) {}
        try { nc.shutterAngle = orig.shutterAngle; } catch (e5) {}
        try { nc.shutterPhase = orig.shutterPhase; } catch (e6) {}
        try { nc.resolutionFactor = orig.resolutionFactor; } catch (e7) {}
        try {
            if (orig.duration > 0 && orig.workAreaDuration >= 0) {
                nc.workAreaStart = orig.workAreaStart;
                nc.workAreaDuration = orig.workAreaDuration;
            }
        } catch (e8) {}
        try { nc.renderer = orig.renderer; } catch (e9) {}
    }

    function copyCompLayers(srcComp, newComp, ctx, modeRef) {
        var n = 0;
        try { n = srcComp.numLayers; } catch (e0) { n = 0; }
        if (n <= 0) return;

        // copyToComp 能力探测（API 存在则优先走该路径）
        var useCopyToComp = false;
        var probe = null;
        try { probe = srcComp.layer(1); } catch (eP) { probe = null; }
        if (probe != null && probe.copyToComp != null) useCopyToComp = true;

        var newLayers = [];
        for (var i = 1; i <= n; i++) {
            var src = null;
            try { src = srcComp.layer(i); } catch (eL0) { src = null; }
            if (src == null) {
                newLayers[i] = null;
                continue;
            }
            var ref = null;
            if (useCopyToComp) {
                var before = newComp.numLayers;
                try {
                    src.copyToComp(newComp);
                    ref = pickCopiedRef(newComp, src, modeRef);
                } catch (eCT) {
                    var mid = newComp.numLayers;
                    if (mid > before) {
                        // copyToComp 中途异常但已落层：按底部插入处理
                        modeRef.mode = "bottom";
                        try { ref = newComp.layer(mid); } catch (eR1) { ref = null; }
                    } else {
                        try { ref = copyLayerManual(src, newComp, ctx); } catch (eM) { ref = null; }
                    }
                }
            } else {
                try { ref = copyLayerManual(src, newComp, ctx); } catch (eM2) { ref = null; }
            }
            if (ref == null) {
                ctx.errors.push("第 " + i + " 层「" + src.name + "」未能复制（已跳过）");
            }
            newLayers[i] = ref;
        }

        // copyToComp 若是顶部插入，按原层序用 moveAfter 链修正为自上而下
        if (useCopyToComp && modeRef.mode === "top") {
            for (var k = 2; k <= n; k++) {
                try {
                    if (newLayers[k] != null && newLayers[k - 1] != null) {
                        newLayers[k].moveAfter(newLayers[k - 1]);
                    }
                } catch (eMv) {}
            }
        }

        // 层序稳定后：source 重映射到新副本 / 父级重链接
        for (var j = 1; j <= n; j++) {
            var srcL = null;
            try { srcL = srcComp.layer(j); } catch (eL1) { srcL = null; }
            var dstL = newLayers[j];
            if (srcL == null || dstL == null) continue;
            remapLayerSource(srcL, dstL, ctx);
            remapLayerParent(srcL, dstL, newLayers);
        }
    }

    function copyComp(orig, ctx) {
        var folder = resolveFolder(orig.parentFolder, ctx.folderMap, ctx.mirrorFolders);
        var newName = uniqueName(orig.name + ctx.suffix);
        var newComp = app.project.items.addComp(newName, orig.width, orig.height, orig.pixelAspect, orig.duration, orig.frameRate);
        copyCompAttributes(orig, newComp);
        if (folder != null) {
            try { newComp.parentFolder = folder; } catch (eF) {}
        }
        var modeRef = { mode: null };
        copyCompLayers(orig, newComp, ctx, modeRef);
        ctx.itemMap[String(orig.id)] = newComp;
        ctx.compMap[String(orig.id)] = newComp;
        ctx.copiedComps.push(orig.name + " -> " + newComp.name);
        return newComp;
    }

    /* ======================================================================
     *  Footage 复制（可选）：Item.duplicate 共享同一源文件
     * ==================================================================== */

    function copyFootageItem(orig, ctx) {
        var folder = resolveFolder(orig.parentFolder, ctx.folderMap, ctx.mirrorFolders);
        var nf = null;
        try { nf = orig.duplicate(); } catch (e0) { nf = null; }
        if (nf == null) {
            ctx.errors.push("footage「" + orig.name + "」复制失败（保留共享原素材）");
            return null;
        }
        try { nf.name = uniqueName(orig.name + ctx.suffix); } catch (e1) {}
        if (folder != null) {
            try { nf.parentFolder = folder; } catch (e2) {}
        }
        ctx.itemMap[String(orig.id)] = nf;
        ctx.copiedFootage.push(orig.name + " -> " + nf.name);
        return nf;
    }

    /* ======================================================================
     *  主流程
     * ==================================================================== */

    function runDuplication(rootComps, excludedIds, opts) {
        var ctx = {
            suffix: opts.suffix,
            mirrorFolders: opts.mirrorFolders,
            itemMap: {},
            folderMap: {},
            compMap: {},
            copiedComps: [],
            copiedFootage: [],
            errors: []
        };

        var closure = collectClosure(rootComps, excludedIds, opts.copyFootage);

        // 1) footage 先复制（依赖顺序：素材 -> 底层 comp -> 上层 comp）
        for (var f = 0; f < closure.footage.length; f++) {
            try {
                copyFootageItem(closure.footage[f], ctx);
            } catch (eF) {
                ctx.errors.push("footage「" + closure.footage[f].name + "」复制异常：" + errText(eF));
            }
        }

        // 2) comp 按依赖在前（DFS 后序）逐个复制
        for (var c = 0; c < closure.comps.length; c++) {
            var orig = closure.comps[c];
            try {
                copyComp(orig, ctx);
            } catch (eC) {
                ctx.errors.push("comp「" + orig.name + "」复制异常：" + errText(eC));
            }
        }

        // 3) 收尾：全不选中，选中新根 comp 并设为活动项
        var newRoot = ctx.compMap[String(rootComps[0].id)];
        if (newRoot == null) newRoot = null;
        try {
            var numItems = app.project.numItems;
            for (var s = 1; s <= numItems; s++) {
                app.project.item(s).selected = false;
            }
        } catch (eS) {}
        if (newRoot != null) {
            try { newRoot.selected = true; } catch (eSel) {}
            try { app.project.activeItem = newRoot; } catch (eAct) {}
        }

        return {
            compCount: ctx.copiedComps.length,
            footCount: ctx.copiedFootage.length,
            newRootName: (newRoot != null ? newRoot.name : null),
            errors: ctx.errors
        };
    }

    function doRun(rootComps, excludedIds, opts) {
        app.beginUndoGroup(SCRIPT_NAME);
        try {
            var result = runDuplication(rootComps, excludedIds, opts);
            var lines = ["复制完成：共创建 " + result.compCount + " 个 comp 副本"];
            if (opts.copyFootage) {
                lines.push("创建 " + result.footCount + " 个 footage 副本");
            } else {
                lines.push("footage 未复制（共享原素材）");
            }
            if (result.newRootName != null) {
                lines.push("根副本：" + result.newRootName);
            }
            if (result.errors.length > 0) {
                lines.push("---- 警告 " + result.errors.length + " 条 ----");
                var max = Math.min(result.errors.length, 8);
                for (var i = 0; i < max; i++) {
                    lines.push(result.errors[i]);
                }
                if (result.errors.length > max) {
                    lines.push("…… 其余 " + (result.errors.length - max) + " 条从略");
                }
            }
            alert(lines.join("\n"), SCRIPT_NAME);
        } catch (e) {
            var msg = "执行失败：" + errText(e);
            try { if (e.line != null) msg += "（行 " + e.line + "）"; } catch (e2) {}
            alert(msg, SCRIPT_NAME);
        } finally {
            try { app.endUndoGroup(); } catch (e3) {}
        }
    }

    /* ======================================================================
     *  UI（ScriptUI，ES3）
     * ==================================================================== */

    function buildUI() {
        var selComps = getSelectedComps();
        var excludedIds = {};
        var LIST_MARK = "  \u2713   ";
        var LIST_BLANK = "      ";

        var w = new Window("dialog", SCRIPT_NAME + " v" + SCRIPT_VERSION);
        w.orientation = "column";
        w.alignChildren = ["fill", "top"];
        w.spacing = 8;
        w.margins = 16;

        var countText = w.add("statictext", undefined, "");
        countText.preferredSize = [430, 34];

        var nameGrp = w.add("group");
        nameGrp.orientation = "row";
        nameGrp.alignChildren = ["left", "center"];
        nameGrp.add("statictext", undefined, "名称后缀：");
        var suffixEdit = nameGrp.add("edittext");
        suffixEdit.characters = 16;
        suffixEdit.text = loadSetting(KEY_SUFFIX, " 2");
        nameGrp.add("statictext", undefined, "（重名时自动递增编号）");

        var chkGrp = w.add("group");
        chkGrp.orientation = "row";
        chkGrp.alignChildren = ["left", "center"];
        var footChk = chkGrp.add("checkbox", undefined, "同时复制 footage 素材");
        footChk.value = (loadSetting(KEY_FOOTAGE, "0") === "1");
        var mirrorChk = chkGrp.add("checkbox", undefined, "镜像原始文件夹结构");
        mirrorChk.value = (loadSetting(KEY_MIRROR, "1") === "1");

        w.add("statictext", undefined, "排除列表（点击条目切换排除；被排除的 comp 不复制也不递归）：");
        var lb = w.add("listbox", undefined, []);
        lb.preferredSize = [430, 200];
        var comps = getProjectComps();
        for (var i = 0; i < comps.length; i++) {
            var it = lb.add("item", LIST_BLANK + comps[i].name);
            it.compId = String(comps[i].id);
            it.compName = comps[i].name;
        }
        lb.onChange = function () {
            var row = this.selection;
            if (row == null || row.compId == null) return;
            if (excludedIds[row.compId]) {
                delete excludedIds[row.compId];
                row.text = LIST_BLANK + row.compName;
            } else {
                excludedIds[row.compId] = true;
                row.text = LIST_MARK + row.compName;
            }
            updateCount();
        };

        function updateCount() {
            if (selComps.length === 0) {
                countText.text = "未选中 Comp：请在项目面板选中要复制的合成后点「刷新选中」。";
                return;
            }
            var clo = collectClosure(selComps, excludedIds, footChk.value);
            var msg = "已选 " + selComps.length + " 个根 comp，将复制 " + clo.comps.length + " 个 comp（含依赖闭包）";
            if (footChk.value) {
                msg += " + " + clo.footage.length + " 个 footage 素材";
            } else {
                msg += "（footage 共享不复制）";
            }
            countText.text = msg;
        }

        var btnGrp = w.add("group");
        btnGrp.orientation = "row";
        btnGrp.alignment = ["right", "bottom"];
        var refreshBtn = btnGrp.add("button", undefined, "刷新选中");
        var clearBtn = btnGrp.add("button", undefined, "清除排除");
        var runBtn = btnGrp.add("button", undefined, "创建副本");
        var cancelBtn = btnGrp.add("button", undefined, "取消");

        refreshBtn.onClick = function () {
            selComps = getSelectedComps();
            updateCount();
        };
        clearBtn.onClick = function () {
            excludedIds = {};
            for (var k = 0; k < lb.items.length; k++) {
                lb.items[k].text = LIST_BLANK + lb.items[k].compName;
            }
            updateCount();
        };
        runBtn.onClick = function () {
            if (selComps.length === 0) {
                alert("请先在项目面板选中要复制的 Comp。", SCRIPT_NAME);
                return;
            }
            var opts = {
                suffix: suffixEdit.text,
                mirrorFolders: mirrorChk.value,
                copyFootage: footChk.value
            };
            saveSetting(KEY_SUFFIX, opts.suffix);
            saveSetting(KEY_FOOTAGE, opts.copyFootage ? "1" : "0");
            saveSetting(KEY_MIRROR, opts.mirrorFolders ? "1" : "0");
            w.close(1);
            doRun(selComps, excludedIds, opts);
        };
        cancelBtn.onClick = function () {
            w.close(0);
        };

        footChk.onClick = updateCount;
        updateCount();
        w.center();
        w.show();
    }

    /* ======================================================================
     *  入口
     * ==================================================================== */

    function main() {
        if (app.project == null) {
            alert("请先打开一个 After Effects 工程。", SCRIPT_NAME);
            return;
        }
        buildUI();
    }

    try {
        main();
    } catch (eFatal) {
        var fatalMsg = "脚本初始化失败：" + errText(eFatal);
        try {
            if (eFatal.line != null) fatalMsg += "（行 " + eFatal.line + "）";
        } catch (eL) {}
        alert(fatalMsg, SCRIPT_NAME);
    }
})();
