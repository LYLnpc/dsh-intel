// =============================================================================
//  SquirrelClone v1.0  --  After Effects layer-hierarchy tree panel
//  generated_at: 2026-11-14T00:26:00Z
//  task: clean-room clone of "Squirrel" (paid-list.md #13, A-class, jsx)
// -----------------------------------------------------------------------------
//  CLEAN-ROOM DECLARATION
//  This script is an independent reimplementation written ONLY from the public
//  feature description: "A hierarchy editor that converts your timeline into an
//  interactive treeview based on layer parenting, much like what you would
//  find in any 3D application." No original product code was decompiled, read,
//  copied or translated. All AE API usage follows docs/api-cheatsheet.md;
//  non-whitelisted APIs are wrapped in try/catch.
//  Target: After Effects CS6+ (ExtendScript), ES3 only, pure ASCII UI strings.
// =============================================================================

(function squirrelClone(thisObj) {

    var TOOL = "SquirrelClone";
    var VER = "1.0";
    var MAX_DEPTH = 32;      // tree recursion guard
    var MAX_CHAIN = 64;      // parent-chain walk guard

    // ---------------------------------------------------------------
    // tiny utils
    // ---------------------------------------------------------------

    function msg(e) {
        return (e && e.message) ? e.message : String(e);
    }

    function isComp(item) {
        return (item && item instanceof CompItem);
    }

    function activeComp() {
        if (!app.project) {
            throw new Error("No project open.");
        }
        var comp = app.project.activeItem;
        if (!isComp(comp)) {
            throw new Error("Activate a composition first (click inside its timeline).");
        }
        return comp;
    }

    function layerByIndex(comp, idx) {
        try {
            return comp.layer(idx);
        } catch (eL) {
            return null;
        }
    }

    // is maybeAncestor on the parent chain of child? (cycle guard)
    function isAncestorOf(child, maybeAncestor) {
        var cur = child;
        var depth = 0;
        while (cur && cur.parent && depth < MAX_CHAIN) {
            if (cur.parent.index === maybeAncestor.index) { return true; }
            cur = cur.parent;
            depth++;
        }
        return false;
    }

    // group layers by parent index: roots (no parent) + children map
    function hierarchyMap(comp) {
        var roots = [];
        var kids = {};
        var i, L, pi;
        for (i = 1; i <= comp.numLayers; i++) {
            L = comp.layer(i);
            if (L.parent) {
                pi = L.parent.index;
                if (!kids[pi]) { kids[pi] = []; }
                kids[pi].push(L);
            } else {
                roots.push(L);
            }
        }
        // timeline order everywhere (index ascending = top to bottom)
        roots.sort(function (a, b) { return a.index - b.index; });
        var k;
        for (k in kids) {
            if (kids.hasOwnProperty(k)) {
                kids[k].sort(function (a, b) { return a.index - b.index; });
            }
        }
        return { roots: roots, kids: kids };
    }

    // ---------------------------------------------------------------
    // tree building
    // ---------------------------------------------------------------

    function addSubtree(parentNode, layer, kids, depth) {
        var children = kids[layer.index] || [];
        var label = layer.name + "  [" + layer.index + "]";
        var node;
        if (children.length > 0) {
            node = parentNode.add("node", label);
        } else {
            node = parentNode.add("item", label);
        }
        node.layerIndex = layer.index;
        if (children.length > 0 && depth < MAX_DEPTH) {
            var i;
            for (i = 0; i < children.length; i++) {
                addSubtree(node, children[i], kids, depth + 1);
            }
        }
    }

    function rebuildTree(tree, comp) {
        tree.removeAll();
        var h = hierarchyMap(comp);
        var i;
        for (i = 0; i < h.roots.length; i++) {
            addSubtree(tree, h.roots[i], h.kids, 0);
        }
        return h.roots.length;
    }

    // ---------------------------------------------------------------
    // actions
    // ---------------------------------------------------------------

    function selectInComp(tree) {
        var comp = activeComp();
        var node = tree.selection;
        if (!node || node.layerIndex === undefined) {
            throw new Error("Pick a layer in the tree first.");
        }
        var target = layerByIndex(comp, node.layerIndex);
        if (!target) {
            throw new Error("Layer no longer exists (index " + node.layerIndex + ") - refresh the tree.");
        }
        var changed = 0;
        var i, L;
        for (i = 1; i <= comp.numLayers; i++) {
            L = comp.layer(i);
            var want = (L.index === target.index);
            if (L.selected !== want) {
                L.selected = want;
                changed++;
            }
        }
        return "Selected '" + target.name + "' in the comp.";
    }

    function doParent(comp, sel, parentLayer, errors) {
        var i, L;
        for (i = 0; i < sel.length; i++) {
            L = sel[i];
            if (parentLayer) {
                if (L.index === parentLayer.index) {
                    errors.push("'" + L.name + "' is the chosen parent itself - skipped.");
                    continue;
                }
                if (isAncestorOf(L, parentLayer)) {
                    errors.push("'" + L.name + "' -> '" + parentLayer.name +
                        "' would create a cycle - skipped.");
                    continue;
                }
            }
            try {
                L.parent = parentLayer; // null unparents
            } catch (eP) {
                errors.push("Cannot re-parent '" + L.name + "': " + msg(eP));
            }
        }
    }

    function doRename(comp, sel, base, errors) {
        // timeline order, auto-suffix when renaming several layers
        var arr = sel.slice(0);
        arr.sort(function (a, b) { return a.index - b.index; });
        var i, L, nm;
        for (i = 0; i < arr.length; i++) {
            L = arr[i];
            nm = (arr.length > 1) ? (base + " " + (i + 1)) : base;
            try {
                L.name = nm;
            } catch (eR) {
                errors.push("Cannot rename '" + L.name + "': " + msg(eR));
            }
        }
        return arr.length;
    }

    function chosenParentLayer(dd, comp) {
        if (!dd.selection) { return undefined; }
        if (dd.selection.index2 === 0) { return null; } // "None (unparent)"
        return layerByIndex(comp, dd.selection.index2);
    }

    // ---------------------------------------------------------------
    // UI
    // ---------------------------------------------------------------

    var uiRefs = { tree: null, ddParent: null, status: null };

    function setStatus(s) {
        if (uiRefs.status) { uiRefs.status.text = s; }
    }

    function refreshPanel(tree, dd) {
        var comp = activeComp();
        var rootCount = rebuildTree(tree, comp);
        // parent dropdown: index2 = 0 -> unparent, else layer index
        dd.removeAll();
        var it0 = dd.add("item", "None (unparent)");
        it0.index2 = 0;
        var i, L, it;
        for (i = 1; i <= comp.numLayers; i++) {
            L = comp.layer(i);
            it = dd.add("item", L.name);
            it.index2 = L.index;
        }
        if (dd.items.length > 0) { dd.selection = dd.items[0]; }
        setStatus(rootCount + " root layer(s), " + comp.numLayers + " total.");
    }

    function buildUI(thisObj) {
        var win = (thisObj instanceof Panel)
            ? thisObj
            : new Window("palette", TOOL + " v" + VER, undefined, { resizeable: true });
        win.orientation = "column";
        win.alignChildren = ["fill", "top"];
        win.spacing = 6;
        win.margins = 10;

        var tree = win.add("treeview", undefined, []);
        tree.size = [250, 210];
        tree.helpTip = "Timeline hierarchy (layer.parent chains). Pick a row, then use the buttons.";
        uiRefs.tree = tree;

        var gP = win.add("group");
        gP.orientation = "row";
        gP.alignChildren = ["left", "center"];
        gP.add("statictext", undefined, "Parent to:");
        var dd = gP.add("dropdownlist", undefined, []);
        dd.size = [160, 22];
        uiRefs.ddParent = dd;

        var gBtn1 = win.add("group");
        gBtn1.orientation = "row";
        var btnParent = gBtn1.add("button", undefined, "PARENT SEL");
        btnParent.helpTip = "Re-parent all comp-selected layers to the dropdown choice";
        var btnUnparent = gBtn1.add("button", undefined, "UNPARENT SEL");
        btnUnparent.helpTip = "Remove parenting from all comp-selected layers";

        var gRn = win.add("group");
        gRn.orientation = "row";
        gRn.alignChildren = ["left", "center"];
        var etName = gRn.add("edittext", undefined, "");
        etName.characters = 18;
        etName.helpTip = "New name (auto-suffix 1..N when several layers are selected)";
        var btnRename = gRn.add("button", undefined, "RENAME SEL");

        var gBtn2 = win.add("group");
        gBtn2.orientation = "row";
        var btnSelect = gBtn2.add("button", undefined, "SELECT IN COMP");
        btnSelect.helpTip = "Make the picked tree row the only selected layer";
        var btnRefresh = gBtn2.add("button", undefined, "REFRESH TREE");

        var st = win.add("statictext", undefined, "Ready.");
        st.characters = 58;
        st.multiline = true;
        uiRefs.status = st;

        btnParent.onClick = function () {
            try {
                var comp = activeComp();
                var sel = comp.selectedLayers;
                if (sel.length === 0) {
                    throw new Error("Select layer(s) in the timeline first.");
                }
                var parentLayer = chosenParentLayer(dd, comp);
                if (parentLayer === undefined) {
                    throw new Error("Pick a parent in the dropdown first.");
                }
                var errors = [];
                app.beginUndoGroup(TOOL + ": re-parent");
                try {
                    doParent(comp, sel, parentLayer, errors);
                } finally {
                    app.endUndoGroup();
                }
                refreshPanel(tree, dd);
                setStatus("Re-parented " + sel.length + " layer(s)." +
                    (errors.length > 0 ? " Warnings: " + errors.join(" | ") : ""));
            } catch (e) {
                alert(TOOL + " error:\n" + msg(e));
            }
        };

        btnUnparent.onClick = function () {
            try {
                var comp = activeComp();
                var sel = comp.selectedLayers;
                if (sel.length === 0) {
                    throw new Error("Select layer(s) in the timeline first.");
                }
                var errors = [];
                app.beginUndoGroup(TOOL + ": unparent");
                try {
                    doParent(comp, sel, null, errors);
                } finally {
                    app.endUndoGroup();
                }
                refreshPanel(tree, dd);
                setStatus("Un-parented " + sel.length + " layer(s)." +
                    (errors.length > 0 ? " Warnings: " + errors.join(" | ") : ""));
            } catch (e) {
                alert(TOOL + " error:\n" + msg(e));
            }
        };

        btnRename.onClick = function () {
            try {
                var comp = activeComp();
                var sel = comp.selectedLayers;
                if (sel.length === 0) {
                    throw new Error("Select layer(s) in the timeline first.");
                }
                var base = etName.text.replace(/^\s+|\s+$/g, "");
                if (base === "") {
                    throw new Error("Type a new name first.");
                }
                var errors = [];
                var n;
                app.beginUndoGroup(TOOL + ": rename");
                try {
                    n = doRename(comp, sel, base, errors);
                } finally {
                    app.endUndoGroup();
                }
                refreshPanel(tree, dd);
                setStatus("Renamed " + n + " layer(s)." +
                    (errors.length > 0 ? " Warnings: " + errors.join(" | ") : ""));
            } catch (e) {
                alert(TOOL + " error:\n" + msg(e));
            }
        };

        btnSelect.onClick = function () {
            try {
                setStatus(selectInComp(tree));
            } catch (e) {
                alert(TOOL + " error:\n" + msg(e));
            }
        };

        btnRefresh.onClick = function () {
            try {
                refreshPanel(tree, dd);
            } catch (e) {
                alert(TOOL + " error:\n" + msg(e));
            }
        };

        win.onResizing = win.onResize = function () {
            this.layout.resize();
        };
        win.layout.layout(true);
        return win;
    }

    var win = buildUI(thisObj);
    if (win instanceof Window) {
        win.center();
        win.show();
    } else {
        win.layout.layout(true);
    }
    try {
        refreshPanel(uiRefs.tree, uiRefs.ddParent);
    } catch (eBoot) {
        // no active comp at startup: fine, user presses REFRESH later
    }

})(this);
