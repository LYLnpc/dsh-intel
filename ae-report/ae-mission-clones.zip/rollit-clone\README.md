---
generated_at: 2026-11-14T00:06:23Z
task: clean-room 复刻收费脚本 Roll it!（图层滚动工具）——main.jsx + README；功能输入来自 intel/paid-list.md 的 Roll it! 条目与任务下发的功能基线；未反编译、未接触原代码
---

# RollIt Clone v1.0

clean-room 复刻的 AE「真实滚动」工具。图层沿指定轴位移 D 时自动产生贴合滚动旋转：

```
rotation = D × 方向 × 倍速 / (π × 直径) × 360°    （周长公式 C = π·d）
```

直径按图层实际包围盒自动计算（`sourceRectAtTime`，X 轴/路径滚动取 width，Y 轴滚动取 height；取不到时回退 `layer.width/height`）。

## Clean-room 声明

本工具仅依据公开的功能描述（paid-list.md 条目 + 任务功能基线）从零实现。未反编译、未读取、未复制、未翻译任何原产品代码。滚动=位移联动旋转属于通用物理常识。所有 AE API 均对照 `docs/api-cheatsheet.md` 白名单使用；白名单未收录的 API 一律包 try/catch（见下文"API 合规"）。

## 文件

| 文件 | 说明 |
|---|---|
| `main.jsx` | 全部实现。ES3 / ExtendScript，无外部依赖，纯 ASCII（避免 Windows 编码问题） |
| `README.md` | 本文件 |

安装：拷入 AE 的 `ScriptUI Panels` 目录后在 Window 菜单打开；或 File > Scripts > Run Script File 直接运行。

## 功能与基线对照

| 基线要求 | 实现 |
|---|---|
| 周长公式滚动（D→角度） | 表达式与烘焙两种模式均按 `D/(π·d)·360°` 计算 |
| 直径自动取 sourceRectAtTime | 表达式内实时取（文本/形状随时间变化也跟随）；烘焙模式在起始时间取一次 |
| 两关键帧间自动插值滚动 | 表达式模式每帧采样位置差分（preExpression），任意缓动/任意键数都真实滚动；烘焙模式逐帧采样写关键帧 |
| 沿路径滚动（mask path 累计弧长近似） | 烘焙模式：蒙版路径贝塞尔细分（每段 12 子段）→ 累计弧长表 → 二分查找按弧长定位；**往返路径用相邻位移点积判向，倒车自动反转滚向** |
| 轴向 X/Y/沿路径 | UI 单选 |
| 方向正反 + 倍速 | UI 单选 + 数字输入（烘焙为数值因子；表达式模式写入表达式常量 `rollDir/rollK`） |
| undo 组 | 每次应用 `app.beginUndoGroup`/`endUndoGroup`（try/finally 成对） |
| 空选中防护 | 无活动 comp / 选层数量 / 锁定层 / 无蒙版 / 位置键 <2 / 帧数上限 5000，全部有明确 alert |
| 双模式 | Expression(live) 与 Bake keys 单选 |

## 使用方法

1. **X 轴贴地滚动（最常用）**：选中图层，给 Position 打 ≥2 个关键帧（可任意缓动）→ 面板选 `Expression (live)` + `X` → APPLY。Rotation 被写入联动表达式：之后随便改位置关键帧/缓动，滚动自动跟随（这是表达式模式相对烘焙的核心优势）。
2. **烘焙模式**：同上但选 `Bake keys` → 逐帧采样位置差，直接写 Rotation 关键帧（线性插值），适合要交给不懂表达式的人或导出模板。若在时间线上选中了 ≥2 个位置关键帧，只处理选中键的时间范围；否则取全部键首尾。
3. **Y 轴（贴墙）**：轴向选 `Y`，直径取图层高度。
4. **沿路径滚动**：选中两个图层——滚动的图层 + 带蒙版的图层（**有蒙版的那个是轨迹**，与选择顺序无关，脚本自动识别）→ 轴选 `Along mask path`。时间窗取 comp 工作区（无工作区则用滚动层的位置键范围，再不行用 comp 全长）；逐帧把滚动层 Position 摆到蒙版路径等弧长点上并写入联动 Rotation。**注意：会清空滚动层现有的 Position 关键帧与表达式，属于本模式的预期行为**（单次 undo 可撤）。沿路径模式只支持烘焙（表达式无法读取他层蒙版路径逐点数据）。

## 实现要点（复刻组交接）

- **表达式模式**（X/Y）：Rotation 表达式 = `(当前轴值 − 首键轴值) × dir × k / (π·d) × 360`，采样用 `valueAtTime(t, true)`（preExpression，取表达式前的原始值）。零点固定为位置第一个关键帧时刻（无键则 inPoint）。分离维度时改读 `xPosition/yPosition`（脚本侧生成对应变体）。
- **烘焙模式**（X/Y）：与表达式同公式，逐帧 `setValueAtTime`，随后全部 `setInterpolationTypeAtKey(LINEAR)`；不触碰用户的 Position 关键帧。
- **路径模式**：`Shape.vertices/inTangents/outTangents/closed` → 每段三次贝塞尔细分 → 累计弧长 cum 表 → 按帧序号取 `total·i/N` 弧长定位 → 蒙版层空间点经 `toComp` 转 comp 空间 → 写 Position + Rotation 键；Position 键关闭 roving（保证贴合折线）。
- 方向物理约定：AE 正角度=顺时针；地面滚动向右（+x）时轮子顺时针为正，故公式不按轴翻转符号；贴左墙等场景用 UI 的 Reverse 翻转。

## API 合规（对照 docs/api-cheatsheet.md）

- 关键帧删除用 `removeKey`（未用指南 0 命中的 `deleteKey`）。
- `setInterpolationTypeAtKey` / `KeyframeInterpolationType.LINEAR` / `setRovingAtKey` / `selectedKeys` / `valueAtTime(t, preExpression)` / `numKeys` / `key(i).time` / `PropertyValueType.TwoD_SPATIAL·TwoD`（混合大小写）等均按白名单书写。
- 速查表未收录、但已按其政策包 try/catch 并需实机冒烟验证的 API：`layer.sourceRectAtTime`、`layer.toComp`、`transform.xPosition/yPosition`、`position.dimensionsSeparated`（均有回退分支或防御分支）。
- 集合遍历全部遵守"1-based + numXxx；selected 类 0-based"两套索引约定。

## 自查结果（2026-11-14）

- `node --check`（经 .js 副本，main.jsx 为 .jsx 后缀 node 直接拒绝）：**通过**。
- ES3 扫描（箭头函数/let/const/模板串/JSON./Object.keys/Array 方法链/`for..of`/Set/Map/可选链/#指令 等 30+ 模式）：**0 命中**。
- 无制表符、无数组尾逗号、无 BOM、无尾随逗号。
- AE 实机冒烟：**未做**（本环境无 AE）。首次使用请按上表逐项点一遍，重点验证：表达式写入是否被 AE 接受、分离维度层、沿路径模式的 toComp 转换。

## 已知限制

- 直径=包围盒宽/高是近似：非圆形图层（矩形、文本）滚动半径取其投影宽度，属基线约定的近似口径。
- 沿路径模式：滚动层不能有父级（comp 空间烘焙）；需先取消分离维度；蒙版路径点的变换走 `toComp`（轨迹层缩放/旋转可正确跟随，但轨迹层自身的父级链在回退分支下会被忽略）。
- 3D 图层：写入的是 Z 轴 Rotation（2D 用法）；Y 轴滚动在 3D 图层上语义有限。
- 表达式模式若之后删光位置关键帧，表达式会报错（key(1) 失效）——删除键后需重新 APPLY 或改为烘焙。
- 静态蒙版路径只采样一次；带关键帧的变形蒙版路径逐帧采样（帧数上限 5000 保护）。
- X/Y 表达式模式按"当前轴位移差"计算，滚动过程中若图层被父级带动，读的是局部 Position（父级空间滚动）——这是设计口径，README 明示。
