/**
 * KM Clone (clean-room) -- keyframe batch management tools for After Effects.
 * ============================================================================
 * CLEAN-ROOM NOTICE:
 *   This file was written from a written feature description only
 *   (intel/paid-list.md entry #17 "KeyMaster", Owain Street, $25: cross-layer
 *   keyframe selection/batch tools, [未核实细节]) plus the public feature
 *   baseline given for this task (time flip / value negate / unify
 *   interpolation / thin redundant keys). No decompilation, no original
 *   source code, no original resources were used or inspected. All code
 *   structure, math and naming below are original work. "KeyMaster" is a
 *   commercial product by Owain Street; this clone is for learning/interop
 *   research only.
 *
 * FOUR TOOL ZONES (task baseline):
 *   1. Time Flip   -- mirror the selected keys inside their own [t0, t1]
 *                     span: newTime = t0 + t1 - t. Values unchanged, in/out
 *                     interpolation swapped, ease speeds negated (a time
 *                     mirror is a reverse playback: dv/dt -> -dv/dt with
 *                     in/out sides swapped).
 *   2. Negate      -- multiply selected key values by -1 (per-component
 *                     option for multi-D), writing via setValueAtKey and
 *                     negating the temporal-ease speeds on the same
 *                     components so the curve shape mirrors correctly.
 *   3. Interp      -- set all selected keys to LINEAR, or to BEZIER +
 *                     temporal auto-bezier (Easy-Ease style). HOLD keys are
 *                     counted and warned before conversion.
 *   4. Thin        -- remove selected keys whose gap to the previous key is
 *                     smaller than N frames (descending removeKey).
 *
 * API NOTE: all names cross-checked against docs/api-cheatsheet.md --
 *   setValueAtKey(k, value[, time]), removeKey (never deleteKey),
 *   keyIn/OutTemporalEase + setTemporalEaseAtKey (both sides always passed),
 *   KeyframeEase(speed, influence), KeyframeInterpolationType.LINEAR/BEZIER/
 *   HOLD, setTemporalAutoBezierAtKey, selectedKeys (1-based, manual numeric
 *   ordering), undo groups in try/finally pairs.
 *
 * ES3 / ExtendScript. Run: ScriptUI Panels folder or File > Scripts.
 * ============================================================================
 */

(function KMClone(thisObj) {

    var SCRIPT_NAME = 'KM Clone';
    var SCRIPT_VER = '1.0.0';
    var ORIG_NAME = 'KeyMaster (Owain Street, aescripts, $25)';

    // ------------------------------------------------------------------
    // small utils
    // ------------------------------------------------------------------

    function getComp() {
        var it = app.project ? app.project.activeItem : null;
        return (it && it instanceof CompItem) ? it : null;
    }

    // review-4 fix: propertyType is outside the cheatsheet whitelist -> wrap
    // in try/catch, fall back to the numProperties-undefined sniff
    function isProperty(p) {
        try {
            return String(p.propertyType) === 'PROPERTY';
        } catch (ePT) {
            var nk = undefined;
            try { nk = p.numProperties; } catch (eN) { nk = undefined; }
            return (typeof nk !== 'number');
        }
    }

    // numeric value types eligible for negation (COLOR excluded on purpose)
    function isNumericValueType(p) {
        var t = p.propertyValueType;
        return t === PropertyValueType.OneD ||
            t === PropertyValueType.TwoD || t === PropertyValueType.TwoD_SPATIAL ||
            t === PropertyValueType.ThreeD || t === PropertyValueType.ThreeD_SPATIAL;
    }

    function dimOf(p) {
        var t = p.propertyValueType;
        if (t === PropertyValueType.OneD) { return 1; }
        if (t === PropertyValueType.TwoD || t === PropertyValueType.TwoD_SPATIAL) { return 2; }
        if (t === PropertyValueType.ThreeD || t === PropertyValueType.ThreeD_SPATIAL) { return 3; }
        return 0;
    }

    function timeStr(t) {
        var m = Math.floor(t / 60);
        var s = t - m * 60;
        return m + ':' + (s < 10 ? '0' : '') + (Math.round(s * 100) / 100);
    }

    // Targets: properties that currently have selected keys. Prefer
    // comp.selectedProperties; else walk selected layers' trees.
    function collectKeyProps(comp) {
        var out = [];
        var i, p;
        var sel = comp.selectedProperties;
        if (sel && sel.length > 0) {
            for (i = 0; i < sel.length; i++) {
                p = sel[i];
                if (!isProperty(p)) { continue; }
                var sk = null;
                try { sk = p.selectedKeys; } catch (e0) { sk = null; }
                if (sk && sk.length > 0) { out.push(p); }
            }
        }
        if (out.length > 0) { return out; }
        var layers = comp.selectedLayers;
        var li;
        for (li = 0; li < layers.length; li++) {
            var found = [];
            walkProps(layers[li], 0, found);
            for (i = 0; i < found.length; i++) { out.push(found[i]); }
        }
        return out;
    }

    function walkProps(group, depth, out) {
        if (depth > 5 || out.length > 40) { return; }
        var i, p;
        for (i = 1; i <= group.numProperties; i++) {
            try { p = group.property(i); } catch (e) { continue; }
            if (p === null || p === undefined) { continue; }
            if (isProperty(p)) {
                var sk = null;
                try { sk = p.selectedKeys; } catch (e1) { sk = null; }
                if (sk && sk.length > 0) { out.push(p); }
            } else if (p.matchName !== 'ADBE Effect Parade') {
                walkProps(p, depth + 1, out);
            }
        }
    }

    // sorted (by time, ascending) snapshot of the selected keys of p
    function selectedKeyTimes(p) {
        var sk = null;
        try { sk = p.selectedKeys; } catch (e) { sk = null; }
        if (!sk || sk.length === 0) { return null; }
        var arr = [];
        var i, j;
        for (i = 0; i < sk.length; i++) {
            var kt = 0;
            try { kt = p.keyTime(sk[i]); } catch (e2) { continue; }
            arr.push({ k: sk[i], t: kt });
        }
        // insertion sort by time (ES3, numeric)
        for (i = 1; i < arr.length; i++) {
            var cur = arr[i];
            j = i - 1;
            while (j >= 0 && arr[j].t > cur.t) { arr[j + 1] = arr[j]; j--; }
            arr[j + 1] = cur;
        }
        return arr;
    }

    function isHold(p, k) {
        try {
            if (p.keyInInterpolationType(k) === KeyframeInterpolationType.HOLD) { return true; }
            if (p.keyOutInterpolationType(k) === KeyframeInterpolationType.HOLD) { return true; }
        } catch (e) { /* treat as non-hold */ }
        return false;
    }

    function negateEaseArr(easeArr, mask) {
        // easeArr: Array of KeyframeEase (length = property dimension)
        // mask: array of booleans per dimension (true = negate speed)
        var out = [];
        var i;
        for (i = 0; i < easeArr.length; i++) {
            var e = easeArr[i];
            var spd = e.speed;
            if (mask && mask[i]) { spd = -spd; }
            var inf = e.influence;
            if (inf < 0.1) { inf = 0.1; }
            if (inf > 100) { inf = 100; }
            out.push(new KeyframeEase(spd, inf));
        }
        return out;
    }

    // ------------------------------------------------------------------
    // zone 1: time flip (mirror in own span)
    // ------------------------------------------------------------------

    function timeFlip(comp, status) {
        var targets = collectKeyProps(comp);
        if (targets.length === 0) {
            alert('Select keyframes in the timeline first.');
            return;
        }
        var done = 0, skipped = 0, errs = [];
        app.beginUndoGroup('KM Clone: time flip');
        try {
            var ti;
            for (ti = 0; ti < targets.length; ti++) {
                var p = targets[ti];
                try {
                    var sel = selectedKeyTimes(p);
                    if (!sel || sel.length < 2) { skipped++; continue; }
                    var t0 = sel[0].t;
                    var t1 = sel[sel.length - 1].t;
                    if (t1 - t0 < 0.0001) { skipped++; continue; }

                    // snapshot everything we need BEFORE deleting
                    var snaps = [];
                    var si;
                    for (si = 0; si < sel.length; si++) {
                        var k = sel[si].k;
                        var ie = null, oe = null;
                        try { ie = p.keyInTemporalEase(k); } catch (eI) { ie = null; }
                        try { oe = p.keyOutTemporalEase(k); } catch (eO) { oe = null; }
                        snaps.push({
                            t: sel[si].t,
                            v: p.keyValue(k),
                            inType: p.keyInInterpolationType(k),
                            outType: p.keyOutInterpolationType(k),
                            inEase: ie,
                            outEase: oe,
                            hold: isHold(p, k)
                        });
                    }

                    // times of keys NOT selected (conflict check targets)
                    var otherT = [];
                    var all;
                    for (all = 1; all <= p.numKeys; all++) {
                        var isSel = false;
                        var si2;
                        for (si2 = 0; si2 < sel.length; si2++) {
                            if (sel[si2].k === all) { isSel = true; break; }
                        }
                        if (!isSel) { otherT.push(p.keyTime(all)); }
                    }

                    // review-4 fix (data-loss bug): old code deleted ALL
                    // selected keys first and dropped clashing ones afterwards,
                    // losing their values. Now a key whose mirrored time lands
                    // on a non-moving key is marked immovable and stays put.
                    // Mirrored swaps among selected keys remain movable.
                    var movable = [];
                    var mvI;
                    for (mvI = 0; mvI < snaps.length; mvI++) { movable.push(true); }
                    var resolved = false;
                    while (!resolved) {
                        resolved = true;
                        var mvJ;
                        for (mvJ = 0; mvJ < snaps.length; mvJ++) {
                            if (!movable[mvJ]) { continue; }
                            var nt = t0 + t1 - snaps[mvJ].t;
                            var blocked = false;
                            var oi2;
                            for (oi2 = 0; oi2 < otherT.length; oi2++) {
                                if (Math.abs(otherT[oi2] - nt) < 0.00001) { blocked = true; break; }
                            }
                            if (!blocked) {
                                var mvK;
                                for (mvK = 0; mvK < snaps.length; mvK++) {
                                    if (mvK !== mvJ && !movable[mvK] &&
                                        Math.abs(snaps[mvK].t - nt) < 0.00001) {
                                        blocked = true;
                                        break;
                                    }
                                }
                            }
                            if (blocked) { movable[mvJ] = false; resolved = false; }
                        }
                    }

                    // delete only movable selected keys, descending by index
                    var di;
                    for (di = sel.length - 1; di >= 0; di--) {
                        if (movable[di]) { p.removeKey(sel[di].k); }
                    }

                    // rebuild mirrored (movable keys only)
                    var okHere = 0;
                    var si3;
                    for (si3 = 0; si3 < snaps.length; si3++) {
                        if (!movable[si3]) { skipped++; continue; }
                        var s = snaps[si3];
                        var newT = t0 + t1 - s.t;
                        p.setValueAtTime(newT, s.v);
                        var idx = p.nearestKeyIndex(newT);
                        // interpolation: in/out swapped for the mirror
                        p.setInterpolationTypeAtKey(idx, s.outType, s.inType);
                        // ease: swap sides AND negate speeds (reverse playback)
                        if (!s.hold && s.inEase !== null && s.outEase !== null) {
                            var dim = s.inEase.length;
                            var mask = [];
                            var mi;
                            for (mi = 0; mi < dim; mi++) { mask.push(true); }
                            var newIn = negateEaseArr(s.outEase, mask);
                            var newOut = negateEaseArr(s.inEase, mask);
                            p.setTemporalEaseAtKey(idx, newIn, newOut);
                        }
                        okHere++;
                    }
                    done += okHere;
                } catch (eFlip) {
                    errs.push(p.name + ': ' + eFlip.toString());
                }
            }
        } finally {
            app.endUndoGroup();
        }
        status.text = 'Time flip: ' + done + ' key(s) mirrored' +
            (skipped ? ' | skipped ' + skipped : '') +
            (errs.length ? ' | ' + errs.join('; ') : '');
    }

    // ------------------------------------------------------------------
    // zone 2: negate values
    // ------------------------------------------------------------------

    function negateValues(comp, compMode, status) {
        var targets = collectKeyProps(comp);
        if (targets.length === 0) {
            alert('Select keyframes in the timeline first.');
            return;
        }
        var done = 0, skipped = 0, errs = [];
        app.beginUndoGroup('KM Clone: negate values');
        try {
            var ti;
            for (ti = 0; ti < targets.length; ti++) {
                var p = targets[ti];
                try {
                    if (!isNumericValueType(p)) { skipped++; continue; } // COLOR etc.
                    var dim = dimOf(p);
                    var sk = selectedKeyTimes(p);
                    if (!sk) { skipped++; continue; }
                    var si;
                    for (si = 0; si < sk.length; si++) {
                        var k = sk[si].k;
                        try {
                            var v = p.keyValue(k);
                            var nv;
                            var mask = null;
                            if (dim === 1) {
                                nv = -v;
                                mask = [true];
                            } else {
                                var arr = [v[0], v[1], dim === 3 ? v[2] : 0];
                                mask = [false, false, false];
                                var mi;
                                for (mi = 0; mi < dim; mi++) {
                                    if (compMode === 'all' ||
                                        (compMode === 'x' && mi === 0) ||
                                        (compMode === 'y' && mi === 1) ||
                                        (compMode === 'z' && mi === 2)) {
                                        arr[mi] = -arr[mi];
                                        mask[mi] = true;
                                    }
                                }
                                nv = (dim === 2) ? [arr[0], arr[1]] : arr;
                            }
                            p.setValueAtKey(k, nv);
                            // ease speeds must negate on the same components
                            var ie = null, oe = null;
                            try { ie = p.keyInTemporalEase(k); } catch (eI) { ie = null; }
                            try { oe = p.keyOutTemporalEase(k); } catch (eO) { oe = null; }
                            if (ie !== null && oe !== null) {
                                p.setTemporalEaseAtKey(k, negateEaseArr(ie, mask), negateEaseArr(oe, mask));
                            }
                            done++;
                        } catch (eK) { errs.push(p.name + ' key ' + k + ': ' + eK.toString()); }
                    }
                } catch (eP) { errs.push(p.name + ': ' + eP.toString()); }
            }
        } finally {
            app.endUndoGroup();
        }
        status.text = 'Negate (' + compMode + '): ' + done + ' key(s) negated' +
            (skipped ? ' | skipped ' + skipped + ' (non-numeric)' : '') +
            (errs.length ? ' | ' + errs.join('; ') : '');
    }

    // ------------------------------------------------------------------
    // zone 3: unify interpolation
    // ------------------------------------------------------------------

    function unifyInterp(comp, kind, status) {
        var targets = collectKeyProps(comp);
        if (targets.length === 0) {
            alert('Select keyframes in the timeline first.');
            return;
        }
        // pre-scan HOLD keys and warn once
        var holdCount = 0;
        var ti, si;
        for (ti = 0; ti < targets.length; ti++) {
            var pp = targets[ti];
            var sk0 = selectedKeyTimes(pp);
            if (!sk0) { continue; }
            for (si = 0; si < sk0.length; si++) {
                if (isHold(pp, sk0[si].k)) { holdCount++; }
            }
        }
        if (holdCount > 0) {
            alert('Warning: selection contains ' + holdCount + ' HOLD keyframe side(s).\n' +
                'Converting to ' + (kind === 'linear' ? 'Linear' : 'Auto-Bezier') +
                ' will lose the hold behaviour (undo is available).');
        }
        var done = 0, errs = [];
        app.beginUndoGroup('KM Clone: unify ' + kind);
        try {
            for (ti = 0; ti < targets.length; ti++) {
                var p = targets[ti];
                try {
                    var sk = selectedKeyTimes(p);
                    if (!sk) { continue; }
                    for (si = 0; si < sk.length; si++) {
                        var k = sk[si].k;
                        try {
                            if (kind === 'linear') {
                                p.setInterpolationTypeAtKey(k,
                                    KeyframeInterpolationType.LINEAR, KeyframeInterpolationType.LINEAR);
                            } else {
                                p.setInterpolationTypeAtKey(k,
                                    KeyframeInterpolationType.BEZIER, KeyframeInterpolationType.BEZIER);
                                try { p.setTemporalAutoBezierAtKey(k, true); } catch (eA) { /* optional */ }
                            }
                            done++;
                        } catch (eK) { errs.push(p.name + ' key ' + k + ': ' + eK.toString()); }
                    }
                } catch (eP2) { errs.push(p.name + ': ' + eP2.toString()); }
            }
        } finally {
            app.endUndoGroup();
        }
        status.text = (kind === 'linear' ? 'Linear' : 'Auto-Bezier') + ' applied to ' +
            done + ' key(s)' + (errs.length ? ' | ' + errs.join('; ') : '');
    }

    // ------------------------------------------------------------------
    // zone 4: thin keys closer than N frames
    // ------------------------------------------------------------------

    function thinKeys(comp, nFrames, status) {
        var targets = collectKeyProps(comp);
        if (targets.length === 0) {
            alert('Select keyframes in the timeline first.');
            return;
        }
        var fd = comp.frameDuration;
        if (!(fd > 0)) { fd = 1 / 25; }
        var minGap = nFrames * fd;
        var removed = 0, errs = [];
        app.beginUndoGroup('KM Clone: thin keys < ' + nFrames + 'f');
        try {
            var ti;
            for (ti = 0; ti < targets.length; ti++) {
                var p = targets[ti];
                try {
                    var sk = selectedKeyTimes(p);
                    if (!sk || sk.length < 2) { continue; }
                    // mark: keep first of each run, drop later keys whose gap
                    // to the last KEPT key is < minGap
                    // (review-4 fix: old code compared against the previous
                    // ORIGINAL key, so a chain of dense keys was over-removed)
                    var toRemove = [];
                    var lastKeptT = sk[0].t;
                    var si;
                    for (si = 1; si < sk.length; si++) {
                        if (sk[si].t - lastKeptT < minGap) {
                            toRemove.push(sk[si].k);
                        } else {
                            lastKeptT = sk[si].t;
                        }
                    }
                    // remove descending so indices stay valid
                    var ri;
                    for (ri = toRemove.length - 1; ri >= 0; ri--) {
                        p.removeKey(toRemove[ri]);
                        removed++;
                    }
                } catch (eP) { errs.push(p.name + ': ' + eP.toString()); }
            }
        } finally {
            app.endUndoGroup();
        }
        status.text = 'Thin: removed ' + removed + ' key(s) with gap < ' + nFrames +
            'f' + (errs.length ? ' | ' + errs.join('; ') : '');
    }

    // ------------------------------------------------------------------
    // UI
    // ------------------------------------------------------------------

    function buildUI(thisObj) {
        var win = (thisObj instanceof Panel) ? thisObj
            : new Window('palette', SCRIPT_NAME + ' v' + SCRIPT_VER, undefined, { resizeable: true });
        win.orientation = 'column';
        win.alignChildren = ['fill', 'top'];
        win.spacing = 6;
        win.margins = 10;

        var decl = win.add('statictext', undefined,
            'Clean-room reimplementation inspired by KeyMaster\u2019s public feature list. No original code used.', { truncate: true });
        decl.maximumSize.width = 400;

        var p1 = win.add('panel', undefined, '1. Time flip (mirror selected keys in their span)');
        p1.orientation = 'row';
        p1.margins = 10;
        var bFlip = p1.add('button', undefined, 'Flip time');
        bFlip.preferredSize = [120, 26];
        p1.add('statictext', undefined, 'values kept, in/out interp + ease swapped');

        var p2 = win.add('panel', undefined, '2. Negate values (x -1, ease speeds follow)');
        p2.orientation = 'row';
        p2.alignChildren = ['left', 'center'];
        p2.margins = 10;
        p2.spacing = 5;
        p2.add('statictext', undefined, 'components');
        var ddComp = p2.add('dropdownlist', undefined, ['all', 'x only', 'y only', 'z only']);
        ddComp.selection = 0;
        var bNeg = p2.add('button', undefined, 'Negate');
        bNeg.preferredSize = [90, 26];

        var p3 = win.add('panel', undefined, '3. Unify interpolation (selected keys)');
        p3.orientation = 'row';
        p3.margins = 10;
        p3.spacing = 5;
        var bLin = p3.add('button', undefined, 'All Linear');
        bLin.preferredSize = [100, 26];
        var bBez = p3.add('button', undefined, 'All Auto-Bezier');
        bBez.preferredSize = [120, 26];
        p3.add('statictext', undefined, '(hold keys warned first)');

        var p4 = win.add('panel', undefined, '4. Thin keys (gap < N frames)');
        p4.orientation = 'row';
        p4.alignChildren = ['left', 'center'];
        p4.margins = 10;
        p4.spacing = 5;
        p4.add('statictext', undefined, 'N frames');
        var etN = p4.add('edittext', undefined, '2');
        etN.characters = 4;
        var bThin = p4.add('button', undefined, 'Remove redundant');
        bThin.preferredSize = [130, 26];

        var status = win.add('statictext', undefined,
            SCRIPT_NAME + ' v' + SCRIPT_VER + ' ready. Original: ' + ORIG_NAME, { multiline: true });
        status.preferredSize = [380, 40];

        bFlip.onClick = function () {
            var comp = getComp();
            if (!comp) { alert('Open a composition first.'); return; }
            timeFlip(comp, status);
        };
        bNeg.onClick = function () {
            var comp = getComp();
            if (!comp) { alert('Open a composition first.'); return; }
            var m = ddComp.selection ? ddComp.selection.text : 'all';
            var mode = (m === 'x only') ? 'x' : (m === 'y only') ? 'y' : (m === 'z only') ? 'z' : 'all';
            negateValues(comp, mode, status);
        };
        bLin.onClick = function () {
            var comp = getComp();
            if (!comp) { alert('Open a composition first.'); return; }
            unifyInterp(comp, 'linear', status);
        };
        bBez.onClick = function () {
            var comp = getComp();
            if (!comp) { alert('Open a composition first.'); return; }
            unifyInterp(comp, 'bez', status);
        };
        bThin.onClick = function () {
            var comp = getComp();
            if (!comp) { alert('Open a composition first.'); return; }
            var n = parseInt(etN.text, 10);
            if (isNaN(n) || n < 1) { n = 1; }
            thinKeys(comp, n, status);
        };

        win.layout.layout(true);
        win.layout.resize();
        win.onResizing = win.onResize = function () { this.layout.resize(); };
        return win;
    }

    var kmWin = buildUI(thisObj);
    // review-4 fix: a palette run via File > Scripts never showed its window
    if (kmWin instanceof Window) {
        kmWin.center();
        kmWin.show();
    }

})(this);
