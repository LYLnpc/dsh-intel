// =============================================================================
//  SauceClone v1.0  --  After Effects "layer stack + effects" bundle tool
//  generated_at: 2026-11-14T00:16:40Z
//  task: clean-room clone of "Add Sauce" (paid-list.md #20, A-class, jsx)
// -----------------------------------------------------------------------------
//  CLEAN-ROOM DECLARATION
//  This script is an independent reimplementation written ONLY from the public
//  feature description: "Save a bundle of adjustment layers (or normal layers)
//  with their effects and every property saved, and apply them all in one
//  click." No original product code was decompiled, read, copied or
//  translated. All AE API usage follows docs/api-cheatsheet.md; APIs outside
//  that whitelist are wrapped in try/catch with fallbacks.
//  Target: After Effects CS6+ (ExtendScript), ES3 only, pure ASCII UI strings.
// =============================================================================

(function sauceClone(thisObj) {

    var TOOL = "SauceClone";
    var VER = "1.0";
    var EXT = ".sauce";
    var MAX_ERRORS_SHOWN = 12;

    // ---------------------------------------------------------------
    // tiny utils
    // ---------------------------------------------------------------

    function msg(e) {
        return (e && e.message) ? e.message : String(e);
    }

    function isComp(item) {
        return (item && item instanceof CompItem);
    }

    function esc(s) {
        var t = String(s);
        t = t.replace(/\\/g, "\\\\");
        t = t.replace(/\|/g, "\\p");
        t = t.replace(/\r/g, "\\r");
        t = t.replace(/\n/g, "\\n");
        return t;
    }

    function unesc(s) {
        var out = "";
        var i = 0;
        var c, n;
        while (i < s.length) {
            c = s.charAt(i);
            if (c === "\\" && i + 1 < s.length) {
                n = s.charAt(i + 1);
                if (n === "p") { out += "|"; i += 2; continue; }
                if (n === "n") { out += "\n"; i += 2; continue; }
                if (n === "r") { out += "\r"; i += 2; continue; }
                if (n === "\\") { out += "\\"; i += 2; continue; }
            }
            out += c;
            i++;
        }
        return out;
    }

    function safeName(s) {
        var t = String(s).replace(/[\\\/:*?"<>|]/g, "_");
        t = t.replace(/^\s+|\s+$/g, "");
        if (t === "") { t = "sauce"; }
        return t;
    }

    function parseNumList(s) {
        var arr = String(s).split(",");
        var out = [];
        var i;
        for (i = 0; i < arr.length; i++) { out.push(parseFloat(arr[i])); }
        return out;
    }

    function acceptsEffects(layer) {
        try {
            var g = layer.property("ADBE Effect Parade");
            return !!(g && typeof g.addProperty === "function");
        } catch (eAcc) {
            return false;
        }
    }

    function findByMatch(grp, mm) {
        try {
            var n = grp.numProperties;
            if (typeof n !== "number") { return null; }
            var i, p;
            for (i = 1; i <= n; i++) {
                p = grp.property(i);
                if (p && p.matchName === mm) { return p; }
            }
        } catch (eNav) { /* not a group */ }
        return null;
    }

    function navigate(root, segs) {
        var cur = root;
        var i, p;
        for (i = 0; i < segs.length; i++) {
            p = findByMatch(cur, segs[i]);
            if (!p) { return null; }
            cur = p;
        }
        return cur;
    }

    // ---------------------------------------------------------------
    // capture: layer -> bundle lines
    // ---------------------------------------------------------------

    // leaf Property -> "tag|valueString" line payload; null when skippable
    function encodeLeaf(p) {
        var vt = p.propertyValueType;
        if (vt === PropertyValueType.NO_VALUE || vt === PropertyValueType.MARKER ||
            vt === PropertyValueType.SHAPE || vt === PropertyValueType.TEXT_DOCUMENT ||
            vt === PropertyValueType.CUSTOM_VALUE) {
            return null;
        }
        try { if (p.elided) { return null; } } catch (eEl) { /* keep */ }
        var v;
        try { v = p.value; } catch (eVal) { return null; }
        if (typeof v === "boolean") { return "b|" + (v ? "1" : "0"); }
        if (typeof v === "number") { return "n|" + String(v); }
        if (v instanceof Array && v.length >= 2 && v.length <= 4) {
            var parts = [];
            var j;
            for (j = 0; j < v.length; j++) { parts.push(String(v[j])); }
            return "a|" + parts.join(",");
        }
        return null;
    }

    function captureProps(grp, prefix, out) {
        var i, p, nk, enc, ex;
        for (i = 1; i <= grp.numProperties; i++) {
            p = grp.property(i);
            if (!p) { continue; }
            if (p.matchName === "ADBE Effect Built In Params") { continue; }
            nk = undefined;
            try { nk = p.numProperties; } catch (eN) { nk = undefined; }
            if (typeof nk === "number") {
                captureProps(p, prefix + "/" + p.matchName, out);
                continue;
            }
            enc = encodeLeaf(p);
            if (enc === null) { continue; }
            out.push("CPROP|" + prefix + "/" + p.matchName + "|" + enc);
            ex = "";
            try { ex = p.expression; } catch (eX) { ex = ""; }
            if (ex !== "") {
                out.push("CEXP|" + prefix + "/" + p.matchName + "|" + esc(ex));
            }
        }
    }

    function captureLayerLines(layer, out) {
        var adj = 0;
        try { adj = layer.adjustmentLayer ? 1 : 0; } catch (eA) { adj = 0; }
        var bm = 0;
        try { bm = layer.blendingMode; } catch (eB) { bm = 0; }
        var col = "1,1,1";
        try {
            var ms = layer.source.mainSource;
            if (ms && ms.color && ms.color.length >= 3) {
                var c = ms.color;
                col = Math.round(c[0] * 1000) / 1000 + "," +
                      Math.round(c[1] * 1000) / 1000 + "," +
                      Math.round(c[2] * 1000) / 1000;
            }
        } catch (eC) { col = "1,1,1"; }
        out.push("CLAYER|" + esc(layer.name) + "|" + adj + "|" + bm + "|" + col);

        var parade = null;
        try { parade = layer.property("ADBE Effect Parade"); } catch (eP) { parade = null; }
        if (!parade) { return; }
        var i, eff;
        for (i = 1; i <= parade.numProperties; i++) {
            eff = parade.property(i);
            if (!eff) { continue; }
            out.push("CEFF|" + esc(eff.name) + "|" + eff.matchName + "|" +
                (eff.enabled ? 1 : 0));
            captureProps(eff, eff.matchName, out);
        }
    }

    function buildBundle(comp) {
        var sel = comp.selectedLayers;
        if (sel.length < 1) {
            throw new Error("Select at least 1 layer to capture.");
        }
        // timeline order (index ascending = top first); selectedLayers order
        // is not documented, so sort explicitly by layer.index
        var arr = sel.slice(0);
        arr.sort(function (a, b) { return a.index - b.index; });
        var out = ["SAUCE1"];
        var skipped = [];
        var i;
        for (i = 0; i < arr.length; i++) {
            if (!acceptsEffects(arr[i])) {
                skipped.push(arr[i].name);
                continue;
            }
            captureLayerLines(arr[i], out);
        }
        if (out.length <= 1) {
            throw new Error("No capturable layers (cameras/lights are skipped).");
        }
        return { lines: out, skipped: skipped };
    }

    // ---------------------------------------------------------------
    // parse + apply
    // ---------------------------------------------------------------

    function parseSauce(txt) {
        txt = txt.replace(/\r/g, "");
        var lines = txt.split("\n");
        var bundle = { layers: [] };
        var curLayer = null;
        var curEff = null;
        var i, ln, parts, tag;
        for (i = 0; i < lines.length; i++) {
            ln = lines[i];
            if (ln === "") { continue; }
            if (ln.indexOf("SAUCE1") === 0) { continue; }
            parts = ln.split("|");
            tag = parts[0];
            if (tag === "CLAYER" && parts.length >= 5) {
                curLayer = {
                    name: unesc(parts[1]),
                    adj: (parts[2] === "1"),
                    bm: parseInt(parts[3], 10),
                    color: parseNumList(parts[4]),
                    effs: []
                };
                bundle.layers.push(curLayer);
                curEff = null;
            } else if (tag === "CEFF" && parts.length >= 4) {
                if (!curLayer) { continue; }
                curEff = {
                    name: unesc(parts[1]),
                    mm: parts[2],
                    en: (parts[3] === "1"),
                    props: [],
                    exprs: []
                };
                curLayer.effs.push(curEff);
            } else if (tag === "CPROP" && parts.length >= 4) {
                if (!curEff) { continue; }
                curEff.props.push({
                    path: parts[1].split("/"),
                    tag: parts[2],
                    vals: parseNumList(parts[3])
                });
            } else if (tag === "CEXP" && parts.length >= 3) {
                if (!curEff) { continue; }
                curEff.exprs.push({
                    path: parts[1].split("/"),
                    ex: unesc(parts[2])
                });
            }
        }
        return bundle;
    }

    function applyProps(effG, props, effName, errors) {
        var j, spec, pv, v;
        for (j = 0; j < props.length; j++) {
            spec = props[j];
            pv = navigate(effG, spec.path);
            if (!pv) {
                errors.push("Param not found on '" + effName + "': " +
                    spec.path.join("/"));
                continue;
            }
            if (spec.tag === "b") { v = (spec.vals[0] !== 0); }
            else if (spec.tag === "n") { v = spec.vals[0]; }
            else { v = spec.vals; }
            try {
                pv.setValue(v);
            } catch (eSet) {
                errors.push("Cannot set '" + effName + "/" +
                    spec.path.join("/") + "': " + msg(eSet));
            }
        }
    }

    function applyExprs(effG, exprs, effName, errors) {
        var j, spec, pv;
        for (j = 0; j < exprs.length; j++) {
            spec = exprs[j];
            pv = navigate(effG, spec.path);
            if (!pv) { continue; } // already reported by applyProps
            try {
                pv.expression = spec.ex;
            } catch (eEx) {
                errors.push("Cannot set expression on '" + effName + "/" +
                    spec.path.join("/") + "': " + msg(eEx));
            }
        }
    }

    function applyBundle(comp, target, bundle) {
        var errors = [];
        var created = 0;
        var li, k, L, col, sol, parade;
        for (li = 0; li < bundle.layers.length; li++) {
            L = bundle.layers[li];
            col = (L.color && L.color.length >= 3)
                ? [L.color[0], L.color[1], L.color[2]]
                : [1, 1, 1];
            sol = null;
            try {
                sol = comp.layers.addSolid(col, L.name, comp.width,
                    comp.height, comp.pixelAspect, comp.duration);
            } catch (eAdd) {
                errors.push("Cannot create layer '" + L.name + "': " + msg(eAdd));
                continue;
            }
            created++;
            try { sol.adjustmentLayer = L.adj; } catch (eAdj) { /* ok */ }
            try { sol.blendingMode = L.bm; } catch (eBm) { /* ok */ }
            // stack above target: creating top-first and always inserting
            // right before target yields the stored top->bottom order
            try {
                sol.moveBefore(target);
            } catch (eMv) {
                try { sol.moveAfter(target); } catch (eMv2) { /* ok */ }
            }
            parade = null;
            try { parade = sol.property("ADBE Effect Parade"); } catch (eP) { parade = null; }
            if (!parade || typeof parade.addProperty !== "function") {
                errors.push("Layer '" + L.name + "' cannot host effects.");
                continue;
            }
            for (k = 0; k < L.effs.length; k++) {
                var eff = L.effs[k];
                var effG = null;
                try {
                    effG = parade.addProperty(eff.mm);
                } catch (eEf) {
                    errors.push("Effect unavailable on '" + L.name + "': " +
                        eff.name + " (" + msg(eEf) + ")");
                    continue;
                }
                try { effG.enabled = eff.en; } catch (eEn) { /* ok */ }
                applyProps(effG, eff.props, eff.name, errors);
                applyExprs(effG, eff.exprs, eff.name, errors);
            }
        }
        return { created: created, errors: errors };
    }

    // ---------------------------------------------------------------
    // file IO (bundles live in <userData>/SauceClones/*.sauce)
    // ---------------------------------------------------------------

    function bundleFolder() {
        try {
            var f = new Folder(Folder.userData.fsName + "/SauceClones");
            if (!f.exists) { f.create(); }
            return f;
        } catch (eF) {
            return null;
        }
    }

    function listSauces() {
        var f = bundleFolder();
        if (!f) { return []; }
        var files = [];
        try { files = f.getFiles("*" + EXT); } catch (eG) { files = []; }
        var names = [];
        var i;
        for (i = 0; i < files.length; i++) {
            if (files[i] instanceof File) {
                names.push(files[i].name);
            }
        }
        names.sort();
        return names;
    }

    function writeSauce(name, lines) {
        var f = bundleFolder();
        if (!f) { throw new Error("Cannot access bundle folder."); }
        var file = new File(f.fsName + "/" + safeName(name) + EXT);
        file.encoding = "UTF-8";
        if (!file.open("w")) {
            throw new Error("Cannot write " + file.fsName);
        }
        file.write(lines.join("\n"));
        file.close();
        return file;
    }

    function readSauce(name) {
        var f = bundleFolder();
        if (!f) { throw new Error("Cannot access bundle folder."); }
        var file = new File(f.fsName + "/" + name);
        file.encoding = "UTF-8";
        if (!file.open("r")) {
            throw new Error("Cannot read " + file.fsName);
        }
        var txt = file.read();
        file.close();
        return txt;
    }

    // ---------------------------------------------------------------
    // actions
    // ---------------------------------------------------------------

    function doSave(nameEdit) {
        if (!app.project) { throw new Error("No project open."); }
        var comp = app.project.activeItem;
        if (!isComp(comp)) {
            throw new Error("Activate a composition first.");
        }
        if (!nameEdit.text || nameEdit.text === "") {
            throw new Error("Type a name for the sauce before saving.");
        }
        var res = buildBundle(comp);
        var file = writeSauce(nameEdit.text, res.lines);
        var note = "Saved '" + file.name + "' (" +
            (res.lines.length - 1) + " lines).";
        if (res.skipped.length > 0) {
            note += " Skipped (no effects host): " + res.skipped.join(", ");
        }
        return note;
    }

    function doApply(statusText) {
        if (!app.project) { throw new Error("No project open."); }
        var comp = app.project.activeItem;
        if (!isComp(comp)) {
            throw new Error("Activate a composition first.");
        }
        var sel = comp.selectedLayers;
        if (sel.length !== 1) {
            throw new Error("Select exactly 1 target layer (the stack is recreated above it).");
        }
        var target = sel[0];
        if (!acceptsEffects(target)) {
            throw new Error("Target layer '" + target.name + "' cannot host effects (camera/light?).");
        }
        var res = applyFromSelectedList(comp, target);
        var note = "Applied " + res.created + " layer(s) above '" +
            target.name + "'.";
        if (res.errors.length > 0) {
            var shown = res.errors.slice(0, MAX_ERRORS_SHOWN);
            if (res.errors.length > MAX_ERRORS_SHOWN) {
                shown.push("... +" + (res.errors.length - MAX_ERRORS_SHOWN) + " more");
            }
            if (statusText) { statusText.text = note; }
            alert(TOOL + " finished with warnings:\n" + shown.join("\n"));
        }
        return note;
    }

    function applyFromSelectedList(comp, target) {
        var lb = uiRefs.list;
        if (!lb || !lb.selection) {
            throw new Error("Pick a sauce in the list first.");
        }
        var txt = readSauce(lb.selection.text + EXT);
        var bundle = parseSauce(txt);
        if (bundle.layers.length < 1) {
            throw new Error("Bundle file is empty or unreadable.");
        }
        app.beginUndoGroup(TOOL + ": apply sauce");
        var out;
        try {
            out = applyBundle(comp, target, bundle);
        } finally {
            app.endUndoGroup();
        }
        return out;
    }

    function doDelete() {
        var lb = uiRefs.list;
        if (!lb || !lb.selection) {
            throw new Error("Pick a sauce in the list first.");
        }
        var f = bundleFolder();
        if (!f) { throw new Error("Cannot access bundle folder."); }
        var file = new File(f.fsName + "/" + lb.selection.text + EXT);
        if (!file.remove()) {
            throw new Error("Cannot delete " + file.fsName);
        }
        return "Deleted '" + lb.selection.text + EXT + "'.";
    }

    // ---------------------------------------------------------------
    // UI
    // ---------------------------------------------------------------

    var uiRefs = { list: null, status: null, name: null };

    function refreshList() {
        var lb = uiRefs.list;
        if (!lb) { return; }
        lb.removeAll();
        var names = listSauces();
        var i;
        for (i = 0; i < names.length; i++) {
            lb.add("item", names[i].substring(0, names[i].length - EXT.length));
        }
        setStatus(names.length + " sauce(s) on disk.");
    }

    function setStatus(s) {
        if (uiRefs.status) { uiRefs.status.text = s; }
    }

    function buildUI(thisObj) {
        var win = (thisObj instanceof Panel)
            ? thisObj
            : new Window("palette", TOOL + " v" + VER, undefined, { resizeable: true });
        win.orientation = "column";
        win.alignChildren = ["fill", "top"];
        win.spacing = 6;
        win.margins = 10;

        var gName = win.add("group");
        gName.orientation = "row";
        gName.alignChildren = ["left", "center"];
        var etName = gName.add("edittext", undefined, "");
        etName.characters = 22;
        etName.helpTip = "Sauce name for saving";
        uiRefs.name = etName;
        var btnSave = gName.add("button", undefined, "SAVE");
        btnSave.helpTip = "Capture selected layers (effects + props) into a bundle";

        var lb = win.add("listbox", undefined, [],
            { multiselect: false });
        lb.size = [240, 110];
        uiRefs.list = lb;

        var gBtn = win.add("group");
        gBtn.orientation = "row";
        var btnApply = gBtn.add("button", undefined, "APPLY");
        btnApply.helpTip = "Recreate the stack above the selected target layer";
        var btnDel = gBtn.add("button", undefined, "DELETE");
        var btnRef = gBtn.add("button", undefined, "REFRESH");

        var st = win.add("statictext", undefined,
            "SAVE: select layers, type name. APPLY: select 1 target layer, " +
            "pick a sauce. Bundles go to <userData>/SauceClones.");
        st.characters = 58;
        st.multiline = true;
        uiRefs.status = st;

        btnSave.onClick = function () {
            try {
                setStatus(doSave(etName));
                refreshList();
            } catch (e) {
                alert(TOOL + " error:\n" + msg(e));
            }
        };
        btnApply.onClick = function () {
            try {
                setStatus(doApply(st));
                refreshList();
            } catch (e) {
                alert(TOOL + " error:\n" + msg(e));
            }
        };
        btnDel.onClick = function () {
            try {
                setStatus(doDelete());
                refreshList();
            } catch (e) {
                alert(TOOL + " error:\n" + msg(e));
            }
        };
        btnRef.onClick = function () {
            refreshList();
        };

        win.onResizing = win.onResize = function () {
            this.layout.resize();
        };
        win.layout.layout(true);
        return win;
    }

    var win = buildUI(thisObj);
    if (win instanceof Window) {
        win.center();
        win.show();
    } else {
        win.layout.layout(true);
    }
    refreshList();

})(this);
