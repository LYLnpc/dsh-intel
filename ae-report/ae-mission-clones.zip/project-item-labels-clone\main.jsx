#target aftereffects

/**************************************************************************
 * Project Item Labels Clone  v1.0.0  (ExtendScript .jsx for AE)
 * ------------------------------------------------------------------------
 * CLEAN-ROOM REIMPLEMENTATION NOTICE:
 * Written from scratch from the public one-line product description
 * ("batch-set label colors by project item type") plus general AE
 * Scripting API knowledge. No original source, installer, binary or
 * resource of the commercial script was obtained or referenced.
 * ------------------------------------------------------------------------
 * ES3 / ExtendScript only. ASCII-only source on purpose.
 *
 * NOTE ON LABEL COLOURS:
 * The Scripting API only exposes label INDEXES (1..16). The actual RGB of
 * each index comes from the user's AE Preferences > Labels list, which is
 * NOT readable from a script. The swatches drawn here are an approximation
 * of the factory preset and are cosmetic only.
 **************************************************************************/

(function projectItemLabelsClone(thisObj) {

    var SCRIPT_NAME = "Project Item Labels Clone";
    var VERSION = "1.0.0";

    // Approximate factory-preset swatch colours, purely cosmetic.
    // Index 1..16 -> [r,g,b] 0..1
    var LABEL_SWATCH = [
        [0.55, 0.55, 0.55], // 1
        [0.85, 0.20, 0.20], // 2
        [0.95, 0.85, 0.25], // 3
        [0.35, 0.75, 0.85], // 4
        [0.90, 0.55, 0.75], // 5
        [0.65, 0.60, 0.85], // 6
        [0.95, 0.75, 0.50], // 7
        [0.55, 0.85, 0.70], // 8
        [0.30, 0.55, 0.90], // 9
        [0.40, 0.75, 0.40], // 10
        [0.70, 0.50, 0.85], // 11
        [0.95, 0.65, 0.30], // 12
        [0.60, 0.45, 0.35], // 13
        [0.85, 0.40, 0.65], // 14
        [0.45, 0.80, 0.85], // 15
        [0.75, 0.75, 0.60]  // 16
    ];

    var LABEL_NAMES = [
        "Grey", "Red", "Yellow", "Aqua", "Pink", "Lavender", "Peach",
        "Sea Foam", "Blue", "Green", "Violet", "Orange", "Brown",
        "Fuchsia", "Cyan", "Sand"
    ];

    var IMAGE_EXT = ["png", "jpg", "jpeg", "gif", "psd", "psb", "tif", "tiff",
        "bmp", "tga", "ai", "pdf", "exr", "hdr", "dpx", "tga"];
    var VIDEO_EXT = ["mov", "mp4", "m4v", "avi", "mxf", "wmv", "webm", "mkv",
        "r3d", "braw", "flv", "mpg", "mpeg"];
    var AUDIO_EXT = ["wav", "mp3", "aif", "aiff", "m4a", "aac", "ogg", "flac"];

    /* ==================================================================
     *  Type detection
     * ================================================================== */

    function extOf(item) {
        if (!item || !item.file) { return ""; }
        try {
            var nm = item.file.name;
            var dot = nm.lastIndexOf(".");
            if (dot < 0) { return ""; }
            return nm.substring(dot + 1).toLowerCase();
        } catch (e) { return ""; }
    }

    function inList(val, list) {
        var i;
        for (i = 0; i < list.length; i++) {
            if (list[i] === val) { return true; }
        }
        return false;
    }

    // Rule keys, in evaluation priority order.
    var RULE_ORDER = ["missing", "placeholder", "solid", "comp", "folder",
        "image", "video", "audio", "other"];

    function ruleKeyOf(item) {
        if (!item) { return "other"; }
        var ms = null;
        if (item instanceof FootageItem) {
            try { ms = item.mainSource; } catch (e0) { ms = null; }
            if (item.footageMissing) { return "missing"; }
            if (ms && (ms instanceof PlaceholderSource)) { return "placeholder"; }
            if (ms && (ms instanceof SolidSource)) { return "solid"; }
            var ext = extOf(item);
            if (inList(ext, IMAGE_EXT)) { return "image"; }
            if (inList(ext, VIDEO_EXT)) { return "video"; }
            if (inList(ext, AUDIO_EXT)) { return "audio"; }
            // Sequence footage without a usable extension: treat as video.
            return "video";
        }
        if (item instanceof CompItem) { return "comp"; }
        if (item instanceof FolderItem) { return "folder"; }
        return "other";
    }

    /* ==================================================================
     *  Collection walker
     * ================================================================== */

    function collectFrom(folder, out) {
        var i;
        var it;
        for (i = 1; i <= folder.numItems; i++) {
            it = folder.item(i);
            out.push(it);
            if (it instanceof FolderItem) {
                collectFrom(it, out);
            }
        }
    }

    /* ==================================================================
     *  Apply
     * ================================================================== */

    function apply(opt) {
        var items = [];
        var i;
        var stats = { scanned: 0, changed: 0, skipped: 0, byRule: {} };

        if (!app.project) {
            return { ok: false, message: "No project open." };
        }

        if (opt.selectionOnly) {
            var sel = app.project.selection;
            for (i = 0; i < sel.length; i++) { items.push(sel[i]); }
            if (items.length === 0) {
                return { ok: false, message: "Nothing selected in the Project panel." };
            }
        } else {
            var root = app.project.rootFolder;
            collectFrom(root, items);
        }

        app.beginUndoGroup(SCRIPT_NAME + " - set item labels");
        try {
            for (i = 0; i < items.length; i++) {
                var item = items[i];
                var key = ruleKeyOf(item);
                var rule = opt.rules[key];
                stats.scanned++;
                if (!rule || !rule.enabled || rule.label < 1) {
                    stats.skipped++;
                    continue;
                }
                if (opt.onlyIfDifferent && item.label === rule.label) {
                    stats.skipped++;
                    continue;
                }
                try {
                    item.label = rule.label;
                    stats.changed++;
                    if (!stats.byRule[key]) { stats.byRule[key] = 0; }
                    stats.byRule[key]++;
                } catch (eSet) {
                    stats.skipped++;
                }
            }
        } catch (err) {
            app.endUndoGroup();
            return { ok: false, message: "Failed: " + err.toString() };
        }
        app.endUndoGroup();

        var msg = "Scanned " + stats.scanned + ", relabelled " + stats.changed +
            ", skipped " + stats.skipped + ".";
        return { ok: true, message: msg, stats: stats };
    }

    /* ==================================================================
     *  UI
     * ================================================================== */

    var RULE_DEFS = [
        { key: "missing", title: "Missing footage", def: 2, on: true },
        { key: "placeholder", title: "Placeholders", def: 12, on: true },
        { key: "solid", title: "Solids", def: 13, on: true },
        { key: "comp", title: "Compositions", def: 9, on: true },
        { key: "folder", title: "Folders", def: 1, on: true },
        { key: "image", title: "Still images", def: 10, on: true },
        { key: "video", title: "Video / sequences", def: 11, on: true },
        { key: "audio", title: "Audio", def: 8, on: true },
        { key: "other", title: "Everything else", def: 1, on: false }
    ];

    function labelMenuText(n) {
        var nm = LABEL_NAMES[(n - 1) % LABEL_NAMES.length];
        return n + "  " + nm;
    }

    function buildUI(thisObj) {
        var pal = (thisObj instanceof Panel) ? thisObj :
            new Window("palette", SCRIPT_NAME + " " + VERSION, undefined, { resizeable: true });
        pal.orientation = "column";
        pal.alignChildren = ["fill", "top"];
        pal.spacing = 8;
        pal.margins = 12;

        var top = pal.add("group");
        top.orientation = "column";
        top.alignChildren = ["left", "top"];
        top.add("statictext", undefined, "Assign a label index to each project item type.");
        top.add("statictext", undefined, "Label colours themselves come from AE Preferences > Labels.");

        var grid = pal.add("panel", undefined, "Rules");
        grid.orientation = "column";
        grid.alignChildren = ["fill", "top"];
        grid.margins = 10;
        grid.spacing = 3;

        var ruleState = {};
        var rows = [];
        var i;

        for (i = 0; i < RULE_DEFS.length; i++) {
            var def = RULE_DEFS[i];
            var row = grid.add("group");
            row.alignment = ["fill", "top"];
            row.spacing = 6;

            var cb = row.add("checkbox", undefined, def.title);
            cb.value = def.on;
            cb.preferredSize.width = 165;

            var dd = row.add("dropdownlist", undefined, []);
            var k;
            for (k = 1; k <= 16; k++) { dd.add("item", labelMenuText(k)); }
            dd.selection = def.def;
            dd.preferredSize.width = 130;

            var state = { key: def.key, enabled: def.on, label: def.def, cb: cb, dd: dd };
            ruleState[def.key] = state;
            rows.push(state);

            (function (st) {
                st.cb.onClick = function () { st.enabled = st.cb.value; };
                st.dd.onChange = function () { st.label = st.dd.selection.index + 1; };
            })(state);
        }

        var optBox = pal.add("panel", undefined, "Scope");
        optBox.orientation = "column";
        optBox.alignChildren = ["left", "top"];
        optBox.margins = 10;
        optBox.spacing = 4;

        var rbAll = optBox.add("radiobutton", undefined, "Entire project (recursive)");
        var rbSel = optBox.add("radiobutton", undefined, "Selected items only");
        rbAll.value = true;
        var cbOnlyDiff = optBox.add("checkbox", undefined, "Skip items already using that label");
        cbOnlyDiff.value = true;

        var btnRow = pal.add("group");
        btnRow.alignment = ["fill", "top"];
        var btnApply = btnRow.add("button", undefined, "Apply Labels");
        btnApply.preferredSize.width = 150;
        var btnReset = btnRow.add("button", undefined, "Reset Rules");

        var status = pal.add("statictext", undefined, "Ready.", { multiline: true });
        status.preferredSize.width = 340;

        function resetRules() {
            var j;
            for (j = 0; j < RULE_DEFS.length; j++) {
                var d = RULE_DEFS[j];
                var st = ruleState[d.key];
                st.cb.value = d.on;
                st.enabled = d.on;
                st.dd.selection = d.def;
            }
            status.text = "Rules reset to defaults.";
        }

        btnReset.onClick = resetRules;

        btnApply.onClick = function () {
            var rules = {};
            var j;
            for (j = 0; j < RULE_DEFS.length; j++) {
                var key = RULE_DEFS[j].key;
                rules[key] = { enabled: ruleState[key].enabled, label: ruleState[key].label };
            }
            var res = apply({
                rules: rules,
                selectionOnly: rbSel.value,
                onlyIfDifferent: cbOnlyDiff.value
            });
            status.text = res.message;
        };

        pal.onResizing = pal.onResize = function () { this.layout.resize(); };

        return pal;
    }

    var ui = buildUI(thisObj);
    if (ui instanceof Window) {
        ui.center();
        ui.show();
    } else {
        ui.layout.layout(true);
    }

})(this);
