// =============================================================================
//  EasyBake Clone v1.0  --  After Effects "expressions -> keyframes" baker
//  generated_at: 2026-11-14T00:22:00Z
//  task: clean-room clone of "Easy Bake" (paid-list.md #25, A-class, jsx)
// -----------------------------------------------------------------------------
//  CLEAN-ROOM DECLARATION
//  This script is an independent reimplementation written ONLY from the public
//  feature one-liner: "Convert expressions to keyframes faster, simpler and
//  with more control than ever before." No original product code was
//  decompiled, read, copied or translated. The bake loop (sample pre-expression
//  values with valueAtTime(t, preExpression=true), write them as keyframes)
//  is the standard scripting approach. All AE API usage follows
//  docs/api-cheatsheet.md; non-whitelisted APIs are wrapped in try/catch.
//  Target: After Effects CS6+ (ExtendScript), ES3 only, pure ASCII UI strings.
// =============================================================================

(function easyBakeClone(thisObj) {

    var TOOL = "EasyBake Clone";
    var VER = "1.0";
    var MAX_SAMPLES = 5000;      // per-property sample cap
    var WALK_DEPTH = 12;         // property-group recursion cap
    var EQ_EPS = 1e-7;           // static-key optimization tolerance

    // ---------------------------------------------------------------
    // tiny utils
    // ---------------------------------------------------------------

    function msg(e) {
        return (e && e.message) ? e.message : String(e);
    }

    function isComp(item) {
        return (item && item instanceof CompItem);
    }

    function valEq(a, b) {
        if (typeof a === "number" && typeof b === "number") {
            return Math.abs(a - b) < EQ_EPS;
        }
        if (a instanceof Array && b instanceof Array && a.length === b.length) {
            var i;
            for (i = 0; i < a.length; i++) {
                if (Math.abs(a[i] - b[i]) >= EQ_EPS) { return false; }
            }
            return true;
        }
        return a === b;
    }

    function hasExpression(p) {
        try {
            return (p.expression !== "");
        } catch (eEx) {
            return false;
        }
    }

    // owning layer of a property (parentProperty is not in the cheatsheet
    // whitelist -> whole walk wrapped in try/catch, null fallback)
    function ownerLayer(prop) {
        try {
            var cur = prop;
            var depth = 0;
            while (cur && !(cur instanceof Layer) && depth < 16) {
                cur = cur.parentProperty;
                depth++;
            }
            return (cur instanceof Layer) ? cur : null;
        } catch (eOwn) {
            return null;
        }
    }

    // collect every expression-driven Property under a group (layer included)
    function collectExprProps(grp, out, depth) {
        if (depth > WALK_DEPTH) { return; }
        var n;
        try { n = grp.numProperties; } catch (eN) { n = undefined; }
        if (typeof n !== "number") { return; }
        var i, p;
        for (i = 1; i <= n; i++) {
            p = null;
            try { p = grp.property(i); } catch (eP) { p = null; }
            if (!p) { continue; }
            if (p instanceof Property) {
                if (hasExpression(p)) { out.push(p); }
            } else {
                collectExprProps(p, out, depth + 1);
            }
        }
    }

    // selection -> list of bakes-able properties
    function gatherTargets(cfg) {
        var comp = app.project.activeItem;
        if (!isComp(comp)) {
            throw new Error("Activate a composition first (click inside its timeline).");
        }
        var out = [];
        var i, it;
        if (cfg.scope === 0) {
            var sp = comp.selectedProperties;
            if (!sp || sp.length === 0) {
                throw new Error("Select at least one property (with an expression) in the timeline.");
            }
            for (i = 0; i < sp.length; i++) {
                it = sp[i];
                if (it instanceof Property && hasExpression(it)) {
                    out.push(it);
                }
            }
        } else {
            var layers = comp.selectedLayers;
            if (!layers || layers.length === 0) {
                throw new Error("Select at least one layer for layer-scope baking.");
            }
            for (i = 0; i < layers.length; i++) {
                collectExprProps(layers[i], out, 0);
            }
        }
        if (out.length === 0) {
            throw new Error("No expression-driven properties found in the current selection.");
        }
        return { comp: comp, props: out };
    }

    // ---------------------------------------------------------------
    // range resolution
    // ---------------------------------------------------------------

    function resolveRange(comp, prop, cfg, errors) {
        var t1, t2;
        if (cfg.range === 0) {
            if (comp.workAreaDuration > 0) {
                t1 = comp.workAreaStart;
                t2 = t1 + comp.workAreaDuration;
            } else {
                errors.push("Work area is empty; set it in the timeline or pick another range (" +
                    prop.name + " skipped).");
                return null;
            }
        } else if (cfg.range === 1) {
            var lay = ownerLayer(prop);
            if (lay) {
                t1 = lay.inPoint;
                t2 = lay.outPoint;
            } else {
                errors.push("Cannot resolve owning layer for '" + prop.name +
                    "'; baked over whole comp instead.");
                t1 = 0;
                t2 = comp.duration;
            }
        } else {
            t1 = 0;
            t2 = comp.duration;
        }
        if (!(t2 > t1)) {
            errors.push("Empty time range for '" + prop.name + "'.");
            return null;
        }
        return [t1, t2];
    }

    // ---------------------------------------------------------------
    // bake
    // ---------------------------------------------------------------

    function writeKey(prop, t, v, errors) {
        try {
            prop.setValueAtTime(t, v);
            return true;
        } catch (eW) {
            errors.push("Cannot write key on '" + prop.name + "' @ " +
                (Math.round(t * 1000) / 1000) + "s: " + msg(eW));
            return false;
        }
    }

    function linearizeKeys(prop) {
        var i;
        for (i = 1; i <= prop.numKeys; i++) {
            try {
                prop.setInterpolationTypeAtKey(i,
                    KeyframeInterpolationType.LINEAR,
                    KeyframeInterpolationType.LINEAR);
            } catch (eL) { /* some key types reject */ }
        }
    }

    function unroveSpatial(prop) {
        var i;
        for (i = 1; i <= prop.numKeys; i++) {
            try { prop.setRovingAtKey(i, false); } catch (eR) { /* ok */ }
        }
    }

    function clearKeysInRange(prop, t1, t2) {
        var doomed = [];
        var i, kt;
        for (i = 1; i <= prop.numKeys; i++) {
            kt = prop.keyTime(i);
            if (kt >= t1 - 1e-9 && kt <= t2 + 1e-9) {
                doomed.push(i);
            }
        }
        for (i = doomed.length - 1; i >= 0; i--) {
            prop.removeKey(doomed[i]);
        }
        return doomed.length;
    }

    function bakeOne(comp, prop, cfg, stats, errors) {
        if (!hasExpression(prop)) {
            stats.skipped++;
            return;
        }
        var range = resolveRange(comp, prop, cfg, errors);
        if (!range) {
            stats.skipped++;
            return;
        }
        var t1 = range[0];
        var t2 = range[1];
        var fD = comp.frameDuration;
        if (!(fD > 0)) {
            errors.push("Invalid comp frame duration.");
            stats.skipped++;
            return;
        }
        var step = cfg.step * fD;
        var n = Math.floor((t2 - t1) / step + 0.0001);
        if (n < 1) { n = 1; }
        if (n > MAX_SAMPLES) {
            errors.push("'" + prop.name + "': " + n +
                " samples would exceed the cap of " + MAX_SAMPLES +
                " (raise the step or shorten the range).");
            stats.skipped++;
            return;
        }

        if (cfg.clearKeys) {
            stats.cleared += clearKeysInRange(prop, t1, t2);
        }

        // sample pre-expression values (valueAtTime(t, true) is whitelisted)
        var times = [];
        var vals = [];
        var i, t, v;
        for (i = 0; i <= n; i++) {
            t = t1 + i * step;
            if (t > t2) { t = t2; }
            try {
                v = prop.valueAtTime(t, true);
                times.push(t);
                vals.push(v);
            } catch (eS) {
                errors.push("'" + prop.name + "': sample failed @ " +
                    (Math.round(t * 1000) / 1000) + "s (" + msg(eS) + ")");
            }
        }
        if (times[times.length - 1] < t2 - 1e-9) {
            try {
                v = prop.valueAtTime(t2, true);
                times.push(t2);
                vals.push(v);
            } catch (eS2) { /* end sample optional */ }
        }
        if (times.length === 0) {
            errors.push("'" + prop.name + "': no samples collected.");
            stats.skipped++;
            return;
        }

        // write keys: always the first sample; afterwards only where the
        // value changed. When it changes, also close the hold run by writing
        // the previous (unchanged) sample time.
        var writes = 0;
        var lastWriteIdx = -1;
        for (i = 0; i < times.length; i++) {
            if (i === 0) {
                if (writeKey(prop, times[0], vals[0], errors)) { writes++; }
                lastWriteIdx = 0;
            } else if (cfg.optimize && valEq(vals[i], vals[i - 1])) {
                // static run: skip
            } else {
                if (lastWriteIdx !== i - 1 && writeKey(prop, times[i - 1], vals[i - 1], errors)) {
                    writes++;
                }
                if (writeKey(prop, times[i], vals[i], errors)) { writes++; }
                lastWriteIdx = i;
            }
        }

        linearizeKeys(prop);
        if (prop.propertyValueType === PropertyValueType.TwoD_SPATIAL) {
            unroveSpatial(prop);
        }

        if (cfg.dropExpr) {
            try {
                prop.expression = "";
            } catch (eD) {
                errors.push("'" + prop.name + "': keys baked but expression could not be removed: " +
                    msg(eD));
            }
        }
        stats.baked++;
        stats.keys += writes;
    }

    // ---------------------------------------------------------------
    // action + guards
    // ---------------------------------------------------------------

    function doBake(cfg) {
        if (!app.project) {
            throw new Error("No project open.");
        }
        var picked = gatherTargets(cfg);
        var comp = picked.comp;
        var props = picked.props;

        var stats = { baked: 0, skipped: 0, keys: 0, cleared: 0 };
        var errors = [];

        app.beginUndoGroup(TOOL + ": bake expressions");
        try {
            var i;
            for (i = 0; i < props.length; i++) {
                bakeOne(comp, props[i], cfg, stats, errors);
            }
        } finally {
            app.endUndoGroup();
        }

        var note = "Baked " + stats.baked + " propert" +
            (stats.baked === 1 ? "y" : "ies") + ", " + stats.keys +
            " key(s), " + stats.cleared + " old key(s) cleared, " +
            stats.skipped + " skipped.";
        if (errors.length > 0) {
            var shown = errors.slice(0, 10);
            if (errors.length > 10) {
                shown.push("... +" + (errors.length - 10) + " more");
            }
            note += "\nWarnings:\n" + shown.join("\n");
        }
        return note;
    }

    // ---------------------------------------------------------------
    // UI
    // ---------------------------------------------------------------

    function buildUI(thisObj) {
        var win = (thisObj instanceof Panel)
            ? thisObj
            : new Window("palette", TOOL + " v" + VER, undefined, { resizeable: true });
        win.orientation = "column";
        win.alignChildren = ["fill", "top"];
        win.spacing = 6;
        win.margins = 10;

        var sP = win.add("panel", undefined, "Scope");
        sP.orientation = "row";
        sP.alignChildren = ["left", "center"];
        sP.margins = 8;
        var rbSelProps = sP.add("radiobutton", undefined, "Selected properties");
        var rbSelLayers = sP.add("radiobutton", undefined, "Selected layers (all expr props)");
        rbSelProps.value = true;

        var rP = win.add("panel", undefined, "Range");
        rP.orientation = "row";
        rP.alignChildren = ["left", "center"];
        rP.margins = 8;
        var rbWork = rP.add("radiobutton", undefined, "Work area");
        var rbLayer = rP.add("radiobutton", undefined, "Layer in/out");
        var rbComp = rP.add("radiobutton", undefined, "Whole comp");
        rbWork.value = true;

        var oP = win.add("panel", undefined, "Sampling / options");
        oP.orientation = "column";
        oP.alignChildren = ["left", "top"];
        oP.margins = 8;
        var gStep = oP.add("group");
        gStep.orientation = "row";
        gStep.alignChildren = ["left", "center"];
        gStep.add("statictext", undefined, "Step (frames):");
        var etStep = gStep.add("edittext", undefined, "1");
        etStep.characters = 5;
        var cbClear = oP.add("checkbox", undefined, "Clear existing keys inside the range first");
        cbClear.value = true;
        var cbOpt = oP.add("checkbox", undefined, "Optimize: skip keys on unchanged values");
        cbOpt.value = true;
        var cbDrop = oP.add("checkbox", undefined, "Remove expression after baking");
        cbDrop.value = false;

        var btn = win.add("button", undefined, "BAKE EXPRESSIONS TO KEYS", { name: "ok" });

        var st = win.add("statictext", undefined,
            "Samples each property's pre-expression value via valueAtTime and " +
            "writes the result as linear keyframes. Undo-able in one step.");
        st.characters = 58;
        st.multiline = true;
        var stStatus = win.add("statictext", undefined, "Ready.");
        stStatus.characters = 58;
        stStatus.multiline = true;

        btn.onClick = function () {
            var step = parseInt(etStep.text, 10);
            if (isNaN(step) || step < 1) { step = 1; }
            if (step > 100) { step = 100; }
            var cfg = {
                scope: rbSelLayers.value ? 1 : 0,
                range: rbLayer.value ? 1 : (rbComp.value ? 2 : 0),
                step: step,
                clearKeys: cbClear.value,
                optimize: cbOpt.value,
                dropExpr: cbDrop.value
            };
            try {
                var note = doBake(cfg);
                stStatus.text = note;
            } catch (e) {
                alert(TOOL + " error:\n" + msg(e));
            }
        };

        win.onResizing = win.onResize = function () {
            this.layout.resize();
        };
        win.layout.layout(true);
        return win;
    }

    var win = buildUI(thisObj);
    if (win instanceof Window) {
        win.center();
        win.show();
    } else {
        win.layout.layout(true);
    }

})(this);
