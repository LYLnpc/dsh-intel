/**
 * AG Clone (clean-room) -- keyframe loop / repeat toolset for After Effects.
 * ============================================================================
 * CLEAN-ROOM NOTICE:
 *   This file was written from a written feature description only
 *   (intel/paid-list.md entry #19 "Again!", Adam Sacks, $5 NYOP: "repeat the
 *   animation from a new start value"). [未核实细节] per source. No
 *   decompilation, no original source code, no original resources were used
 *   or inspected. All expression math, code structure and naming below are
 *   original work. "Again!" is a commercial product by Adam Sacks; this
 *   clone is for learning/interop research only.
 *
 * FEATURE BASELINE (task spec, original implementation):
 *   1. One-click standard loops: loopIn/loopOut x cycle/pingpong/offset/
 *      continue written onto selected keyframed properties.
 *   2. Custom loop segment: pick a key range (auto-inferred from selected
 *      keys, else first..last) and repeat count; segment is replayed after
 *      its end time. cycle replays verbatim; offset replays "from a new
 *      start value" (the Again! idea): each pass adds the segment's value
 *      delta, so the same motion keeps advancing from the last end value.
 *   3. Custom pingpong with optional smoothstep easing on the return swing.
 *   4. Time-remap looping (enable timeRemap, then loopOut(mode) on it).
 *
 * EXPRESSION SAFETY NOTE (why valueAtTime recursion terminates here):
 *   valueAtTime() on a property WITH expressions evaluates those expressions
 *   too. Our custom expressions only sample tt = t0 + (raw % seg), which is
 *   always <= t1, and the recursion guard is "time > t1" -- so the nested
 *   call lands on the plain "value" branch and recursion depth is <= 2.
 *
 * ES3 / ExtendScript. API names cross-checked against docs/api-cheatsheet.md
 * (PropertyValueType.OneD/TwoD mixed case, selectedKeys 1-based, etc).
 * Run: ScriptUI Panels folder, or File > Scripts > Run Script File...
 * ============================================================================
 */

(function AGClone(thisObj) {

    var SCRIPT_NAME = 'AG Clone';
    var SCRIPT_VER = '1.0.0';
    var ORIG_NAME = 'Again! (Adam Sacks, aescripts, $5 NYOP)';

    var LOOP_MODES = ['cycle', 'pingpong', 'offset', 'continue'];

    // ------------------------------------------------------------------
    // small utils
    // ------------------------------------------------------------------

    function getComp() {
        var it = app.project ? app.project.activeItem : null;
        return (it && it instanceof CompItem) ? it : null;
    }

    function tf(layer) {
        return layer.property('ADBE Transform Group');
    }

    function isLoopableLayer(layer) {
        return !(layer instanceof CameraLayer) && !(layer instanceof LightLayer);
    }

    function isProperty(p) {
        return String(p.propertyType) === 'PROPERTY';
    }

    function canLoop(p) {
        try {
            if (p.numKeys < 2) { return false; }
            if (!p.canSetExpression) { return false; }
        } catch (e) { return false; }
        return true;
    }

    function f2(x) {
        return String(Math.round(x * 100) / 100);
    }

    function timeStr(t) {
        var m = Math.floor(t / 60);
        var s = t - m * 60;
        return m + ':' + (s < 10 ? '0' : '') + f2(s);
    }

    // Collect keyframed, expression-capable numeric-ish properties from the
    // selection: selectedProperties first, else walk selected layers' trees.
    function collectTargets(comp) {
        var out = [];
        var i, p, sel;
        sel = comp.selectedProperties;
        if (sel && sel.length > 0) {
            for (i = 0; i < sel.length; i++) {
                p = sel[i];
                if (isProperty(p) && canLoop(p)) { out.push(p); }
            }
        }
        if (out.length > 0) { return out; }
        var layers = comp.selectedLayers;
        var li, found;
        for (li = 0; li < layers.length; li++) {
            found = [];
            walkProps(layers[li], 0, found);
            for (i = 0; i < found.length; i++) {
                out.push(found[i]);
            }
        }
        return out;
    }

    function walkProps(group, depth, out) {
        if (depth > 5 || out.length > 60) { return; }
        var i, p;
        for (i = 1; i <= group.numProperties; i++) {
            try { p = group.property(i); } catch (e) { continue; }
            if (p === null || p === undefined) { continue; }
            if (isProperty(p)) {
                if (canLoop(p)) { out.push(p); }
            } else if (p.matchName !== undefined) {
                // 效果组/蒙版组等一并递归（效果滑杆同样可循环）；深度与数量有上限
                walkProps(p, depth + 1, out);
            }
        }
    }

    // Loop segment: selected keys span (1-based indices), else full range.
    // Returns {k1, k2} or null. (selectedKeys is 1-based; ES3 numeric sort
    // is manual per api-cheatsheet.)
    function inferSegment(p) {
        var sk = null;
        try { sk = p.selectedKeys; } catch (eS) { sk = null; }
        var k1 = 0, k2 = 0, i;
        if (sk && sk.length > 0) {
            k1 = sk[0];
            k2 = sk[0];
            for (i = 1; i < sk.length; i++) {
                if (sk[i] < k1) { k1 = sk[i]; }
                if (sk[i] > k2) { k2 = sk[i]; }
            }
        } else {
            k1 = 1;
            k2 = p.numKeys;
        }
        if (!(k1 >= 1 && k2 > k1 && k2 <= p.numKeys)) { return null; }
        return { k1: k1, k2: k2 };
    }

    // ------------------------------------------------------------------
    // expression builders (all original, ES3-safe for both AE engines)
    // ------------------------------------------------------------------

    function buildStandardExpr(side, mode) {
        // side: 'out' | 'in'
        if (side === 'in') { return '// AG-clone v' + SCRIPT_VER + ' standard loop\nloopIn("' + mode + '");'; }
        return '// AG-clone v' + SCRIPT_VER + ' standard loop\nloopOut("' + mode + '");';
    }

    function buildCustomExpr(mode, k1, k2, reps, ease) {
        var head = [
            '// AG-clone v' + SCRIPT_VER + ' (clean-room) custom ' + mode + ' on keys ' + k1 + '..' + k2,
            'var K1 = ' + k1 + ', K2 = ' + k2 + ', REPS = ' + reps + ';',
            'var t0 = key(K1).time;',
            'var t1 = key(K2).time;',
            'var seg = t1 - t0;',
            'var out = value;'
        ];
        if (mode === 'pingpong') {
            return head.concat([
                'if (time > t1 && seg > 0) {',
                '    var period = seg * 2;',
                '    var raw = time - t1;',
                '    var cyc = Math.floor(raw / period);',
                '    var rem = raw - cyc * period;',
                '    if (REPS <= 0 || cyc + 1 <= REPS) {',
                '        var tt;',
                '        if (rem < seg) { tt = t0 + rem; }',
                '        else {',
                '            var x = (rem - seg) / seg;',
                '            if (' + (ease ? 1 : 0) + ' === 1) { x = x * x * (3 - 2 * x); }',
                '            tt = t1 - x * seg;',
                '        }',
                '        out = valueAtTime(tt); // tt <= t1, recursion depth <= 2',
                '    }',
                '}',
                'out;'
            ]).join('\n');
        }
        if (mode === 'offset') {
            // the "Again!" idea: replay the same motion from a new start
            // value -- every pass adds the segment's value delta, so the
            // motion keeps advancing instead of snapping back.
            return head.concat([
                'if (time > t1 && seg > 0) {',
                '    var raw = time - t1;',
                '    var n = Math.floor(raw / seg) + 1;',
                '    if (REPS <= 0 || n <= REPS) {',
                '        var smp = valueAtTime(t0 + (raw % seg));',
                '        out = smp + (valueAtTime(t1) - valueAtTime(t0)) * n;',
                '    }',
                '}',
                'out;'
            ]).join('\n');
        }
        // default: cycle
        return head.concat([
            'if (time > t1 && seg > 0) {',
            '    var raw = time - t1;',
            '    var n = Math.floor(raw / seg) + 1;',
            '    if (REPS <= 0 || n <= REPS) {',
            '        out = valueAtTime(t0 + (raw % seg));',
            '    }',
            '}',
            'out;'
        ]).join('\n');
    }

    // ------------------------------------------------------------------
    // actions
    // ------------------------------------------------------------------

    function applyStandard(comp, side, mode, status) {
        var props = collectTargets(comp);
        if (props.length === 0) {
            alert('Select keyframed properties in the timeline first.\n(Or select layers that have keyframes.)');
            return;
        }
        var expr = buildStandardExpr(side, mode);
        var ok = 0, errs = [];
        app.beginUndoGroup('AG Clone: loop' + (side === 'in' ? 'In' : 'Out') + ' ' + mode);
        try {
            var i;
            for (i = 0; i < props.length; i++) {
                try { props[i].expression = expr; ok++; }
                catch (e) { errs.push(props[i].name + ': ' + e.toString()); }
            }
        } finally {
            app.endUndoGroup();
        }
        status.text = 'loop' + (side === 'in' ? 'In' : 'Out') + '("' + mode + '") on ' + ok +
            ' propert(ies)' + (errs.length ? ' | failed: ' + errs.join('; ') : '');
    }

    function applyCustom(comp, mode, reps, ease, status) {
        var props = collectTargets(comp);
        if (props.length === 0) {
            alert('Select keyframed properties in the timeline first.\n(Or select layers that have keyframes.)');
            return;
        }
        var ok = 0, errs = [];
        var i, p, seg, expr;
        app.beginUndoGroup('AG Clone: custom ' + mode);
        try {
            for (i = 0; i < props.length; i++) {
                p = props[i];
                try {
                    seg = inferSegment(p);
                    if (seg === null) { errs.push(p.name + ': needs >= 2 keys'); continue; }
                    expr = buildCustomExpr(mode, seg.k1, seg.k2, reps, ease);
                    p.expression = expr;
                    ok++;
                } catch (e) { errs.push(p.name + ': ' + e.toString()); }
            }
        } finally {
            app.endUndoGroup();
        }
        status.text = 'custom ' + mode + ' on ' + ok + ' propert(ies)' +
            (errs.length ? ' | failed: ' + errs.join('; ') : '');
    }

    function describeSegment(comp, status) {
        var props = collectTargets(comp);
        if (props.length === 0) { status.text = 'No keyframed property selected.'; return; }
        var p = props[0];
        var seg = inferSegment(p);
        if (seg === null) { status.text = p.name + ': needs at least 2 keyframes.'; return; }
        try {
            status.text = 'Segment on "' + p.name + '": keys ' + seg.k1 + '..' + seg.k2 +
                ' (' + timeStr(p.key(seg.k1).time) + ' -> ' + timeStr(p.key(seg.k2).time) + ')' +
                (props.length > 1 ? ' | first of ' + props.length + ' props' : '');
        } catch (e) {
            status.text = 'Segment: keys ' + seg.k1 + '..' + seg.k2;
        }
    }

    function applyTimeRemap(comp, mode, autoEnable, status) {
        var layers = comp.selectedLayers;
        if (!layers || layers.length === 0) {
            status.text = 'No layers selected. Select layer(s) for time-remap loop.';
            return;
        }
        var ok = 0, errs = [];
        var i, L, tr;
        app.beginUndoGroup('AG Clone: time-remap loop ' + mode);
        try {
            for (i = 0; i < layers.length; i++) {
                L = layers[i];
                try {
                    if (!isLoopableLayer(L)) { errs.push(L.name + ': camera/light'); continue; }
                    if (!L.timeRemapEnabled) {
                        if (!autoEnable) { errs.push(L.name + ': time remap off'); continue; }
                        L.timeRemapEnabled = true; // wrapped in try; if the build rejects it, user enables manually
                    }
                    tr = L.property('ADBE Time Remapping');
                    if (!tr) { errs.push(L.name + ': no time remap'); continue; }
                    tr.expression = 'loopOut("' + mode + '");';
                    ok++;
                } catch (eT) { errs.push(L.name + ': ' + eT.toString()); }
            }
        } finally {
            app.endUndoGroup();
        }
        status.text = 'time-remap loopOut("' + mode + '") on ' + ok + ' layer(s)' +
            (errs.length ? ' | failed: ' + errs.join('; ') : '');
    }

    // ------------------------------------------------------------------
    // UI
    // ------------------------------------------------------------------

    function buildUI(thisObj) {
        var win = (thisObj instanceof Panel) ? thisObj
            : new Window('palette', SCRIPT_NAME + ' v' + SCRIPT_VER, undefined, { resizeable: true });
        win.orientation = 'column';
        win.alignChildren = ['fill', 'top'];
        win.spacing = 6;
        win.margins = 10;

        var decl = win.add('statictext', undefined,
            'Clean-room reimplementation of "Again!" from its written feature list. No original code used.', { truncate: true });
        decl.maximumSize.width = 400;

        // ---- zone 1: one-click standard loops ----
        var p1 = win.add('panel', undefined, '1. Standard loop (AE native)');
        p1.orientation = 'row';
        p1.alignChildren = ['left', 'center'];
        p1.margins = 10;
        p1.spacing = 5;
        p1.add('statictext', undefined, 'side');
        var ddSide = p1.add('dropdownlist', undefined, ['loopOut', 'loopIn']);
        ddSide.selection = 0;
        p1.add('statictext', undefined, 'mode');
        var ddMode = p1.add('dropdownlist', undefined, LOOP_MODES);
        ddMode.selection = 0;
        var bStd = p1.add('button', undefined, 'Apply');
        bStd.preferredSize = [70, 24];

        // ---- zone 2: custom segment loop (cycle / offset) ----
        var p2 = win.add('panel', undefined, '2. Custom segment loop (selected keys = segment)');
        p2.orientation = 'row';
        p2.alignChildren = ['left', 'center'];
        p2.margins = 10;
        p2.spacing = 5;
        p2.add('statictext', undefined, 'mode');
        var ddCMode = p2.add('dropdownlist', undefined, ['cycle', 'offset (Again! style)']);
        ddCMode.selection = 0;
        p2.add('statictext', undefined, 'reps(0=inf)');
        var etReps = p2.add('edittext', undefined, '0');
        etReps.characters = 5;
        var bCyc = p2.add('button', undefined, 'Apply');
        bCyc.preferredSize = [70, 24];

        // ---- zone 3: pingpong with eased return ----
        var p3 = win.add('panel', undefined, '3. Custom pingpong (eased return swing)');
        p3.orientation = 'row';
        p3.alignChildren = ['left', 'center'];
        p3.margins = 10;
        p3.spacing = 5;
        p3.add('statictext', undefined, 'reps(0=inf)');
        var etPRep = p3.add('edittext', undefined, '0');
        etPRep.characters = 5;
        var cbEase = p3.add('checkbox', undefined, 'smoothstep return');
        cbEase.value = true;
        var bPp = p3.add('button', undefined, 'Apply');
        bPp.preferredSize = [70, 24];

        // ---- zone 4: time remap loop ----
        var p4 = win.add('panel', undefined, '4. Time-remap loop (on selected layers)');
        p4.orientation = 'row';
        p4.alignChildren = ['left', 'center'];
        p4.margins = 10;
        p4.spacing = 5;
        p4.add('statictext', undefined, 'mode');
        var ddTR = p4.add('dropdownlist', undefined, LOOP_MODES);
        ddTR.selection = 0;
        var cbTR = p4.add('checkbox', undefined, 'enable time remap');
        cbTR.value = true;
        var bTR = p4.add('button', undefined, 'Apply');
        bTR.preferredSize = [70, 24];

        var bInfo = win.add('button', undefined, 'Show detected segment');

        var status = win.add('statictext', undefined,
            SCRIPT_NAME + ' v' + SCRIPT_VER + ' ready. Original: ' + ORIG_NAME, { multiline: true });
        status.preferredSize = [360, 40];

        bStd.onClick = function () {
            var comp = getComp();
            if (!comp) { alert('Open a composition first.'); return; }
            var side = (ddSide.selection && ddSide.selection.text === 'loopIn') ? 'in' : 'out';
            applyStandard(comp, side, ddMode.selection ? ddMode.selection.text : 'cycle', status);
        };
        bCyc.onClick = function () {
            var comp = getComp();
            if (!comp) { alert('Open a composition first.'); return; }
            var reps = parseInt(etReps.text, 10);
            if (isNaN(reps) || reps < 0) { reps = 0; }
            var m = (ddCMode.selection && ddCMode.selection.index === 1) ? 'offset' : 'cycle';
            applyCustom(comp, m, reps, false, status);
        };
        bPp.onClick = function () {
            var comp = getComp();
            if (!comp) { alert('Open a composition first.'); return; }
            var reps = parseInt(etPRep.text, 10);
            if (isNaN(reps) || reps < 0) { reps = 0; }
            applyCustom(comp, 'pingpong', reps, cbEase.value, status);
        };
        bTR.onClick = function () {
            var comp = getComp();
            if (!comp) { alert('Open a composition first.'); return; }
            applyTimeRemap(comp, ddTR.selection ? ddTR.selection.text : 'cycle', cbTR.value, status);
        };
        bInfo.onClick = function () {
            var comp = getComp();
            if (!comp) { alert('Open a composition first.'); return; }
            describeSegment(comp, status);
        };

        win.layout.layout(true);
        win.layout.resize();
        // 浮动窗口模式（Run Script File）必须显式 show，否则面板不出现
        if (win instanceof Window) {
            win.center();
            win.show();
        }
        win.onResizing = win.onResize = function () { this.layout.resize(); };
        return win;
    }

    buildUI(thisObj);

})(this);
