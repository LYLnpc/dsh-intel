// =============================================================================
//  RollIt Clone v1.0  --  After Effects "real rolling" tool (main.jsx)
//  generated_at: 2026-11-14T00:06:23Z   task: clean-room clone of a paid
//  "layer rolling" script (Roll it! feature baseline, intel/paid-list.md)
// -----------------------------------------------------------------------------
//  CLEAN-ROOM DECLARATION
//  This script is an independent reimplementation written ONLY from a public,
//  high-level feature description. No original product code was decompiled,
//  read, copied, or translated. The core behavior (rolling = rotation linked
//  to travelled distance through the circumference formula
//  angle = D / (PI * diameter) * 360 deg) is standard mechanics, implemented
//  from scratch. All AE API usage follows docs/api-cheatsheet.md (official
//  scripting-guide whitelist); non-whitelisted APIs are wrapped in try/catch.
// -----------------------------------------------------------------------------
//  Target: After Effects CS6+ (ExtendScript). ES3 only. No external deps.
//  UI strings are ASCII on purpose (Windows ExtendScript + UTF-8 quirks).
// =============================================================================

(function rollItClone(thisObj) {

    var TOOL = "RollIt Clone";
    var VER = "1.0";
    var MAX_FRAMES = 5000;   // safety cap for baked frame loops
    var SUBDIV = 12;         // bezier subdivisions per path segment

    // ---------------------------------------------------------------
    // small helpers
    // ---------------------------------------------------------------

    function isComp(item) {
        return (item && item instanceof CompItem);
    }

    // remove expression + all keys from a Property (removeKey, NOT deleteKey)
    function clearProp(p) {
        try { p.expression = ""; } catch (eClear) { /* read-only expr */ }
        var i;
        for (i = p.numKeys; i >= 1; i--) {
            p.removeKey(i);
        }
    }

    // rolling "wheel diameter": X axis / path -> layer width, Y axis -> height
    // sourceRectAtTime is not in the cheatsheet whitelist -> try/catch + fallback
    function layerDiameter(layer, axis, t) {
        var d = 0;
        try {
            var sr = layer.sourceRectAtTime(t, false);
            d = (axis === 1) ? sr.height : sr.width;
        } catch (eSR) {
            d = 0;
        }
        if (!(d > 0)) {
            d = (axis === 1) ? layer.height : layer.width;
        }
        return d;
    }

    function maskCount(layer) {
        try {
            return layer.property("ADBE Mask Parade").numProperties;
        } catch (eMask) {
            return 0;
        }
    }

    function getFirstMaskShapeProp(layer) {
        try {
            var masks = layer.property("ADBE Mask Parade");
            var i, mp, sp;
            for (i = 1; i <= masks.numProperties; i++) {
                mp = masks.property(i);
                // 官方 matchName 为 ADBE Mask Atom（ADBE Mask Group 不存在）
                if (mp.matchName === "ADBE Mask Atom") {
                    sp = mp.property("ADBE Mask Shape");
                    if (sp) { return sp; }
                }
            }
        } catch (eMask2) { /* no masks */ }
        return null;
    }

    // axis property: position, or xPosition/yPosition when dimensions separated
    // (xPosition/yPosition not in whitelist -> try/catch, caller null-checks)
    function axisProp(layer, axis, separated) {
        var tr = layer.transform;
        if (!separated) { return tr.position; }
        try {
            return (axis === 0) ? tr.xPosition : tr.yPosition;
        } catch (eAxis) {
            return null;
        }
    }

    function dimensionsSeparated(layer) {
        try {
            return (layer.transform.position.dimensionsSeparated === true);
        } catch (eSep) {
            return false;
        }
    }

    // time range: selected keys if >= 2 selected, else first..last key
    function keyRange(ap) {
        var t1 = ap.key(1).time;
        var t2 = ap.key(ap.numKeys).time;
        try {
            var sk = ap.selectedKeys;
            if (sk && sk.length >= 2) {
                var tmin = ap.key(sk[0]).time;
                var tmax = tmin;
                var i, tt;
                for (i = 1; i < sk.length; i++) {
                    tt = ap.key(sk[i]).time;
                    if (tt < tmin) { tmin = tt; }
                    if (tt > tmax) { tmax = tt; }
                }
                t1 = tmin;
                t2 = tmax;
            }
        } catch (eSel) { /* fall back to full key range */ }
        return [t1, t2];
    }

    function linearize(p) {
        var i;
        for (i = 1; i <= p.numKeys; i++) {
            try {
                p.setInterpolationTypeAtKey(i,
                    KeyframeInterpolationType.LINEAR,
                    KeyframeInterpolationType.LINEAR);
            } catch (eLin) { /* some key types reject */ }
        }
    }

    function frameCount(comp, t1, t2) {
        var fD = comp.frameDuration;
        if (!(fD > 0)) {
            throw new Error("Invalid comp frame duration.");
        }
        var n = Math.round((t2 - t1) / fD);
        if (n < 1) { n = 1; }
        if (n > MAX_FRAMES) {
            throw new Error("Range is " + n + " frames, over the cap of " +
                MAX_FRAMES + ". Shorten the keyframe range or work area.");
        }
        return n;
    }

    // ---------------------------------------------------------------
    // path sampling (mask path -> polyline via bezier subdivision)
    // ---------------------------------------------------------------

    function cubicPt(p0, c1, c2, p3, u) {
        var mu = 1 - u;
        var a = mu * mu * mu;
        var b = 3 * mu * mu * u;
        var c = 3 * mu * u * u;
        var d = u * u * u;
        return [a * p0[0] + b * c1[0] + c * c2[0] + d * p3[0],
                a * p0[1] + b * c1[1] + c * c2[1] + d * p3[1]];
    }

    // sample mask shape at time t -> { pts, cum, total } in COMP space
    // "cumulative arc length approximation" = polyline over subdivided beziers
    function sampleShapeAt(shProp, t, pathLayer) {
        var sh = shProp.valueAtTime(t, true);
        var v = sh.vertices;
        if (!v || v.length < 2) {
            throw new Error("Mask path has fewer than 2 vertices.");
        }
        var n = v.length;
        var segCount = sh.closed ? n : n - 1;
        var pts = [];
        var cum = [];
        pts.push([v[0][0], v[0][1]]);
        cum.push(0);
        var i, s;
        for (i = 0; i < segCount; i++) {
            var a = i % n;
            var b = (i + 1) % n;
            var p0 = v[a];
            var p3 = v[b];
            var c1 = [p0[0] + sh.outTangents[a][0], p0[1] + sh.outTangents[a][1]];
            var c2 = [p3[0] + sh.inTangents[b][0], p3[1] + sh.inTangents[b][1]];
            for (s = 1; s <= SUBDIV; s++) {
                var u = s / SUBDIV;
                var p = cubicPt(p0, c1, c2, p3, u);
                var last = pts[pts.length - 1];
                var ddx = p[0] - last[0];
                var ddy = p[1] - last[1];
                cum.push(cum[cum.length - 1] +
                    Math.sqrt(ddx * ddx + ddy * ddy));
                pts.push(p);
            }
        }
        // layer space -> comp space (toComp not in whitelist -> try/catch)
        for (i = 0; i < pts.length; i++) {
            pts[i] = toCompSafe(pathLayer, pts[i], t);
        }
        return { pts: pts, cum: cum, total: cum[cum.length - 1] };
    }

    function toCompSafe(pathLayer, pt, t) {
        try {
            return pathLayer.toComp(pt, t);
        } catch (eTC) {
            // naive fallback (correct for unrotated / unscaled layers):
            // comp = position + (maskPoint - anchorPoint)
            var an = [0, 0];
            var po = [0, 0];
            try { an = pathLayer.transform.anchorPoint.value; } catch (eA) {}
            try { po = pathLayer.transform.position.value; } catch (eP) {}
            return [pt[0] - an[0] + po[0], pt[1] - an[1] + po[1]];
        }
    }

    // point on polyline at arc length s (binary search over cum table)
    function pointAtLength(pts, cum, s) {
        var lastIdx = cum.length - 1;
        if (s <= 0) { return [pts[0][0], pts[0][1]]; }
        if (s >= cum[lastIdx]) {
            return [pts[lastIdx][0], pts[lastIdx][1]];
        }
        var lo = 0;
        var hi = lastIdx;
        var mid;
        while (hi - lo > 1) {
            mid = Math.floor((lo + hi) / 2);
            if (cum[mid] <= s) { lo = mid; } else { hi = mid; }
        }
        var segLen = cum[hi] - cum[lo];
        var u = (segLen > 0) ? (s - cum[lo]) / segLen : 0;
        return [pts[lo][0] + (pts[hi][0] - pts[lo][0]) * u,
                pts[lo][1] + (pts[hi][1] - pts[lo][1]) * u];
    }

    // ---------------------------------------------------------------
    // mode 1: live expression on rotation (X/Y)
    //   rotation = axisDisplacement * dir * k / (PI * d) * 360
    //   displacement sampled each frame via valueAtTime (pre-expression),
    //   so easing / any keyframing / even driven motion all roll correctly.
    // ---------------------------------------------------------------

    function buildAxisExpression(axis, dir, k, separated) {
        var L = [];
        L.push("(function () {");
        L.push("    var rollK = " + k + ";");
        L.push("    var rollDir = " + dir + ";");
        L.push("    var rollAxis = " + axis + ";"); // 0 = X, 1 = Y
        if (separated) {
            L.push("    var ap = (rollAxis === 0) ? transform.xPosition : transform.yPosition;");
            L.push("    var refT = (ap.numKeys > 0) ? ap.key(1).time : thisLayer.inPoint;");
            L.push("    var curV = ap.valueAtTime(time, true);");
            L.push("    var refV = ap.valueAtTime(refT, true);");
            L.push("    var disp = curV - refV;");
        } else {
            L.push("    var pp = transform.position;");
            L.push("    var refT = (pp.numKeys > 0) ? pp.key(1).time : thisLayer.inPoint;");
            L.push("    var curV = pp.valueAtTime(time, true);");
            L.push("    var refV = pp.valueAtTime(refT, true);");
            L.push("    var disp = (rollAxis === 0) ? (curV[0] - refV[0]) : (curV[1] - refV[1]);");
        }
        L.push("    var d = 0;");
        L.push("    try { d = sourceRectAtTime(time, false).width; } catch (e1) { d = 0; }");
        L.push("    if (rollAxis === 1) {");
        L.push("        try { d = sourceRectAtTime(time, false).height; } catch (e2) { d = 0; }");
        L.push("    }");
        L.push("    if (!(d > 0)) { d = (rollAxis === 0) ? thisLayer.width : thisLayer.height; }");
        L.push("    return disp * rollDir * rollK / (Math.PI * d) * 360;");
        L.push("})();");
        return L.join("\n");
    }

    function applyExpression(layer, cfg, separated) {
        var rot = layer.transform.rotation;
        clearProp(rot);
        var expr = buildAxisExpression(cfg.axis, cfg.dir, cfg.speed, separated);
        try {
            rot.expression = expr;
        } catch (eExpr) {
            throw new Error("AE rejected the generated expression: " +
                (eExpr.message || eExpr));
        }
    }

    // ---------------------------------------------------------------
    // mode 2: bake rotation keyframes per frame (X/Y)
    // ---------------------------------------------------------------

    function bakeAxisRoll(comp, layer, t1, t2, cfg, separated) {
        var n = frameCount(comp, t1, t2);
        var fD = comp.frameDuration;
        var ap = axisProp(layer, cfg.axis, separated);
        var refV = ap.valueAtTime(t1, true);
        var rot = layer.transform.rotation;
        clearProp(rot);
        var d = layerDiameter(layer, cfg.axis, t1);
        var isVec = (ap.propertyValueType === PropertyValueType.TwoD_SPATIAL ||
                     ap.propertyValueType === PropertyValueType.TwoD);
        var i, t, v, disp;
        for (i = 0; i <= n; i++) {
            t = t1 + i * fD;
            v = ap.valueAtTime(t, true);
            if (isVec) {
                disp = (cfg.axis === 0) ? (v[0] - refV[0]) : (v[1] - refV[1]);
            } else {
                disp = v - refV;
            }
            rot.setValueAtTime(t,
                disp * cfg.dir * cfg.speed / (Math.PI * d) * 360);
        }
        linearize(rot);
    }

    // ---------------------------------------------------------------
    // mode 3: bake along mask path (roller position + rotation per frame)
    //   arc-length odometer with reversal sign: each frame's displacement
    //   is signed by dot(product) with previous displacement, so rolling
    //   forward/backward along the path flips the wheel direction.
    // ---------------------------------------------------------------

    function bakeAlongPath(comp, roller, pathLayer, cfg) {
        // time window: work area, else roller key range, else comp duration
        var t1, t2;
        if (comp.workAreaDuration > 0) {
            t1 = comp.workAreaStart;
            t2 = t1 + comp.workAreaDuration;
        } else {
            var rp = roller.transform.position;
            if (rp.numKeys >= 2) {
                t1 = rp.key(1).time;
                t2 = rp.key(rp.numKeys).time;
            } else {
                t1 = 0;
                t2 = comp.duration;
            }
        }
        if (!(t2 > t1)) {
            throw new Error("Empty time window (set a work area or 2+ position keys).");
        }
        var n = frameCount(comp, t1, t2);
        var fD = comp.frameDuration;

        var shProp = getFirstMaskShapeProp(pathLayer);
        if (!shProp) {
            throw new Error("No mask found on the path layer.");
        }
        if (roller.parent) {
            throw new Error("Roller must not be parented for along-path baking (position is baked in comp space).");
        }
        if (dimensionsSeparated(roller)) {
            throw new Error("Un-separate the roller's dimensions first (Layer > Transform > Separate Dimensions).");
        }

        clearProp(roller.transform.position);
        var rot = roller.transform.rotation;
        clearProp(rot);
        var d = layerDiameter(roller, 0, t1);

        var prevPt = null;
        var prevX = 0;
        var prevY = 0;
        var havePrev = false;
        var acc = 0;
        // static mask path: sample once instead of per frame
        var staticSmp = null;
        try {
            if (shProp.numKeys === 0) {
                staticSmp = sampleShapeAt(shProp, t1, pathLayer);
            }
        } catch (eStat) {
            staticSmp = null;
        }
        var i, t, smp, sTarget, pt;
        for (i = 0; i <= n; i++) {
            t = t1 + i * fD;
            smp = staticSmp;
            if (!smp) { smp = sampleShapeAt(shProp, t, pathLayer); }
            if (!(smp.total > 0)) {
                throw new Error("Mask path has zero arc length.");
            }
            sTarget = smp.total * (i / n);
            pt = pointAtLength(smp.pts, smp.cum, sTarget);
            roller.transform.position.setValueAtTime(t, pt);
            if (i === 0) {
                rot.setValueAtTime(t, 0);
            } else {
                var dx = pt[0] - prevPt[0];
                var dy = pt[1] - prevPt[1];
                var m = Math.sqrt(dx * dx + dy * dy);
                if (m > 0.0001) {
                    var sgn = 1;
                    if (havePrev && (dx * prevX + dy * prevY) < 0) {
                        sgn = -1;
                    }
                    acc += m * sgn;
                    prevX = dx;
                    prevY = dy;
                    havePrev = true;
                }
                rot.setValueAtTime(t,
                    acc * cfg.dir * cfg.speed / (Math.PI * d) * 360);
            }
            prevPt = pt;
        }
        linearize(roller.transform.position);
        linearize(rot);
        // keep baked polyline faithful (no roving shortcuts)
        var posP = roller.transform.position;
        for (i = 1; i <= posP.numKeys; i++) {
            try { posP.setRovingAtKey(i, false); } catch (eRov) { /* ok */ }
        }
    }

    // ---------------------------------------------------------------
    // entry point with guards
    // ---------------------------------------------------------------

    function applyRoll(cfg) {
        if (!app.project) {
            throw new Error("No project open.");
        }
        var comp = app.project.activeItem;
        if (!isComp(comp)) {
            throw new Error("Activate a composition first (click inside its timeline).");
        }
        var sel = comp.selectedLayers;

        if (cfg.axis === 2) {
            // along path: bake only (expression mode is X/Y only)
            if (sel.length !== 2) {
                throw new Error("Along-path mode: select exactly 2 layers (roller + the layer that carries the mask).");
            }
            var m0 = maskCount(sel[0]);
            var m1 = maskCount(sel[1]);
            var roller, pathLayer;
            if (m0 > 0 && m1 === 0) {
                pathLayer = sel[0];
                roller = sel[1];
            } else if (m1 > 0 && m0 === 0) {
                pathLayer = sel[1];
                roller = sel[0];
            } else {
                throw new Error("Exactly ONE of the two selected layers must contain masks (it provides the trajectory).");
            }
            if (roller.locked) { throw new Error("Roller layer is locked."); }
            if (pathLayer.locked) { throw new Error("Path layer is locked."); }
            app.beginUndoGroup(TOOL + ": bake along path");
            try {
                bakeAlongPath(comp, roller, pathLayer, cfg);
            } finally {
                app.endUndoGroup();
            }
            return "baked along path: " + roller.name;
        }

        if (sel.length !== 1) {
            throw new Error("X/Y mode: select exactly 1 layer (with at least 2 Position keyframes).");
        }
        var layer = sel[0];
        if (layer.locked) {
            throw new Error("Layer is locked.");
        }
        var sep = dimensionsSeparated(layer);
        var ap = axisProp(layer, cfg.axis, sep);
        if (!ap) {
            throw new Error("Cannot access the axis property (separated dimensions?).");
        }
        if (ap.numKeys < 2) {
            throw new Error("Need at least 2 keyframes on Position (axis property has " +
                ap.numKeys + ").");
        }
        var range = keyRange(ap);
        if (cfg.mode === "bake") {
            app.beginUndoGroup(TOOL + ": bake roll " + (cfg.axis === 0 ? "X" : "Y"));
            try {
                bakeAxisRoll(comp, layer, range[0], range[1], cfg, sep);
            } finally {
                app.endUndoGroup();
            }
            return "baked roll on " + (cfg.axis === 0 ? "X" : "Y") + ": " + layer.name;
        }
        app.beginUndoGroup(TOOL + ": expression roll " + (cfg.axis === 0 ? "X" : "Y"));
        try {
            applyExpression(layer, cfg, sep);
        } finally {
            app.endUndoGroup();
        }
        return "live expression on " + (cfg.axis === 0 ? "X" : "Y") + ": " + layer.name;
    }

    // ---------------------------------------------------------------
    // UI
    // ---------------------------------------------------------------

    function buildUI(thisObj) {
        var win = (thisObj instanceof Panel)
            ? thisObj
            : new Window("palette", TOOL + " v" + VER, undefined, { resizeable: true });
        win.orientation = "column";
        win.alignChildren = ["fill", "top"];
        win.spacing = 6;
        win.margins = 10;

        var mP = win.add("panel", undefined, "Mode");
        mP.orientation = "row";
        mP.alignChildren = ["left", "center"];
        mP.margins = 8;
        var rbExpr = mP.add("radiobutton", undefined, "Expression (live)");
        var rbBake = mP.add("radiobutton", undefined, "Bake keys");
        rbExpr.value = true;

        var aP = win.add("panel", undefined, "Axis");
        aP.orientation = "row";
        aP.alignChildren = ["left", "center"];
        aP.margins = 8;
        var rbX = aP.add("radiobutton", undefined, "X (ground)");
        var rbY = aP.add("radiobutton", undefined, "Y (wall)");
        var rbPath = aP.add("radiobutton", undefined, "Along mask path");
        rbX.value = true;

        var dP = win.add("panel", undefined, "Direction / speed");
        dP.orientation = "row";
        dP.alignChildren = ["left", "center"];
        dP.margins = 8;
        var rbFwd = dP.add("radiobutton", undefined, "Forward");
        var rbRev = dP.add("radiobutton", undefined, "Reverse");
        rbFwd.value = true;
        dP.add("statictext", undefined, "Speed x");
        var etSpeed = dP.add("edittext", undefined, "1.0");
        etSpeed.characters = 6;

        var btn = win.add("button", undefined, "APPLY ROLL", { name: "ok" });

        var st = win.add("statictext", undefined,
            "X/Y: select 1 layer with 2+ Position keys. " +
            "Path: select roller + a masked layer (bake only, uses work area).");
        st.characters = 64;
        st.multiline = true;

        btn.onClick = function () {
            var cfg = {
                mode: rbExpr.value ? "expr" : "bake",
                axis: rbPath.value ? 2 : (rbY.value ? 1 : 0),
                dir: rbRev.value ? -1 : 1,
                speed: 1
            };
            var sp = parseFloat(etSpeed.text);
            if (isNaN(sp) || !(sp > 0)) { sp = 1; }
            cfg.speed = sp;
            try {
                var msg = applyRoll(cfg);
                st.text = "Done: " + msg;
            } catch (e) {
                alert(TOOL + " error:\n" + (e.message || e));
            }
        };

        win.onResizing = win.onResize = function () {
            this.layout.resize();
        };
        win.layout.layout(true);
        return win;
    }

    var win = buildUI(thisObj);
    if (win instanceof Window) {
        win.center();
        win.show();
    } else {
        win.layout.layout(true);
    }

})(this);
