#target aftereffects

/**************************************************************************
 * Move Anchor Point Clone (jsx edition)  v1.0.0
 * ------------------------------------------------------------------------
 * CLEAN-ROOM REIMPLEMENTATION NOTICE:
 * Written from scratch from the public one-line product description
 * ("snap the anchor point to a corner / edge / centre of a layer while
 * keeping the layer visually still") plus general AE Scripting API
 * knowledge. No original source, installer, binary or resource of the
 * commercial script/plugin was obtained or referenced.
 * ------------------------------------------------------------------------
 * ES3 / ExtendScript only. ASCII-only source on purpose.
 *
 * NON-WHITELISTED APIs USED (declared in README):
 *   Layer.sourceRectAtTime(), Layer.toComp(), Layer.fromComp(),
 *   Property.setValueAtTime() for keyed properties.
 * See README.md section 5 for the documented alternatives.
 **************************************************************************/

(function moveAnchorPointClone(thisObj) {

    var SCRIPT_NAME = "Move Anchor Point Clone";
    var VERSION = "1.0.0";

    /* ==================================================================
     *  Generic helpers
     * ================================================================== */

    function getActiveComp() {
        if (!app.project) { return null; }
        var it = app.project.activeItem;
        if (!it || !(it instanceof CompItem)) { return null; }
        return it;
    }

    function asArray(v) {
        if (v instanceof Array) { return v; }
        return [v];
    }

    function propValue(prop) {
        var v = prop.value;
        return asArray(v);
    }

    // Writes a value to a property, honouring existing keyframes.
    // Returns true when a keyframe had to be used.
    function writeProp(prop, value, time) {
        if (prop.numKeys !== undefined && prop.numKeys > 0) {
            prop.setValueAtTime(time, value);
            return true;
        }
        prop.setValue(value);
        return false;
    }

    // Separated position (X Position / Y Position / Z Position) is a
    // PropertyGroup, not a Property - detect it and refuse.
    function isSeparated(prop) {
        return (prop.numKeys === undefined);
    }

    /* ==================================================================
     *  Core: move the anchor point of one layer
     * ================================================================== */

    // fx, fy in 0..1 select a point inside the layer content rectangle.
    // Returns {ok, message, keyed}
    function moveAnchor(layer, fx, fy, comp) {
        var info = { ok: false, message: "", keyed: false };

        if (isSeparated(layer.position)) {
            info.message = layer.name + ": separated position dimensions are not supported.";
            return info;
        }
        if (isSeparated(layer.anchorPoint)) {
            info.message = layer.name + ": separated anchor point dimensions are not supported.";
            return info;
        }

        var time = comp.time;
        var a0 = propValue(layer.anchorPoint);
        var is3d = (a0.length >= 3);
        var dim = is3d ? 3 : 2;
        var p0 = propValue(layer.position);

        if (p0.length < 2) {
            info.message = layer.name + ": unexpected position value type.";
            return info;
        }

        // Content rectangle in layer space, origin = current anchor point.
        var rect = null;
        try {
            rect = layer.sourceRectAtTime(time, false);
        } catch (eRect) {
            info.message = layer.name + ": sourceRectAtTime unavailable (" + eRect.toString() + ")";
            return info;
        }
        if (!rect || rect.width <= 0 || rect.height <= 0) {
            info.message = layer.name + ": layer has no measurable content bounds.";
            return info;
        }

        var tx = rect.left + fx * rect.width;
        var ty = rect.top + fy * rect.height;

        // New anchor value = old anchor + offset of the target point.
        var a1 = [a0[0] + tx, a0[1] + ty];
        if (is3d) { a1.push(a0[2]); }

        // Comp-space position of the target point BEFORE the move.
        var probeOld = is3d ? [tx, ty, 0] : [tx, ty];
        var compBefore;
        try {
            compBefore = asArray(layer.toComp(probeOld));
        } catch (eTo) {
            info.message = layer.name + ": toComp failed (" + eTo.toString() + ")";
            return info;
        }

        // Apply the new anchor value.
        info.keyed = writeProp(layer.anchorPoint, a1, time) || info.keyed;

        // After the move, the target point IS the layer origin.
        var origin = is3d ? [0, 0, 0] : [0, 0];
        var compAfter;
        try {
            compAfter = asArray(layer.toComp(origin));
        } catch (eTo2) {
            info.message = layer.name + ": toComp failed after anchor move (" + eTo2.toString() + ")";
            return info;
        }

        // Convert the comp-space correction into the property's own space.
        // position lives in the parent layer space (or comp space when the
        // layer has no parent), so reverse that transform explicitly.
        var deltaX = compBefore[0] - compAfter[0];
        var deltaY = compBefore[1] - compAfter[1];
        var deltaZ = 0;
        if (is3d) {
            deltaZ = (compBefore[2] || 0) - (compAfter[2] || 0);
        }

        if (layer.parent) {
            var pb = null;
            var pa = null;
            try {
                pb = asArray(layer.parent.fromComp(is3d ? [compBefore[0], compBefore[1], compBefore[2] || 0]
                    : [compBefore[0], compBefore[1]]));
                pa = asArray(layer.parent.fromComp(is3d ? [compAfter[0], compAfter[1], compAfter[2] || 0]
                    : [compAfter[0], compAfter[1]]));
            } catch (eFrom) {
                info.message = layer.name + ": parent.fromComp failed (" + eFrom.toString() + ")";
                return info;
            }
            deltaX = pb[0] - pa[0];
            deltaY = pb[1] - pa[1];
            if (is3d) { deltaZ = (pb[2] || 0) - (pa[2] || 0); }
        }

        var p1 = [p0[0] + deltaX, p0[1] + deltaY];
        if (is3d) { p1.push((p0[2] || 0) + deltaZ); }

        info.keyed = writeProp(layer.position, p1, time) || info.keyed;

        info.ok = true;
        info.message = layer.name + ": anchor moved" + (info.keyed ? " (keyframes written at current time)" : "");
        return info;
    }

    /* ==================================================================
     *  Batch
     * ================================================================== */

    function moveAnchorBatch(comp, layers, fx, fy) {
        var result = { moved: 0, failed: 0, log: "", keyed: 0 };
        var i;

        if (!layers || layers.length === 0) {
            result.log = "No layer selected.";
            return result;
        }

        app.beginUndoGroup(SCRIPT_NAME + " - move anchor point");
        try {
            for (i = 0; i < layers.length; i++) {
                var r;
                try {
                    r = moveAnchor(layers[i], fx, fy, comp);
                } catch (err) {
                    r = { ok: false, message: layers[i].name + ": " + err.toString(), keyed: false };
                }
                if (r.ok) {
                    result.moved++;
                    if (r.keyed) { result.keyed++; }
                } else {
                    result.failed++;
                    result.log += (result.log === "" ? "" : "\n") + r.message;
                }
            }
        } finally {
            app.endUndoGroup();
        }
        return result;
    }

    /* ==================================================================
     *  UI
     * ================================================================== */

    var GRID_POS = [
        [0, 0], [0.5, 0], [1, 0],
        [0, 0.5], [0.5, 0.5], [1, 0.5],
        [0, 1], [0.5, 1], [1, 1]
    ];

    function buildUI(thisObj) {
        var pal = (thisObj instanceof Panel) ? thisObj :
            new Window("palette", SCRIPT_NAME + " " + VERSION, undefined, { resizeable: true });
        pal.orientation = "column";
        pal.alignChildren = ["fill", "top"];
        pal.spacing = 8;
        pal.margins = 12;

        var info = pal.add("statictext", undefined, "Select layers, then click a target position.", { multiline: true });
        info.preferredSize.width = 320;

        var grid = pal.add("panel", undefined, "Anchor target (layer content bounds)");
        grid.orientation = "column";
        grid.alignChildren = ["fill", "top"];
        grid.margins = 8;
        grid.spacing = 3;

        var cells = [];
        var r;
        var c;
        for (r = 0; r < 3; r++) {
            var line = grid.add("group");
            line.alignment = ["fill", "top"];
            line.spacing = 3;
            for (c = 0; c < 3; c++) {
                var idx = r * 3 + c;
                var b = line.add("button", undefined, GRID_POS[idx][0] + "," + GRID_POS[idx][1]);
                b.preferredSize = [96, 26];
                (function (button, fx, fy) {
                    button.onClick = function () {
                        run(fx, fy);
                    };
                })(b, GRID_POS[idx][0], GRID_POS[idx][1]);
                cells.push(b);
            }
        }

        var customBox = pal.add("panel", undefined, "Custom position (0..1 of content bounds)");
        customBox.orientation = "row";
        customBox.alignChildren = ["left", "center"];
        customBox.margins = 8;
        customBox.spacing = 6;
        customBox.add("statictext", undefined, "X:");
        var edX = customBox.add("edittext", undefined, "0.5");
        edX.characters = 5;
        customBox.add("statictext", undefined, "Y:");
        var edY = customBox.add("edittext", undefined, "0.5");
        edY.characters = 5;
        var btnCustom = customBox.add("button", undefined, "Apply");
        btnCustom.preferredSize.width = 70;

        var status = pal.add("statictext", undefined, "Ready.", { multiline: true });
        status.preferredSize.width = 320;

        function run(fx, fy) {
            var comp = getActiveComp();
            if (!comp) {
                status.text = "Open a composition first.";
                return;
            }
            var layers = comp.selectedLayers;
            if (!layers || layers.length === 0) {
                status.text = "Select at least one layer in the timeline.";
                return;
            }
            var res = moveAnchorBatch(comp, layers, fx, fy);
            var msg = "Moved " + res.moved + ", failed " + res.failed + ".";
            if (res.keyed > 0) {
                msg += "\n" + res.keyed + " layer(s) had keyframes - anchors/positions were keyed at the current time.";
            }
            if (res.log !== "") { msg += "\n" + res.log; }
            status.text = msg;
        }

        btnCustom.onClick = function () {
            var fx = parseFloat(edX.text);
            var fy = parseFloat(edY.text);
            if (isNaN(fx) || isNaN(fy)) {
                status.text = "Custom X/Y must be numbers.";
                return;
            }
            run(fx, fy);
        };

        pal.onResizing = pal.onResize = function () { this.layout.resize(); };
        return pal;
    }

    var ui = buildUI(thisObj);
    if (ui instanceof Window) {
        ui.center();
        ui.show();
    } else {
        ui.layout.layout(true);
    }

})(this);
