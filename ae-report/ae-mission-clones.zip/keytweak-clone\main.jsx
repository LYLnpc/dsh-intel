﻿#target aftereffects
/**
 * ============================================================================
 *  KeyTweak Clone —— 关键帧时间编辑/重定时工具的 clean-room 复刻实现
 * ============================================================================
 *
 *  [CLEAN-ROOM 声明]
 *  本脚本依据功能需求描述（intel/paid-list.md 第 11 条 "KeyTweak"）从零独立
 *  编写。编写过程中未反编译原插件，未阅读、复制或改写原插件的任何源代码、
 *  字节码或资源文件；仅依赖 Adobe After Effects 公开脚本 API（docsforadobe
 *  官方指南镜像核实版，见 docs/api-cheatsheet.md 白名单）与需求文档。与原
 *  产品的相似性仅来自功能需求本身。仅供学习研究；KeyTweak 商标与著作权归
 *  mamoworld（Mathias Möhl）所有，需完整功能请购买正版（aescripts.com，
 *  $5.99 NYOP）。
 *
 *  功能概述（本次基线 = 关键帧时间维度批量编辑，作用于选中属性的关键帧）：
 *    1. 等距重排——选中的关键帧在首尾跨度内均匀重分布；
 *    2. 时间缩放——整体拉伸/压缩指定倍数，以第一个选中关键帧为锚；
 *    3. 时间偏移——整体平移 N 帧（可负）；
 *    4. 对齐——吸附到帧边界 / 首键对齐到指定时间。
 *    每个操作：读出关键帧的值/插值/时间缓动/空间切线/各开关 → 倒序 removeKey
 *    删除选中键 → 按新时间正序 setValueAtTime 重插 → 按序回填全部属性。
 *
 *  API 名一律照 docs/api-cheatsheet.md 白名单书写（keyInTemporalEase/
 *  keyOutTemporalEase/removeKey/PropertyValueType.OneD 混合大小写等）。
 *
 *  ExtendScript / ES3 兼容：无 let/const/箭头函数/模板字符串/JSON/ES5 数组方法。
 * ============================================================================
 */

(function (ktThisObj) {

    var KT_NAME = "KeyTweak Clone";
    var KT_VER = "1.0.0";
    var KT_SECTION = "keyTweakClone";
    var KT_MIN_GAP = 0.0001;      // 重排后相邻键最小间隔（秒），防键重叠/覆盖
    var KT_EPS = 0.000001;        // 时间相等判定阈值

    /* ======================================================================
     *  设置持久化（app.settings 白名单用法：getHavingSaved 返回布尔，
     *  值经 getSetting 读取；写入用 saveSetting）
     * ==================================================================== */

    function ktLoadSetting(key, fallback) {
        try {
            if (app.settings.getHavingSaved(KT_SECTION, key)) {
                return app.settings.getSetting(KT_SECTION, key);
            }
        } catch (e1) { /* 缺失或异常 */ }
        return fallback;
    }

    function ktSaveSetting(key, value) {
        try { app.settings.saveSetting(KT_SECTION, key, value); } catch (e1) {}
        try { app.settings.saveToDisk(); } catch (e2) {}
    }

    /* ======================================================================
     *  ES3 基础工具
     * ==================================================================== */

    function ktNum(s, fallback) {
        var v = parseFloat(s);
        if (isNaN(v)) { return fallback; }
        return v;
    }

    function ktFmt(x) {
        return "" + (Math.round(x * 1000) / 1000);
    }

    // 带异常回退的属性读取（缓动/切线/开关在部分属性类型上会抛异常）
    function ktTry(fn) {
        try { return fn(); } catch (e) { return undefined; }
    }

    /* ======================================================================
     *  选中关键帧快照：读出全部可保留属性（值/插值/缓动/切线/开关）
     * ==================================================================== */

    function ktIsSpatial(prop) {
        var vt = prop.propertyValueType;
        return vt === PropertyValueType.TwoD_SPATIAL || vt === PropertyValueType.ThreeD_SPATIAL;
    }

    function ktSnapshot(prop) {
        var keys = prop.selectedKeys;
        var indices = [];
        var i;
        for (i = 0; i < keys.length; i++) { indices.push(keys[i]); }
        indices.sort(function (a, b) { return a - b; }); // ES3 无默认数值比较
        var items = [];
        var spatial = ktIsSpatial(prop);
        for (i = 0; i < indices.length; i++) {
            var idx = indices[i];
            items.push({
                idx: idx,
                t: prop.keyTime(idx),
                v: prop.keyValue(idx),
                inT: ktTry(function () { return prop.keyInInterpolationType(idx); }),
                outT: ktTry(function () { return prop.keyOutInterpolationType(idx); }),
                inE: ktTry(function () { return prop.keyInTemporalEase(idx); }),
                outE: ktTry(function () { return prop.keyOutTemporalEase(idx); }),
                spatial: spatial,
                inS: spatial ? ktTry(function () { return prop.keyInSpatialTangent(idx); }) : undefined,
                outS: spatial ? ktTry(function () { return prop.keyOutSpatialTangent(idx); }) : undefined,
                rov: ktTry(function () { return prop.keyRoving(idx); }),
                tAB: ktTry(function () { return prop.keyTemporalAutoBezier(idx); }),
                tC: ktTry(function () { return prop.keyTemporalContinuous(idx); }),
                sAB: spatial ? ktTry(function () { return prop.keySpatialAutoBezier(idx); }) : undefined,
                sC: spatial ? ktTry(function () { return prop.keySpatialContinuous(idx); }) : undefined
            });
        }
        return { indices: indices, items: items };
    }

    // 倒序删除选中关键帧（保证剩余键索引不失效；removeKey 为官方唯一删键方法）
    function ktDeleteSelected(prop, indices) {
        var i;
        for (i = indices.length - 1; i >= 0; i--) {
            prop.removeKey(indices[i]);
        }
    }

    // 某时刻是否已存在键（含未选中的既有键）；返回索引或 -1
    function ktKeyAtTime(prop, t) {
        try {
            var ni = prop.nearestKeyIndex(t);
            if (Math.abs(prop.keyTime(ni) - t) < KT_EPS) { return ni; }
        } catch (e1) { /* 无关键帧等情形 */ }
        return -1;
    }

    // 正序插入一个键：避让既有键 → 写值 → 回填插值/缓动/切线/开关
    function ktInsert(prop, t, item, minGap) {
        var guard = 0;
        while (ktKeyAtTime(prop, t) >= 0 && guard < 10) {
            t = t + minGap; // 落点撞上未选中的既有键时微移，避免覆盖它
            guard++;
        }
        prop.setValueAtTime(t, item.v);
        var ni = prop.nearestKeyIndex(t);
        try { prop.setInterpolationTypeAtKey(ni, item.inT, item.outT); } catch (e1) {}
        try {
            if (item.inE !== undefined && item.outE !== undefined) {
                prop.setTemporalEaseAtKey(ni, item.inE, item.outE);
            }
        } catch (e2) {} // HOLD 键等情形 AE 会拒绝，跳过
        try {
            if (item.spatial && item.inS !== undefined && item.outS !== undefined) {
                prop.setSpatialTangentsAtKey(ni, item.inS, item.outS);
            }
        } catch (e3) {}
        try { if (item.rov === true) { prop.setRovingAtKey(ni, true); } } catch (e4) {}
        try { if (item.tAB === true) { prop.setTemporalAutoBezierAtKey(ni, true); } } catch (e5) {}
        try { if (item.tC === true) { prop.setTemporalContinuousAtKey(ni, true); } } catch (e6) {}
        try { if (item.sAB === true) { prop.setSpatialAutoBezierAtKey(ni, true); } } catch (e7) {}
        try { if (item.sC === true) { prop.setSpatialContinuousAtKey(ni, true); } } catch (e8) {}
        return t;
    }

    // 公共管线：新时间序列 → 相邻键强制最小间隔 → 倒序删除 → 正序插入
    function ktTransform(prop, snap, newTimes) {
        var i;
        for (i = 1; i < newTimes.length; i++) {
            if (newTimes[i] < newTimes[i - 1] + KT_MIN_GAP) {
                newTimes[i] = newTimes[i - 1] + KT_MIN_GAP;
            }
        }
        ktDeleteSelected(prop, snap.indices);
        var written = 0;
        for (i = 0; i < newTimes.length; i++) {
            ktInsert(prop, newTimes[i], snap.items[i], KT_MIN_GAP);
            written++;
        }
        return written;
    }

    /* ======================================================================
     *  选中属性收集与主流程
     * ==================================================================== */

    function ktGetComp() {
        var it = (app.project != null) ? app.project.activeItem : null;
        if (it != null && it instanceof CompItem) { return it; }
        return null;
    }

    function ktCollectProps(comp) {
        var out = [];
        var sel = comp.selectedProperties;
        if (sel == null) { return out; }
        for (var i = 0; i < sel.length; i++) {
            var p = sel[i];
            try {
                // PropertyGroup 的 numKeys 为 undefined，比较自然过滤掉非叶子属性
                if (p.numKeys > 0 && p.selectedKeys.length > 0) { out.push(p); }
            } catch (e) {}
        }
        return out;
    }

    // op(prop, snap) -> 新时间数组（与 snap.items 等长）；返回 null 表示该属性跳过
    function ktRunOp(op, statusText, opName) {
        var comp = ktGetComp();
        if (comp === null) {
            alert("请先激活一个合成。", KT_NAME);
            return;
        }
        var props = ktCollectProps(comp);
        if (props.length === 0) {
            alert("请先在时间线中选中属性下的关键帧（选中属性的关键帧，而非仅图层）。", KT_NAME);
            return;
        }
        var touched = 0;
        var moved = 0;
        var skipped = 0;
        app.beginUndoGroup(KT_NAME + ": " + opName);
        try {
            for (var pi = 0; pi < props.length; pi++) {
                var prop = props[pi];
                var snap = ktSnapshot(prop);
                var newTimes = op(prop, snap);
                if (newTimes === null) { skipped++; continue; }
                moved += ktTransform(prop, snap, newTimes);
                touched++;
            }
        } finally {
            app.endUndoGroup();
        }
        statusText.text = opName + "：处理 " + touched + " 个属性 / 移动 " + moved +
            " 个关键帧" + (skipped > 0 ? "（跳过 " + skipped + " 个属性：选中键不足或跨度为 0）" : "");
    }

    /* ======================================================================
     *  四个时间编辑操作
     * ==================================================================== */

    // 1) 等距重排：首尾选中关键帧之间均匀重分布
    function ktOpEven(prop, snap) {
        var n = snap.items.length;
        if (n < 2) { return null; }
        var t0 = snap.items[0].t;
        var t1 = snap.items[n - 1].t;
        if (!(t1 - t0 > 0)) { return null; }
        var newTimes = [];
        for (var i = 0; i < n; i++) {
            newTimes.push(t0 + (t1 - t0) * i / (n - 1));
        }
        return newTimes;
    }

    // 2) 时间缩放：以第一个选中关键帧为锚，整体 ×factor
    function ktOpScale(factor) {
        return function (prop, snap) {
            if (snap.items.length < 1) { return null; }
            var t0 = snap.items[0].t;
            var newTimes = [];
            for (var i = 0; i < snap.items.length; i++) {
                newTimes.push(t0 + (snap.items[i].t - t0) * factor);
            }
            return newTimes;
        };
    }

    // 3) 时间偏移：整体平移 frames 帧（可负）
    function ktOpOffset(frames) {
        return function (comp, prop, snap) {
            var fd = comp.frameDuration;
            if (!(fd > 0)) { return null; }
            var newTimes = [];
            for (var i = 0; i < snap.items.length; i++) {
                newTimes.push(snap.items[i].t + frames * fd);
            }
            return newTimes;
        };
    }

    // 4) 对齐：mode 0 = 吸附到最近帧边界；mode 1 = 首键对齐到目标时间（组内相对间隔不变）
    function ktOpAlign(comp, mode, targetTime) {
        return function (prop, snap) {
            if (snap.items.length < 1) { return null; }
            var newTimes = [];
            var i;
            if (mode === 0) {
                var fd = comp.frameDuration;
                if (!(fd > 0)) { return null; }
                for (i = 0; i < snap.items.length; i++) {
                    newTimes.push(Math.round(snap.items[i].t / fd) * fd);
                }
            } else {
                var delta = targetTime - snap.items[0].t;
                for (i = 0; i < snap.items.length; i++) {
                    newTimes.push(snap.items[i].t + delta);
                }
            }
            return newTimes;
        };
    }

    /* ======================================================================
     *  UI（ScriptUI 面板，四工具区，ES3）
     * ==================================================================== */

    function ktBuildUI(thisObj) {
        var win = (thisObj instanceof Panel) ? thisObj :
            new Window("palette", KT_NAME + " v" + KT_VER, undefined, { resizeable: true });
        win.orientation = "column";
        win.alignChildren = ["fill", "top"];
        win.spacing = 6;
        win.margins = 12;

        win.add("statictext", undefined, KT_NAME + " v" + KT_VER + "（clean-room）");

        // ---- 区 1：等距重排 ----
        var p1 = win.add("panel", undefined, "1. 等距重排");
        p1.orientation = "row";
        p1.alignChildren = ["left", "center"];
        p1.margins = [10, 6, 10, 6];
        var btnEven = p1.add("button", undefined, "均匀重分布");
        btnEven.preferredSize.width = 110;
        p1.add("statictext", undefined, "在首尾选中关键帧之间均匀分布");

        // ---- 区 2：时间缩放 ----
        var p2 = win.add("panel", undefined, "2. 时间缩放");
        p2.orientation = "row";
        p2.alignChildren = ["left", "center"];
        p2.margins = [10, 6, 10, 6];
        p2.add("statictext", undefined, "倍数:");
        var eScale = p2.add("edittext", undefined, "1.00");
        eScale.characters = 7;
        var btnScale = p2.add("button", undefined, "应用缩放");
        btnScale.preferredSize.width = 90;
        p2.add("statictext", undefined, "以第一个选中关键帧为锚");

        // ---- 区 3：时间偏移 ----
        var p3 = win.add("panel", undefined, "3. 时间偏移");
        p3.orientation = "row";
        p3.alignChildren = ["left", "center"];
        p3.margins = [10, 6, 10, 6];
        p3.add("statictext", undefined, "帧数:");
        var eOffset = p3.add("edittext", undefined, "0");
        eOffset.characters = 7;
        var btnOffset = p3.add("button", undefined, "应用偏移");
        btnOffset.preferredSize.width = 90;
        p3.add("statictext", undefined, "正=后移 负=前移");

        // ---- 区 4：对齐 ----
        var p4 = win.add("panel", undefined, "4. 对齐");
        p4.orientation = "column";
        p4.alignChildren = ["left", "top"];
        p4.margins = [10, 6, 10, 6];
        p4.spacing = 4;
        var g4a = p4.add("group");
        g4a.orientation = "row";
        g4a.alignChildren = ["left", "center"];
        g4a.add("statictext", undefined, "模式:");
        var ddAlign = g4a.add("dropdownlist", undefined, ["吸附到帧边界", "首键对齐到目标时间"]);
        ddAlign.selection = 0;
        var g4b = p4.add("group");
        g4b.orientation = "row";
        g4b.alignChildren = ["left", "center"];
        g4b.add("statictext", undefined, "目标时间(秒):");
        var eTarget = g4b.add("edittext", undefined, "0.00");
        eTarget.characters = 8;
        var btnAlign = g4b.add("button", undefined, "应用对齐");
        btnAlign.preferredSize.width = 90;

        var status = win.add("statictext", undefined, KT_NAME + " v" + KT_VER + " 就绪。", { multiline: true });
        status.preferredSize = [330, 34];

        // 恢复上次参数
        try {
            eScale.text = ktLoadSetting("scale", "1.00");
            eOffset.text = ktLoadSetting("offset", "0");
            var savedMode = ktNum(ktLoadSetting("alignMode", "0"), 0);
            if (savedMode === 1) { ddAlign.selection = 1; }
            eTarget.text = ktLoadSetting("alignTarget", "0.00");
        } catch (eS) {}

        function runOp(opName, opFn) {
            try {
                ktRunOp(opFn, status, opName);
            } catch (eX) {
                alert("操作失败：" + eX.toString(), KT_NAME);
            }
        }

        btnEven.onClick = function () {
            runOp("等距重排", function (prop, snap) { return ktOpEven(prop, snap); });
        };

        btnScale.onClick = function () {
            var factor = ktNum(eScale.text, NaN);
            if (!(factor > 0)) {
                alert("倍数必须是大于 0 的数字（不支持负数/0，反向请用关键帧辅助工具）。", KT_NAME);
                return;
            }
            ktSaveSetting("scale", eScale.text);
            var op = ktOpScale(factor);
            runOp("时间缩放 ×" + ktFmt(factor), function (prop, snap) { return op(prop, snap); });
        };

        btnOffset.onClick = function () {
            var frames = ktNum(eOffset.text, NaN);
            if (isNaN(frames)) {
                alert("帧数必须是数字（可为负）。", KT_NAME);
                return;
            }
            ktSaveSetting("offset", eOffset.text);
            var comp = ktGetComp();
            if (comp === null) { alert("请先激活一个合成。", KT_NAME); return; }
            var op = ktOpOffset(frames);
            runOp("时间偏移 " + frames + " 帧", function (prop, snap) { return op(comp, prop, snap); });
        };

        btnAlign.onClick = function () {
            var mode = (ddAlign.selection !== null) ? ddAlign.selection.index : 0;
            var targetTime = 0;
            if (mode === 1) {
                targetTime = ktNum(eTarget.text, NaN);
                if (isNaN(targetTime)) {
                    alert("目标时间必须是数字（单位：秒）。", KT_NAME);
                    return;
                }
            }
            ktSaveSetting("alignMode", "" + mode);
            ktSaveSetting("alignTarget", eTarget.text);
            var comp = ktGetComp();
            if (comp === null) { alert("请先激活一个合成。", KT_NAME); return; }
            var op = ktOpAlign(comp, mode, targetTime);
            runOp(mode === 0 ? "对齐-吸附帧边界" : "对齐-首键至 " + ktFmt(targetTime) + "s",
                function (prop, snap) { return op(prop, snap); });
        };

        win.onResizing = win.onResize = function () {
            this.layout.resize();
        };

        if (win instanceof Window) {
            win.center();
            win.show();
        } else {
            win.layout.layout(true);
            win.layout.resize();
        }
        return win;
    }

    function ktMain() {
        if (typeof app === "undefined" || app.project == null) {
            alert("请先打开一个 After Effects 工程。", KT_NAME);
            return;
        }
        ktBuildUI(ktThisObj);
    }

    ktMain();

})(this);
