/**
 * M2 Clone (clean-room) -- core toolset inspired by the Motion 2 feature set.
 *
 * CLEAN-ROOM NOTICE:
 *   This file was written from a written feature description only
 *   (intel/paid-list.md, entry "Motion 2"). No decompilation, no original
 *   source code, no original resources were used or inspected. All math,
 *   code structure, naming and expressions below are original work.
 *
 * Features (3 functional zones):
 *   1. Smart Anchor Move  -- move a layer's anchor to a 3x3 grid target
 *      (corners / edge midpoints / center of the layer bounding box) while
 *      compensating position so the on-screen content does not move.
 *      Math: for each position keyframe time t, keep the comp-space location
 *      P of the old anchor constant: P = toComp(oldAnchor, t), then after
 *      setting the new anchor set position(t) = fromComp(P, t). This is
 *      exact under any parent / rotation / scale chain (2D layers).
 *   2. Keyframe Direction Tools -- read the velocity vector at the active
 *      keyframe span via velocityAtTime() and attach an expression to
 *      rotation (face motion direction) or to scale (speed-based squash /
 *      stretch with volume preservation).
 *   3. One-click Spring Presets -- attach a decaying-sinusoid post
 *      expression (elastic / bounce / pendulum) driven by the velocity at
 *      the nearest previous keyframe; amplitude / frequency / decay are
 *      user adjustable from the panel.
 *
 * Target: Adobe After Effects (ExtendScript / ES3). Run via
 *   File > Scripts > Run Script File...  (or dockable via ScriptUI Panels).
 */

(function M2Clone(thisObj) {

    var SCRIPT_NAME = 'M2 Clone (clean-room)';
    var SCRIPT_VER = '0.1.0';

    var DECLAIMER = 'Clean-room reimplementation. Written from a feature list only. No original Motion 2 code used.';

    // Squash/stretch tuning constants (kept simple on purpose).
    var SQUASH_GAIN = 0.06;   // speed -> stretch factor
    var SQUASH_MAX = 60;      // max stretch percent

    // ------------------------------------------------------------------
    // small utils
    // ------------------------------------------------------------------

    function num(v, fallback) {
        var x = parseFloat(v, 10);
        return isNaN(x) ? fallback : x;
    }

    function f4(x) {
        // ES3-safe fixed formatting (4 decimals, no trailing garbage)
        var s = (Math.round(x * 10000) / 10000).toString();
        return s;
    }

    function getComp() {
        var it = app.project ? app.project.activeItem : null;
        if (it && it instanceof CompItem) { return it; }
        return null;
    }

    function tf(layer) {
        return layer.property('ADBE Transform Group');
    }

    function isTransformable(layer) {
        if (layer instanceof CameraLayer || layer instanceof LightLayer) { return false; }
        return true;
    }

    // ------------------------------------------------------------------
    // Zone 1: smart anchor move
    // ------------------------------------------------------------------

    // bounding box in layer space: [left, top, width, height]
    function layerBox(layer, t) {
        var r = null;
        try { r = layer.sourceRectAtTime(t, false); } catch (err) { r = null; }
        if (r && r.width > 0 && r.height > 0) { return [r.left, r.top, r.width, r.height]; }
        if (layer.width && layer.height && layer.width > 0 && layer.height > 0) {
            return [0, 0, layer.width, layer.height];
        }
        return null;
    }

    // 3x3 grid target in layer space
    function targetPoint(box, mode) {
        var l = box[0], t = box[1], w = box[2], h = box[3];
        var mx = l + w / 2, my = t + h / 2, rx = l + w, by = t + h;
        if (mode === 'tl') { return [l, t]; }
        if (mode === 'tc') { return [mx, t]; }
        if (mode === 'tr') { return [rx, t]; }
        if (mode === 'ml') { return [l, my]; }
        if (mode === 'mc') { return [mx, my]; }
        if (mode === 'mr') { return [rx, my]; }
        if (mode === 'bl') { return [l, by]; }
        if (mode === 'bc') { return [mx, by]; }
        return [rx, by]; // 'br'
    }

    function moveAnchor(layers, mode, statusText) {
        var comp = getComp();
        if (!comp) { alert('Open a composition first.'); return; }
        var t = comp.time;
        var done = 0;
        var skipped = [];
        app.beginUndoGroup('M2Clone: move anchor');
        var i, k, L, ap, pos, box, oldA, target;
        var times, pts;
        for (i = 0; i < layers.length; i++) {
            L = layers[i];
            if (!isTransformable(L)) { skipped.push(L.name + ' (camera/light)'); continue; }
            if (L.threeDLayer) { skipped.push(L.name + ' (3D)'); continue; }
            ap = tf(L).property('ADBE Anchor Point');
            pos = tf(L).property('ADBE Position');
            if (!ap || !pos) { continue; }
            if (ap.numKeys > 0) { skipped.push(L.name + ' (animated anchor)'); continue; }
            box = layerBox(L, t);
            if (!box) { skipped.push(L.name + ' (no size)'); continue; }
            oldA = ap.value;
            target = targetPoint(box, mode);

            // snapshot: comp-space point that must stay fixed, per time
            times = [];
            pts = [];
            if (pos.numKeys > 0) {
                for (k = 1; k <= pos.numKeys; k++) {
                    times.push(pos.key(k).time);
                    pts.push(L.toComp(oldA, times[k - 1]));
                }
            } else {
                times.push(null);
                pts.push(L.toComp(oldA));
            }

            ap.setValue(target);

            // restore the same comp-space point through position:
            // position(t) = fromComp(P, t)  (handles parent/rotation/scale)
            if (pos.numKeys > 0) {
                for (k = 0; k < times.length; k++) {
                    pos.setValueAtTime(times[k], L.fromComp(pts[k], times[k]));
                }
            } else {
                pos.setValue(L.fromComp(pts[0]));
            }
            done++;
        }
        app.endUndoGroup();
        statusText.text = 'Anchor moved on ' + done + ' layer(s)' +
            (skipped.length ? ' | skipped: ' + skipped.join(', ') : '');
    }

    // ------------------------------------------------------------------
    // Zone 2: keyframe direction tools
    // ------------------------------------------------------------------

    function dirCoreExpr(lines) {
        // shared prologue: pick nearest key span midpoint velocity
        return lines.join('\n');
    }

    function buildRotationExpr() {
        return dirCoreExpr([
            '// M2Clone clean-room: rotate to motion direction',
            'var p = transform.position;',
            'var out = value;',
            'if (p.numKeys > 1) {',
            '    var n = p.nearestKey(time).index;',
            '    if (p.key(n).time > time && n > 1) { n = n - 1; }',
            '    var t0 = p.key(n).time;',
            '    var tm = (n < p.numKeys) ? (t0 + p.key(n + 1).time) / 2 : t0;',
            '    var v = p.velocityAtTime(tm);',
            '    var spd = Math.sqrt(v[0] * v[0] + v[1] * v[1]);',
            '    if (spd > 0.01) { out = radiansToDegrees(Math.atan2(v[1], v[0])); }',
            '}',
            'out;'
        ]);
    }

    function buildSquashExpr(gain, maxPct) {
        return dirCoreExpr([
            '// M2Clone clean-room: speed-based squash & stretch (x-stretch)',
            'var p = transform.position;',
            'var out = value;',
            'if (p.numKeys > 1) {',
            '    var n = p.nearestKey(time).index;',
            '    if (p.key(n).time > time && n > 1) { n = n - 1; }',
            '    var t0 = p.key(n).time;',
            '    var tm = (n < p.numKeys) ? (t0 + p.key(n + 1).time) / 2 : t0;',
            '    var v = p.velocityAtTime(tm);',
            '    var spd = Math.sqrt(v[0] * v[0] + v[1] * v[1]);',
            '    var k = Math.min(spd * ' + f4(gain) + ', ' + f4(maxPct) + ') / 100;',
            '    out = [value[0] * (1 + k), value[1] / (1 + k)];',
            '}',
            'out;'
        ]);
    }

    function applyDirection(layers, kind, statusText) {
        var comp = getComp();
        if (!comp) { alert('Open a composition first.'); return; }
        if (!layers || layers.length === 0) {
            statusText.text = 'No layers selected. Select layer(s) first.';
            return;
        }
        var done = 0;
        var skipped = [];
        var expr = (kind === 'rotation') ? buildRotationExpr() : buildSquashExpr(SQUASH_GAIN, SQUASH_MAX);
        app.beginUndoGroup('M2Clone: direction ' + kind);
        var i, L, r, s;
        for (i = 0; i < layers.length; i++) {
            L = layers[i];
            if (!isTransformable(L)) { skipped.push(L.name); continue; }
            if (L.threeDLayer) { skipped.push(L.name + ' (3D)'); continue; }
            if (kind === 'rotation') {
                r = tf(L).property('ADBE Rotate Z');
                if (!r) { skipped.push(L.name); continue; }
                r.expression = expr;
            } else {
                s = tf(L).property('ADBE Scale');
                if (!s) { skipped.push(L.name); continue; }
                s.expression = expr;
            }
            done++;
        }
        app.endUndoGroup();
        statusText.text = kind + ' direction expression on ' + done + ' layer(s)' +
            (skipped.length ? ' | skipped: ' + skipped.join(', ') : '');
    }

    // ------------------------------------------------------------------
    // Zone 3: spring presets (elastic / bounce / pendulum)
    // ------------------------------------------------------------------

    function buildPresetExpr(mode, amp, freq, decay) {
        var A = f4(amp), F = f4(freq), D = f4(decay);
        var head = [
            '// M2Clone clean-room spring preset: ' + mode,
            'var A = ' + A + ', F = ' + F + ', D = ' + D + ';',
            'var n = 0;',
            'if (numKeys > 0) {',
            '    n = nearestKey(time).index;',
            '    if (key(n).time > time) { n = n - 1; }',
            '}',
            'var out = value;'
        ];
        if (mode === 'pendulum') {
            // fixed-amplitude decaying swing (good for rotation, degrees)
            return head.concat([
                'if (n > 0) {',
                '    var t = time - key(n).time;',
                '    var o = A * Math.sin(F * t * 2 * Math.PI) / Math.exp(D * t);',
                '    if (value.length === 2) { out = [value[0] + o, value[1] + o]; }',
                '    else { out = value + o; }',
                '}',
                'out;'
            ]).join('\n');
        }
        // velocity-driven variants
        var core = [
            'if (n > 0) {',
            '    var t = time - key(n).time;',
            '    var fd = thisComp.frameDuration;',
            '    var V = velocityAtTime(key(n).time - fd / 10);',
            '    var s = Math.sin(F * t * 2 * Math.PI) / Math.exp(D * t);'
        ];
        if (mode === 'elastic') {
            core.push('    out = value + V * A * s;');
        } else { // bounce: one-sided rebounds via abs(sin)
            core.push('    var b = Math.abs(Math.sin(F * t * Math.PI)) / Math.exp(D * t);');
            core.push('    out = value + V * A * b;');
        }
        core.push('}');
        core.push('out;');
        return head.concat(core).join('\n');
    }

    function collectTargetProps(comp, layers) {
        var out = [];
        var sel = comp.selectedProperties;
        var i, p, L;
        if (sel && sel.length > 0) {
            for (i = 0; i < sel.length; i++) {
                p = sel[i];
                if (String(p.propertyType) === 'PROPERTY' && p.numKeys > 0) { out.push(p); }
            }
        }
        if (out.length === 0 && layers && layers.length > 0) {
            for (i = 0; i < layers.length; i++) {
                L = layers[i];
                if (!isTransformable(L)) { continue; }
                p = tf(L).property('ADBE Position');
                if (p && p.numKeys > 0) { out.push(p); }
            }
        }
        return out;
    }

    function applyPreset(comp, layers, mode, amp, freq, decay, statusText) {
        if (!comp) { alert('Open a composition first.'); return; }
        var props = collectTargetProps(comp, layers);
        if (props.length === 0) {
            statusText.text = 'No keyframed property selected (select keys or layers).';
            return;
        }
        var expr = buildPresetExpr(mode, amp, freq, decay);
        app.beginUndoGroup('M2Clone: preset ' + mode);
        var i;
        for (i = 0; i < props.length; i++) {
            props[i].expression = expr;
        }
        app.endUndoGroup();
        statusText.text = mode + ' preset on ' + props.length + ' propert(y/ies) | A=' +
            f4(amp) + ' F=' + f4(freq) + ' D=' + f4(decay);
    }

    // ------------------------------------------------------------------
    // UI
    // ------------------------------------------------------------------

    function buildUI(thisObj) {
        var win = (thisObj instanceof Panel) ? thisObj : new Window('palette', SCRIPT_NAME, undefined, { resizeable: true });
        win.orientation = 'column';
        win.alignChildren = ['fill', 'top'];
        win.spacing = 6;
        win.margins = 10;

        var decl = win.add('statictext', undefined, DECLAIMER, { truncate: true });
        decl.maximumSize.width = 420;

        // ---- zone 1: anchor move (3x3 grid) ----
        var p1 = win.add('panel', undefined, '1. Smart Anchor Move (content stays put)');
        p1.orientation = 'column';
        p1.alignChildren = ['center', 'top'];
        p1.margins = 10;
        var gridRows = [
            ['tl', 'tc', 'tr'],
            ['ml', 'mc', 'mr'],
            ['bl', 'bc', 'br']
        ];
        var gridLabels = {
            tl: 'TL', tc: 'TC', tr: 'TR',
            ml: 'ML', mc: 'C', mr: 'MR',
            bl: 'BL', bc: 'BC', br: 'BR'
        };
        var rowG, ci, rj, btn;
        for (rj = 0; rj < gridRows.length; rj++) {
            rowG = p1.add('group');
            rowG.orientation = 'row';
            rowG.spacing = 3;
            for (ci = 0; ci < gridRows[rj].length; ci++) {
                btn = rowG.add('button', undefined, gridLabels[gridRows[rj][ci]]);
                btn.preferredSize = [42, 26];
                btn.mode = gridRows[rj][ci];
                btn.onClick = (function (b) {
                    return function () {
                        var comp = getComp();
                        if (comp) { moveAnchor(comp.selectedLayers, b.mode, win.statusTxt); }
                    };
                })(btn);
            }
        }
        p1.add('statictext', undefined, 'Select layer(s), click a grid point.');

        // ---- zone 2: direction tools ----
        var p2 = win.add('panel', undefined, '2. Keyframe Direction Tools');
        p2.orientation = 'row';
        p2.alignChildren = ['center', 'top'];
        p2.margins = 10;
        p2.spacing = 6;
        var bRot = p2.add('button', undefined, 'Dir > Rotation');
        bRot.preferredSize = [110, 26];
        bRot.onClick = function () {
            var comp = getComp();
            if (comp) { applyDirection(comp.selectedLayers, 'rotation', win.statusTxt); }
        };
        var bSq = p2.add('button', undefined, 'Speed > Squash');
        bSq.preferredSize = [110, 26];
        bSq.onClick = function () {
            var comp = getComp();
            if (comp) { applyDirection(comp.selectedLayers, 'squash', win.statusTxt); }
        };
        p2.add('statictext', undefined, 'needs keyframed position');

        // ---- zone 3: spring presets ----
        var p3 = win.add('panel', undefined, '3. Spring Presets (post expression)');
        p3.orientation = 'column';
        p3.alignChildren = ['fill', 'top'];
        p3.margins = 10;
        var rowA = p3.add('group');
        rowA.orientation = 'row';
        rowA.spacing = 5;
        rowA.add('statictext', undefined, 'mode');
        var ddl = rowA.add('dropdownlist', undefined, ['elastic', 'bounce', 'pendulum']);
        ddl.selection = 0;
        rowA.add('statictext', undefined, 'amp');
        var eAmp = rowA.add('edittext', undefined, '0.03');
        eAmp.characters = 6;
        rowA.add('statictext', undefined, 'freq');
        var eFreq = rowA.add('edittext', undefined, '2.5');
        eFreq.characters = 5;
        rowA.add('statictext', undefined, 'decay');
        var eDecay = rowA.add('edittext', undefined, '5');
        eDecay.characters = 5;

        var rowB = p3.add('group');
        rowB.orientation = 'row';
        rowB.spacing = 5;
        var bApply = rowB.add('button', undefined, 'Apply to selected keyframes');
        bApply.preferredSize = [220, 28];
        p3.add('statictext', undefined, 'pendulum amp: 1 unit = 1000 degrees (0.02 = 20 deg)');

        bApply.onClick = function () {
            var comp = getComp();
            if (!comp) { alert('Open a composition first.'); return; }
            applyPreset(
                comp,
                comp.selectedLayers,
                ddl.selection ? ddl.selection.text : 'elastic',
                num(eAmp.text, 0.03),
                num(eFreq.text, 2.5),
                num(eDecay.text, 5),
                win.statusTxt
            );
        };

        // ---- status ----
        win.statusTxt = win.add('statictext', undefined, SCRIPT_NAME + ' v' + SCRIPT_VER + ' ready.');
        win.statusTxt.maximumSize.width = 420;

        win.layout.layout(true);
        win.layout.resize();
        win.onResizing = win.onResize = function () { this.layout.resize(); };
        return win;
    }

    buildUI(thisObj);

})(this);
