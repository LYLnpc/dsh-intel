---
generated_at: 2026-11-14T08:30:00+08:00
task: 自主选件 clean-room 复刻 Parrot（aescripts, Mike Overbeck, $29.99）核心功能——图层动画接力/延迟复现；输入 = intel/paid-list.md 第 13 条功能性描述，不反编译不参考原代码
---

# Parrot Clone（动画接力/延迟复现 · clean-room 复刻）

- 产出：`main.jsx`（ExtendScript，ES3）
- **选件理由**（自主选件任务）：① paid-list 前 15 个 A 类条目中未被任何 clone 覆盖（17 个现有目录无 parrot）；② 功能域独特——"把一个图层的动画接力到其他图层（follow-through/延迟复现）"，与已有 clone（flow/easecopy=缓动、autosway/wobblebox 域=弹簧、rubberhose=IK、rowscols=排列）零重叠；③ 复刻要点在 paid-list 中明确（"表达式 valueAtTime(t-offset) 链式采样 + 值域重映射"），纯 jsx 可实现；④ 剩余时间预算内可完成。
- 输入依据：`intel/paid-list.md` 第 13 条 Parrot（$29.99，Mike Overbeck）功能性描述："把一个图层的动画'接力'到其他图层（follow-through/延迟复现），参数包括延迟帧数、值偏移、时间偏移、接力次数"
- API 全部取自 `docs/api-cheatsheet.md` 白名单（`Property.valueAtTime(time, preExpression)`、`ADBE Rotate Z`、`comp.frameRate` 均 `[官方核实]`）

## CLEAN-ROOM 声明

1. 本复刻为清室实现：未反编译、未阅读、未复制 Parrot 的任何原始代码；仅依据公开的功能性描述与 AE 公开脚本 API 从零编写。
2. 仅供学习研究；Parrot 商标与著作权归原作者所有，需要完整功能请购买正版。

## 功能对照（复刻范围）

| Parrot 功能点（paid-list 描述） | 本复刻状态 | 说明 |
|---|---|---|
| 把图层 A 的动画"接力"到其他图层（延迟复现） | ✅ 已复刻 | 驱动层 = 选中第 1 个（时间线最上），其余为接力层；接力层写入 `valueAtTime(time - delaySec)` 采样表达式 |
| 延迟帧数 | ✅ | 每级延迟帧数；换算为秒后以字面量写进表达式（Node 验证 3 帧@25fps=0.12s 精确采样） |
| 接力次数 | ✅ | 接力次数 0 = 全部后续层；>0 只处理前 N 个接力层 |
| 值偏移 | ✅ | Position 模式偏移 X/Y（3D 保留 z）；Rotation 模式角度偏移 |
| 时间偏移 | ✅（合并实现） | 延迟本身即时间偏移；"逐级递增"关闭时为固定延迟（等效全局时间偏移） |
| 逐级递增（follow-through 链） | ✅ | 勾选后第 k 级接力层延迟 = k × 每级帧数；链式场景（接力层驱动接力层）延迟自然逐级叠加（Node 验证总延迟=各级之和） |
| 值域重映射 | ⚠️ 简化 | 仅平移偏移（加法），无缩放重映射（原版可能有范围映射，描述未细述） |
| 应用属性 | ✅ | Position（2D/3D）/ Rotation 二选一；其余属性（scale 等）未覆盖 |
| 随机化/衰减 | ❌ 未复刻 | paid-list 未细述，不在基线 |

## 安装

`main.jsx` 放入 ScriptUI Panels 目录重启 AE 从 Window 菜单打开（可停靠），或 `File > Scripts > Run Script File...` 直接运行。

## 使用

1. 时间线**先选驱动层**（动画源），**再加选接力层**（顺序即接力顺序）。
2. 面板设置：应用属性（Position/Rotation）、延迟帧数、是否逐级递增、接力次数（0=全部）、值偏移。
3. 点 **Relay 接力**：为每个接力层写入采样表达式（undo 组包裹）；**Clear 清除**可清掉选中层 position/rotation 的表达式。
4. 效果：驱动层动画整体延迟 N 帧在接力层复现（follow-through 甩尾感）；值偏移让接力层错位跟随。
5. 链式接力：把接力层再当驱动层对下一批使用 Relay（valueAtTime 默认取表达式计算后的值，延迟自动逐级叠加）。

## 自查记录（2026-11-14）

1. `node --check`：通过；ES3 扫描（排除注释行）：零命中。
2. **表达式逐字执行验证**：Node 从 main.jsx `PARROT-EXPR-START/END` 标记块提取模板函数，生成表达式字符串后**以桩对象实际执行**（driver.position(t)=[100t,50t] 线性轨迹），7 项断言 ALL PASS：
   - T1 位置接力：t=1.0、延迟 0.4s、偏移(10,-5) → 精确等于 driver(0.6)+偏移 = [70,25]
   - T2 3D 位置保留 z 分量
   - T3 旋转接力：90×(2−0.2)+15 = 177
   - T4 延迟字面量换算：3 帧@25fps = 0.12s，t=1.12 精确采样 driver(1.0)
   - T5 链式接力：两级 0.4s 接力总延迟 0.8s（1.6 → driver(0.8) = [80,0]）
   - T6 驱动层名含双引号时转义仍正确解析
3. API 对照：`valueAtTime`、`ADBE Rotate Z`、`frameRate`、`duplicate` 未用、`escName` 转义等全部核对 cheatsheet 白名单。

## 限制（如实说明）

1. **未在 AE 实机测试**：需实机验证表达式写入（尤其旧 JS 引擎下 `valueAtTime` 对带表达式驱动层的递归求值性能）。
2. 仅支持 Position/Rotation 两个属性（Scale/Opacity 等未覆盖）；值域重映射仅平移偏移。
3. 有父级的接力层在 Position 模式下被跳过（采样值是合成坐标，父层坐标系下直接写会错位）；Rotation 模式不检查父级（角度叠加语义，用户自行判断）。
4. 驱动层重命名会使接力层表达式断链（`thisComp.layer("名字")` 按名引用）；Clear 后重跑即可重建。
5. 接力层自身若有关键帧动画会被表达式接管（表达式优先级高于关键帧），Clear 前原关键帧仍在但不起作用。
6. 延迟秒数字面量四舍五入到 1e-6 秒（防表达式浮点噪声），25fps 下 3 帧 = 0.12s 精确。

## 交叉评审记录（review-4，2026-11-14）

- 已修复 1：`escName` 未转义反斜杠（层名含 `\` 会生成非法表达式字面量）；现先转义 `\` 再转义 `"`。
- 已修复 2：延迟原以脚本侧当前 frameRate 换算成秒常数写入表达式——合成帧率日后改动即失准；现嵌入 `帧数 × thisComp.frameDuration` 活动计算（PARROT-EXPR 模板块已更新，Node 提取自查需按新模板重跑）。
- 已修复 3：Clear 原来无条件清空选中层 position/rotation 表达式，会误删用户自写表达式；现只清除含 `Parrot Clone (clean-room)` 标记的本工具表达式。
- 已修复 4：UI 提示与实现矛盾（提示"先选驱动层"暗示点击顺序，代码却按时间线 index 排序）；提示改为"最上层选中层=驱动层"，与 cheatsheet"选中顺序无文档保证"一致。
- 加固：ScriptUI PenType 着色两处包 try/catch（graphics API 非速查表范围，宿主异常不再崩面板）。
