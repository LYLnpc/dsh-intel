﻿#target aftereffects
/**
 * ============================================================================
 *  Ease Stash Clone —— 缓动预设收藏管理器的 clean-room 复刻实现
 * ============================================================================
 *
 *  [CLEAN-ROOM 声明]
 *  本脚本依据功能需求描述（intel/paid-list.md 第 19 条 "Ease Stash" 的公开
 *  一句话简介，细节为推断展开，见 README）从零独立编写。编写过程中未反编译
 *  原插件，未阅读、复制或改写原插件的任何源代码、字节码或资源文件；仅依赖
 *  Adobe After Effects 公开脚本 API（docs/api-cheatsheet.md 白名单）与需求
 *  文档。与原产品的相似性仅来自功能需求本身。仅供学习研究；Ease Stash 商标
 *  与著作权归 null1 lab 所有，需完整功能请购买正版（aescripts.com，$35）。
 *
 *  功能概述：
 *    - Stash：读取选中关键帧的 keyInTemporalEase/keyOutTemporalEase（取第一个
 *      选中属性的第一个选中键），存为命名预设；
 *    - 持久化：写入脚本同目录 presets.json（自产严格格式 + 魔数头，解析仅用
 *      eval 处理本工具自产文件——ExtendScript 无 JSON 对象，见 README 安全说明）；
 *    - Apply：从预设下拉选择 → 对全部选中属性的全部选中关键帧
 *      setTemporalEaseAtKey 回写（维度适配：目标 1D 取预设第一维；目标多维时
 *      逐维映射、缺失维回退预设末维；单维预设复制到目标全部维）；
 *    - 倍率滑杆：应用时对 speed 与 influence 同乘倍率（influence 钳制
 *      [0.1, 100]，AE 合法范围）；
 *    - UI：预设下拉 + 名称输入 + Stash/Apply/Delete + 倍率滑杆 + 预设信息行。
 *
 *  API 名一律照 docs/api-cheatsheet.md 白名单（keyInTemporalEase/
 *  keyOutTemporalEase/setTemporalEaseAtKey/removeKey/PropertyValueType.OneD
 *  混合大小写/app.settings 两段式）。
 *
 *  ExtendScript / ES3 兼容：无 let/const/箭头函数/模板字符串/JSON 对象/ES5
 *  数组方法。
 * ============================================================================
 */

(function (estThisObj) {

    var EST_NAME = "Ease Stash Clone";
    var EST_VER = "1.0.0";
    var EST_MAGIC = "EASESTASH_V1";
    var EST_MULT_MIN = 0.2;
    var EST_MULT_MAX = 3.0;
    var EST_SECTION = "easeStashClone";

    /* ======================================================================
     *  ES3 基础工具
     * ==================================================================== */

    function estClamp(v, lo, hi) {
        if (v < lo) { return lo; }
        if (v > hi) { return hi; }
        return v;
    }

    function estNum(s, fallback) {
        var v = parseFloat(s);
        if (isNaN(v)) { return fallback; }
        return v;
    }

    function estFmt(x) {
        return "" + (Math.round(x * 1000) / 1000);
    }

    // 序列化用数字清洗：非有限值一律归 0（自产文件不写入 NaN/Infinity）
    function estSafeNum(x) {
        var n = Number(x);
        if (!isFinite(n)) { n = 0; }
        n = Math.round(n * 10000) / 10000;
        if (!isFinite(n)) { n = 0; }
        return n;
    }

    // 预设名转义：反斜杠/引号/换行——保证 eval 只见到合法字符串字面量
    function estEsc(s) {
        var t = String(s);
        t = t.replace(/\\/g, "\\\\");
        t = t.replace(/"/g, "\\\"");
        t = t.replace(/\r/g, " ");
        t = t.replace(/\n/g, " ");
        return t;
    }

    /* ======================================================================
     *  持久化：presets.json（脚本同目录优先，任务指定目录兜底）
     *  ExtendScript 无 JSON 对象——写入自产严格格式，解析仅 eval 本工具
     *  自产文件（魔数校验 + 结构清洗，见 README 安全说明）
     * ==================================================================== */

    function estPresetFile() {
        var dirs = [];
        try {
            var sf = new File($.fileName);
            if (sf != null && sf.exists) { dirs.push(sf.parent); }
        } catch (e0) { /* 无脚本路径上下文 */ }
        dirs.push(new Folder("C:/Users/19894/ae-mission/clones/easestash-clone"));
        for (var i = 0; i < dirs.length; i++) {
            var f = new File(dirs[i].fsName + "/presets.json");
            if (f.exists) { return f; }          // 已有库存文件优先
        }
        if (dirs.length > 0) {
            return new File(dirs[0].fsName + "/presets.json"); // 否则用首选目录
        }
        return null;
    }

    function estSerialize(presets) {
        var rows = [];
        for (var i = 0; i < presets.length; i++) {
            var p = presets[i];
            var inParts = [];
            var outParts = [];
            var d;
            for (d = 0; d < p.inE.length; d++) {
                inParts.push("{s:" + estSafeNum(p.inE[d].s) + ",i:" + estSafeNum(p.inE[d].i) + "}");
            }
            for (d = 0; d < p.outE.length; d++) {
                outParts.push("{s:" + estSafeNum(p.outE[d].s) + ",i:" + estSafeNum(p.outE[d].i) + "}");
            }
            rows.push('{name:"' + estEsc(p.name) + '",from:"' + estEsc(p.from) +
                '",dims:' + Math.floor(p.dims) +
                ',inE:[' + inParts.join(",") + '],outE:[' + outParts.join(",") + ']}');
        }
        var L = [];
        L.push(EST_MAGIC);
        L.push("({v:1,presets:[");
        L.push(rows.join(",\n")); // 预设行之间必须有逗号（round-trip 实测抓过的 bug）
        L.push("]})");
        return L.join("\n");
    }

    // eval 后的条目清洗：逐字段类型校验，任一字段不合法即弃置该条
    function estSanitize(p) {
        if (p == null || typeof p !== "object") { return null; }
        var name = (typeof p.name === "string" && p.name !== "") ? p.name : "未命名";
        var from = (typeof p.from === "string") ? p.from : "";
        var dims = (typeof p.dims === "number" && p.dims >= 1 && isFinite(p.dims)) ? Math.floor(p.dims) : 0;
        if (dims < 1 || dims > 8) { return null; }
        function sanitizeEase(arr) {
            if (arr == null || typeof arr.length !== "number") { return null; }
            var out = [];
            for (var i = 0; i < arr.length; i++) {
                var e = arr[i];
                if (e == null || typeof e !== "object") { return null; }
                var s = Number(e.s);
                var infl = Number(e.i);
                if (!isFinite(s) || !isFinite(infl)) { return null; }
                out.push({ s: s, i: estClamp(infl, 0.1, 100) });
            }
            return out;
        }
        var inE = sanitizeEase(p.inE);
        var outE = sanitizeEase(p.outE);
        if (inE === null || outE === null) { return null; }
        if (inE.length !== dims || outE.length !== dims) { return null; }
        return { name: name, from: from, dims: dims, inE: inE, outE: outE };
    }

    function estParse(text) {
        var out = [];
        try {
            if (text == null) { return out; }
            if (text.charCodeAt(0) === 0xFEFF) { text = text.substring(1); } // 剥离 UTF-8 BOM
            if (text.substring(0, EST_MAGIC.length) !== EST_MAGIC) { return out; } // 魔数不符
            var nl = text.indexOf("\n");
            if (nl < 0) { return out; }
            if (text.length - nl > 262144) { return out; } // 体积上限 256KB，防异常文件
            var obj = eval(text.substring(nl + 1));
            if (obj == null || typeof obj !== "object" || obj.presets == null ||
                typeof obj.presets.length !== "number") { return out; }
            for (var i = 0; i < obj.presets.length; i++) {
                var p = estSanitize(obj.presets[i]);
                if (p !== null) { out.push(p); }
            }
        } catch (e1) {
            return [];
        }
        return out;
    }

    function estLoad() {
        var f = estPresetFile();
        if (f === null || !f.exists) { return []; }
        var text = "";
        try {
            f.encoding = "UTF-8";
            f.open("r");
            text = f.read();
            f.close();
        } catch (e1) {
            try { f.close(); } catch (e2) {}
            return [];
        }
        return estParse(text);
    }

    function estSave(presets) {
        var f = estPresetFile();
        if (f === null) { return false; }
        try {
            f.encoding = "UTF-8";
            f.open("w");
            f.write(estSerialize(presets));
            f.close();
            return true;
        } catch (e1) {
            try { f.close(); } catch (e2) {}
            return false;
        }
    }

    /* ======================================================================
     *  选中属性收集（与速查表一致：selectedProperties 0-based、
     *  selectedKeys 1-based 索引需自定义数值排序）
     * ==================================================================== */

    function estCollectProps(comp) {
        var out = [];
        var sel = comp.selectedProperties;
        if (sel == null) { return out; }
        for (var i = 0; i < sel.length; i++) {
            var p = sel[i];
            try {
                // PropertyGroup 的 numKeys 为 undefined，比较自然过滤非叶子属性
                if (p.numKeys > 0 && p.selectedKeys.length > 0) { out.push(p); }
            } catch (e) {}
        }
        return out;
    }

    // 目标维度：优先回读该键现有 ease 数组长度（官方约定 TwoD/ThreeD→2/3，
    // OneD/COLOR 等→1）；读不到再按 propertyValueType 回退
    function estDimsOf(prop, idx) {
        try {
            var arr = prop.keyInTemporalEase(idx);
            if (arr != null && arr.length > 0) { return arr.length; }
        } catch (e1) {}
        if (prop.propertyValueType === PropertyValueType.OneD) { return 1; }
        return 2;
    }

    /* ======================================================================
     *  维度适配映射：
     *    目标 1D → 取预设第一维（任务指定规则）
     *    单维预设 → 复制到目标全部维
     *    多维 → 逐维映射，缺失维回退预设末维
     *  倍率：speed 与 influence 同乘 mult（influence 钳制 [0.1, 100]）
     * ==================================================================== */

    function estMapEase(srcArr, tgtDims, mult) {
        var m = srcArr.length;
        var out = [];
        for (var d = 0; d < tgtDims; d++) {
            var src = (m === 1) ? srcArr[0] : srcArr[Math.min(d, m - 1)];
            out.push(new KeyframeEase(src.s * mult, estClamp(src.i * mult, 0.1, 100)));
        }
        return out;
    }

    /* ======================================================================
     *  Stash / Apply
     * ==================================================================== */

    function estStash(ui, presets) {
        var comp = app.project ? app.project.activeItem : null;
        if (comp === null || !(comp instanceof CompItem)) {
            alert("请先激活一个合成。", EST_NAME);
            return false;
        }
        var props = estCollectProps(comp);
        if (props.length === 0) {
            alert("请先在时间线中选中属性下的关键帧（选中属性的关键帧，而非仅图层）。", EST_NAME);
            return false;
        }
        // 取第一个选中属性的第一个选中键（按索引升序）
        var prop = props[0];
        var keys = prop.selectedKeys;
        var minIdx = keys[0];
        for (var i = 1; i < keys.length; i++) {
            if (keys[i] < minIdx) { minIdx = keys[i]; }
        }
        var dims = estDimsOf(prop, minIdx);
        var inArr = [];
        var outArr = [];
        try {
            var rawIn = prop.keyInTemporalEase(minIdx);
            var rawOut = prop.keyOutTemporalEase(minIdx);
            if (rawIn == null || rawOut == null || rawIn.length < 1 || rawOut.length < 1) {
                throw new Error("缓动读取为空");
            }
            for (var d = 0; d < dims; d++) {
                inArr.push({ s: estSafeNum(rawIn[d].speed), i: estSafeNum(rawIn[d].influence) });
                outArr.push({ s: estSafeNum(rawOut[d].speed), i: estSafeNum(rawOut[d].influence) });
            }
        } catch (e1) {
            alert("读取缓动失败：" + e1.toString(), EST_NAME);
            return false;
        }
        // 命名：输入框优先；为空则自动 "预设 N"
        var name = String(ui.nameEdit.text);
        if (name === "") { name = "预设 " + (presets.length + 1); }
        // 同名覆盖（更新已有条目）
        var replaced = -1;
        for (var r = 0; r < presets.length; r++) {
            if (presets[r].name === name) { replaced = r; break; }
        }
        var preset = { name: name, from: prop.name, dims: dims, inE: inArr, outE: outArr };
        if (replaced >= 0) { presets[replaced] = preset; } else { presets.push(preset); }
        if (!estSave(presets)) {
            alert("presets.json 写入失败（目录只读？），预设仅本次会话有效。", EST_NAME);
        }
        estRebuildList(ui, presets, name);
        ui.statusText.text = "已收存「" + name + "」：" + dims + " 维（来源属性：" + prop.name +
            "，键 #" + minIdx + "）" + (replaced >= 0 ? "——同名条目已更新" : "");
        return true;
    }

    function estApply(ui, presets) {
        var sel = (ui.dd.selection !== null) ? ddIndex(ui.dd) : -1;
        if (sel < 0 || sel >= presets.length) {
            alert("请先在预设下拉中选择一条预设。", EST_NAME);
            return;
        }
        var preset = presets[sel];
        var comp = app.project ? app.project.activeItem : null;
        if (comp === null || !(comp instanceof CompItem)) {
            alert("请先激活一个合成。", EST_NAME);
            return;
        }
        var props = estCollectProps(comp);
        if (props.length === 0) {
            alert("请先在时间线中选中属性下的关键帧（选中属性的关键帧，而非仅图层）。", EST_NAME);
            return;
        }
        var mult = estNum(ui.multEdit.text, 1);
        mult = estClamp(mult, EST_MULT_MIN, EST_MULT_MAX);
        var applied = 0;
        var skipped = 0;
        var errors = 0;
        var lastErr = "";
        app.beginUndoGroup(EST_NAME + ": 应用「" + preset.name + "」");
        try {
            for (var pi = 0; pi < props.length; pi++) {
                var prop = props[pi];
                var keys = prop.selectedKeys;
                var idxArr = [];
                for (var ki = 0; ki < keys.length; ki++) { idxArr.push(keys[ki]); }
                idxArr.sort(function (a, b) { return a - b; });
                for (var ii = 0; ii < idxArr.length; ii++) {
                    var idx = idxArr[ii];
                    try {
                        var tDims = estDimsOf(prop, idx);
                        var inArr = estMapEase(preset.inE, tDims, mult);
                        var outArr = estMapEase(preset.outE, tDims, mult);
                        prop.setTemporalEaseAtKey(idx, inArr, outArr);
                        applied++;
                    } catch (eK) {
                        // HOLD 键等 AE 拒绝写缓动的情形
                        errors++;
                        lastErr = eK.toString();
                    }
                }
            }
        } finally {
            app.endUndoGroup();
        }
        var msg = "「" + preset.name + "」×" + estFmt(mult) + "：应用 " + applied + " 个关键帧";
        if (skipped > 0) { msg += "，跳过 " + skipped; }
        if (errors > 0) { msg += "，错误 " + errors + "（" + lastErr + "）"; }
        ui.statusText.text = msg;
        if (errors > 0) { alert(msg, EST_NAME); }
    }

    function ddIndex(dd) {
        return dd.selection.index;
    }

    /* ======================================================================
     *  UI（ScriptUI 面板，ES3）
     * ==================================================================== */

    function estPresetInfo(p) {
        if (p == null) { return ""; }
        var s = p.name + "（" + p.dims + " 维";
        if (p.from !== "") { s += "，来源：" + p.from; }
        s += "）| in spd " + estFmt(p.inE[0].s) + " inf " + estFmt(p.inE[0].i) +
            " | out spd " + estFmt(p.outE[0].s) + " inf " + estFmt(p.outE[0].i);
        if (p.dims > 1) { s += "（其余维未展示）"; }
        return s;
    }

    function estRebuildList(ui, presets, selectName) {
        ui.dd.removeAll();
        for (var i = 0; i < presets.length; i++) {
            ui.dd.add("item", presets[i].name);
        }
        var sel = -1;
        if (selectName != null) {
            for (var j = 0; j < presets.length; j++) {
                if (presets[j].name === selectName) { sel = j; break; }
            }
        }
        if (sel < 0 && presets.length > 0) { sel = 0; }
        if (sel >= 0 && ui.dd.items.length > sel) { ui.dd.selection = sel; }
        estUpdateInfo(ui, presets);
    }

    function estUpdateInfo(ui, presets) {
        var sel = (ui.dd.selection !== null) ? ui.dd.selection.index : -1;
        if (sel < 0 || sel >= presets.length) {
            ui.infoText.text = "（库为空：先用 Stash 收存一条缓动）";
            return;
        }
        ui.infoText.text = estPresetInfo(presets[sel]);
    }

    function estBuildUI(thisObj) {
        var win = (thisObj instanceof Panel) ? thisObj :
            new Window("palette", EST_NAME + " v" + EST_VER, undefined, { resizeable: true });
        win.orientation = "column";
        win.alignChildren = ["fill", "top"];
        win.spacing = 6;
        win.margins = 12;

        win.add("statictext", undefined, EST_NAME + " v" + EST_VER + "（clean-room）");

        var presets = [];
        try { presets = estLoad(); } catch (eL) { presets = []; }

        // 预设列表
        var g1 = win.add("group");
        g1.orientation = "row";
        g1.alignChildren = ["left", "center"];
        g1.add("statictext", undefined, "预设:");
        var dd = g1.add("dropdownlist");
        dd.preferredSize.width = 190;
        var btnRefresh = g1.add("button", undefined, "刷新");
        btnRefresh.preferredSize.width = 44;
        btnRefresh.helpTip = "重新从 presets.json 读取（外部改动后用）";

        // 名称
        var g2 = win.add("group");
        g2.orientation = "row";
        g2.alignChildren = ["left", "center"];
        g2.add("statictext", undefined, "名称:");
        var nameEdit = g2.add("edittext");
        nameEdit.characters = 22;
        nameEdit.helpTip = "Stash 的命名；与现有预设同名时更新该条";

        // 倍率
        var g3 = win.add("group");
        g3.orientation = "row";
        g3.alignChildren = ["left", "center"];
        g3.add("statictext", undefined, "倍率:");
        var sMult = g3.add("slider", undefined, 100, 20, 300);
        sMult.preferredSize.width = 130;
        var multEdit = g3.add("edittext", undefined, "1.00");
        multEdit.characters = 6;
        multEdit.helpTip = "应用时 speed 与 influence 同乘倍率（influence 钳制 0.1–100）";

        // 按钮行
        var g4 = win.add("group");
        g4.orientation = "row";
        g4.alignment = ["fill", "top"];
        var btnStash = g4.add("button", undefined, "Stash 收存");
        var btnApply = g4.add("button", undefined, "Apply 应用", { name: "ok" });
        var btnDel = g4.add("button", undefined, "Delete 删除");

        var infoText = win.add("statictext", undefined, "", { multiline: true });
        infoText.preferredSize = [330, 28];
        var statusText = win.add("statictext", undefined, "就绪。选中关键帧后 Stash 收存 / Apply 应用。", { multiline: true });
        statusText.preferredSize = [330, 34];

        // 恢复上次倍率（仅一个短字符串，app.settings 无长度压力）
        try {
            if (app.settings.getHavingSaved(EST_SECTION, "mult")) {
                multEdit.text = app.settings.getSetting(EST_SECTION, "mult");
            }
        } catch (eM) {}
        try {
            var m0 = estClamp(estNum(multEdit.text, 1), EST_MULT_MIN, EST_MULT_MAX);
            sMult.value = m0 * 100;
            multEdit.text = m0.toFixed(2);
        } catch (eM2) {}

        var ui = {
            win: win, dd: dd, nameEdit: nameEdit, multEdit: multEdit,
            infoText: infoText, statusText: statusText
        };

        // 滑杆与输入框联动
        sMult.onChanging = function () {
            try { multEdit.text = (this.value / 100).toFixed(2); } catch (e1) {}
        };
        sMult.onChange = function () {
            try { multEdit.text = (this.value / 100).toFixed(2); } catch (e2) {}
        };
        multEdit.onChange = function () {
            try {
                var v = estClamp(estNum(multEdit.text, 1), EST_MULT_MIN, EST_MULT_MAX);
                sMult.value = v * 100;
                multEdit.text = v.toFixed(2);
                try { app.settings.saveSetting(EST_SECTION, "mult", v.toFixed(2)); } catch (e3) {}
            } catch (e4) {}
        };

        dd.onChange = function () {
            // 选中预设时把名称回填输入框（便于同名覆盖更新）
            var sel = (this.selection !== null) ? this.selection.index : -1;
            if (sel >= 0 && sel < presets.length) {
                nameEdit.text = presets[sel].name;
            }
            estUpdateInfo(ui, presets);
        };

        btnRefresh.onClick = function () {
            try { presets = estLoad(); } catch (eR) { presets = []; }
            estRebuildList(ui, presets, null);
            statusText.text = "已刷新：从 presets.json 读到 " + presets.length + " 条预设。";
        };

        btnStash.onClick = function () {
            try {
                estStash(ui, presets);
            } catch (eS) {
                alert("收存失败：" + eS.toString(), EST_NAME);
            }
        };

        btnApply.onClick = function () {
            try {
                estApply(ui, presets);
            } catch (eA) {
                alert("应用失败：" + eA.toString(), EST_NAME);
            }
        };

        btnDel.onClick = function () {
            var sel = (dd.selection !== null) ? dd.selection.index : -1;
            if (sel < 0 || sel >= presets.length) {
                alert("请先在下拉中选择要删除的预设。", EST_NAME);
                return;
            }
            var gone = presets[sel].name;
            presets.splice(sel, 1);
            if (!estSave(presets)) {
                alert("presets.json 写入失败，删除未持久化。", EST_NAME);
            }
            estRebuildList(ui, presets, null);
            statusText.text = "已删除「" + gone + "」，剩余 " + presets.length + " 条。";
        };

        estRebuildList(ui, presets, null);

        win.onResizing = win.onResize = function () {
            this.layout.resize();
        };

        if (win instanceof Window) {
            win.center();
            win.show();
        } else {
            win.layout.layout(true);
            win.layout.resize();
        }
        return win;
    }

    function estMain() {
        if (typeof app === "undefined" || app.project == null) {
            alert("请先打开一个 After Effects 工程。", EST_NAME);
            return;
        }
        estBuildUI(estThisObj);
    }

    estMain();

})(this);
