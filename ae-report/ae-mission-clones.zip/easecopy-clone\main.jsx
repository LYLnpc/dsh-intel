#target aftereffects

/**************************************************************************
 * EaseCopy Clone  v1.0.0  (ExtendScript .jsx for Adobe After Effects)
 * ------------------------------------------------------------------------
 * CLEAN-ROOM REIMPLEMENTATION NOTICE:
 * This script was written from scratch based ONLY on the publicly available
 * feature description of the commercial After Effects script "EaseCopy"
 * (aescripts.com / mikeoverbeck.com) plus a written feature baseline.
 * No original EaseCopy source code, installer, binary, or resources were
 * obtained, inspected, decompiled or referenced in any way. Any resemblance
 * in UI wording beyond generic terms (copy / paste / ease) is coincidental
 * or derived solely from public marketing descriptions. Written for study
 * and interoperability purposes.
 * ------------------------------------------------------------------------
 * ES3 / ExtendScript only: no let/const, no arrow functions, no
 * JSON.stringify, no ES5+ array extras (map/filter/forEach/indexOf...).
 * File is intentionally ASCII-only (ExtendScript reads non-BOM files in
 * the system codepage, which would garble non-ASCII text).
 **************************************************************************/

(function easeCopyClone(thisObj) {

    var SCRIPT_NAME = "EaseCopy Clone";
    var SCRIPT_VERSION = "1.0.0";
    var MAX_SLOTS = 4;

    // ------------------------------------------------------------------
    // In-memory slot storage. Cleared when the panel closes / AE quits
    // (no cross-session persistence is implemented - see README.md).
    // ------------------------------------------------------------------
    var easeSlots = [null, null, null, null]; // one ease slot object or null
    var animSlot = null;                      // whole-animation slot object or null
    var slotRows = [];                        // UI row references for status text
    var animInfo = null;                      // UI status text for animation slot

    // Interpolation enum snapshots (evaluated inside AE, safe).
    var KIT_LINEAR = KeyframeInterpolationType.LINEAR;
    var KIT_BEZIER = KeyframeInterpolationType.BEZIER;
    var KIT_HOLD = KeyframeInterpolationType.HOLD;

    /* ==================================================================
     *  Selection helpers
     * ================================================================== */

    function getActiveComp() {
        if (!app.project) { return null; }
        var item = app.project.activeItem;
        if (item === null || item === undefined) { return null; }
        if (!(item instanceof CompItem)) { return null; }
        return item;
    }

    // PropertyGroup objects have no numKeys attribute (undefined), so this
    // also filters groups out of comp.selectedProperties.
    function isPropertyWithKeys(p) {
        if (p === null || p === undefined) { return false; }
        if (p.numKeys === undefined) { return false; }
        return p.numKeys > 0;
    }

    // Properties selected in the timeline that have at least one selected key.
    // Key indexes returned by selectedKeys are 1-based.
    function getKeyedSelectedProps(comp) {
        var result = [];
        if (!comp || !comp.selectedProperties) { return result; }
        var props = comp.selectedProperties;
        for (var i = 0; i < props.length; i++) {
            var p = props[i];
            if (!isPropertyWithKeys(p)) { continue; }
            var sel = p.selectedKeys;
            if (sel && sel.length > 0) { result.push(p); }
        }
        return result;
    }

    // Properties selected in the timeline with any keys at all (the whole
    // animation of each is copied, so key selection is not required).
    function getAnimatedSelectedProps(comp) {
        var result = [];
        if (!comp || !comp.selectedProperties) { return result; }
        var props = comp.selectedProperties;
        for (var i = 0; i < props.length; i++) {
            var p = props[i];
            if (isPropertyWithKeys(p)) { result.push(p); }
        }
        return result;
    }

    /* ==================================================================
     *  Value-type / ease helpers
     * ================================================================== */

    // Number of value dimensions that carry temporal ease. Returns 0 for
    // types without temporal easing (e.g. CUSTOM_VALUE shape paths).
    function dimFromValueType(vt) {
        // 官方指南枚举成员为混合大小写：OneD/TwoD/TwoD_SPATIAL/ThreeD/ThreeD_SPATIAL
        if (vt === PropertyValueType.OneD) { return 1; }
        if (vt === PropertyValueType.COLOR) { return 1; }
        if (vt === PropertyValueType.TwoD_SPATIAL) { return 2; }
        if (vt === PropertyValueType.TwoD) { return 2; }
        if (vt === PropertyValueType.ThreeD_SPATIAL) { return 3; }
        if (vt === PropertyValueType.ThreeD) { return 3; }
        return 0;
    }

    // Clone an array of KeyframeEase (one entry per dimension) into plain
    // {speed, influence} objects so the slot storage does not hold host
    // objects that could be invalidated by undo/redo.
    function cloneEaseArray(easeArr) {
        var out = [];
        if (!easeArr) { return out; }
        for (var i = 0; i < easeArr.length; i++) {
            out.push({ speed: easeArr[i].speed, influence: easeArr[i].influence });
        }
        return out;
    }

    // AE clamps KeyframeEase influence to [0.1, 100]; clamp ourselves so
    // values round-trip predictably.
    function clampInfluence(v) {
        if (v < 0.1) { return 0.1; }
        if (v > 100) { return 100; }
        return v;
    }

    // Build a per-dimension KeyframeEase array for a target property.
    //   plainArr   : source per-dimension clones [{speed, influence}, ...]
    //   targetDims : dimension count of the target property
    //   speedScale : multiplier for speeds (1/timeScale when stretching)
    // Dimensions are mapped by index; a missing source dimension falls back
    // to the last available one.
    function buildEaseForDims(plainArr, targetDims, speedScale) {
        var out = [];
        if (!plainArr || plainArr.length === 0 || targetDims < 1) { return out; }
        var sc = (speedScale === undefined) ? 1 : speedScale;
        for (var i = 0; i < targetDims; i++) {
            var src = plainArr[Math.min(i, plainArr.length - 1)];
            out.push(new KeyframeEase(src.speed * sc, clampInfluence(src.influence)));
        }
        return out;
    }

    function fmtNum(x) {
        return String(Math.round(x * 10) / 10);
    }

    function interpToString(t) {
        if (t === KIT_HOLD) { return "HOLD"; }
        if (t === KIT_LINEAR) { return "LINEAR"; }
        return "BEZIER";
    }

    function interpFromString(s) {
        if (s === "HOLD") { return KIT_HOLD; }
        if (s === "LINEAR") { return KIT_LINEAR; }
        return KIT_BEZIER;
    }

    // Adapt a copied key value to the target dimension count.
    //   srcDims === tDims          -> unchanged (also covers COLOR, whose
    //                                 "1D" value is really an [r,g,b,a] array)
    //   target 1D, source nD       -> first component
    //   target nD, source 1D       -> replicate the scalar into every dimension
    //   target nD, source mD (m<n) -> clamp missing dims to the last source dim
    function adaptValue(v, srcDims, tDims) {
        if (srcDims === tDims) { return v; }
        if (tDims === 1) { return (srcDims > 1) ? v[0] : v; }
        var out = [];
        for (var i = 0; i < tDims; i++) {
            if (srcDims === 1) { out.push(v); }
            else { out.push(v[Math.min(i, srcDims - 1)]); }
        }
        return out;
    }

    /* ==================================================================
     *  Ease copy / paste (temporal ease only, values untouched)
     * ================================================================== */

    // inOnly / outOnly: checkbox states. Only one side is restricted when
    // exactly one box is checked; both or neither = copy in + out.
    function copyEaseToSlot(slotIdx, inOnly, outOnly) {
        var comp = getActiveComp();
        if (comp === null) { alert("Open a composition first."); return; }
        var props = getKeyedSelectedProps(comp);
        if (props.length < 1) {
            alert("Select at least one keyframe in the timeline, then click Copy.");
            return;
        }

        var prop = props[0];
        var ki = prop.selectedKeys[0]; // ease of the first selected keyframe
        var dims = dimFromValueType(prop.propertyValueType);
        if (dims < 1) {
            alert("Property \"" + prop.name + "\" does not support temporal easing.");
            return;
        }

        var hasIn = true;
        var hasOut = true;
        if (inOnly && !outOnly) { hasIn = true; hasOut = false; }
        else if (outOnly && !inOnly) { hasIn = false; hasOut = true; }

        // 官方读取接口为 keyInTemporalEase / keyOutTemporalEase（每维一组）
        var easeIn = null;
        var easeOut = null;
        try { easeIn = cloneEaseArray(prop.keyInTemporalEase(ki)); } catch (eIn) { easeIn = null; }
        try { easeOut = cloneEaseArray(prop.keyOutTemporalEase(ki)); } catch (eOut) { easeOut = null; }
        if (easeIn === null && easeOut === null) {
            alert("Property \"" + prop.name + "\" does not support temporal ease reading.");
            return;
        }

        var slot = { dims: dims, hasIn: hasIn, hasOut: hasOut, inEase: null, outEase: null, sourceName: prop.name };
        if (hasIn) { slot.inEase = (easeIn !== null) ? easeIn : easeOut; }
        if (hasOut) { slot.outEase = (easeOut !== null) ? easeOut : easeIn; }
        easeSlots[slotIdx] = slot;
        updateSlotLabel(slotIdx);
    }

    function pasteEaseFromSlot(slotIdx) {
        var slot = easeSlots[slotIdx];
        if (slot === null) {
            alert("Slot " + (slotIdx + 1) + " is empty. Copy an ease into it first.");
            return;
        }
        var comp = getActiveComp();
        if (comp === null) { alert("Open a composition first."); return; }
        var props = getKeyedSelectedProps(comp);
        if (props.length < 1) {
            alert("Select the target keyframe(s) in the timeline, then click Paste.");
            return;
        }

        var applied = 0;
        var skipped = 0;
        app.beginUndoGroup("EaseCopy Clone: Paste Ease " + (slotIdx + 1));
        try {
            for (var p = 0; p < props.length; p++) {
                var prop = props[p];
                var dims = dimFromValueType(prop.propertyValueType);
                if (dims < 1) { skipped++; continue; }

                // Build per-dimension arrays for this target property; the
                // side that is not being pasted keeps its current ease.
                var inE = (slot.hasIn && slot.inEase !== null) ? buildEaseForDims(slot.inEase, dims, 1) : null;
                var outE = (slot.hasOut && slot.outEase !== null) ? buildEaseForDims(slot.outEase, dims, 1) : null;

                var keys = prop.selectedKeys;
                for (var k = 0; k < keys.length; k++) {
                    var ki = keys[k];
                    // 单侧粘贴时用官方接口回读保留侧 ease（原始 KeyframeEase 数组可直接回传）
                    var curIn = null;
                    var curOut = null;
                    try { curIn = prop.keyInTemporalEase(ki); } catch (curErr1) { curIn = null; }
                    try { curOut = prop.keyOutTemporalEase(ki); } catch (curErr2) { curOut = null; }
                    try {
                        if (inE !== null && outE !== null) {
                            prop.setTemporalEaseAtKey(ki, inE, outE);
                        } else if (inE !== null) {
                            prop.setTemporalEaseAtKey(ki, inE, (curOut !== null ? curOut : inE));
                        } else if (outE !== null) {
                            prop.setTemporalEaseAtKey(ki, (curIn !== null ? curIn : outE), outE);
                        }
                        applied++;
                    } catch (keyErr) {
                        skipped++; // e.g. hold keyframes reject temporal ease
                    }
                }
            }
        } finally {
            app.endUndoGroup();
        }
        if (skipped > 0) {
            alert("Ease applied to " + applied + " keyframe(s); skipped " + skipped +
                " (unsupported, hold or edge keyframes).");
        }
    }

    /* ==================================================================
     *  Whole-animation copy / paste with time scaling
     * ================================================================== */

    // Copies ALL keyframes of every selected animated property:
    // relative times, values, in/out interpolation types and temporal ease.
    function copyAnimationToSlot() {
        var comp = getActiveComp();
        if (comp === null) { alert("Open a composition first."); return; }
        var props = getAnimatedSelectedProps(comp);
        if (props.length < 1) {
            alert("Select one or more animated properties in the timeline (click the property name), then click Copy Animation.");
            return;
        }

        // Global source span across all copied properties.
        var t0 = Infinity;
        var t1 = -Infinity;
        var i;
        var j;
        for (i = 0; i < props.length; i++) {
            var p = props[i];
            for (j = 1; j <= p.numKeys; j++) {
                var t = p.keyTime(j);
                if (t < t0) { t0 = t; }
                if (t > t1) { t1 = t; }
            }
        }
        var dur = t1 - t0;
        if (dur < 0) { alert("Invalid keyframe times."); return; }

        var srcProps = [];
        for (i = 0; i < props.length; i++) {
            var prop = props[i];
            var dims = dimFromValueType(prop.propertyValueType);
            if (dims < 1) { continue; } // shape paths etc. cannot be re-timed

            var times = [];
            var values = [];
            var inTypes = [];
            var outTypes = [];
            var inEases = [];
            var outEases = [];
            for (j = 1; j <= prop.numKeys; j++) {
                times.push(prop.keyTime(j) - t0);
                var v = prop.keyValue(j);
                if (dims > 1) {
                    var vc = [];
                    for (var d = 0; d < dims; d++) { vc.push(v[d]); }
                    values.push(vc);
                } else {
                    values.push(v);
                }
                inTypes.push(interpToString(prop.keyInInterpolationType(j)));
                outTypes.push(interpToString(prop.keyOutInterpolationType(j)));
                inEases.push(cloneEaseArray(prop.keyInTemporalEase(j)));
                outEases.push(cloneEaseArray(prop.keyOutTemporalEase(j)));
            }
            srcProps.push({
                dims: dims,
                times: times,
                values: values,
                inTypes: inTypes,
                outTypes: outTypes,
                inEases: inEases,
                outEases: outEases,
                name: prop.name
            });
        }
        if (srcProps.length < 1) {
            alert("None of the selected properties support temporal animation copy.");
            return;
        }

        animSlot = { t0: t0, duration: dur, props: srcProps, compName: comp.name };
        updateAnimLabel();
    }

    // Pastes the stored animation onto every target property that has
    // selected keyframes. The span between the first and the last selected
    // target key defines the new duration; the copied span is scaled to fit
    // (key times scale by `scale`, ease speeds by 1/scale, influence is kept).
    function pasteAnimationFromSlot() {
        if (animSlot === null) {
            alert("No animation stored. Click Copy Animation first.");
            return;
        }
        var comp = getActiveComp();
        if (comp === null) { alert("Open a composition first."); return; }
        var props = getKeyedSelectedProps(comp);
        if (props.length < 1) {
            alert("Select the target keyframe(s) that define the new time interval, then click Paste Animation.");
            return;
        }

        // Target interval from the selected keys (min first / max last).
        var ta = Infinity;
        var tb = -Infinity;
        for (var i = 0; i < props.length; i++) {
            var p = props[i];
            var ks = p.selectedKeys;
            for (var j = 0; j < ks.length; j++) {
                var t = p.keyTime(ks[j]);
                if (t < ta) { ta = t; }
                if (t > tb) { tb = t; }
            }
        }
        var span = tb - ta;
        var scale = 1;
        if (span > 0 && animSlot.duration > 0) {
            scale = span / animSlot.duration;
        }
        // With zero-span selection (a single selected key) or a single-key
        // source, timing is kept 1:1 and starts at the first selected key.
        var speedScale = (scale > 0) ? (1 / scale) : 1;

        var applied = 0;
        var skipped = 0;
        app.beginUndoGroup("EaseCopy Clone: Paste Animation");
        try {
            for (var pi = 0; pi < props.length; pi++) {
                var prop = props[pi];
                var tDims = dimFromValueType(prop.propertyValueType);
                if (tDims < 1) { skipped++; continue; }

                // Map source properties to targets by selection order; if
                // there are more targets than sources, cycle through them.
                var src = animSlot.props[pi % animSlot.props.length];

                var times = [];
                var values = [];
                for (var k = 0; k < src.times.length; k++) {
                    times.push(ta + src.times[k] * scale);
                    values.push(adaptValue(src.values[k], src.dims, tDims));
                }
                try {
                    prop.setValuesAtTimes(times, values);
                } catch (setErr) {
                    skipped++;
                    continue;
                }

                // Re-apply interpolation types and scaled temporal ease on
                // the freshly created keys (nearestKeyIndex lands on the key
                // we just created at that exact time).
                for (var k2 = 0; k2 < times.length; k2++) {
                    var idx = prop.nearestKeyIndex(times[k2]);
                    try {
                        prop.setInterpolationTypeAtKey(idx,
                            interpFromString(src.inTypes[k2]),
                            interpFromString(src.outTypes[k2]));
                    } catch (interpErr) { /* edge key: keep default */ }

                    var inE = null;
                    var outE = null;
                    if (src.inEases.length > k2) { inE = buildEaseForDims(src.inEases[k2], tDims, speedScale); }
                    if (src.outEases.length > k2) { outE = buildEaseForDims(src.outEases[k2], tDims, speedScale); }
                    try {
                        if (inE !== null && outE !== null && inE.length > 0 && outE.length > 0) {
                            prop.setTemporalEaseAtKey(idx, inE, outE);
                        }
                    } catch (easeErr) { /* hold or edge key: skip ease */ }
                    applied++;
                }
            }
        } finally {
            app.endUndoGroup();
        }
        var msg = "Animation pasted: " + applied + " keyframe(s) written";
        if (skipped > 0) { msg += "; skipped " + skipped + " propert(ies)"; }
        msg += ".\nTime scale: " + fmtNum(scale) + "x (ease speed x" + fmtNum(speedScale) + ")";
        alert(msg);
    }

    /* ==================================================================
     *  UI
     * ================================================================== */

    function updateSlotLabel(idx) {
        if (idx >= slotRows.length) { return; }
        var s = easeSlots[idx];
        var info = slotRows[idx].info;
        if (s === null) { info.text = "empty"; return; }

        var sides;
        if (s.hasIn && s.hasOut) { sides = "in+out"; }
        else if (s.hasIn) { sides = "in only"; }
        else { sides = "out only"; }
        var txt = s.dims + "D, " + sides;
        if (s.hasIn && s.inEase !== null && s.inEase.length > 0) {
            txt += " | in spd " + fmtNum(s.inEase[0].speed) + " inf " + fmtNum(s.inEase[0].influence);
        }
        if (s.hasOut && s.outEase !== null && s.outEase.length > 0) {
            txt += " | out spd " + fmtNum(s.outEase[0].speed) + " inf " + fmtNum(s.outEase[0].influence);
        }
        info.text = txt;
    }

    function countAnimKeys() {
        if (animSlot === null) { return 0; }
        var n = 0;
        for (var i = 0; i < animSlot.props.length; i++) { n += animSlot.props[i].times.length; }
        return n;
    }

    function updateAnimLabel() {
        if (animSlot === null || animInfo === null) { return; }
        animInfo.text = "stored: " + animSlot.props.length + " prop(s), " +
            countAnimKeys() + " keys, span " + fmtNum(animSlot.duration) + " s";
    }

    function addSlotRow(ui, idx, chkIn, chkOut) {
        var row = ui.add("group");
        row.orientation = "row";
        row.alignment = "fill";
        row.alignChildren = ["left", "center"];

        var lbl = row.add("statictext", undefined, "Slot " + (idx + 1) + ":");
        lbl.preferredSize.width = 44;

        var btnC = row.add("button", undefined, "Copy " + (idx + 1));
        btnC.preferredSize.width = 64;
        btnC.helpTip = "Copy the temporal ease (speed + influence) of the first selected keyframe into slot " + (idx + 1) + ".";

        var btnP = row.add("button", undefined, "Paste " + (idx + 1));
        btnP.preferredSize.width = 64;
        btnP.helpTip = "Apply the ease stored in slot " + (idx + 1) + " to every selected keyframe. Keyframe values are not touched.";

        var info = row.add("statictext", undefined, "empty");
        info.preferredSize.width = 220;

        btnC.onClick = function () {
            try {
                copyEaseToSlot(idx, chkIn.value, chkOut.value);
            } catch (err) {
                alert("Copy failed: " + err.toString());
            }
        };
        btnP.onClick = function () {
            try {
                pasteEaseFromSlot(idx);
            } catch (err) {
                alert("Paste failed: " + err.toString());
            }
        };
        slotRows.push({ info: info });
    }

    function buildUI(thisObj) {
        var ui = (thisObj instanceof Panel)
            ? thisObj
            : new Window("palette", SCRIPT_NAME + " v" + SCRIPT_VERSION, undefined, { resizeable: true });
        ui.orientation = "column";
        ui.alignChildren = ["fill", "top"];
        ui.spacing = 6;
        ui.margins = 10;

        var title = ui.add("statictext", undefined, SCRIPT_NAME + "  v" + SCRIPT_VERSION);
        title.helpTip = "Clean-room clone. Copies keyframe temporal ease (speed + influence), never keyframe values.";

        var optRow = ui.add("group");
        optRow.orientation = "row";
        optRow.alignChildren = ["left", "center"];
        var chkIn = optRow.add("checkbox", undefined, "In only");
        chkIn.helpTip = "Copy only the incoming (ease in) part of the ease.";
        var chkOut = optRow.add("checkbox", undefined, "Out only");
        chkOut.helpTip = "Copy only the outgoing (ease out) part of the ease.";
        var note = optRow.add("statictext", undefined, "(both / none = in+out)");
        note.enabled = false;

        for (var i = 0; i < MAX_SLOTS; i++) {
            addSlotRow(ui, i, chkIn, chkOut);
        }

        var sep = ui.add("statictext", undefined, "--- whole animation (time-scaled paste) ---");
        sep.enabled = false;

        var animRow = ui.add("group");
        animRow.orientation = "row";
        animRow.alignChildren = ["left", "center"];
        var btnACopy = animRow.add("button", undefined, "Copy Animation");
        btnACopy.preferredSize.width = 110;
        btnACopy.helpTip = "Copy ALL keyframes of every selected animated property: relative times, values, interpolation types and ease.";
        var btnAPaste = animRow.add("button", undefined, "Paste Animation");
        btnAPaste.preferredSize.width = 110;
        btnAPaste.helpTip = "Paste the stored animation; its time span is scaled so it matches the span of the selected target keyframes.";
        btnACopy.onClick = function () {
            try { copyAnimationToSlot(); } catch (errA) {
                alert("Copy Animation failed: " + errA.toString());
            }
        };
        btnAPaste.onClick = function () {
            try { pasteAnimationFromSlot(); } catch (errB) {
                alert("Paste Animation failed: " + errB.toString());
            }
        };
        animInfo = ui.add("statictext", undefined, "stored: nothing");

        var help1 = ui.add("statictext", undefined, "Ease: select source key(s) -> Copy N; select target key(s) -> Paste N.");
        help1.enabled = false;
        var help2 = ui.add("statictext", undefined, "Anim: target span = copied span; ease speeds scale by 1/timeScale.");
        help2.enabled = false;

        ui.onResizing = ui.onResize = function () { this.layout.resize(); };

        if (ui instanceof Window) {
            ui.center();
            ui.show();
        } else {
            ui.layout.layout(true);
        }
    }

    try {
        buildUI(thisObj);
    } catch (buildErr) {
        alert(SCRIPT_NAME + " failed to build UI: " + buildErr.toString());
    }

})(this);
