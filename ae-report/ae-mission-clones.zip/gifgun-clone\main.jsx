﻿#targetengine session
/**
 * ============================================================================
 *  GifGun Clone —— GifGun 核心功能（一键 GIF 导出）的 clean-room 复刻实现
 * ============================================================================
 *
 *  [CLEAN-ROOM 声明]
 *  本脚本依据功能需求描述（intel/paid-list.md 第 5 条 "GifGun"）从零独立编写。
 *  编写过程中未反编译原插件，未阅读、复制或改写原插件的任何源代码、字节码或
 *  资源文件；仅依赖 Adobe After Effects 公开脚本 API 与 ffmpeg 公开命令行用法。
 *  与原产品的相似性仅来自功能需求本身。
 *
 *  功能概述（本次复刻范围 = 一键 GIF 导出核心）：
 *    - 取当前活动合成的工作区范围（或全时长）；
 *    - 经 AE 渲染队列输出 PNG 序列到临时目录；
 *    - 调用系统 ffmpeg，palettegen/paletteuse 两遍法合成高质量 GIF
 *      （fps 抽帧、最大宽度缩放、质量映射调色板颜色数与抖动方式均可参数化）；
 *    - 完成后打开输出目录；ffmpeg 缺失时降级为仅导出序列帧并给出指引。
 *
 *  技术路线：PNG 序列（渲染队列）→ ffmpeg 两遍法，无 C++ 依赖。
 *
 *  ExtendScript / ES3 兼容：无 let/const/箭头函数/模板字符串/JSON/ES5 数组方法。
 * ============================================================================
 */

(function (thisObj) {

    var SCRIPT_NAME = "GifGun Clone";
    var SCRIPT_VERSION = "1.0.0";
    var SETTINGS_SECTION = "gifGunClone";

    /* ======================================================================
     *  基础工具（ES3）
     * ==================================================================== */

    function errText(e) {
        var s = "未知错误";
        try {
            if (e != null && e.message != null && e.message !== "") {
                s = e.message;
            } else if (e != null) {
                s = e.toString();
            }
        } catch (e2) {
            s = "未知错误";
        }
        return s;
    }

    function clamp(v, lo, hi) {
        if (v < lo) return lo;
        if (v > hi) return hi;
        return v;
    }

    // 文件名非法字符替换
    function sanitizeFileName(s) {
        return String(s).replace(/[\/\\:*?\"<>|]/g, "_");
    }

    // ffmpeg 参数统一用正斜杠，避免反斜杠转义问题
    function toFfPath(p) {
        return String(p).replace(/\\/g, "/");
    }

    function isWindows() {
        try { return File.fs === "Windows"; } catch (e) { return true; }
    }

    /* ======================================================================
     *  设置持久化（app.settings，失败静默降级）
     * ==================================================================== */

    function loadSetting(key, fallback) {
        var v = "";
        try {
            v = app.settings.getHavingSaved(SETTINGS_SECTION, key);
        } catch (e1) {
            v = "";
        }
        if (v == null || v === "") return fallback;
        return v;
    }

    function saveSetting(key, value) {
        try {
            app.settings.save(SETTINGS_SECTION, key, value);
        } catch (e1) {}
        try {
            app.settings.saveToDisk();
        } catch (e2) {}
    }

    /* ======================================================================
     *  合成与路径
     * ==================================================================== */

    function getActiveComp() {
        try {
            var it = app.project.activeItem;
            if (it != null && it instanceof CompItem) return it;
        } catch (e1) {}
        try {
            var sel = app.project.selection;
            for (var i = 0; i < sel.length; i++) {
                if (sel[i] instanceof CompItem) return sel[i];
            }
        } catch (e2) {}
        return null;
    }

    function defaultOutDir() {
        try {
            if (app.project != null && app.project.file != null) {
                return app.project.file.parent.fsName;
            }
        } catch (e1) {}
        try { return Folder.desktop.fsName; } catch (e2) { return ""; }
    }

    function scriptDir() {
        try {
            var sf = new File($.fileName);
            if (sf != null && sf.exists) return sf.parent;
        } catch (e1) {}
        return null;
    }

    function revealFolder(folder) {
        try {
            folder.execute();
            return;
        } catch (e1) {}
        try {
            if (isWindows()) {
                system.callSystem("explorer \"" + toFfPath(folder.fsName) + "\"");
            } else {
                system.callSystem("open \"" + toFfPath(folder.fsName) + "\"");
            }
        } catch (e2) {}
    }

    /* ======================================================================
     *  ffmpeg 检测：用户指定路径 → 脚本同目录 → 系统 PATH
     * ==================================================================== */

    function ffmpegResponds(quotedCmd) {
        try {
            var out = system.callSystem(quotedCmd + " -version");
            return out != null && String(out).toLowerCase().indexOf("ffmpeg version") >= 0;
        } catch (e) {
            return false;
        }
    }

    function detectFfmpeg(userPath) {
        var exe = isWindows() ? "ffmpeg.exe" : "ffmpeg";

        if (userPath != null && userPath !== "") {
            var p = String(userPath);
            if (ffmpegResponds('"' + toFfPath(p) + '"')) return p;
        }

        var dir = scriptDir();
        if (dir != null) {
            var cand = dir.fsName + "/" + exe;
            var f = new File(cand);
            if (f.exists && ffmpegResponds('"' + toFfPath(cand) + '"')) return cand;
        }

        if (ffmpegResponds("ffmpeg")) return "ffmpeg"; // 系统 PATH

        return null;
    }

    /* ======================================================================
     *  质量映射：1-5 → palettegen 颜色数 + paletteuse 抖动方式
     * ==================================================================== */

    function qualityParams(q) {
        if (q >= 4) return { colors: "256", dither: "dither=sierra2_4a" };
        if (q === 3) return { colors: "256", dither: "dither=bayer:bayer_scale=3" };
        if (q === 2) return { colors: "128", dither: "dither=bayer:bayer_scale=4" };
        return { colors: "64", dither: "dither=bayer:bayer_scale=5" };
    }

    /* ======================================================================
     *  输出模块模板挑选：优先含 "png" 的模板，其次任意图像序列模板
     * ==================================================================== */

    function pickPngTemplate(om) {
        var names = [];
        try { names = om.templates; } catch (e0) { names = []; }
        var i;
        var n;
        for (i = 0; i < names.length; i++) {
            n = String(names[i]).toLowerCase();
            if (n.indexOf("png") >= 0) return names[i];
        }
        for (i = 0; i < names.length; i++) {
            n = String(names[i]).toLowerCase();
            if (n.indexOf("sequence") >= 0) return names[i];
        }
        return null;
    }

    function collectSeqFiles(folder) {
        var out = [];
        try {
            var files = folder.getFiles("*.png");
            for (var i = 0; i < files.length; i++) {
                if (files[i] instanceof File && files[i].name !== "palette.png") {
                    out.push(files[i]);
                }
            }
        } catch (e) {}
        return out;
    }

    function cleanupFolder(folder) {
        try {
            var files = folder.getFiles();
            for (var i = 0; i < files.length; i++) {
                if (files[i] instanceof File) {
                    try { files[i].remove(); } catch (e1) {}
                }
            }
            folder.remove();
        } catch (e2) {}
    }

    /* ======================================================================
     *  主导出流程
     * ==================================================================== */

    function setStatus(ui, msg) {
        ui.statusText.text = msg;
        try { ui.win.update(); } catch (e) {}
    }

    function saveSettings(ui) {
        saveSetting("fps", String(Math.round(ui.fpsSlider.value)));
        saveSetting("width", String(ui.widthEdit.text));
        saveSetting("quality", String(Math.round(ui.qSlider.value)));
        saveSetting("outdir", String(ui.outEdit.text));
        saveSetting("workarea", ui.waChk.value ? "1" : "0");
        saveSetting("keepframes", ui.keepChk.value ? "1" : "0");
        saveSetting("ffpath", String(ui.ffEdit.text));
    }

    function doExport(ui) {
        var comp = getActiveComp();
        if (comp == null) {
            alert("请先在项目面板双击打开（或选中）要导出的合成。", SCRIPT_NAME);
            return;
        }

        var compFps = comp.frameRate;
        if (!(compFps > 0)) compFps = 25;

        // 范围：工作区 或 全时长
        var start = 0;
        var dur = comp.duration;
        if (ui.waChk.value) {
            try {
                if (comp.workAreaDuration > 0) {
                    start = comp.workAreaStart;
                    dur = comp.workAreaDuration;
                } else {
                    dur = comp.duration;
                }
            } catch (eW) {
                dur = comp.duration;
            }
        }
        if (!(dur > 0)) {
            alert("合成时长为 0，无法导出。", SCRIPT_NAME);
            return;
        }

        // 参数解析与约束
        var gifFps = clamp(Math.round(ui.fpsSlider.value), 8, 30);
        var outW = parseInt(ui.widthEdit.text, 10);
        if (!(outW > 0)) outW = comp.width;
        if (outW > comp.width) outW = comp.width;
        outW = outW - (outW % 2);
        if (outW < 2) outW = 2;
        var q = clamp(Math.round(ui.qSlider.value), 1, 5);

        // 输出目录
        var outText = String(ui.outEdit.text);
        var outFolder = (outText === "") ? new Folder(defaultOutDir()) : new Folder(outText);
        try { if (!outFolder.exists) outFolder.create(); } catch (eO1) {}
        if (!outFolder.exists) {
            alert("输出目录不可用：" + outText, SCRIPT_NAME);
            return;
        }

        saveSettings(ui);

        // ffmpeg 检测
        setStatus(ui, "检测 ffmpeg ...");
        var ffPath = detectFfmpeg(String(ui.ffEdit.text));

        // 临时目录
        var tmp = new Folder(Folder.temp.fsName + "/gifGunClone_" + (new Date()).getTime());
        try { tmp.create(); } catch (eT1) {}
        if (!tmp.exists) {
            alert("无法创建临时目录：" + tmp.fsName, SCRIPT_NAME);
            return;
        }

        var framesExpected = Math.floor(dur * compFps + 0.5);
        var preQueued = 0;
        var renderOK = false;
        var omNote = "";

        // 1) 渲染队列输出 PNG 序列（rq.render() 为同步调用，AE 会显示自带进度）
        app.beginUndoGroup(SCRIPT_NAME);
        try {
            var rq = app.project.renderQueue;
            if (rq.rendering) {
                alert("渲染队列正在渲染，请稍后再试。", SCRIPT_NAME);
            } else {
                preQueued = rq.numItems;
                var rqItem = rq.items.add(comp);
                try { rqItem.applyTemplate("Best Settings"); } catch (eR1) {}
                try {
                    rqItem.timeSpanStart = start;
                    rqItem.timeSpanDuration = dur;
                } catch (eR2) {}
                var om = rqItem.outputModule(1);
                var tpl = pickPngTemplate(om);
                if (tpl != null) {
                    try { om.applyTemplate(tpl); } catch (eR3) { tpl = null; }
                }
                if (tpl == null) {
                    omNote = "未找到 PNG 序列输出模块模板，已尝试用默认模块直接输出 PNG。";
                }
                try { om.file = new File(tmp.fsName + "/frame_[#####].png"); } catch (eR4) {}

                setStatus(ui, "渲染 PNG 序列中（约 " + framesExpected + " 帧，" + start.toFixed(2) + "s 起 " + dur.toFixed(2) + "s）…");
                rq.render();
                renderOK = true;
            }
        } catch (eR) {
            alert("渲染失败：" + errText(eR), SCRIPT_NAME);
        } finally {
            app.endUndoGroup();
        }
        if (!renderOK) return;

        // 2) 校验序列帧
        var frameFiles = collectSeqFiles(tmp);
        if (frameFiles.length === 0) {
            setStatus(ui, "失败：没有序列帧。");
            alert("渲染完成但未在临时目录找到 PNG 序列。\n" +
                (omNote !== "" ? omNote + "\n" : "") +
                "请确认 AE 中存在 PNG Sequence 类输出模块模板（编辑 > 模板 > 输出模块）。", SCRIPT_NAME);
            try { tmp.execute(); } catch (eX0) {}
            return;
        }

        // 3) ffmpeg 缺失降级：保留序列帧 + 指引
        if (ffPath == null) {
            setStatus(ui, "未检测到 ffmpeg：已导出 " + frameFiles.length + " 帧序列（已保留）");
            revealFolder(tmp);
            alert("未检测到 ffmpeg，无法直接合成 GIF。\n\n" +
                "已导出 PNG 序列（" + frameFiles.length + " 帧）：\n" + tmp.fsName + "\n\n" +
                "安装 ffmpeg 后重试，或手动转换：\n" +
                "ffmpeg -framerate " + compFps + " -i frame_%05d.png out.gif\n\n" +
                "下载指引见 README.md（ffmpeg.org / gyan.dev / BtbN builds / brew）。", SCRIPT_NAME);
            return;
        }

        // 4) ffmpeg 两遍法：palettegen → paletteuse
        var qp = qualityParams(q);
        var ffQ = '"' + toFfPath(ffPath) + '"';
        var seqP = toFfPath(tmp.fsName) + "/frame_%05d.png";
        var palP = toFfPath(tmp.fsName) + "/palette.png";
        var chain = "fps=" + gifFps + ",scale=" + outW + ":-2:flags=lanczos";

        var compBase = sanitizeFileName(comp.name);
        var gifName = compBase;
        var nGif = 1;
        while (new File(outFolder.fsName + "/" + gifName + ".gif").exists && nGif < 100) {
            gifName = compBase + "_" + nGif;
            nGif++;
        }
        var gifPath = toFfPath(outFolder.fsName) + "/" + gifName + ".gif";

        var cmd1 = ffQ + " -y -hide_banner -loglevel error -framerate " + compFps +
            " -i \"" + seqP + "\" -vf \"" + chain +
            ",palettegen=max_colors=" + qp.colors + ":stats_mode=diff\" \"" + palP + "\"";
        var out1 = "";
        try { out1 = system.callSystem(cmd1); } catch (eF1) { out1 = String(eF1); }

        var palFile = new File(tmp.fsName + "/palette.png");
        if (!palFile.exists || palFile.length === 0) {
            setStatus(ui, "失败：palettegen 未生成调色板。");
            alert("ffmpeg 调色板生成失败。\n\n命令：\n" + cmd1 +
                "\n\n（callSystem 只能捕获 stdout，ffmpeg 的错误走 stderr 看不到；" +
                "请把上面命令复制到终端手动运行查看详细报错。）", SCRIPT_NAME);
            return;
        }

        setStatus(ui, "ffmpeg 第二遍（合成 GIF）…");
        var cmd2 = ffQ + " -y -hide_banner -loglevel error -framerate " + compFps +
            " -i \"" + seqP + "\" -i \"" + palP +
            "\" -filter_complex \"[0:v]" + chain + "[x];[x][1:v]paletteuse=" + qp.dither +
            "\" -loop 0 \"" + gifPath + "\"";
        var out2 = "";
        try { out2 = system.callSystem(cmd2); } catch (eF2) { out2 = String(eF2); }

        var gifFile = new File(outFolder.fsName + "/" + gifName + ".gif");
        if (!gifFile.exists || gifFile.length === 0) {
            setStatus(ui, "失败：GIF 未生成。");
            alert("ffmpeg 合成 GIF 失败。\n\n命令：\n" + cmd2 +
                "\n\n（callSystem 只能捕获 stdout，ffmpeg 的错误走 stderr 看不到；" +
                "请把上面命令复制到终端手动运行查看详细报错。）", SCRIPT_NAME);
            return;
        }

        // 5) 收尾：清理本工具加入的渲染队列项（原队列项保留）
        try {
            if (rqItem != null && rq.numItems > preQueued) {
                rqItem.remove();
            }
        } catch (eRQ) { /* 清理失败不影响交付 */ }
        if (!ui.keepChk.value) {
            cleanupFolder(tmp);
        }
        var note = (preQueued > 0) ? "（注：队列中原有 " + preQueued + " 个已排队项也被一并渲染）" : "";
        setStatus(ui, "完成：" + gifName + ".gif（" + frameFiles.length + " 帧 → " + gifFps + "fps / " + outW + "px）" + note);
        revealFolder(outFolder);
    }

    /* ======================================================================
     *  UI（ScriptUI 面板 / 独立调色板窗口，ES3）
     * ==================================================================== */

    function buildUI(thisObj) {
        var win = (thisObj instanceof Panel) ? thisObj :
            new Window("palette", SCRIPT_NAME + " v" + SCRIPT_VERSION, undefined, { resizeable: true });
        win.orientation = "column";
        win.alignChildren = ["fill", "top"];
        win.spacing = 6;
        win.margins = 12;

        var statusText = win.add("statictext", undefined, "就绪。打开要导出的合成后点「一键导出 GIF」。");
        statusText.preferredSize = [310, 30];

        // 帧率
        var fpsGrp = win.add("group");
        fpsGrp.orientation = "row";
        fpsGrp.alignChildren = ["left", "center"];
        fpsGrp.add("statictext", undefined, "GIF 帧率:");
        var fpsSlider = fpsGrp.add("slider", undefined, 15, 8, 30);
        fpsSlider.preferredSize = [130, 14];
        var fpsLabel = fpsGrp.add("statictext", undefined, "15 fps");
        fpsSlider.onChanging = function () {
            fpsLabel.text = Math.round(this.value) + " fps";
        };

        // 宽度 + 质量
        var wqGrp = win.add("group");
        wqGrp.orientation = "row";
        wqGrp.alignChildren = ["left", "center"];
        wqGrp.add("statictext", undefined, "最大宽度:");
        var widthEdit = wqGrp.add("edittext");
        widthEdit.characters = 6;
        wqGrp.add("statictext", undefined, "质量:");
        var qSlider = wqGrp.add("slider", undefined, 4, 1, 5);
        qSlider.preferredSize = [90, 14];
        var qLabel = wqGrp.add("statictext", undefined, "4");
        qSlider.onChanging = function () {
            qLabel.text = String(Math.round(this.value));
        };

        // 范围 / 中间帧
        var optGrp = win.add("group");
        optGrp.orientation = "row";
        var waChk = optGrp.add("checkbox", undefined, "仅渲染工作区");
        var keepChk = optGrp.add("checkbox", undefined, "保留序列帧");

        // 输出目录
        var outGrp = win.add("group");
        outGrp.orientation = "row";
        outGrp.alignChildren = ["left", "center"];
        outGrp.add("statictext", undefined, "输出目录:");
        var outEdit = outGrp.add("edittext");
        outEdit.characters = 20;
        var browseBtn = outGrp.add("button", undefined, "...");

        // ffmpeg 路径
        var ffGrp = win.add("group");
        ffGrp.orientation = "row";
        ffGrp.alignChildren = ["left", "center"];
        ffGrp.add("statictext", undefined, "ffmpeg路径:");
        var ffEdit = ffGrp.add("edittext");
        ffEdit.characters = 22;
        ffEdit.tooltip = "留空自动检测：脚本同目录 → 系统 PATH";

        // 导出按钮
        var exportBtn = win.add("button", undefined, "一键导出 GIF");
        exportBtn.preferredSize = [320, 36];

        // 恢复持久化设置
        try {
            fpsSlider.value = clamp(parseFloat(loadSetting("fps", "15")) || 15, 8, 30);
            fpsLabel.text = Math.round(fpsSlider.value) + " fps";
            widthEdit.text = loadSetting("width", "640");
            qSlider.value = clamp(parseInt(loadSetting("quality", "4"), 10) || 4, 1, 5);
            qLabel.text = String(Math.round(qSlider.value));
            waChk.value = (loadSetting("workarea", "0") === "1");
            keepChk.value = (loadSetting("keepframes", "0") === "1");
            outEdit.text = loadSetting("outdir", defaultOutDir());
            ffEdit.text = loadSetting("ffpath", "");
        } catch (eS) {}

        var ui = {
            win: win,
            statusText: statusText,
            fpsSlider: fpsSlider,
            widthEdit: widthEdit,
            qSlider: qSlider,
            waChk: waChk,
            keepChk: keepChk,
            outEdit: outEdit,
            ffEdit: ffEdit
        };

        browseBtn.onClick = function () {
            var f = Folder.selectDialog("选择输出目录");
            if (f != null) outEdit.text = f.fsName;
        };

        exportBtn.onClick = function () {
            try {
                doExport(ui);
            } catch (eX) {
                alert("导出失败：" + errText(eX), SCRIPT_NAME);
            }
        };

        if (win instanceof Window) {
            win.center();
            win.show();
        } else {
            win.layout.layout(true);
            win.layout.resize();
            win.onResizing = win.onResize = function () {
                this.layout.resize();
            };
        }
        return win;
    }

    /* ======================================================================
     *  入口
     * ==================================================================== */

    function main(thisObj) {
        if (app.project == null) {
            alert("请先打开一个 After Effects 工程。", SCRIPT_NAME);
            return;
        }
        buildUI(thisObj);
    }

    try {
        main(thisObj);
    } catch (eFatal) {
        var fatalMsg = "脚本初始化失败：" + errText(eFatal);
        try {
            if (eFatal.line != null) fatalMsg += "（行 " + eFatal.line + "）";
        } catch (eL) {}
        alert(fatalMsg, SCRIPT_NAME);
    }
})(this);
