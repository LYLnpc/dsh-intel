/*******************************************************************************
 * WobbleBox Clone (jelly box follower) - main.jsx
 * generated_at: 2026-11-14T08:26:00+08:00
 * task: clean-room 复刻 WobbleBox（aescripts, Mike Overbeck, $5 NYOP，预设+表达式）
 *       核心功能：图层运动时盒体以果冻方式弹性反应（输入 = intel/paid-list.md
 *       第 15 条功能性描述，不反编译不抄原代码）
 *
 * CLEAN-ROOM 声明：
 * 1. 本脚本为清室（clean-room）独立实现。实现者未反编译、未阅读、未复制
 *    WobbleBox 的任何原始代码；仅依据公开的功能性描述（"图层运动时盒体以
 *    果冻方式弹性反应，spring 表达式驱动"）与 AE 公开脚本 API 从零编写
 *    （API 对照 docs/api-cheatsheet.md 白名单）。
 * 2. 实现路线：为目标层创建一个矩形形状层"果冻盒"，父级到目标层（layer.parent
 *    [官方核实]）跟随其位置/旋转；盒体 scale 写 Verlet 弹簧表达式——目标幅度
 *    由父层 position 相邻帧位移（valueAtTime [官方核实]）换算的速度驱动，
 *    刚度/阻尼/最大幅度用 Slider 控制（含数值稳定域钳制）。
 * 3. 本脚本按 ES3 (ExtendScript) 编写：无 let/const/箭头函数/JSON.stringify。
 *
 * 用法：File > Scripts > Run Script File... 或放入 ScriptUI Panels 目录。
 * 选中 1 个以上图层 → Create Jelly Box → 播放即可看到果冻跟随。
 ******************************************************************************/

(function (wbThisObj) {

    var SCRIPT_NAME = "WobbleBox Clone";
    var SCRIPT_VER = "1.0.0";
    var PFX = "WB:";
    var WB_MEM = 300; // 弹簧历史采样帧数上限（递归深度保险丝）

    // ------------------------------------------------------------------
    // 小工具（ES3）
    // ------------------------------------------------------------------
    function toNum2(s, fallback, min) {
        var v = parseFloat(s);
        if (isNaN(v)) { v = fallback; }
        if (v < min) { v = min; }
        return v;
    }

    function escName(n) {
        return ("" + n).replace(/"/g, "\\\"");
    }

    function ensureFx(layer, matchName, fxName, valuePropName, defaultValue) {
        var effects = layer.property("ADBE Effect Parade");
        var fx = null;
        var i;
        for (i = 1; i <= effects.numProperties; i++) {
            var p = effects.property(i);
            if (p.name === fxName) { fx = p; break; }
        }
        if (fx === null) {
            fx = effects.addProperty(matchName);
            fx.name = fxName;
            if (defaultValue !== null && defaultValue !== undefined) {
                fx.property(valuePropName).setValue(defaultValue);
            }
        }
        return fx;
    }

    // 目标层内容包围盒（源空间）：sourceRectAtTime 不在白名单 → try/catch + 回退
    function contentRect(layer, comp) {
        try {
            var rect = layer.sourceRectAtTime(comp.time, false);
            if (rect !== null && rect.width > 0 && rect.height > 0) { return rect; }
        } catch (e0) { /* 空文本/空形状 → 回退 */ }
        var w = 0, h = 0;
        try { w = layer.width; h = layer.height; } catch (e1) { w = 0; h = 0; }
        if (!(w > 0)) { w = comp.width; }
        if (!(h > 0)) { h = comp.height; }
        return { left: 0, top: 0, width: w, height: h };
    }

    // ------------------------------------------------------------------
    // 果冻盒 scale 弹簧表达式（Verlet，白名单 API；仅用 valueAtTime 位移测速）
    // ------------------------------------------------------------------
    function buildJellyScaleExpr() {
        var L = [];
        L.push("// === WobbleBox Clone (clean-room) v" + SCRIPT_VER + " : jelly scale ===");
        L.push("// speed from parent frame delta (valueAtTime), Verlet spring toward");
        L.push("// target stretch; stability-clamped like a critically-safe spring.");
        L.push("var f = thisComp.frameDuration;");
        L.push("var t0 = thisComp.displayStartTime;");
        L.push("var t = time;");
        L.push("var outV = value;");
        L.push("try {");
        L.push("  var pp = parent.transform.position;");
        L.push("  var v1 = pp.valueAtTime(t);");
        L.push("  var v0 = pp.valueAtTime(t - f);");
        L.push("  var dx = v1[0] - v0[0], dy = v1[1] - v0[1];");
        L.push("  var sp = Math.sqrt(dx * dx + dy * dy) / f;"); // 父层速度 px/s
        L.push("  var gain = effect(\"" + PFX + " Gain\")(\"Slider\");");
        L.push("  var ampMax = effect(\"" + PFX + " Max Amp\")(\"Slider\") / 100;");
        L.push("  var tgt = Math.min(ampMax, (sp / 1000) * (gain / 100));"); // 目标拉伸比例：gain=每 1000px/s 的百分比
        L.push("  var m = 1;");
        L.push("  var k = Math.max(0, effect(\"" + PFX + " Stiffness\")(\"Slider\"));");
        L.push("  var c = Math.max(0, effect(\"" + PFX + " Damping\")(\"Slider\"));");
        L.push("  var kMax = m * 2.25 / (f * f);");
        L.push("  var k2 = Math.min(k, kMax);");
        L.push("  var aK = k2 * f * f / m;");
        L.push("  var bC = Math.min(c * f / m, (3.6 - aK) / 2);");
        L.push("  var cE = bC * m / f;");
        L.push("  function dimStep(a1, a2, tg, i) {");
        L.push("    var v = (a1[i] - a2[i]) / f;");
        L.push("    if (!isFinite(v)) { v = 0; }");
        L.push("    var acc = (k2 * (tg[i] - a1[i]) - cE * v) / m;");
        L.push("    var xn = 2 * a1[i] - a2[i] + acc * f * f;");
        L.push("    var dxx = xn - a1[i];");
        L.push("    if (dxx > 8) { dxx = 8; }");   // 单帧百分比钳制（scale 单位 %）
        L.push("    if (dxx < -8) { dxx = -8; }");
        L.push("    return dxx;");
        L.push("  }");
        L.push("  if (f > 0 && (t - t0) >= 2 * f && (t - t0) <= " + WB_MEM + " * f) {");
        L.push("    var x1 = thisProperty.valueAtTime(t - f);");
        L.push("    var x2 = thisProperty.valueAtTime(t - 2 * f);");
        L.push("    var a1 = (typeof x1.length === \"number\") ? x1 : [x1];");
        L.push("    var a2 = (typeof x2.length === \"number\") ? x2 : [x2];");
        L.push("    var tgA = [100 * (1 + tgt), 100 / (1 + tgt)];"); // 体积守恒近似
        L.push("    var outA = [];");
        L.push("    for (var i = 0; i < a1.length; i++) { outA[i] = a1[i] + dimStep(a1, a2, tgA, i); }");
        L.push("    outV = outA;");
        L.push("  } else {");
        L.push("    outV = [100 * (1 + tgt), 100 / (1 + tgt)];");
        L.push("  }");
        L.push("} catch (eW) { outV = value; }"); // 无父级等异常 → 回退静态
        L.push("outV;");
        return L.join("\n");
    }

    // ------------------------------------------------------------------
    // 创建果冻盒
    // ------------------------------------------------------------------
    function findLayerByName(comp, name) {
        var i;
        for (i = 1; i <= comp.numLayers; i++) {
            if (comp.layer(i).name === name) { return comp.layer(i); }
        }
        return null;
    }

    function createJellyBox(comp, target, cfg, report) {
        var boxName = PFX + " Jelly - " + target.name;
        if (findLayerByName(comp, boxName) !== null) {
            report.warnings.push("[" + target.name + "] 已有果冻盒（" + boxName + "），跳过。");
            return;
        }
        var rect = contentRect(target, comp);
        var w = rect.width + cfg.padding * 2;
        var h = rect.height + cfg.padding * 2;
        if (!(w > 2) || !(h > 2)) {
            report.warnings.push("[" + target.name + "] 内容尺寸无效，跳过。");
            return;
        }

        var box = comp.layers.addShape();
        try { box.name = boxName; } catch (eN) { /* 命名失败不阻断 */ }

        // 盒体矩形：以 (0,0) 为中心（形状层默认锚点 [0,0]，缩放绕盒心）
        var contents = box.property("ADBE Root Vectors Group");
        var group = contents.addProperty("ADBE Vector Shape - Group");
        try { group.name = "Jelly Rect"; } catch (eG) { /* 忽略 */ }
        var hw = w / 2, hh = h / 2;
        var pathProp = null;
        var tries = ["ADBE Vector Shape - Path", "ADBE Vector Shape - Group"];
        var ti;
        for (ti = 0; ti < tries.length; ti++) {
            try {
                var cand = group.property(tries[ti]);
                if (cand !== null) { pathProp = cand; break; }
            } catch (eT) { /* 尝试下一个 */ }
        }
        if (pathProp === null) {
            pathProp = group.addProperty("ADBE Vector Shape - Path");
        }
        var sh = new Shape();
        sh.vertices = [[-hw, -hh], [hw, -hh], [hw, hh], [-hw, hh]];
        sh.inTangents = [[0, 0], [0, 0], [0, 0], [0, 0]];
        sh.outTangents = [[0, 0], [0, 0], [0, 0], [0, 0]];
        sh.closed = true;
        pathProp.setValue(sh);

        // 描边（半透明白盒更接近"盒子"观感）
        try {
            var stroke = group.addProperty("ADBE Vector Graphic - Stroke");
            stroke.property("ADBE Vector Stroke Color").setValue([1, 1, 1]);
            stroke.property("ADBE Vector Stroke Opacity").setValue(60);
            stroke.property("ADBE Vector Stroke Width").setValue(4);
            stroke.property("ADBE Vector Stroke Line Join").setValue(2);
        } catch (eS) { /* 描边失败不影响弹簧 */ }

        // 参数效果
        ensureFx(box, "ADBE Slider Control", PFX + " Gain", "Slider", cfg.gain);
        ensureFx(box, "ADBE Slider Control", PFX + " Max Amp", "Slider", cfg.maxAmp);
        ensureFx(box, "ADBE Slider Control", PFX + " Stiffness", "Slider", cfg.stiffness);
        ensureFx(box, "ADBE Slider Control", PFX + " Damping", "Slider", cfg.damping);

        // 父级到目标层（layer.parent [官方核实]）→ 位置/旋转全部跟随
        box.property("ADBE Transform Group").property("ADBE Position").setValue(
            [rect.left + rect.width / 2 - cfg.ax, rect.top + rect.height / 2 - cfg.ay]);
        try { box.parent = target; } catch (ePar) {
            report.warnings.push("[" + target.name + "] 父级设置失败：" + ePar.toString());
            try { box.remove(); } catch (eRm) { /* 保留现场 */ }
            return;
        }

        // scale 弹簧表达式
        try {
            box.property("ADBE Transform Group").property("ADBE Scale").expression = buildJellyScaleExpr();
        } catch (eX) {
            report.warnings.push("[" + boxName + "] 表达式写入失败：" + eX.toString());
        }
        try { box.selected = true; } catch (eSel) { /* 忽略 */ }
        report.boxes++;
    }

    function doCreate(cfg) {
        if (app.project === null) { alert("没有打开的项目。"); return; }
        var comp = app.project.activeItem;
        if (comp === null || !(comp instanceof CompItem)) {
            alert("请先激活一个合成。"); return;
        }
        var sel = comp.selectedLayers;
        if (sel.length === 0) {
            alert("请先在时间线中选中至少 1 个要加果冻盒的图层。"); return;
        }

        app.beginUndoGroup(SCRIPT_NAME + ": Create Jelly Box");
        var report = { boxes: 0, warnings: [] };
        var i;
        try {
            for (i = 0; i < sel.length; i++) {
                var target = sel[i];
                var anchor = [0, 0];
                try {
                    anchor = target.property("ADBE Transform Group").property("ADBE Anchor Point").value;
                } catch (eA) { anchor = [0, 0]; }
                cfg.ax = anchor[0];
                cfg.ay = anchor[1];
                createJellyBox(comp, target, cfg, report);
            }
        } catch (eMain) {
            report.warnings.push("执行异常：" + eMain.toString());
        }
        app.endUndoGroup();

        var msg = "完成：创建 " + report.boxes + " 个果冻盒。";
        if (report.warnings.length > 0) {
            var max = Math.min(report.warnings.length, 6);
            msg += "\n---- 提示 " + report.warnings.length + " 条 ----";
            for (var w = 0; w < max; w++) { msg += "\n" + report.warnings[w]; }
            if (report.warnings.length > max) { msg += "\n…… 其余从略"; }
        }
        alert(msg, SCRIPT_NAME);
    }

    function doRemove() {
        if (app.project === null) { alert("没有打开的项目。"); return; }
        var comp = app.project.activeItem;
        if (comp === null || !(comp instanceof CompItem)) {
            alert("请先激活一个合成。"); return;
        }
        app.beginUndoGroup(SCRIPT_NAME + ": Remove Jelly Boxes");
        var removed = 0;
        var i;
        try {
            for (i = comp.numLayers; i >= 1; i--) {
                var lay = comp.layer(i);
                if (lay.name.indexOf(PFX + " Jelly - ") === 0) {
                    lay.remove();
                    removed++;
                }
            }
        } catch (eR) {
            alert("移除异常：" + eR.toString(), SCRIPT_NAME);
        }
        app.endUndoGroup();
        alert("已移除 " + removed + " 个果冻盒（目标图层不受影响）。", SCRIPT_NAME);
    }

    // ------------------------------------------------------------------
    // UI（ScriptUI，可停靠）
    // ------------------------------------------------------------------
    function buildUI(thisObj) {
        var win = (thisObj instanceof Panel) ? thisObj : new Window("palette", SCRIPT_NAME, undefined, { resizeable: true });
        win.orientation = "column";
        win.alignChildren = ["fill", "top"];
        win.spacing = 6;
        win.margins = 12;

        win.add("statictext", undefined, SCRIPT_NAME + " v" + SCRIPT_VER + "（clean-room）");
        var tip = win.add("statictext", undefined, "选中图层 → 创建果冻盒（父级跟随 + 速度弹簧）。");
        tip.graphics.foregroundColor = tip.graphics.newPen(win.graphics.PenType.SOLID_COLOR, [0.5, 0.5, 0.5], 1);

        var row1 = win.add("group");
        row1.orientation = "row";
        row1.add("statictext", undefined, "内边距(px):");
        var etPad = row1.add("edittext", undefined, "10");
        etPad.characters = 5;
        row1.add("statictext", undefined, " 增益:");
        var etGain = row1.add("edittext", undefined, "60");
        etGain.characters = 5;

        var row2 = win.add("group");
        row2.orientation = "row";
        row2.add("statictext", undefined, "最大幅度%:");
        var etAmp = row2.add("edittext", undefined, "25");
        etAmp.characters = 5;
        row2.add("statictext", undefined, " 刚度:");
        var etK = row2.add("edittext", undefined, "120");
        etK.characters = 5;
        row2.add("statictext", undefined, " 阻尼:");
        var etC = row2.add("edittext", undefined, "9");
        etC.characters = 5;

        var gBtn = win.add("group");
        gBtn.orientation = "row";
        var btnGo = gBtn.add("button", undefined, "Create 创建", { name: "ok" });
        var btnRm = gBtn.add("button", undefined, "Remove 移除");

        var note = win.add("statictext", undefined, "ES3；盒=父级跟随，scale=Verlet 弹簧（速度驱动）。");
        note.graphics.foregroundColor = note.graphics.newPen(win.graphics.PenType.SOLID_COLOR, [0.5, 0.5, 0.5], 1);

        btnGo.onClick = function () {
            try {
                doCreate({
                    padding: toNum2(etPad.text, 10, 0),
                    gain: toNum2(etGain.text, 60, 0),
                    maxAmp: toNum2(etAmp.text, 25, 1),
                    stiffness: toNum2(etK.text, 120, 0),
                    damping: toNum2(etC.text, 9, 0)
                });
            } catch (e) {
                alert("Create 失败: " + e.toString());
            }
        };
        btnRm.onClick = function () {
            try { doRemove(); } catch (e2) { alert("Remove 失败: " + e2.toString()); }
        };

        win.layout.layout(true);
        if (win instanceof Window) {
            win.center();
            win.show();
        }
        return win;
    }

    buildUI(thisObj);

})(this);
