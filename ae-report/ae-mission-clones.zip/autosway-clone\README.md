---
generated_at: 2026-11-14T07:18:00+08:00
task: clean-room 复刻 AutoSway 核心功能（弹簧摆动链），ExtendScript jsx 实现；输入 = intel/paid-list.md 的 AutoSway 条目（功能性描述），不反编译不参考原代码
---

# AS Spring Clone（AutoSway 风格弹簧摆动链 · clean-room 复刻）

- 产出：`main.jsx`（ExtendScript，ES3）
- 输入依据：`C:\Users\19894\ae-mission\intel\paid-list.md` 第 6 条 AutoSway [A类] 的**功能性描述**（二次运动弹簧绑定 / 图层链传导 / stiffness·amplitude·decay·权重·风力参数）
- 实现方式：欠阻尼弹簧微分方程 **Verlet（Störmer-Verlet）离散化** + AE 内置 `valueAtTime` 前帧状态递推，全部独立推导

## CLEAN-ROOM 声明

1. 本复刻为清室实现：未反编译、未阅读、未复制 AutoSway 原始代码，仅依据公开的商品页功能描述与通用物理/数值计算知识从零编写。
2. 表达式核心为公开数学（Verlet 积分）与 AE 表达式通用惯例（`thisProperty.valueAtTime` 采样自身前帧），不构成对原作品表达性内容的复制。
3. 仅供学习研究；AutoSway 商标与著作权归其原作者所有。如需完整功能与支持，请购买正版（aescripts.com，$39.99）。

## 功能对照（复刻范围）

| AutoSway 功能点（paid-list 描述） | 本复刻状态 | 说明 |
|---|---|---|
| 对图层/形状点添加二次运动（摆尾/弹簧） | ✅ 已实现（图层级） | 旋转（2D rotation / 3D zRotation）与 2D 位置两种模式 |
| 选中按顺序的图层 → 一键生成表达式链，上级运动滞后传导 | ✅ 已实现 | 按时间线图层顺序（自上而下=根→梢）成链；子层目标 = 自身 Base + 风力 + 父层摆动量 × Inherit%，滞后由弹簧自然产生 |
| stiffness 刚度 | ✅ `AS: Stiffness` | k，欠阻尼时振荡频率 ∝ sqrt(k/m) |
| decay 衰减 | ✅ `AS: Damping` | c；c=0 等幅振荡，c 越大衰减越快 |
| amplitude 振幅 | ✅ `AS: Wind Strength` | 风力摆幅（旋转=度 / 位置=像素） |
| 风力方向 | ⚠️ 简化 | 旋转模式以 Strength 正负号控制方向；位置模式风沿 X 轴 |
| 按段权重 | ✅ `AS: Inherit` | 链上每层独立的传导权重（0–100+） |
| 质量 | ✅ `AS: Mass` | 原条目未列，按弹簧方程补齐 |
| 手动驱动 | ✅ | 给 `AS: Base`（Angle）/ `AS: Base Pos`（Point）打关键帧即为目标驱动，脚本自动把原旋转/位置状态迁入 Base |
| 生成控制 Null | ❌ 未实现 | 控制直接挂在图层效果上（Slider/Angle/Point/Checkbox），不生成额外 Null |
| 形状点（puppet pin/路径点）链 | ❌ 未实现 | 基线仅做图层链；形状点链为后续扩展 |
| 重力 | ❌ 未实现 | 可用恒定 Base 偏移近似 |

## 安装

- 方式 A（推荐，可停靠面板）：把 `main.jsx` 放入 AE 脚本面板目录：
  - Windows：`C:\Program Files\Adobe\Adobe After Effects <版本>\Support Files\Scripts\ScriptUI Panels\`
  - 重启 AE，菜单 `Window`（窗口）底部出现 `AS Spring Clone.jsx`
  - 若想允许脚本写文件/网络，需在 `Edit > Preferences > Scripting & Expressions` 勾选 Allow Scripts to Write Files and Access Network（本脚本不需要，但面板化运行一般无碍）
- 方式 B（直接运行）：AE 菜单 `File > Scripts > Run Script File...` 选择 `main.jsx`，弹出浮动面板。

## 使用

1. 时间线中按**自上而下**顺序选中图层（最上层 = 链根；根层受风力/自身 Base 驱动，下层依次跟随）。
2. 面板选择模式（Rotation/Position）、链深度（0=全部选中层）、默认参数、频率单位（按秒/按帧）。
3. 点 **Apply 应用**：每层自动添加 `AS:*` 系列效果并写入弹簧表达式（整体包在一个 Undo 组，Ctrl+Z 可整体撤销）。
4. 调节：直接在效果控件里改 Stiffness/Damping/Mass/Wind Strength/Wind Frequency/Inherit（每层独立）。
5. 点 **Remove 移除**：清除表达式并删除所有 `AS:*` 效果。

### 参数速查

| 效果 | 含义 | 默认 |
|---|---|---|
| AS: Stiffness | 弹簧刚度 k | 150 |
| AS: Damping | 阻尼 c（欠阻尼判据 c < 2·sqrt(k·m)） | 8 |
| AS: Mass | 质量 m | 1 |
| AS: Wind Strength | 风力振幅（负值=反向） | 8 |
| AS: Wind Frequency | 风频（按秒=Hz / 勾选 Freq per Frame 后=周期/帧） | 0.5 |
| AS: Freq per Frame | 频率单位切换（Checkbox） | 关 |
| AS: Inherit | 子层继承父层摆动量比例 % | 60 |
| AS: Safety | 单帧位移钳制（稳定性保险丝，度/像素） | 30 |
| AS: Memory | 弹簧历史采样帧数上限（=递归深度上限） | 120 |
| AS: Base / Base Pos | 目标值（含关键帧迁移），手动驱动入口 | 迁移自原属性 |

## 数学原理（自行推导）

欠阻尼弹簧 ODE：`m·x'' = k·(target − x) − c·x'`

Verlet 离散化（每帧 dt，仅用位置历史，无需存储速度）：

```
v[n-1]   = (x[n-1] − x[n-2]) / dt
x[n]     = 2·x[n-1] − x[n-2] + (dt²/m) · ( k·(target − x[n-1]) − c·v[n-1] )
```

- 表达式用 `thisProperty.valueAtTime(t − n·dt)` 取自身前两帧状态递推；起步 2 帧与超出 Memory 帧数时退化为静态目标。
- **数值稳定域**：特征根稳定性要求 `a + 2b < 4`（a = k·dt²/m，b = c·dt/m）。表达式自动收缩：`k2 = min(k, 2.25·m/dt²)`，再把 `b` 限到 `(3.6 − a)/2`（留 0.4 裕量），任何极端参数均有界收敛。
- 位置模式对 [x, y] 逐维执行同一递推。

## 自查记录（2026-11-14）

1. `node --check`：通过（复制为 .js 后检查；.jsx 扩展名 node 不识别）。
2. ES3 扫描（排除注释行）：`let/const/箭头函数/JSON.stringify/模板串/forEach/map/filter/includes/for-of` 均无命中。
3. Verlet 数学独立仿真（与表达式逐字一致的 Node 复算，25/60fps）：

| 用例 | 结果 |
|---|---|
| T1 欠阻尼 k150/c8/m1 → 阶跃目标 30° | 收敛到 30.000，29 次过冲穿越（振荡衰减）✅ |
| T2 过阻尼 c30 | 无过冲，收敛 ✅ |
| T3 极端刚度 k5000/c0.5/m0.1 | 稳定域钳制后有界、收敛 ✅ |
| T3b 超大刚度 k50000 | 与 T3 一致（钳制生效）✅ |
| T3c 超大阻尼 c1000 | 联合钳制后无过冲收敛（修复前曾边界失稳）✅ |
| T3d 零阻尼 c0 | 等幅振荡不衰减（物理正确）、有界无 NaN ✅ |
| T6 持续风摆 sin 激励 | 有界受迫振荡、幅值跟随风力 ✅ |
| T5 60fps | 收敛，帧率无关性良好 ✅ |

## 限制（如实说明）

1. **未在 AE 实机测试**：本环境无 After Effects。语法/ES3/数学已验证，但 AE 内表达式求值行为（尤其 `thisProperty.valueAtTime` 递归开销、新旧 JS 引擎差异）需实机复核后再交付使用。
2. 缓动曲线不迁移：旋转/位置的既有关键帧会复制到 Base（时间+值），但 ease 曲线丢失；如需原缓动请改为手动驱动 Base。
3. 位置模式不支持 3D 图层（Point 控件为 2D）；3D 层请用旋转模式（zRotation）。
4. 性能：链式 + 历史递推最坏 O(帧数×Memory)；长合成建议 Memory ≤ 120，或烘焙关键帧（选中属性 `Animation > Keyframe Assistant > Convert Expression to Keyframes`）。
5. 与 AE 原生父子绑定（parent）同用时，位置模式在父层坐标系解释，语义可能偏移；建议链用表达式传导、不要再叠 parent。
6. 极端参数会被自动软化到数值稳定域（见数学原理），此时实际刚度/阻尼低于设定值——这是数值稳定性的代价。
7. 撤销以 Undo 组包裹；效果命名带 `AS:` 前缀，不会与正版 AutoSway 或其他脚本冲突。
