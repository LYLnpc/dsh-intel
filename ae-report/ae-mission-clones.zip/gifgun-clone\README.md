# GifGun Clone —— GifGun 核心功能（一键 GIF 导出）的 clean-room 复刻

> **CLEAN-ROOM 声明**：本项目为依据功能需求描述（`intel/paid-list.md` 第 5 条
> "GifGun"）从零独立编写的复刻实现。编写过程中未反编译原插件，未阅读、复制或
> 改写原插件的任何源代码、字节码或资源文件；仅依赖 Adobe After Effects 公开
> 脚本 API 与 ffmpeg 公开命令行用法。与原产品的相似性仅来自功能需求本身。

- 原品：GifGun 2（Nik Ska，aescripts，$39.99，jsx 面板）
- 复刻：`main.jsx`（ExtendScript / ES3，单文件，约 500 行）
- 定位：选中合成一键导出高质量 GIF。技术路线 =
  **AE 渲染队列输出 PNG 序列 → 系统 ffmpeg（palettegen/paletteuse 两遍法）合成 GIF**，
  这是无 C++ 依赖的唯一可行复刻路径（复刻要点与情报条目一致）。

---

## 一、功能对照表

### 已复刻

| 功能 | 说明 |
|------|------|
| 一键 GIF 导出 | 活动合成 → 渲染队列 PNG 序列 → ffmpeg 两遍法 → GIF，全自动串联 |
| 范围选择 | 「仅渲染工作区」复选框：工作区（workAreaStart/Duration）或全时长，经 `timeSpanStart/timeSpanDuration` 自定义渲染跨度 |
| 帧率参数化 | fps 滑杆 8–30；渲染按合成原始帧率出序列，GIF 帧率经 ffmpeg `fps` 滤镜抽帧实现（不改动用户合成） |
| 输出尺寸 | 「最大宽度」：超过合成宽度则取合成宽度；`scale={W}:-2:flags=lanczos`（高 lanczos 重采样，高度自适应偶数） |
| 质量参数化 | 质量 1–5 映射：调色板颜色数（256/128/64）+ 抖动方式（高质量 `sierra2_4a`、中低质量 `bayer` 不同 scale） |
| 高质量两遍法 | `palettegen=stats_mode=diff`（面向运动内容生成全局调色板）→ `paletteuse` 应用，GIF 色彩质量显著优于单遍 `-vf` 直转 |
| 循环设置 | `-loop 0` 无限循环（GIF 标准行为） |
| PNG 序列输出 | 渲染队列项 + 输出模块模板自动匹配（优先含 "png" 的模板，其次任意序列模板），找不到模板时给出明确指引；输出文件用 `[#####]` 帧号模式写入临时目录 |
| ffmpeg 检测 | 三级自动检测：用户指定路径 → 脚本同目录（ffmpeg.exe/ffmpeg）→ 系统 PATH（`ffmpeg -version` 响应校验）；支持手动指定路径（UI 输入框） |
| 降级方案 | ffmpeg 缺失：保留 PNG 序列帧、弹窗给出手动转换命令行与下载指引、自动打开帧目录 |
| 输出目录 | 默认工程文件所在目录（未保存则桌面），可浏览选择；GIF 同名自动追加 `_1/_2` 防覆盖 |
| 进度状态行 | 各阶段状态（检测 ffmpeg → 渲染序列 → 两遍合成 → 完成/失败） |
| 完成后自动打开输出目录 | `Folder.execute()`，失败回退 `explorer`/`open` |
| 面板常驻 | `#targetengine session` + `Panel`/`palette` 双模式（放 ScriptUI Panels 目录即常驻面板） |
| 设置记忆 | fps/宽度/质量/输出目录/工作区/保留帧/ffmpeg 路径经 `app.settings` 持久化 |
| 中间帧管理 | 成功后默认清理临时序列帧；「保留序列帧」可保留 |
| ES3 兼容 | 无 let/const/箭头函数/模板字符串/JSON/ES5 数组方法；全部逐段 try/catch 降级 |

### 未复刻（与原品的差距）

| 功能 | 状态 | 说明 |
|------|------|------|
| WEBP / WEBM / MP4 多格式导出 | 未复刻 | 本次范围仅 GIF；扩展只需替换 ffmpeg 输出参数 |
| dither 抖动方式手动选择 | 未复刻 | 由质量滑杆间接映射，不做独立下拉 |
| loop 循环次数设置 | 未复刻 | 固定无限循环 |
| 后台渲染不锁 AE | 未复刻 | 本复刻用同步 `renderQueue.render()`（AE 自带渲染进度可见），渲染/合成期间 UI 冻结 |
| 队列管理 / 批量导出 | 未复刻 | 单合成单次导出 |
| 快捷键 / KBar 触发 | 未复刻 | 面板按钮触发 |
| 输出命名模板 | 未复刻 | 固定 `合成名.gif`（重名自动加序号） |

---

## 二、安装

### 1. 本脚本

两种方式任选：

1. **面板常驻（推荐，同 GifGun 体验）**：把 `main.jsx` 复制到
   - Windows: `C:\Program Files\Adobe\Adobe After Effects <版本>\Support Files\Scripts\ScriptUI Panels\`
   - macOS: `/Applications/Adobe After Effects <版本>/Scripts/ScriptUI Panels/`
   重启 AE，在 `Window` 菜单底部找到 "GifGun Clone.jsx" 勾选。
2. **直接运行**：`File > Scripts > Run Script File...` 选 `main.jsx`（弹出独立小窗）。

### 2. ffmpeg（必需，缺失时降级为仅出序列帧）

- **下载**：
  - 官方镜像页：https://ffmpeg.org/download.html
  - Windows 推荐：https://www.gyan.dev/ffmpeg/builds/（release full 版，解压即用）
  - Windows 备选：https://github.com/BtbN/FFmpeg-Builds/releases
  - macOS：`brew install ffmpeg`
- **放置**（三选一，脚本按此顺序自动检测）：
  1. 把 `ffmpeg.exe`（Windows）/ `ffmpeg`（macOS）放到 **脚本 main.jsx 同目录**；
  2. 加入系统 **PATH**（命令行输入 `ffmpeg -version` 有输出即可）；
  3. 在面板 "ffmpeg路径" 输入框填写完整路径（留空=自动检测）。
- **验证**：命令行运行 `ffmpeg -version`，能打印版本号即成功。

---

## 三、使用步骤

1. 在 AE 项目面板**双击打开**（或选中）要导出的合成。
2. 打开 GifGun Clone 面板；如需只导出工作区段落，在 AE 时间线设好工作区并勾选「仅渲染工作区」。
3. 设置 GIF 帧率（8–30 fps，默认 15）、最大宽度（默认 640px，超过合成宽度自动取合成宽度）、质量（1–5，默认 4）。
4. 确认输出目录（默认工程目录/桌面）与 ffmpeg 路径（一般留空自动检测）。
5. 点 **一键导出 GIF**：
   - AE 弹出自带渲染进度（渲染 PNG 序列，按合成原始帧率，约 `时长×帧率` 帧）；
   - 随后 ffmpeg 两遍合成（面板状态行提示第一遍/第二遍）；
   - 完成后自动打开输出目录，状态行显示成品信息。
6. 一次 Ctrl+Z 可撤销渲染队列项的添加（GIF 文件不受影响）。

### 两遍法命令（脚本实际生成，供手动复现/排错）

```bash
# 第一遍：生成全局调色板（随 fps 抽帧与缩放链）
ffmpeg -y -hide_banner -loglevel error -framerate {合成帧率} -i frame_%05d.png \
  -vf "fps={GIF帧率},scale={最大宽度}:-2:flags=lanczos,palettegen=max_colors={颜色数}:stats_mode=diff" palette.png

# 第二遍：应用调色板生成 GIF
ffmpeg -y -hide_banner -loglevel error -framerate {合成帧率} -i frame_%05d.png -i palette.png \
  -filter_complex "[0:v]fps={GIF帧率},scale={最大宽度}:-2:flags=lanczos[x];[x][1:v]paletteuse={抖动方式}" \
  -loop 0 合成名.gif
```

质量映射：q≥4 → 256 色 + `sierra2_4a`；q=3 → 256 色 + `bayer:bayer_scale=3`；
q=2 → 128 色 + `bayer:bayer_scale=4`；q≤1 → 64 色 + `bayer:bayer_scale=5`。

---

## 四、已知限制

1. **同步阻塞**：渲染与 ffmpeg 调用期间 AE UI 冻结（渲染时 AE 自带进度可见）；
   原品的"后台渲染不锁 AE"未复刻。
2. **渲染队列遗留**：脚本无法用公开 API 移除渲染队列项，每次导出会在队列里留下
   一个已渲染项，需手动清理。
3. **已有排队项会被一并渲染**：`renderQueue.render()` 会渲染队列中所有"已排队"
   项；导出前请清空或取消勾选其他排队项（完成提示中会注明）。
4. **时间跨度依赖**：通过 `timeSpanStart/timeSpanDuration` 自定义渲染跨度；
   若个别 AE 版本该设置被渲染设置模板覆盖导致渲染全时长，请在
   `编辑 > 模板 > 渲染设置` 中自定义时间跨度后重试。
5. **输出模块模板依赖**：需要工程中存在 PNG Sequence 类输出模块模板（AE 默认
   自带）；全部缺失时自动回退尝试默认模块，仍失败会弹出指引。
6. **ffmpeg 检测原理**：以 `callSystem` 输出中包含 "ffmpeg version" 判定；
   极端环境（输出重定向异常）可能误判，可在输入框手动指定完整路径绕过。
7. **抽帧精度**：GIF 帧率经 `fps` 滤镜均匀抽帧，与合成原始帧率非整数倍时
   相邻帧间隔会有 ±1 原帧的抖动（GIF 的通用现象）。
8. **GIF 格式本身**：无音频、256 色上限；透明边缘可能出现白/黑边（调色板法
   已尽量缓解，属格式限制）。
9. **性能**：长合成/高帧率合成会渲染大量 PNG（时长×合成帧率），磁盘占用与
   渲染时间线性增长；建议配合「仅渲染工作区」使用。

---

## 五、自查结果（编写期已完成）

| 检查项 | 结果 |
|--------|------|
| `node --check`（剥离 `#targetengine` 行后） | 通过 |
| 真尾逗号（对象/数组字面量末尾逗号） | 0 处 |
| ES3 特征扫描 | 干净（仅头部注释文字提及"let/const"；3 处 `.indexOf(` 均为 `String.indexOf`，ES1/ES3 合法；无 `Array.prototype.indexOf`，数组查找用手写循环） |
| 保留字作标识符扫描 | 干净 |
| 编码 | UTF-8 带 BOM（中文 Windows 下 ExtendScript 无 BOM 会按系统码页误读中文字符串） |

> 说明：本机无 After Effects 与 ffmpeg 运行环境，以上为静态自查；建议按
> 「使用步骤」在 AE 中做一次冒烟测试（短合成 + 工作区 + 各质量档）。

---

## 六、冒烟测试建议（AE 中）

1. 建 5 秒 30fps 合成（含运动图形），设 2–3 秒工作区。
2. 勾选「仅渲染工作区」，fps=15、宽度=640、质量=4 → 导出：
   应得到约 45 帧的 GIF（15fps × 3s），尺寸 640px 等比，无限循环。
3. 质量=1 与质量=5 各导一次对比色彩/抖动差异与文件大小。
4. 把 ffmpeg 从脚本目录/PATH 移除后再导出：应降级为仅序列帧 + 弹窗指引 + 自动打开帧目录。
5. 输出到已存在同名 GIF 的目录：应自动生成 `名字_1.gif` 而非覆盖。
6. 渲染队列里预先放一个其他合成排队项：完成提示应注明"队列原有 1 个已排队项也被一并渲染"。
