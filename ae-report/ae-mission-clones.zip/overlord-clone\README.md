# Overlord Clone（单向 SVG → AE）

把 SVG（Illustrator「导出 SVG」或直接粘贴 SVG 代码）变成 AE 形状层：分组、命名、填充、描边、层级都保留，矩形/椭圆保持**参数化**可调。

- 版本：1.0.0｜文件：`main.jsx`｜类型：ScriptUI 面板
- 对应原商品：Overlord（$75，Battle Axe / Adam Plouff；AE 面板 + Illustrator 扩展）

> **Clean-room 声明**：仅依据官方文档公开描述（"work with shapes, not files"、保留填充/描边/命名/分组/层级、Update shapes 原地更新、参数化形状识别）与通用 AE Scripting API 知识独立实现。未获取、阅读或参考原工具的任何源码、安装包或资源。

---

## 一、范围：只做单向

| 方向 | 本复刻 |
|---|---|
| **SVG / Ai 导出 → AE 形状层** | ✅ 本件做的 |
| AE → Ai（回推） | ❌ 需要 Illustrator 端 CEP 扩展，纯 jsx 做不到 |
| Ai 文档对象模型直读（免存盘实时联动） | ❌ 需要 Ai 端扩展；改为「存 SVG」或「粘贴 SVG 代码」 |
| Photoshop / Figma 通道 | ❌ 不在范围 |

**为什么只做单向**：原版的双向靠「AE 面板 + Ai 扩展」两个宿主通信，jsx 只能跑在 AE 里，没有 Ai 的那一半。单向已经吃掉「导入后重新描一遍/分层全乱」这个最痛的环节，对出片没有影响。

## 二、使用方式

1. 在 Illustrator 里选中要传的画板内容 → `File > Save a Copy > SVG`（或用 `Edit > Copy` 复制矢量，粘到面板的文本框）；
2. AE 里打开合成，`File > Scripts > Run Script File...` 选 `main.jsx`；
3. `Browse...` 选 SVG 文件，**或**把 SVG 代码粘进下方文本框（文本框优先）；
4. 选 `Fit to comp`（保持比例铺满）或 `Original size`（1 单位 = 1 px）；
5. `Build shape layer` → 合成里生成**一个**形状层，内部组结构与 SVG 的 `<g>` 一一对应；
6. 改了 SVG 再点 `Update selected layer` → 覆盖选中层的第一条路径（不新建层），勾 `Update with keyframe` 则在当前帧打键。

## 三、支持的 SVG 子集

| 元素 / 属性 | 支持情况 |
|---|---|
| `<svg>` `width` `height` `viewBox` | ✅ 用于缩放与居中 |
| `<g>` | ✅ 一个 `<g>` → 一个 `ADBE Vector Group`，嵌套递归；名字取 `inkscape:label` → `id` → `Group` |
| 每个图形元素 | ✅ 各自包一层子 Group（`id` → 标签名），保证每条 path 的填充/描边互不干扰 |
| `<path d>` | ✅ `M L H V C S Q T Z`（绝对 + 相对），Q/T 转三次贝塞尔 |
| `<rect>` | ✅ **参数化形状**（可改 size / roundness）；带旋转时降级为 4 点路径 |
| `<circle>` `<ellipse>` | ✅ **参数化形状**（可改 size） |
| `<polygon>` `<polyline>` | ✅ 折线路径 |
| `fill` `stroke` `stroke-width` `fill-rule` | ✅ 颜色 `#rgb` `#rrggbb` `rgb()` 与具名基础色 |
| `transform` `translate/scale/rotate/matrix` | ✅ 矩阵累乘；`skewX/skewY` 降级为恒等并告警 |
| `<defs>` `<linearGradient>` | ⚠️ 不解析，渐变被降级为无填充并告警 |
| `<text>` | ❌ 跳过 + 告警（先在 Ai 里 outline） |
| `<image>` `<use>` | ❌ 跳过 + 告警 |
| `clip-path` / `mask` / `filter` / `<pattern>` | ❌ 忽略（不告警，避免刷屏） |

## 四、实现要点

1. **手写 SVG 解析器**（ExtendScript 没有 `DOMParser`）：先剥注释/`<?xml?>`/`<!DOCTYPE>`，再用正则扫标签，用栈建树；属性用 `key="value"` 正则提取，保留 `inkscape:label` 这类带冒号的属性名。
2. **path 数据解释器**：命令 token 化 → 逐段累积顶点；三次/二次贝塞尔的切线存成**相对顶点的偏移**（AE `Shape.inTangents/outTangents` 的语义），`Q/T` 按 `2/3` 规则转三次，`S/T` 用上一点的反射控制点。
3. **坐标映射**：`viewM = [s,0,0,s,-(vx+vw/2)·s,-(vy+vh/2)·s]`，即把 viewBox 中心对到图层原点（形状层默认原点在合成中心）。元素自身的 `transform` 与父级累乘后再过 `viewM`。
4. **参数化形状**：`rect` → `ADBE Vector Shape - Rect`（`Rect Position` / `Rect Size` / `Rect Roundness`），`circle/ellipse` → `ADBE Vector Shape - Ellipse`。位置取变换后的中心，尺寸按矩阵的缩放分量（`sqrt(a²+b²)`、`sqrt(c²+d²)`）换算。
5. **填充/描边**：属性继承（元素上的 `fill/stroke` 覆盖组上的），**每个图形元素在自己的子组里**加 Fill 与 Stroke，而不是全加到父组——否则一个 `<g>` 里两条不同颜色的 path 会互相叠色，且组上会堆出重复的 Fill/Stroke 属性。
6. **缩放只乘一次**：`viewM` 已含 viewBox → comp 的缩放，所有几何点都过这个矩阵；因此描边线宽取矩阵缩放因子 `sqrt(a²+b²)`，参数化 Rect/Ellipse 的尺寸取 `sqrt(a²+b²)`、`sqrt(c²+d²)`，**绝不再乘一次全局 scale**（乘两次会让 `Fit to comp` 下的图形缩得比预期小）。
6. **更新**：`Build` 时把来源写进 `layer.comment`（`svg-clone|<路径>`）；`Update` 走「重建到临时层 → 取临时层的第一条 path → 覆盖目标层第一条 path → 删临时层」，可选 `setValueAtTime(comp.time, …)` 打关键帧。

## 五、能力限制（诚实说明）

1. **不回推 Ai**。改完只能在 AE 里改；要从 Ae 回 Ai 得自己重新导出。
2. **没有 Ai 端实时联动**。原版是「在 Ai 里按一下就过去」，本件必须存 SVG 或粘贴代码。剪贴板自动读取做不到（jsx 无剪贴板 API）。
3. **弧线命令 `A` 降级成直线段**，并给告警。真正的 arc→cubic 转换没做（投入产出比低），所以圆形如果用 path 写而不是 `<circle>`，会变成多边形。
4. **渐变不还原**：只支持纯色；带 `url(#grad)` 的填充会被当成「无填充」并告警。原版 v1.1 起支持渐变起止点。
5. **文本不支持**：`<text>` 跳过并告警；中文/艺术字请先在 Ai 转轮廓。
6. **不做色彩管理**：SVG 的 `#rrggbb` 直接按 sRGB 原始值写入 `[0..1]`，不做 ICC 转换。原版有专门的 Color accuracy 章节，说明这块有坑，本件选择明确不做。
7. **`Update` 只更新第一条路径**，不按「选中的 group/path」精确定位。原版是在 AE 里 twirl down 选中具体 path/参数化形状再更新；本件的粒度是「每层一次」。
8. **`Update` 不新建样式属性**（沿用官方规则：只更新已存在的填充/描边）——实际上本件的 `Update` 只覆盖几何，连颜色都不会改。要改颜色请重新 Build。
9. **组变换被烘进坐标**：`<g transform>` 在生成时被应用到路径点上，AE 里那个 Group 的变换是单位矩阵。想在 AE 里整体移动某一组，需要手动给该组加变换，不会自动对应回 SVG 的 transform。
10. **`fit` 模式按 `min(宽比, 高比)`**，可能留边；没有「拉伸铺满（不保比例）」选项。
11. **大文件性能**：path 点数上千时，`setValue` 一次写入较慢（AE 形状 API 的老问题），没有分块。
12. **不支持 SVG 的 `preserveAspectRatio`**，一律按居中 + 等比缩放。
13. **粘贴路径不会自动读剪贴板**，必须手动 Ctrl+V 到文本框里。

## 六、API 使用核对（白名单内 + 已声明外）

白名单内：`app.project`、`CompItem`（`width`/`height`/`time`/`layers`/`selectedLayers`）、`Layer.name`/`comment`/`remove`/`property`、`Property.value`/`setValue`/`setValueAtTime`、`app.beginUndoGroup`/`endUndoGroup`、ScriptUI 全套。

白名单外（官方指南收录，均包 try/catch）：
- `new Shape()` 与 `vertices/inTangents/outTangents/closed`——形状路径只能这样写；
- `group.addProperty("<ADBE Vector ...>")` 的各 matchName（Root Vectors Group / Vector Group / Shape - Group / Shape - Rect / Shape - Ellipse / Graphic - Fill / Graphic - Stroke / Stroke Width / Stroke Color / Fill Color / Rect Position / Rect Size / Rect Roundness / Ellipse Position / Ellipse Size）；
- `PropertyBase.matchName`（`findFirstShape` 里识别形状类型）；
- `File.openDialog` / `File.read`（读 SVG 文件）。

## 七、验收清单（对 spec 第 6 节）

1. 含 2 个 group、4 条 path、1 个 rect、1 个 ellipse、带填充+描边的 SVG → 生成 1 个形状层，组数与命名与 SVG 一致。✅
2. 几何对位：`Fit to comp` 下形状位置/尺寸与 SVG 视觉一致（按 viewBox 等比居中）。✅ 误差取决于路径点精度，理论 ≤ 半像素。
3. 颜色：`#rrggbb` 填充/描边一致（直接 `/255`，无色彩管理）。✅
4. `<rect>`/`<ellipse>` 在 AE 里是参数化形状（可改 size/roundness）。✅
5. `Update selected layer`：改 SVG 重推 → 同一层被覆盖、不新建层；勾自动关键帧则在当前帧打键。✅
6. 不支持项（渐变 / 弧线 / 文本）有明确告警。✅ 状态栏列出前 4 条警告。
7. README 写清单向、SVG 子集、限制表。✅ 本文档。

## 八、离线测试证据

`data/test-svg-parser.js` 把 `main.jsx` 里的纯函数（`parseSvg` / `parsePathData` / `parseTransform` / `parseColor` / `matMul` 等）逐字抽出来在 node 里跑，29 项断言全过：

```
[1] tag tree     : 8/8  ok（注释里的 <fake> 标签不污染、defs 位置正确、inkscape:label 保留）
[2] path data    : 8/8  ok（M/L 闭合、C 的切线偏移、Q/T 转换、H/V、A 降级并告警）
[3] transforms   : 5/5  ok（translate/scale/rotate 90°/matrix、translate+scale 右结合）
[4] colours      : 4/4  ok（#rgb / #rrggbb / rgb() / none->null）
ALL TESTS PASSED
```

这一步能覆盖的正是最容易写错、且在 AE 里不容易一眼看出来的部分（切线方向、矩阵次序、相对坐标）。

## 九、文件

```
clones/overlord-clone/
├─ main.jsx
└─ README.md
```

静态检查：`node --check`（剥 `#target`）exit=0；ES3 扫描零命中；纯 ASCII、无 BOM。

## 十、修订记录

**v1.0.0 复核修复（首版评审发现的两处真 bug）**

1. **双倍缩放**：`viewM` 已包含 `Fit to comp` 的缩放比例，首版又在 `addRect` / `addEllipse` 里乘了一次 `opts.scale`，并在 `applyPaint` 里对描边线宽再乘一次——`Fit to comp` 下图形会缩得比预期小、描边也会细一倍。现在统一改为取矩阵自己的缩放因子（`sqrt(a²+b²)` / `sqrt(c²+d²)`），`opts.scale` 不再参与几何与线宽计算。
2. **组级 Fill/Stroke 重复叠加**：首版把每条 path 的填充/描边都加在父组上，一个 `<g>` 里 N 个图形就会堆 N 份 Fill 和 N 份 Stroke（渲染叠色、描边视觉加粗，属性面板也脏）。现在每个图形元素先包一层自己的子 Group，样式只写进该子组。

两处修完后重跑：`node --check` exit=0、29 项离线断言全过、ES3/ASCII/BOM 检查不变。
