# JNS Clone —— Joysticks 'n Sliders 核心功能复刻（clean-room）

generated_at: 2026-11-13T22:55:00Z
input: ae-mission/intel/paid-list.md 第 7 条（Joysticks 'n Sliders，$39.95，官方商品页全文已核实）
files: main.jsx（ExtendScript 面板脚本，ES3）

---

## 一、Clean-room 声明

本项目为 **clean-room 复刻**：仅依据 `intel/paid-list.md` 中公开商品页的功能性描述（四象限姿势双线性插值、EaseBias 偏置、layer index 引用等**功能层面**的事实）独立实现。未反编译、未下载、未参考 Joysticks 'n Sliders 原脚本的任何源代码、字节码、安装包或资源文件。所有公式、命名约定、UI 布局与工作流设计均为本项目原创。

原脚本版权归 Mike Overbeck / aescripts.com 所有。若复刻版满足不了需求，请支持原版：<https://aescripts.com/joysticks-n-sliders/>

---

## 二、功能对照表

| 原版功能（paid-list 核实） | 本克隆状态 | 说明 |
|---|---|---|
| Joystick：控制器 2D 位置驱动四象限姿势**双线性插值** | ✅ 核心已复刻 | 四角权重 wTL=(1-u)(1-v)、wTR=u(1-v)、wBL=(1-u)v、wBR=uv，权重和恒为 1；出界按边缘钳制 |
| 姿势承载方式：原版为「5 关键帧姿势层 → 一键生成控制器」 | 🔁 改为滑杆角点方案 | 本克隆在 Joy 层上为每个绑定属性生成 4 个角点姿势容器（1D→Slider、2D→Point、3D/4D→分量滑杆），直接调滑杆摆姿势；「选关键帧自动生成」流程未实现 |
| EaseBias 插值偏置曲线（v1.5） | ⚠️ 简化复刻 | Joy 层 0-100 偏置滑杆，值越大 u/v 越向 smoothstep S 曲线混合（中性区更陡）；无原版曲线编辑 |
| 表达式用 layer(index) 引用生成层 | ✅ 同设计 | 生成 `thisComp.layer(N)` 索引引用，防改名断链 |
| Sliders：姿势数量无上限的权重混合 | ❌ 未实现 | 本克隆的滑杆仅作 4 角姿势值容器，不是无限姿势系统 |
| Switch Template（按象限切换素材图层） | ❌ 未实现 | — |
| Path Shape Rigging / Path Flipper（路径顶点绑定，v1.6+） | ❌ 未实现 | 路径（SHAPE 类属性）在选择器中被排除 |
| UI Sliders（合成内可视化滑杆控件层） | ❌ 未实现 | 仅有 Joy 控制层（含边界矩形可视化手柄） |
| Move to Parent / Move to Child（跨 comp 驱动） | ❌ 未实现 | 仅支持同 comp |
| 7 天试用/每 Null 限 4 滑杆等功能墙 | 不适用 | 本克隆无授权系统，无数量限制 |
| 与 Puppet/Limber/Duik 等配合 | 理论可配合 | 表达式绑定与第三方绑定工具正交，未逐一验证 |

---

## 三、实现原理（生成器与表达式骨架）

1. **Setup**（脚本端）：用户选 Joy 层 + 目标属性（属性浏览器多选，或直接用时间线选中属性）+ 边界矩形（合成边界或自定义 L/T/R/B）。
2. **姿势容器**：对每个绑定属性，在 Joy 层效果栈生成 4 个角点效果，命名约定即登记表：
   - 1D 属性：`JNS|<属性名>|TL / TR / BL / BR`（Slider Control）
   - 2D 属性：同上命名（Point Control，一个角点一个点值）
   - 3D/4D 属性：按分量 `JNS|<属性名>~X|TL`…（~Y、~Z、R/G/B/A）
   - 重名自动加 `_2` 后缀；「初始姿势=当前值」勾选时把属性当前值写入四角（中性起步）。
3. **表达式**（写入目标属性，双引擎兼容写法）：

```
// JNS-clone v1.0.0 : bilinear pose blend (clean-room)
var joy = thisComp.layer(2);                       // Joy 层索引引用
var p = joy.toComp(joy.anchorPoint);               // toComp 兼容父级化后的世界坐标
var u = (p[0] - (0)) / (1920);                     // 边界归一化（数值在绑定时固化）
var v = (p[1] - (0)) / (1080);
u = Math.max(0, Math.min(1, u));                   // 出界钳制
v = Math.max(0, Math.min(1, v));
var eb = joy.effect("JNS|EaseBias")(1) / 100;      // 可选偏置
if (eb > 0) { ...smoothstep 混合 u、v... }
var wTL = (1 - u) * (1 - v);
var wTR = u * (1 - v);
var wBL = (1 - u) * v;
var wBR = u * v;
value = wTL*joy.effect("JNS|Scale|TL")(1) + wTR*joy.effect("JNS|Scale|TR")(1)
      + wBL*joy.effect("JNS|Scale|BL")(1) + wBR*joy.effect("JNS|Scale|BR")(1);
```

   效果子属性用 `(1)` 索引引用（不写 "Slider"），避免 AE 界面语言本地化导致断链。2D 点控制 `(1)` 返回 [x,y]，AE 表达式原生支持数组加权求和，1D/2D 共用同一模板。

---

## 四、安装

- **停靠面板（推荐）**：把 `main.jsx` 拷入 AE 安装目录的
  `Support Files\Scripts\ScriptUI Panels\`（Win）或 `Scripts/ScriptUI Panels/`（Mac），重启 AE，从「窗口」菜单底部打开「JNS Clone · Joystick 姿势插值」。
- **临时运行**：AE 菜单 `文件 > 脚本 > 运行脚本文件…` 选 `main.jsx`（浮动窗口）。
- 无需开启「允许脚本写入文件与访问网络」（本脚本不读写磁盘）。

## 五、使用流程

1. 激活目标合成 → 点 **创建 Joy 控制层**：生成 `Joy_Controller` 形状层（黄色矩形=插值边界、白色圆=手柄，位置在边界中心）。
2. 下拉选 **Joy 控制层**（名字含 "joy" 会自动选中）与 **目标图层**。
3. 点 **选属性…** 勾选要绑定的数值属性（可多选）；或直接在时间线选中属性后不勾列表。
4. 边界选「合成边界」或「自定义」（左/上/右/下）。自定义时边界同样可作为 `创建 Joy 控制层` 的矩形范围。
5. 点 **绑定 → 生成表达式**：Joy 层多出 `JNS|...` 角点效果，目标属性挂上表达式。
6. **摆姿势**：选中 Joy 层 → 效果控件调 4 个角点值（如 TL 嘴型闭、BR 嘴型张）。
7. **动起来**：拖动 Joy 层位置，目标属性按双线性权重实时混合。
8. 解绑：时间线选中属性 → **移除选中属性表达式**（JNS| 滑杆效果保留，可手动删）。

---

## 六、已知限制与注意事项

1. **索引引用脆弱性**：表达式用 `layer(N)` 引用 Joy 层（与原版同设计）。删除 Joy 层、或在其上方增删图层导致索引变化，表达式会错位/报错；改图层名不影响。
2. **效果名即契约**：改名/删除 `JNS|` 效果会使对应表达式报错；重复绑定同一属性会生成 `_2` 新滑杆组，需手动清理。
3. **边界为静态数值**：绑定时固化为字面量，不支持随时间变化的边界；Joy 出界按边缘钳制（hold 行为）。
4. **维度支持**：1D/2D/3D/颜色(4D) 数值属性可绑；分离维度位置自动拆成 X/Y 两条 1D 绑定。路径（SHAPE）、文本、标记类不支持——即原版 Path Rigging 不在复刻范围。
5. **同 comp 限制**：Joy 与目标属性必须在同一合成（无跨 comp 引用）。
6. **Joy 层 3D**：插值只用 X/Y（toComp 后取前两个分量），Z 不参与。
7. **本地化**：角点效果名取自属性显示名；在中文版 AE 生成的工程，用其他语言版本打开时若属性名本地化不同，`JNS|缩放|TL` 这类引用仍可用（效果名是我们自定的，不随语言变），但「按属性名匹配」的二次操作（重复绑定去重）建议在同一语言环境完成。
8. **性能**：每属性每帧 4 次效果引用 + 1 次 toComp；大量属性绑定时预览变慢，可先烘焙关键帧再删除表达式。
9. **未实机验证**：开发环境无 After Effects，代码经静态自查（见下），首次使用请先在测试工程试跑；AE 版本间 ScriptUI/表达式行为差异可能需要微调。

---

## 七、自查记录

| 检查项 | 结果 |
|---|---|
| `node --check`（main.jsx 复制为 .js 后） | ✅ SYNTAX_OK（加 UTF-8 BOM 后复验仍通过） |
| ES3 禁用特性扫描（let/const/箭头函数/class/模板字符串/JSON.*、Array.forEach/map/filter/reduce、for-of、Object.keys、Array.isArray、.trim()、async/await、展开运算符、#指令） | ✅ 无命中 |
| 表达式双引擎兼容（无 JSON、无 ES5+ 数组方法、Math.max/min 原生） | ✅ 生成字符串仅用 var/if/Math/数组字面量 |
| AE 实机运行 | ⚠️ 本环境无 AE，未验证 |
