# True Comp Dup Clone —— True Comp Duplicator 的 clean-room 复刻

> **CLEAN-ROOM 声明**：本项目为依据功能需求描述（`intel/paid-list.md` 第 10 条
> "True Comp Duplicator"）从零独立编写的复刻实现。编写过程中未反编译原插件，
> 未阅读、复制或改写原插件的任何源代码、字节码或资源文件；仅依赖 Adobe After
> Effects 公开脚本 API 与需求文档。与原产品的相似性仅来自功能需求本身。

- 原品：True Comp Duplicator（Brennan Chapman，aescripts，$24.99 / NYOP，jsx）
- 复刻：`main.jsx`（ExtendScript / ES3，单文件，约 900 行）
- 定位：把选中合成及其**全部依赖层级树**（嵌套预合成闭包）完整复制为新副本，
  用于模板多版本化（同一套动画做 N 个语言/版本副本）。

---

## 一、功能对照表

### 已复刻

| 功能 | 说明 |
|------|------|
| comp 依赖图构建 | 遍历所有图层，`AVLayer` 且 `source` 为 `CompItem` 的记录为依赖；`FootageItem` 单独收集 |
| 依赖闭包收集 | 从选中 comp（支持多选）出发 DFS 后序遍历，得到"依赖在前"的复制顺序；已访问集合防环 |
| 完整层级树复制 | `items.addComp` 同宽高/像素比/时长/帧率建副本，逐图层复制（非 AE 自带浅复制） |
| 图层复制优先 copyToComp | API 存在时走 `layer.copyToComp`（原生保真：变换/效果/蒙版/关键帧/表达式/标记），并自动探测插入位置（顶部/底部），必要时用 `moveAfter` 链修正层序 |
| 逐属性克隆回退路径 | copyToComp 不可用时：按图层类型分派创建（文本/形状/摄像机/灯光/空对象/调整层/AV 层），按 `matchName` 递归克隆属性树，效果/蒙版/形状运算符用 `canAddProperty` + `addProperty` 补建 |
| 属性维度处理 | 值整体 `setValue`（维度由值对象自带）；关键帧逐键 `setValueAtTime` + `setInterpolationTypeAtKey` + 时间缓动 + `setSpatialTangentsAtKey`（空间切线）+ roving/auto-bezier/continuous 各开关 |
| 表达式原样带过 | `expression` 字符串原样复制（含 Source Text 表达式），不重写 |
| source 重映射 | 复制完成后 `Layer.replaceSource` 把 AVLayer 的引用从原 comp/原素材重链接到新副本（`fixExpressions=true`） |
| 父级重链接 | 按 `parent.index` 找到新 comp 中对应图层重设 `layer.parent` |
| 文本层克隆 | `TextDocument` 逐字段克隆（字体/字号/填充描边/tracking/行距/基线偏移/段落对齐/文本框尺寸/仿粗斜体/大小写等，逐字段 try/catch 兼容版本差异）；文本关键帧逐键复制 |
| comp 属性复制 | 背景色/标签/注释/运动模糊开关/快门角度/快门相位/分辨率系数/工作区/渲染器 |
| 文件夹结构镜像 | 按 `parentFolder` 链递归重建（以 `item.id` 记忆去重，多个 comp 共享同一镜像文件夹）；可用复选框关闭 |
| 递增后缀唯一命名 | `原名 + 后缀`；重名时自动追加递增编号（`" n"`） |
| 排除列表 | UI 中点击切换排除标记；被排除的 comp 不复制也不递归，引用它的图层保持指向原 comp（共享） |
| footage 可选复制 | 复选框开启时对闭包内引用的 FootageItem（含 solids）执行 `Item.duplicate()`（共享同一源文件），同样镜像文件夹+后缀；关闭时全部共享原素材 |
| 层标记（Marker） | 逐个复制 MarkerValue（注释/时长/标签/章节/URL/提示点），尽力设置标记时间 |
| 图层开关与状态 | 混合模式/轨道遮罩类型/保留透明/运动模糊/音频开关/自动定向/3D 开关/环境层/引导层/独奏/隐藏/入出点/拉伸/开始时间/质量；locked 最后设置 |
| 多选批量复制 | 项目面板可多选根 comp，闭包自动去重合并 |
| UI | 计数预览（"将复制 N 个 comp"）/ 后缀输入 / footage 复选框 / 文件夹镜像复选框 / 排除列表 / 刷新选中 / 清除排除 |
| 安全性 | 整个操作包在 `app.beginUndoGroup/endUndoGroup`（一次撤销）；逐项 try/catch，单图层失败不中断整树，结束弹出警告汇总 |
| 设置记忆 | 后缀/复选框状态经 `app.settings` 持久化（失败静默降级） |
| ES3 兼容 | 无 let/const/箭头函数/模板字符串/JSON/ES5 数组方法；集合遍历用文档保证的 `numItems`/`item(i)`、`numLayers`/`layer(i)` |

### 未复刻（与原品的差距）

| 功能 | 状态 | 说明 |
|------|------|------|
| 正则搜索替换新名称 | 未复刻 | 原品支持按正则重命名副本；本复刻只有"原名+后缀" |
| 表达式内 comp("旧名") 重映射 | 未复刻 | 表达式原样带过；若表达式通过 `comp("Name")` 按名引用被改名的副本，将仍指向原 comp。规避法：后缀留空或表达式用 thisComp/index 引用 |
| 命名模板选项 | 未复刻 | 原品的编号/自定义模板等多种命名策略，本复刻只有单一后缀框 |
| 代理（Proxy）保留 | 未复刻 | 未复制 comp/图层代理设置 |
| Layer Styles 完整克隆 | 部分 | 仅回退路径下尽力而为（属性树通常不暴露图层样式） |
| 文本动画器（Animators）完整克隆 | 部分 | 仅回退路径下尽力添加；copyToComp 路径下由原生保真覆盖 |
| 颜色管理/深度等 comp 高级设置 | 未复刻 | 仅复制上文列出的 comp 属性 |

---

## 二、安装与使用

### 安装

两种方式任选：

1. **直接运行**：AE 菜单 `File > Scripts > Run Script File...`，选择 `main.jsx`。
2. **面板常驻**：把 `main.jsx` 复制到 AE 脚本目录
   - Windows: `C:\Program Files\Adobe\Adobe After Effects <版本>\Support Files\Scripts\ScriptUI Panels\`
   - macOS: `/Applications/Adobe After Effects <版本>/Scripts/ScriptUI Panels/`
   重启 AE 后在 `Window` 菜单底部出现（以对话框模式弹出，非停靠面板）。

> 无需勾选"允许脚本写入文件与访问网络"也能运行（仅用 app.settings 记忆偏好；
> 若未授权则偏好记忆静默失效，功能不受影响）。

### 使用步骤

1. 在**项目面板**选中 1 个或多个要复制的 Comp（根合成）。
2. 运行脚本；顶部实时显示"将复制 N 个 comp（含依赖闭包）"。
3. 需要排除某个子 comp 时，在列表中**点击对应条目**切换 `✓` 排除标记
   （被排除的 comp 及其子树共享原版，不被复制）。
4. 按需勾选"同时复制 footage 素材"（默认关闭=共享原素材）与"镜像原始文件夹结构"（默认开启）。
5. 修改"名称后缀"（默认 `" 2"`，与 AE 自带复制惯例一致；重名自动递增编号）。
6. 点 **创建副本**。完成后弹窗汇总（新建 comp 数/素材数/根副本名/警告），
   新根 comp 自动选中并设为活动项；一次 Ctrl+Z 可整体撤销。

### 文件清单

```
clones/true-comp-dup-clone/
├── main.jsx    # 复刻主体（单文件，UTF-8 带 BOM，ES3）
└── README.md   # 本文件
```

---

## 三、已知限制

1. **表达式按名引用的 comp 不重定向**：`comp("旧名")` 在副本中仍指向原 comp
   （见功能对照表）。这是"表达式原样带过"策略的直接结果。
2. **copyToComp 插入位置的版本差异**：不同 AE 版本可能把图层插到目标 comp 顶部
   或底部；脚本已做探测与层序修正。理论上两个完全同名的图层在探测时可能歧义
   （内容相同，仅轨道遮罩配对可能受影响）。
3. **时间缓动读取**：时间缓动按官方接口 `keyInTemporalEase` / `keyOutTemporalEase`
   读取并经 `setTemporalEaseAtKey` 回写；不支持时间缓动的属性类型会跳过该键的
   缓动（值/时间/插值类型/空间切线仍复制）。
4. **回退路径的保真度**：仅当 `copyToComp` 不存在（极老版本 AE）才启用逐属性
   克隆，此路径对文本动画器、图层样式等仅尽力而为；copyToComp 路径无此限制。
5. **调整层**：无 source 的调整层在回退路径下通过新建 solid 再置
   `adjustmentLayer` 实现，会在工程里多出一个白色 solid 素材项。
6. **排除的 comp 不递归**：排除某 comp 时其子树整体共享原版（与"排除"语义一致，
   但不支持"排除自身但继续复制其子树"）。
7. **同名图层探测边界**：闭包内出现完全同名的两个 comp 时，各自副本按复制时序
   递增编号（如 `X v2`、`X v2 2`），不会相互覆盖。
8. **代理、颜色管理、渲染器细节**、素材项的解释帧率等高级属性未复制。
9. **性能**：项目面板条目极多（数千项）时唯一命名与列表构建为 O(N·M) 线性扫描，
   会有可感知的等待；常规工程无感。

---

## 四、自查结果（编写期已完成）

| 检查项 | 结果 |
|--------|------|
| `node --check`（剥离 `#target` 行后） | 通过 |
| ES3 特征扫描（let/const/箭头/模板串/JSON/ES5 数组方法/空值合并/可选链/for-of） | 干净（仅文档注释中提及"无 let/const"字样） |
| 保留字作标识符扫描 | 干净 |
| 真尾逗号（对象/数组字面量末尾逗号） | 0 处 |
| 括号配平 | `{}` 445/445；圆括号计数差来自字符串/注释内全角括号内容，语法已由 node --check 验证 |
| 编码 | UTF-8 带 BOM（中文 Windows 下 ExtendScript 无 BOM 会按系统码页误读中文字符串） |

> 说明：本机无 After Effects，以上为静态自查；建议按"使用步骤"在 AE 中做一次
> 冒烟测试（嵌套两层的 comp + 文本层 + 形状层 + 效果 + 关键帧 + 表达式 + 层标记），
> 对照副本与原树的属性一致性。

---

## 五、冒烟测试建议（AE 中）

1. 建 `Inner`（内含文本层、形状层、带关键帧的纯色层）、`Mid`（引用 Inner + 带效果
   的调整层）、`Main`（引用 Mid，图层带父级与轨道遮罩，层上打标记，某属性写表达式）。
2. 选中 `Main` → 运行脚本 → 预览应显示"将复制 3 个 comp"。
3. 排除 `Inner` → 预览应降为 2 个 comp；创建后 `Mid` 副本中的 `Inner` 图层仍指向原 `Inner`。
4. 开启"同时复制 footage"→ 预览计数应包含 solid/素材数量。
5. 检查副本：层序、父级、轨道遮罩、标记时间、关键帧缓动曲线、表达式文本、
   文本内容与格式、文件夹归属是否与原树一致；Ctrl+Z 应能一次性整体撤销。
