---
generated_at: 2026-11-14T00:16:40Z
task: clean-room 复刻收费脚本（Add Sauce / Easify 二选一）——已选 Add Sauce，产出 main.jsx + README；功能输入为 intel/paid-list.md #20 条目；未反编译、未接触原代码
---

# SauceClone v1.0（Add Sauce 的 clean-room 复刻）

## 选题说明：为什么选 Add Sauce 而不是 Easify

| | Add Sauce ($9.99, Jacopist) | Easify 4 ($49, Leyero) |
|---|---|---|
| 条目描述 | "把一组调整层（或普通层）连同效果与全部属性保存为捆绑，一键套用到当前图层" —— 单一闭环功能 | "Animation Toolkit for Premiere & After Effects…Multi-clip timeline、Align panels、Speed Graph、multi-point curve、quick reveal transitions, and more!" |
| 宿主 | 仅 AE，纯 jsx 可达 | AE+PR 双宿主：PR 侧面板 jsx 根本无法实现 |
| 粒度 | 功能明确可对齐 | 描述粗（"and more!"），无法逐条对齐验收 |

结论：Add Sauce 功能小而完整、验收口径清晰，更适合 clean-room 单文件复刻。Easify 的 PR 宿主部分超出 jsx 能力，AE 侧仅为模糊的大杂烩工具集，未选。

## Clean-room 声明

仅依据上述公开功能描述从零实现；未反编译/读取/复制/翻译任何原产品代码。所有 AE API 按 `docs/api-cheatsheet.md` 白名单书写；白名单未收录 API 全部包 try/catch 并带回退。

## 功能对照（条目写了什么就复刻什么）

条目原句拆成四个能力点，全部实现：

1. **保存一组图层**（调整层或普通层）：SAVE = 把当前选中图层按时间线自上而下顺序捕获为捆绑（多选即多图层捆）。捕获内容：
   - 图层名、**调整层开关**、图层混合模式、纯色层源颜色（尽力读取，取不到回退白色）；
   - **全部效果**：按顺序逐效果捕获（效果名、matchName、启用开关）；
   - **效果的全部可设属性**：递归遍历效果参数组，按 `PropertyValueType` 分类序列化（数值/布尔/2D/3D/颜色），并捕获属性表达式（CEXP 行）；
   - 刻意跳过：NO_VALUE/MARKER/SHAPE/TEXT_DOCUMENT/CUSTOM_VALUE 类型参数、elided 参数、`ADBE Effect Built In Params` 组、相机/灯图层（不可挂效果，保存时提示跳过）。
2. **一键套用**：APPLY = 选中 1 个目标图层，把捆里的每一层在目标图层**上方按原上下顺序**重建（统一重建为纯色层，调整层恢复 adjustment 开关；moveBefore 保证层序），并逐效果 `addProperty(matchName)` + 按属性路径逐参数 `setValue` + 回写表达式。单次 undo 组。
3. **捆绑持久化**：存到 `<系统 userData>/SauceClones/*.sauce`（自研行式格式 SAUCE1：CLAYER/CEFF/CPROP/CEXP 四类行 + 转义规则，支持中文层名/多行表达式，UTF-8）。面板内列表选择 + REFRESH + DELETE。
4. **往返健壮性**：效果缺失/更名（不同 AE 版本 matchName 变化）、参数导航失败、只读参数、表达式写入失败等全部逐条收集为 warning（最多展示 12 条），不中断整批。

## UI

- 名称输入 + SAVE（捕获选中层）
- 捆绑列表（选中后 APPLY / DELETE）
- 状态栏 + 错误 alert
- 安装：拷入 AE `ScriptUI Panels` 目录后从 Window 菜单打开，或 File > Scripts > Run Script File 直接跑。

## 格式说明（SAUCE1 行式）

```
SAUCE1
CLAYER|<层名转义>|adj(0/1)|blendMode|colorR,G,B
CEFF|<效果名转义>|<matchName>|enabled(0/1)
CPROP|<matchName路径按/连接>|<tag n/b/a>|<数值或逗号数组>
CEXP|<matchName路径>|<表达式转义>
```
转义：`\|→\p`、换行→`\n`、回车→`\r`、`\→\\`（扫描式反转义，避免歧义）。路径段全用 matchName（稳定标识符，不含 `/`），属性导航用逐层 matchName 匹配（`PropertyGroup.property()` 官方只认显示名，不认 matchName，故自写 findByMatch）。

## 未复刻清单（超出 jsx 能力或条目未定义的部分）

1. 非 solid 源类型的图层（文本/形状/素材层）重建时统一变成纯色层——"重建任意源图层"超出序列化范畴；
2. 图层样式、蒙版、图层变换关键帧/表达式、图层标记不采集（条目聚焦"效果与属性"）；
3. TEXT_DOCUMENT（源文本）/CUSTOM_VALUE/MARKER/SHAPE 类型的效果参数不可移植，跳过；
4. 拖拽排序、预设市场、图标美化的 UI 细节；
5. 原版具体交互细节（官方页仅一句话简介，交互按本文件定义的口径实现）；
6. 跨 AE 版本 matchName 变更导致的效果缺失只能报 warning，不做映射表。

## API 合规（对照 docs/api-cheatsheet.md）

- 集合遍历全部 1-based + numProperties / numXxx；selectedLayers 用 0-based length 并显式按 `layer.index` 排序（cheatsheet：选中顺序无文档保证）。
- 枚举按表拼写：`PropertyValueType.NO_VALUE / MARKER / SHAPE / TEXT_DOCUMENT / CUSTOM_VALUE`（全大写）。
- 删除文件用 File.remove（ExtendScript 核心 IO，非 AE 对象模型）；AE 对象修改仅在 APPLY 中发生且包 undo 组。
- 白名单未收录、已按政策包 try/catch 的 API：`layer.source.mainSource.color`、`Property.elided`、`Property.canSetValue`（未用到）、`PropertyGroup.property()` 按 matchName 遍历比对、`File/Folder` IO（ExtendScript 核心）。
- `addProperty(matchName)`、`setValue/setValueAtTime`、`expression`、`numProperties`、`matchName` 等均为白名单核心项。

## 自查结果（2026-11-14）

- `node --check`（经 .js 副本，.jsx 后缀 node 拒绝直查）：**通过**。
- ES3 扫描（箭头/let/const/模板串/JSON./Object.keys/数组方法链/for..of/Set/Map/可选链等 30+ 模式）：**0 命中**。
- 数组尾逗号扫描：0 命中；无 BOM。
- AE 实机冒烟：**未做**（本环境无 AE）。首跑请验证：SAVE 捕获含表达式/颜色控制/下拉菜单的效果栈 → APPLY 重建 → 参数与表达式逐一核对。
