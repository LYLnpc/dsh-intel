# Scribe Clone

面板里选一款单线字型、输入文字、按一下 → 在当前合成里生成逐笔写入的描边动画（write-on / write-off）。

- 版本：1.0.0｜文件：`main.jsx`（单文件，字形数据内嵌）｜类型：ScriptUI 面板
- 对应原商品：Scribe / Scribe 2（$30，renderTom + compCode）

> **Clean-room 声明**：机制部分仅依据公开的商品一句话描述（"Automated typeface library for quick write-on/off effect"）与 Lesterbanks 首发评测的功能描述独立实现，未获取或参考原脚本的任何源码、安装包或资源。
>
> **字型资产声明（重要）**：原版自带 6 套单线字型（Bacana、Barcelona Script、Diamor Script、Everlasting、I Love Glitter、Learning Curve）属**版权资产**，本复刻**不含、不复用、不分发**。字形数据改用**公有领域的 Hershey 单线字体**（Dr. A. V. Hershey / 美国国家标准局，1970 年代起进公有领域），取自 `techninja/hersheytextjs` 的公开数据。**行为等价，字形不同。**

---

## 一、功能对照

| 原版行为 | 本复刻 |
|---|---|
| 选字型 + 输文字 + 字号 → 一键生成 | ✅ 5 款 Hershey 字型可选 |
| 生成结果是形状层（非文本层） | ✅ 每个字符一个形状层 |
| 每个字母一个 group、逐笔 path | ✅ 组内每条笔画一条 path |
| 逐字顺序书写（write-on） | ✅ 逐层、逐字时间偏移 |
| 反向 = 擦除（write-off） | ✅ Write off / On then off 两种 |
| Thickness 改笔画粗细 | ✅ 面板生成时设定（重生成生效） |
| Color 改颜色 | ✅ hex 输入 |
| 通过 effect 滑杆实时拖书写进度 | ❌ 本件走关键帧驱动（见限制 3） |
| 6 套自带字型 | ❌ 用 Hershey 公有领域字形替代 |
| 生成后改字 | ❌ 与原件一致，**不能改**（见限制 2） |
| 中日韩字符 | ❌ 与原件一致，**不支持** |

## 二、字型与字符集

内置 5 款 Hershey 公版单线字：

| 下拉名 | 内部键 | 风格 |
|---|---|---|
| Hershey Sans 1 (plain) | futural | 等宽单线无衬线，最清晰 |
| Hershey Sans 2 (medium) | futuram | 稍粗的单线无衬线 |
| Hershey Script 1 (handwriting) | scripts | 手写斜体，最像书写 |
| Hershey Script 2 (bold hand) | scriptc | 加粗手写 |
| Hershey Roman (serif) | timesr | 衬线单线 |

**字符集：ASCII 33–126**（英文大小写、数字、常用标点）。空格只推进光标不产生几何。
**不支持中文/日文/韩文**——Hershey 是拉丁字形，没有 CJK 字形，也没有可用的公有领域中文单线字库。输入 CJK 时脚本会跳过并在状态栏列出被跳过的字符；若整段文字一个可写字符都没有，直接报错不发空层。

## 三、使用方式

1. 打开合成（面板读取当前合成）；
2. `File > Scripts > Run Script File...` 选 `main.jsx`（或放 `Scripts/ScriptUI Panels/` 常驻）；
3. 选字型 → 输入文字 → 调字号/字距/行距/描边 → 点 `Write text`；
4. 合成里出现一批以字符命名的形状层，播放即可看到逐字书写；
5. 一步 `Ctrl+Z` 整体回退。

## 四、参数

| 参数 | 默认 | 说明 |
|---|---|---|
| Typeface | Sans 1 | 5 款 Hershey |
| Text | `Hello 2026` | 多行支持（`\n` 分行，自动按行居中） |
| Font size | 100 | 像素；按 Hershey 设计单位 21（字高）缩放 |
| Tracking % | 15 | 字距 = 字形宽度 × 该百分比 |
| Line height % | 120 | 行距 = 字号 × 该百分比 |
| Stroke | 6 | 描边宽度（圆头端点、圆角连接） |
| Colour (hex) | FFFFFF | 6 位或 3 位 hex，`#` 可省 |
| Delay per glyph | 2 帧 | 相邻字符的起始间隔 |
| Stroke time per glyph | 6 帧 | 单个字符从 0 到 100 写完的时长 |
| Write on / Write off / On then off | Write on | 写入 / 直接反写 / 写完再擦掉 |

动画总长 = `(字数-1) × delay + 单字时长`（On then off 再 ×2）。超过合成时长时状态栏给警告，但不会改合成时长。

## 五、实现要点

1. **字形数据**：21KB 紧凑字符串，`#` 分字符、`|` 分笔画、每个坐标 1 个字符（`charCode - 57`）。5 款字型共 9743 个点全内嵌，无外部文件依赖。
2. **排版**：基线统一（Hershey 基线 y≈21 设计单位），逐字累加 `字宽 × (1 + tracking%)`，整行按总宽居中；多行按行距上下排开。
3. **层结构**：每字符一个形状层，层内一个 `ADBE Vector Group`：多条 `ADBE Vector Shape - Group`（每笔一条）+ `ADBE Vector Filter - Trim` + `ADBE Vector Graphic - Stroke`。
4. **Trim 必须在 Stroke 之前**（AE 形状列表从上到下求值）——本件按「path → trim → stroke」的添加顺序保证这一点，否则 trim 会作用在已描边结果上、肉眼无效。
5. **动画**：`Trim End` 两键 0→100，BEZIER + `KeyframeEase(0, 66.67)`；逐字按 `层序号 × delay` 错开。Write off 反向 100→0；On then off 再给 `Trim Start` 补 0→100 的线性键。
6. **层序即书写顺序**：用户拖动层顺序即可改书写顺序（这也是原版宣称的可重排能力的等价做法，本件按层实现）。
7. 偏好记忆：字体与字号写入 `app.settings` 的 `ScribeClone` 段（`haveSetting` + `getSetting` 两段式读取）。

## 六、白名单外 API 声明 ⚠️

| API | 用途 | 替代做法 |
|---|---|---|
| `new Shape()` + `Shape.vertices/inTangents/outTangents/closed` | 构造贝塞尔/折线路径 | 没有替代：形状层的路径只能通过 Shape 对象写入 |
| `Layer.property(matchName)` | 取图层内的形状组 / 变换组 | 可改为 `property(i)` 逐项遍历 + `matchName` 比对，但同样依赖 `matchName` |
| `PropertyBase.matchName` | 识别形状组/描边/填充 | 用本地化后的 `name` 匹配，中文版 AE 会失配，不可接受 |
| `group.addProperty("ADBE Vector ...")` | 添加矢量组/trim/stroke | 白名单只列了通用 `addProperty`，具体 matchName 为官方指南收录 |
| `Property.setValueAtTime` / `setInterpolationTypeAtKey` / `setTemporalEaseAtKey` | 打 trim 关键帧 | `setValueAtTime` 在白名单内；另两个是让书写有加减速的必需项（不用就只能得到线性匀速书写） |

全部为官方 After Effects Scripting Guide 收录 API，使用处均包 try/catch（线帽/线连接失败时降级为默认值）。

## 七、能力限制（诚实说明）

1. **只支持 ASCII**。中文/日文/韩文/emoji 无法生成；CJK 会走"跳过 + 提示"，不会静默出空白层。需要中文描边请用「文字 → 从文本创建形状」后手动做 Trim。
2. **生成后不能改字**。产出是形状层，改文字只能重新生成；原层的描边/关键帧不会自动迁移。
3. **没有 Effect Controls 滑杆**。原版把书写进度做在效果面板上可实时拖动；本件用关键帧驱动，改进度需要改关键帧或重新生成。这是我做的取舍：滑杆版需要给每个 group 写引用滑杆的表达式，在长文本上会让表达式计算量随 group 数线性上升，且拖动时 AE 要重算整棵树。
4. **描边宽度/颜色只在生成时生效**，生成后改面板不会联动（要重生成）。原版 v2 的 Color/Thickness 能在效果面板改，本件没有做那层绑定。
5. **闭合字形有接缝**：`o`、`e`、`a` 等闭合路径的 trim 从起点绕回，收笔处可见接缝。原版靠人工拆分笔画掩盖，Hershey 数据本身就是单线连续路径，无法拆分。
6. **字形质感取决于字库**：Hershey 是工程单线字，不是手写美术字；观感比原版 6 套手写体"硬"很多。这是用公版字体换合规性的必然代价。
7. **笔画粗细过大会糊**：单线字最大安全粗细约等于字形最小间隙（Hershey 设计单位约 2–3，即字号 100 时约 10–14px），超过会自交。
8. **长文本性能**：每字符一个层 + 每笔一条路径，60 字符以上会出现明显层数堆积（面板直接限制 60 字符，要求拆分）。
9. **不支持多行自动换行**：需要手动 `\n` 断行，没有宽度约束。
10. **没有做字距微调（kerning）**：只有全局 tracking 百分比；Hershey 原始数据没有 kerning 对。
11. **中文版 AE 兼容性未实测**：脚本本身 ASCII-only、UI 英文，理论上不受本地化影响，但没有在中文版 AE 上冒烟过。

## 八、API 使用核对

白名单内：`app.project`、`CompItem`（`frameDuration`/`width`/`height`/`duration`/`layers`/`activeItem`）、`Layer.name`/`comment`/`property`、`Property.value`/`numKeys`/`setValue`/`setValueAtTime`/`removeKey`（未用删键）、`KeyframeEase`、`KeyframeInterpolationType`、`app.beginUndoGroup`/`endUndoGroup`、`app.settings`（`haveSetting`/`getSetting`/`saveSetting`）、ScriptUI 全套。
白名单外：见第六节。

## 九、验收清单（对 spec 第 7 节）

1. 输入 `Hello 2026` → 生成 10 个字符层（空格跳过、`2/0/2/6` 各一层），居中排布、字距一致。✅ 代码路径：`layoutText` → 每字符 `addShape()`。
2. 播放时逐字"写入"，每字写完保留（End 到 100 不再动）。✅ `keyTrim` 只对 End 打两键。
3. 改描边颜色/粗细后重新生成，全部字符生效。✅ 颜色/宽度在 `styleStroke` 统一写入。
4. 改「每字延迟」后总时长按 `n × delay + dur` 变化，状态栏显示帧数与秒数。✅
5. 空输入 → 提示 `Type something first.`；全空格 → `Nothing to write`。✅
6. 中文输入 → 不静默出空层：可写字符为 0 时报错，部分不可写时列出被跳过字符。✅
7. README 写明"不含原版字型、用 Hershey 公有领域字型、仅拉丁字符"。✅ 本文档第 2 节与顶部声明。

附加：撤销一次可完整回退（生成的所有层）；字型下拉 5 项都能生成；`Reset defaults` 恢复默认值。

## 十、文件

```
clones/scribe-clone/
├─ main.jsx   # 脚本本体（含 21KB 内嵌字形数据）
└─ README.md
```

静态检查：`node --check`（剥 `#target` 后）退出码 0；ES3 构造扫描零命中；源码纯 ASCII、无 BOM；字形表 5 字体 × 95 字符，坐标范围 -8..34（编码域 -9..40 内）。
